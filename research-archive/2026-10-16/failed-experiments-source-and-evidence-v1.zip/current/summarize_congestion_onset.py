"""Independent onset-label audit, saved-model reconstruction, and full report."""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import numpy as np
import torch

from recovery_pilot import ROOT,write_json
from multifault_pilot import sha256
from audit_congestion_pilot import compare
from congestion_alert_pilot import SCENARIOS,labels
from congestion_risk_pilot import pool,choose,hidden_features_check
from congestion_ablation import OLD,SEEDS,load_data,load_parts,load_model
from summarize_congestion_risk import check_validation
from congestion_onset_pilot import (OUTPUT,PARTITIONS,OBJECTIVES,OLD_METHODS,NEW_METHODS,METHODS,
    make_targets,onset_targets,supervised_data,new_scores,old_scores,reference_method,evaluate,comparisons)

NAMES={'dense_speed':'密集速度规则','global_calibration':'全局校准','group_calibration':'缺测分组校准',
       'state_logistic':'原状态线性','risk_mlp':'原持续低速MLP',
       'common_persistent_linear':'共同样本持续低速线性','common_persistent_mlp':'共同样本持续低速MLP',
       'onset_linear':'事件起点线性','onset_mlp':'事件起点MLP'}


def independent_targets(data,origins,start,end):
    raw,_,valid,ts,*_=data
    low=raw<=30
    persistent=low[:-2]&low[1:-1]&low[2:]
    transitions=np.zeros(raw.shape,bool)
    transitions[1:-2]=persistent[1:]&~persistent[:-1]
    target=np.stack([transitions[origins+i] for i in range(3)]).any(axis=0)
    known=np.ones(target.shape,bool)
    for offset in range(-1,5):
        ids=origins+offset; inside=(ids>=start)&(ids<end)
        chosen=np.clip(ids,0,len(raw)-1)
        known &= (valid[chosen]>0)&inside[:,None]
    regular=np.ones(len(origins),bool)
    for offset in range(-12,4):
        a,b=origins+offset,origins+offset+1
        inside=(a>=start)&(b<end)
        regular &= inside & (ts[np.clip(b,0,len(ts)-1)]-ts[np.clip(a,0,len(ts)-1)]==np.timedelta64(5,'m'))
    known &= regular[:,None]
    return target&known,known


def mean(rows,field):
    values=[rows[s][field] for s in SCENARIOS if rows[s][field] is not None]
    return float(np.mean(values)) if values else float('nan')


def report(result,logs,output):
    ref=result['reference']; rows=result['evaluation']; budgets=result['selection']['budgets']
    lines=['# 事件起点监督：提前预警增加，检测与误报代价仍存在', '',
           '日期：2026-10-10。8份新权重、9组方法。全部日期曾使用，本轮是探索；原告警标签、匹配、覆盖和计分没有改变。', '',
           f'校准选定的最强简单参考仍是**{NAMES[ref]}**。新起点MLP是预定候选，共同样本持续低速MLP用于隔离目标变化。', '',
           '## 预定主要比较', '',
           '| 对照 | 指标 | 起点MLP−对照 | 95%日期探索区间 | 97.5%日期探索区间 |',
           '| --- | --- | ---: | --- | --- |']
    for key in ('onset_mlp-common_persistent_mlp','onset_mlp-calibration_reference'):
        c=result['comparisons'][key]
        for field,label,factor in [('warning_recall','预警召回（百分点）',100),('detection_recall','含迟报检测（百分点）',100),('false_rate','误报/有效站日',1)]:
            interval=lambda suffix: '['+', '.join(f'{v*factor:.3f}' for v in c[field+suffix])+']'
            lines.append(f'| {NAMES[c["baseline"]]} | {label} | {c[field+"_difference"]*factor:+.3f} | {interval("_ci95")} | {interval("_ci975")} |')
    lines += ['',
              '三情景等权平均。97.5%仅是同一指标两项比较的保守描述，不控制三个指标合计六项检验或历史反复分析的整体错误率。区间条件于当前三种子集成，不含重训练随机性，也不能当独立验证。', '',
              '## 全部9组运行点', '',
              '| 方法 | 阈值/确认 | 校准预警召回 | 评测预警召回 | 评测检测召回 | 误报/有效站日 | 成功预警平均提前分钟 |',
              '| --- | --- | ---: | ---: | ---: | ---: | ---: |']
    for method in METHODS:
        op=result['selection']['methods'][method]['selected']
        threshold=-op['threshold'] if method=='dense_speed' else op['threshold']
        calibration=np.mean([op['by_scenario'][s]['warning_recall'] for s in SCENARIOS])
        r=rows[method]
        lines.append(f'| {NAMES[method]} | {threshold:g}/{op["confirmation"]} | {calibration*100:.2f}% | {mean(r,"warning_recall")*100:.2f}% | {mean(r,"detection_recall")*100:.2f}% | {mean(r,"false_per_valid_station_day"):.3f} | {mean(r,"warning_lead_mean_minutes"):.2f} |')
    c=rows['common_persistent_mlp']; o=rows['onset_mlp']
    lines += ['',
              f'目标改变后的预警召回{mean(c,"warning_recall")*100:.2f}%→{mean(o,"warning_recall")*100:.2f}%，但检测召回{mean(c,"detection_recall")*100:.2f}%→{mean(o,"detection_recall")*100:.2f}%、误报{mean(c,"false_per_valid_station_day"):.3f}→{mean(o,"false_per_valid_station_day"):.3f}。它是明确的预警与检测取舍，不能概括为整体告警改善。', '',
              f'成功预警平均提前量{mean(c,"warning_lead_mean_minutes"):.2f}→{mean(o,"warning_lead_mean_minutes"):.2f}分钟；不同方法成功事件子集不同，不能把差值当同事件因果效应，更不能称“预警更早”。', '',
              '起点线性也单列，MLP相对线性的全部描述区间保存在results.json。它们采用各自校准运行点；不能只看召回、不看误报差来断言MLP必需。', '',
              '## 新目标、共同样本与缺失有效性', '',
              '旧目标Y(t)是当前起点开始三步持续低速；新目标Z(t)是未来三个起点位置内是否出现Y从0到1的转移。新确认读数为t−1到t+4，未来真实读数只用于离线标签，不进风险特征。它不依赖该事件何时结束。', '',
              '对两新目标使用完全相同的六读数有效性和连续时间/分区边界；未知未来不当阴性。在线告警在全部原起点计算，不能用共同监督有效性关闭告警。', '',
              '| 分区 | 原有效唯一点 | 共同有效唯一点 | 原有效点保留率 | 旧目标阳性 | 新目标阳性 | 旧阳性改阴性 | 旧阴性改阳性 |',
              '| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
    for partition,t in result['target_summary'].items():
        lines.append(f'| {partition} | {t["unique_original_valid_points"]} | {t["unique_common_valid_points"]} | {t["common_fraction_of_original_valid"]*100:.2f}% | {t["unique_persistent_positive_points"]} | {t["unique_onset_positive_points"]} | {t["persistent_only_positive"]} | {t["onset_only_positive"]} |')
    lines += ['',
              '三情景共享真实目标，上表为唯一时间-站点；训练总池183105、验证139545样本。原训练抽样仍每15分钟。两目标均用原训练统计量和相同51维输入，除了标签之外共同样本对照的学习流程相同；各自验证BCE选轮数，所选轮数可能不同。', '',
              '各方法事件评测覆盖保持原167500有效点、581.597有效站日、1089完整事件及73删失事件。新目标辅助点分数只在165266共同有效点统计；这个子集不能替换原事件评价分母。', '',
              '## 新模型验证选择', '',
              '| 目标/模型 | 种子或正则化 | 选轮数 | 对应标签验证BCE |',
              '| --- | --- | ---: | ---: |']
    for key,records in logs.items():
        if key.endswith('linear'):
            lines.append(f'| {NAMES[key]} | alpha={records["selected_alpha"]:g} | LBFGS | {records["validation_bce"]:.6f} |')
        else:
            for r in records:
                lines.append(f'| {NAMES[key]} | seed={r["seed"]} | {r["selected_epoch"]} | {r["validation_bce"]:.6f} |')
    lines += ['', '对应标签不同，验证BCE不用于跨目标选择一个胜出模型。', '',
              '## 分情景完整事件指标及预算', '',
              '| 方法 | 情景 | 预警% | 检测% | 漏检 | 误报/有效站日 | 校准经验预算 | 评测超预算 | 提前分钟 | 迟报 | 重复 | 未知 | 删失告警 |',
              '| --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: |']
    exceed=[]
    for method in METHODS:
        for s in SCENARIOS:
            r=rows[method][s]; exceeded=r['false_per_valid_station_day']>budgets[s]
            if exceeded: exceed.append(f'{NAMES[method]}/{s}')
            lead='无' if r['warning_lead_mean_minutes'] is None else f'{r["warning_lead_mean_minutes"]:.2f}'
            lines.append(f'| {NAMES[method]} | {s} | {r["warning_recall"]*100:.2f} | {r["detection_recall"]*100:.2f} | {r["missed_events"]} | {r["false_per_valid_station_day"]:.3f} | {budgets[s]:.3f} | {"是" if exceeded else "否"} | {lead} | {r["late"]:g} | {r["duplicate"]:g} | {r["unknown_alerts"]:g} | {r["censored_alerts"]:g} |')
    lines += ['', '评测超过经验预算的组合：'+('；'.join(exceed) if exceed else '无')+'。预算只在校准段约束，不是线上误报保证。', '',
              '## 辅助逐点与概率分数', '',
              '| 方法 | 情景 | 旧低速点召回% | 新起点点召回% | 新起点点精确率% | 新标签Brier | 新标签BCE |',
              '| --- | --- | ---: | ---: | ---: | ---: | ---: |']
    for method in METHODS:
        for s in SCENARIOS:
            r=rows[method][s]; q=r['onset_auxiliary']; p=q['point']
            scoretext=lambda k: '—' if k not in q else f'{q[k]:.5f}'
            lines.append(f'| {NAMES[method]} | {s} | {r["point_all"]["recall"]*100:.2f} | {p["recall"]*100:.2f} | {p["precision"]*100:.2f} | {scoretext("brier")} | {scoretext("bce")} |')
    lines += ['',
              '原模型输出持续低速风险，新模型输出起点风险，概率语义不同；上表新标签Brier/BCE是目标对齐诊断，不证明它们原任务校准质量优劣。逐点指标也不是事件预警指标。完整原标签概率、故障/其他站逐点指标和点计数均保留在results.json。', '',
              '## 审核与下一步', '',
              '通过独立Y转移法重算新目标及六读数有效性；核查未知、分区、共同样本、标准化、模型验证选择、两线性目标/梯度、隐藏及未来输入不变性。保存权重重建全部新概率；旧概率不变；所有校准网格、参考、事件/逐点/日级统计和日期区间复算一致。', '',
              '不按评测修改阈值、标签或计分，不宣称独立验证、实际控制收益或算法原创性。下一步先检查提前5/10/15分钟分布和迟报/漏检变化，再设计如何兼顾起点通知与持续状态的候选。5分钟训练抽样可作为单独因素检验，不与其他改法一起调优寻找正结果。']
    (output/'report.zh-CN.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    plot(result,output)


def plot(result,output):
    os.environ.setdefault('MPLBACKEND','Agg')
    import matplotlib.pyplot as plt
    labels_=['Speed rule','Global cal.','Group cal.','Original linear','Original MLP',
             'Common BCE linear','Common BCE MLP','Onset linear','Onset MLP']
    colors=['#b9bdc4']*5+['#668eaa','#668eaa','#b57556','#b57556']
    fig,axes=plt.subplots(1,3,figsize=(13,6.1),sharey=True)
    for ax,field,title,factor in zip(axes,['warning_recall','detection_recall','false_per_valid_station_day'],
        ['Advance warning recall (%)','Detection, including late (%)','False alerts / valid station-day'],[100,100,1]):
        values=[mean(result['evaluation'][m],field)*factor for m in METHODS]
        ax.barh(np.arange(len(METHODS)),values,color=colors,height=.7)
        ax.set_title(title,fontsize=10); ax.set_axisbelow(True); ax.grid(axis='x',alpha=.2)
        ax.set_xlim(0,max(values)*1.18)
        for i,v in enumerate(values): ax.text(v+max(values)*.015,i,f'{v:.1f}' if factor==100 else f'{v:.3f}',va='center',fontsize=8)
    axes[0].set_yticks(np.arange(len(METHODS)),labels_); axes[0].invert_yaxis()
    fig.suptitle('Onset supervision: same samples, inputs and unchanged event scoring',fontsize=12)
    fig.text(.52,.015,'Calibrated settings; previously analyzed dates; warning gains involve detection and false-alert costs.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.045,1,.945))
    fig.savefig(output/'summary.png',dpi=170); fig.savefig(output/'summary.svg'); plt.close(fig)


def main():
    parser=argparse.ArgumentParser(description=__doc__); parser.add_argument('--output',type=Path,default=OUTPUT)
    output=parser.parse_args().output; torch.set_num_threads(1); torch.use_deterministic_algorithms(True)
    result=json.loads((output/'results.json').read_text(encoding='utf-8'))
    config=json.loads((output/'config.json').read_text(encoding='utf-8'))
    compare(config,result['config']); audit=json.loads((output/'audit.json').read_text(encoding='utf-8'))
    assert all(sha256(ROOT/k)==v for k,v in config['sha256'].items())
    assert all(sha256(output/k)==v for k,v in audit['artifact_sha256'].items())
    data=load_data(); parts,names=load_parts(data); targets,target_summary=make_targets(parts,data)
    compare(target_summary,result['target_summary']); compare(names,json.loads((output/'features.json').read_text(encoding='utf-8')))
    day=data[8]
    for partition,a,b,stride in PARTITIONS:
        p=parts[partition]['natural']; start,end=int(np.searchsorted(day,a)),int(np.searchsorted(day,b))
        assert np.array_equal(p['origins'],np.arange(start+12,end-2,stride))
        t,m=independent_targets(data,p['origins'],start,end)
        assert np.array_equal(t,targets[partition]['truth']) and np.array_equal(m,targets[partition]['eligible'])
        with np.load(output/f'targets_{partition}.npz') as saved:
            assert all(np.array_equal(v,saved[k]) for k,v in targets[partition].items())
        assert not t[~m].any() and not (m & ~p['eligible']).any()
        for s in SCENARIOS:
            assert np.array_equal(parts[partition][s]['eligible'],p['eligible'])
            assert np.array_equal(parts[partition][s]['truth'],p['truth'])
        counts=target_summary[partition]
        assert sum(counts[k] for k in ('both_positive','persistent_only_positive','onset_only_positive','both_negative'))==int(m.sum())
        modified=list(data); modified[0]=np.where(data[2]>0,data[0],1e6)
        changed,known=onset_targets(tuple(modified),p['origins'],start,end)
        assert np.array_equal(changed,t) and np.array_equal(known,m)
        modified[0]=data[0].copy(); modified[0][end:]=-1e6
        changed,known=onset_targets(tuple(modified),p['origins'],start,end)
        assert np.array_equal(changed,t) and np.array_equal(known,m)
        hidden_features_check(parts[partition],data)
    with np.load(output/'normalization.npz') as n: mean,std=n['mean'],n['std']
    original_train=pool(parts['training'],'state'); checked_std=original_train.std(axis=0); checked_std[checked_std<1e-5]=1
    assert np.array_equal(original_train.mean(axis=0),mean) and np.array_equal(checked_std,std)
    assert sha256(output/'normalization.npz')==sha256(OLD/'normalization.npz')
    x,y=supervised_data(parts['training'],targets['training'],mean,std)
    xv,yv=supervised_data(parts['validation'],targets['validation'],mean,std)
    assert len(y['onset'])==len(y['common_persistent'])==len(x)
    logs=json.loads((output/'model_selection.json').read_text(encoding='utf-8'))
    fitted={}; gradients={}
    for objective in OBJECTIVES:
        key=f'{objective}_linear'; model,saved=load_model(output/f'{key}.pt')
        check_validation(model,saved,xv,yv[objective]); compare({k:v for k,v in saved.items() if k!='state_dict'},logs[key])
        model.zero_grad(set_to_none=True)
        value=torch.nn.functional.binary_cross_entropy_with_logits(model(torch.tensor(x)),torch.tensor(y[objective]))+saved['selected_alpha']/2*model.layers.weight.square().sum()
        value.backward(); gradient=max(p.grad.abs().max().item() for p in model.parameters())
        selected=next(r for r in saved['logs'] if r['alpha']==saved['selected_alpha'])
        assert np.isclose(value.detach().item(),selected['train_objective'],rtol=1e-6,atol=1e-7) and gradient<=1e-4
        gradients[key]=gradient; fitted[key]=[model]
        key=f'{objective}_mlp'; fitted[key]=[]
        for seed in SEEDS:
            model,saved=load_model(output/f'{key}_{seed}.pt')
            assert saved['dimension']==51 and saved['nonlinear'] and saved['seed']==seed
            check_validation(model,saved,xv,yv[objective])
            compare({k:v for k,v in saved.items() if k!='state_dict'},next(r for r in logs[key] if r['seed']==seed))
            fitted[key].append(model)
    old=json.loads((OLD/'results.json').read_text(encoding='utf-8')); maxerror=0.; daily=None
    compare(result['selection']['budgets'],old['selection']['budgets'])
    for partition in ('calibration','evaluation'):
        rebuilt=old_scores(partition); rebuilt.update(new_scores(parts[partition],fitted,mean,std))
        with np.load(output/f'scores_{partition}.npz') as saved:
            assert len(saved.files)==len(METHODS)*len(SCENARIOS)
            for method,by_s in rebuilt.items():
                for s,p in by_s.items():
                    error=float(np.max(np.abs(p-saved[f'{method}_{s}']))); maxerror=max(maxerror,error); assert error==0.
        if partition=='calibration':
            selections={m:choose(m,rebuilt[m],parts[partition],result['selection']['budgets']) for m in METHODS}
            compare(selections,result['selection']['methods'])
            for m in OLD_METHODS: compare(selections[m],old['selection']['methods'][m])
            assert reference_method(selections)==result['reference']
            compare(result['selection'],json.loads((output/'selection.json').read_text(encoding='utf-8')))
        else:
            rows,daily=evaluate(rebuilt,parts[partition],targets[partition],selections)
            compare(rows,result['evaluation'])
            for method in OLD_METHODS:
                for s in SCENARIOS:
                    original={k:v for k,v in old['evaluation'][method][s].items() if k not in ('brier','bce')}
                    compare({k:rows[method][s][k] for k in original},original)
    with np.load(output/'daily_metrics.npz') as saved:
        assert set(saved.files)==set(daily) and all(np.array_equal(v,saved[k]) for k,v in daily.items())
    compare(comparisons(daily,result['reference']),result['comparisons'])
    audit.update({'audit_status':'passed','audit_script_sha256':sha256(Path(__file__)),
                  'independent_Y_transition_targets_and_six_reading_validity_checked':True,
                  'unknown_and_outside_partition_values_do_not_change_known_targets':True,
                  'common_training_samples_and_original_normalization_verified':True,
                  'all_8_weights_validation_choices_and_losses_recomputed':True,
                  'linear_objectives_gradients_recomputed':gradients,
                  'all_new_probabilities_rebuilt_from_weights':True,'maximum_probability_rebuild_error':maxerror,
                  'all_old_probabilities_operating_points_and_event_metrics_unchanged':True,
                  'all_calibration_grids_reference_event_point_daily_statistics_intervals_recomputed':True,
                  'hidden_future_feature_invariance_all_partitions':True})
    write_json(output/'audit.json',audit); report(result,logs,output)
    print(json.dumps({'audit':'passed','probability_error':maxerror,'reference':result['reference'],
                      'new_linear_gradients':gradients,
                      'onset_mlp_evaluation':{s:{k:v for k,v in row.items() if k in ('warning_recall','detection_recall','false_per_valid_station_day','warning_lead_mean_minutes')} for s,row in result['evaluation']['onset_mlp'].items()},
                      'report':str(output/'report.zh-CN.md')},indent=2))


if __name__=='__main__': main()
