"""Frozen-policy causal-context diagnosis; no model/cutoff or policy selection."""
from datetime import datetime, timezone
from pathlib import Path
import sys
import numpy as np
import torch
import calibration_fragility as common
import alarm_start_separability as probe
import early_warning_protection as protection
import effective_alert_pilot as previous
from congestion_alert_pilot import SCENARIOS, runs
from pems_bay_alert_replay import alarm, replay, layout
from train_pems_bay_risk import load_risk

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs/bypass-diagnosis-2026-10-16'
KINDS=('warned','late','false','duplicate','censored','unknown')


def raw_intervals(part, scores):
    result=[]
    for lo,hi in layout(part)[0]:
        for node in range(scores.shape[1]):
            for a,b in runs(scores[lo:hi,node]>=.46):
                result.append((int(a+lo),int(b+lo),node))
    return result


def causal_context(part, scenario, scores, credibility, row, node, cutoff, prepared=None):
    """No truth, eligibility, matched-event type, lead or future duration read."""
    x=part[scenario+'_state']
    features,residuals=prepared if prepared is not None else (probe.start_features(part,scenario,scores),common.causal_residual(part,scenario))
    f=features[row,node];residual=residuals[row,node]
    # A bypass-only decision has three consecutive fresh own observations.
    recent=(x[row-2:row+1,node,8].astype(float)*70).tolist()
    return {'observed_last3_mph':recent,'own_mean_mph':float(f[9]*70),
        'own_trend_scaled':float(f[10]),'own_std_mph':float(f[11]*70),
        'own_coverage':float(f[12]),'own_age_scaled':float(f[13]),
        'forecast5_mph':float(f[0]*70),'forecast10_mph':float(f[1]*70),'forecast15_mph':float(f[2]*70),
        'forecast_seed_std5_mph':float(f[3]*70),'neighbor_last_mph':float(f[15]*70),
        'neighbor_coverage':float(f[19]),'network_coverage':float(f[24]),
        'past_residual_mph':float(residual) if np.isfinite(residual) else None,
        'global_probability':float(scores[row,node]),'effective_probability':float(credibility[row,node]),
        'score_deficit':float(cutoff-credibility[row,node])}


def context_bins(context):
    r=context['past_residual_mph']
    residual=('missing' if r is None else '<-5' if r < -5 else '[-5,0)' if r < 0 else '[0,5]' if r <= 5 else '>5')
    return {'residual':residual,
        'forecast_all_low': 'all<=30' if max(context[k] for k in ('forecast5_mph','forecast10_mph','forecast15_mph'))<=30 else 'some>30',
        'score_deficit':'<=0.05' if context['score_deficit']<=.05 else '>0.05'}


def diagnose(part, scenario, scores, credibility, cutoff):
    bypass=protection.observed_past_low(part,scenario)
    without=protection.episode_gate(scores,credibility,part['origins'],part['timestamps'],cutoff)
    with_=protection.episode_gate(scores,credibility,part['origins'],part['timestamps'],cutoff,bypass)
    baseline=alarm(scores,.46,1,part)
    assert not np.any(without&~with_) and not np.any(with_&~baseline)
    base_row,_,base_events=replay(part,baseline,details=True)
    no_row,_,no_events=replay(part,without,details=True)
    yes_row,_,yes_events=replay(part,with_,details=True)
    fragments=common.episodes(part,with_)
    extra=[];covered=np.zeros_like(with_)
    prepared=(probe.start_features(part,scenario,scores),common.causal_residual(part,scenario))
    for a,b,node in raw_intervals(part,scores):
        if not (bypass[a,node] and credibility[a,node]<cutoff):continue
        covered[a:b,node]=True
        fs=[dict(e) for e in fragments if e['node']==node and a<=e['row']<b]
        context=causal_context(part,scenario,scores,credibility,a,node,cutoff,prepared)
        extra.append({'row':a,'end_row':b,'node':node,'origin':int(part['origins'][a]),
            'timestamp':str(part['timestamps'][part['origins'][a]]),
            'context':context,'strata':context_bins(context),'scored_fragments':fs})
    np.testing.assert_array_equal(covered,with_&~without)
    key=lambda e:(e['node'],e['event_start_origin'])
    bm={key(e):e for e in base_events};nm={key(e):e for e in no_events};ym={key(e):e for e in yes_events}
    assert bm.keys()==nm.keys()==ym.keys()
    changes=[]
    for k,after in ym.items():
        before=nm[k]
        if before==after:continue
        ids=[i for i,e in enumerate(extra) if e['node']==after['node'] and after['alarm_start_origin'] is not None
            and part['origins'][e['row']]<=after['alarm_start_origin']<=part['origins'][e['end_row']-1]]
        original=bm[k]
        original_early=original['status']=='warned' and original['lead_minutes']>=10
        restored=original_early and after['status']=='warned' and after['lead_minutes']>=original['lead_minutes'] and not (
            before['status']=='warned' and before['lead_minutes']>=original['lead_minutes'])
        changes.append({'node':k[0],'event_start_origin':k[1],'without':before,'with':after,'original':original,
            'bypass_raw_run_indices':ids,'restored_original_R10_identity_and_lead':bool(restored),
            'recovered_detection':before['status']=='missed' and after['status']!='missed'})
    kinds={k:sum(e['kind']==k for r in extra for e in r['scored_fragments']) for k in KINDS}
    summary={'added_raw_runs':len(extra),'unique_raw_node_origin_keys':len({(e['node'],e['origin']) for e in extra}),
        'added_scored_fragment_types':kinds,'changed_event_records':len(changes),
        'recovered_detections':sum(e['recovered_detection'] for e in changes),
        'restored_original_R10':sum(e['restored_original_R10_identity_and_lead'] for e in changes),
        'R10_increase':yes_row['warning_recall_at_least10']-no_row['warning_recall_at_least10'] if yes_row['warning_recall_at_least10'] is not None else None,
        'detection_increase':yes_row['detection_recall']-no_row['detection_recall'] if yes_row['detection_recall'] is not None else None,
        'false_rate_increase':yes_row['false_per_valid_station_day']-no_row['false_per_valid_station_day']}
    strata={}
    for feature,labels in {'residual':['missing','<-5','[-5,0)','[0,5]','>5'],
            'forecast_all_low':['all<=30','some>30'],'score_deficit':['<=0.05','>0.05']}.items():
        strata[feature]={}
        for label in labels:
            indices=[i for i,e in enumerate(extra) if e['strata'][feature]==label]
            strata[feature][label]={'raw_runs':len(indices),
                'false_fragments':sum(f['kind']=='false' for i in indices for f in extra[i]['scored_fragments']),
                'warned_fragments':sum(f['kind']=='warned' for i in indices for f in extra[i]['scored_fragments']),
                'late_fragments':sum(f['kind']=='late' for i in indices for f in extra[i]['scored_fragments']),
                'restored_original_R10':sum(e['restored_original_R10_identity_and_lead'] and any(i in indices for i in e['bypass_raw_run_indices']) for e in changes)}
    return {'summary':summary,'strata':strata,'added_runs':extra,'changed_events':changes,
        'operating':{'global_c1':base_row,'effective_no_bypass':no_row,previous.PRIMARY:yes_row}},without,with_


def freeze_plan():
    OUT.mkdir(exist_ok=True)
    names=['bypass_diagnosis.py','effective_alert_pilot.py','alarm_start_separability.py','early_warning_protection.py',
        'calibration_fragility.py','pems_bay_alert_replay.py','congestion_alert_pilot.py','congestion_risk_pilot.py','train_pems_bay_risk.py',
        'outputs/pems-bay-risk/risk_train.npz','outputs/pems-bay-risk/risk_validation.npz',
        'outputs/pems-bay-risk/normalization.npz','outputs/pems-bay-risk/global_calibration.pt',
        'outputs/pems-bay-calibration/calibration.npz',
        'outputs/effective-alert-pilot-2026-10-16/effective_model.npz',
        'outputs/effective-alert-pilot-2026-10-16/training_freeze.json',
        'outputs/effective-alert-pilot-2026-10-16/results.json',
        'outputs/effective-alert-pilot-2026-10-16/activations.npz']
    plan={'stage':'fixed_effective_model_observed_low_bypass_diagnosis','client_date':'2026-10-16',
        'frozen_at_utc':datetime.now(timezone.utc).isoformat(),
        'question':'Which raw runs are admitted solely by observed-low bypass, and what event/false costs do they have?',
        'policy':'unchanged previous effective model and training cutoff; same start-only full-run bypass rule',
        'allowed':'original train28, validation7, calibration14 and its separately replayed halves; reused development only',
        'forbidden':'raw data, original evaluation, consumed or fresh station transfer values',
        'strata_frozen_before_cache_decode':{'residual_mph':['missing','<-5','[-5,0)','[0,5]','>5'],
            'forecast_all3_mph':['all<=30','some>30'],'cutoff_minus_effective_probability':['<=0.05','>0.05']},
        'causal_context':'raw-run decision origin; last3 fresh own observations, cached forecasts/own/neighbor/availability and past one-step residual only',
        'offline_fields':'fragment type, run end/duration and matched event/lead only for diagnosis; not inputs',
        'counting':'raw decision intervals separate from eligibility-fragment episode starts; align exact event IDs and leads',
        'no_classifier_auc_or_candidate_threshold_search':True,'optimizer_updates':0,'new_models':0,
        'independent_confirmation':False,'new_policy_or_acceptance_test':False,
        'original_thesis_primary_test_still_failed':True,
        'source_and_input_sha256':{n:common.sha(ROOT/n) for n in names}}
    if (OUT/'plan.json').exists():raise FileExistsError('Preserve prior planned diagnosis')
    common.write(OUT/'plan.json',plan)
    return plan


def main():
    sys.addaudithook(protection.guard);torch.set_num_threads(1)
    plan=freeze_plan()
    seal=common.read(previous.OUT/'training_freeze.json');cutoff=seal['cutoff']
    assert common.sha(previous.OUT/'effective_model.npz')==seal['model_sha256']
    model=common.load(previous.OUT/'effective_model.npz')
    norm=common.load(common.RISK/'normalization.npz');anchor=load_risk(common.RISK/'global_calibration.pt')
    parts={'training28':common.load(common.RISK/'risk_train.npz'),
        'risk_validation7':common.load(common.RISK/'risk_validation.npz'),
        'calibration_full14':common.load(common.CAL/'calibration.npz')}
    parts.update({'calibration_week1_7':common.subset(parts['calibration_full14'],0,7),
        'calibration_week2_7':common.subset(parts['calibration_full14'],7,14)})
    old=common.read(previous.OUT/'results.json');old_active=common.load(previous.OUT/'activations.npz')
    blocks={}
    for block,part in parts.items():
        probabilities=common.global_scores(part,norm,anchor);blocks[block]={}
        for s in SCENARIOS:
            cred=probe.predict(model,probe.start_features(part,s,probabilities[s]).reshape(-1,30)).reshape(part['truth'].shape)
            diagnosis,no,yes=diagnose(part,s,probabilities[s],cred,cutoff);blocks[block][s]=diagnosis
            if block!='training28':
                for method,bits in [('effective_no_bypass',no),(previous.PRIMARY,yes)]:
                    np.testing.assert_array_equal(bits,old_active[f'{block}__{method}__{s}'])
                for method,row in diagnosis['operating'].items():assert row==old['evaluation'][block][method][s]
        print(block+': '+str({s:d['summary'] for s,d in blocks[block].items()}),flush=True)
    result={'blocks':blocks,'fixed_cutoff':cutoff,'model_sha256':seal['model_sha256'],
        'new_models_fitted':0,'policy_modified':False,'independent_confirmation':False,
        'original_thesis_primary_test_still_failed':True,'previous_candidate_acceptance_passed':old['primary_acceptance_passed'],
        'new_station_cohort_consumed':False,'consumed_transfer_values_used':False,
        'limitation':'Related scenarios and overlapping calibration halves are not independent; descriptive strata are not validated policies.'}
    common.write(OUT/'results.json',result)
    for n,h in plan['source_and_input_sha256'].items():assert common.sha(ROOT/n)==h,n
    common.write(OUT/'access_log.json',{'runtime_output_paths':sorted(set(common.READS)),
        'raw_evaluation_transfer_guard_enabled':True,'forbidden_values_used':False})
    common.write(OUT/'completion.json',{'completed_at_utc':datetime.now(timezone.utc).isoformat(),
        'plan_sha256':common.sha(OUT/'plan.json'),'artifacts':{n:common.sha(OUT/n) for n in ['results.json','access_log.json']}})


if __name__=='__main__':main()
