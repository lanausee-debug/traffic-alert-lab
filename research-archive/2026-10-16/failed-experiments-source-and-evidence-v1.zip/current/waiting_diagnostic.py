"""Exploratory completion-time binary replan, paid five-minute information wait."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import time
import numpy as np
import torch
from recovery_pilot import ROOT, RecoveryForecaster, write_json
from fresh_holdout_pilot import MaskedGraphTCN
from multifault_pilot import ORDERS, infer, day_macro, day_interval, relative_day_interval, sha256
from state_value_pilot import (read_data, ridge_fit, ridge_predict, standardize, weighted_rows, ALPHAS, SEEDS)

METHODS = ('immediate_calendar', 'immediate_state', 'wait_calendar', 'wait_state', 'wait_hidden')


def branch_orders(reference_choices):
    return np.array([[i for i, order in enumerate(ORDERS) if order[0] == ORDERS[int(choice)][0]] for choice in reference_choices])


def completion(group, order_index, wait):
    order = ORDERS[int(order_index)]; clock = 0; completed = np.zeros(3, int)
    for pos, node in enumerate(order):
        if pos == 1: clock += wait
        clock += group['durations_steps'][node]; completed[node] = clock
    return completed


def replan_features(z, valid, context, origin, group, first, wait, adjacency, hide=False):
    finished = origin+group['durations_steps'][first]
    decision = finished+wait
    mask = valid[decision-12:decision].copy(); mask[:, group['nodes']] = 0
    restored = group['nodes'][first]
    age = 0 if hide else min(wait, 12)
    if age: mask[-age:, restored] = valid[decision-age:decision, restored]
    x = np.where(mask > 0, z[decision-12:decision], 0)
    count = mask.sum(axis=0)
    mean = x.sum(axis=0)/np.maximum(count, 1)
    spread = np.sqrt(np.maximum((x*x).sum(axis=0)/np.maximum(count, 1)-mean*mean, 0))
    index = np.where(mask > 0, np.arange(12)[:, None], -1).max(axis=0)
    latest = x[np.maximum(index, 0), np.arange(24)]
    start = np.where(mask > 0, np.arange(12)[:, None], 12).min(axis=0)
    earliest = x[np.minimum(start, 11), np.arange(24)]
    trend = (latest-earliest)/np.maximum(index-start, 1)
    summary = np.stack([latest, mean, trend, spread, count/12], axis=1)
    proxies = []
    for a in (adjacency, adjacency@adjacency):
        weights = a[group['nodes']]*(count > 0)[None]
        denominator = np.maximum(weights.sum(axis=1, keepdims=True), 1e-6)
        proxies.extend([(weights@summary[:, :3]/denominator).ravel(), weights.sum(axis=1)])
    proxy = np.concatenate(proxies); gid = np.eye(12, dtype=np.float32)[group['id']]
    station = np.eye(3, dtype=np.float32)[first]
    calendar = np.concatenate([gid, context[decision], np.outer(gid, context[decision]).ravel(),
                               np.array(group['durations_steps'], np.float32)/6,
                               station, np.outer(gid, station).ravel(), [group['durations_steps'][first]/6, wait/12]])
    state = np.concatenate([calendar, summary.ravel(), proxy, np.outer(gid, proxy).ravel()])
    return calendar.astype(np.float32), state.astype(np.float32)


def cost_requests(events, groups, orders, wait):
    requests, lookup, rows = [], {}, []
    for event, alternatives in zip(events, orders):
        group = groups[event['group']]; event_rows = []
        for order in alternatives:
            finished = completion(group, order, wait); offsets = []
            for step in event['usable_steps']:
                ages = np.clip(step-finished, 0, 12)
                t = event['origin']+step
                for j, age in enumerate(ages):
                    if age and t-age < event['origin']+finished[j]: raise AssertionError('Pre-completion history opened')
                key = (t, tuple(group['nodes']), tuple(int(a) for a in ages))
                if key not in lookup: lookup[key] = len(requests); requests.append(key)
                offsets.append(lookup[key])
            event_rows.append(offsets)
        rows.append(event_rows)
    return requests, rows


def evaluate_waiting(variant, events, groups, orders, z, valid, context, scale, adjacency, output):
    path = output/f'waiting_costs_{variant}.npz'
    if path.exists():
        with np.load(path) as saved: return saved['cost']
    requests, rows = cost_requests(events, groups, orders, 1)
    runs = []
    for seed in SEEDS:
        if variant == 'graph_tcn_candidate':
            model = MaskedGraphTCN(12, 3, adjacency); path_weight = ROOT/'outputs/fresh-holdout-pilot'/f'model_tcn_seed{seed}.pt'
        else:
            model = RecoveryForecaster(12, 3, adjacency, True); path_weight = ROOT/'outputs/recovery-pilot'/f'model_seed{seed}.pt'
        model.load_state_dict(torch.load(path_weight, weights_only=True)['state_dict']); model.eval()
        losses = infer(model, requests, z, valid, context, scale, 12, 3)
        runs.append(np.array([[5*losses[ix].sum() for ix in alternatives] for alternatives in rows]))
        print(f'{variant} wait=5min seed={seed} requests={len(requests)} events={len(events)}', flush=True)
    cost = np.mean(runs, axis=0)
    np.savez_compressed(path, cost=cost, per_seed=np.stack(runs))
    # Independently reproduce nonwaiting labels on a small, diverse request set.
    sample = sorted(set(range(12)) | {len(events)//2, len(events)-1})
    rq, mapping = cost_requests([events[i] for i in sample], groups, orders[sample], 0)
    reconstructed = []
    for seed in SEEDS:
        if variant == 'graph_tcn_candidate':
            model = MaskedGraphTCN(12, 3, adjacency); path_weight = ROOT/'outputs/fresh-holdout-pilot'/f'model_tcn_seed{seed}.pt'
        else:
            model = RecoveryForecaster(12, 3, adjacency, True); path_weight = ROOT/'outputs/recovery-pilot'/f'model_seed{seed}.pt'
        model.load_state_dict(torch.load(path_weight, weights_only=True)['state_dict']); model.eval()
        losses = infer(model, rq, z, valid, context, scale, 12, 3)
        reconstructed.append(np.array([[5*losses[ix].sum() for ix in alternatives] for alternatives in mapping]))
    np.savez_compressed(output/f'zero_wait_check_{variant}.npz', sample=sample, cost=np.mean(reconstructed, axis=0))
    return cost


def summary(costs, healthy, events, chosen):
    ref = costs['keep_plan']; extra = ref-healthy
    extra_mean, extra_ci = day_interval(extra, events)
    result = {'selected_on_old_validation': chosen, 'events': len(events), 'days': len({e['day'] for e in events}),
              'reference_cost': float(day_macro(ref, events)), 'reference_fault_added': float(extra_mean), 'policies': {}}
    for name, cost in costs.items():
        mean, ci = day_interval(ref-cost, events)
        result['policies'][name] = {'cost': float(day_macro(cost, events)), 'absolute_gain': float(mean), 'absolute_ci': ci.tolist(),
            'fault_added_gain': float(mean/extra_mean) if extra_mean > 0 else None,
            'fault_added_ci': relative_day_interval(ref-cost, extra, events).tolist() if extra_ci[0] > 0 else None}
    info_mean, info_ci = day_interval(costs['wait_hidden']-costs['wait_state'], events)
    result['restored_reading_vs_hidden_ablation'] = {'absolute_gain': float(info_mean), 'ci': info_ci.tolist()}
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ROOT/'outputs/waiting-diagnostic')
    parser.add_argument('--prepare-only', action='store_true'); args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(1); torch.use_deterministic_algorithms(True); started = time.perf_counter()
    source = ROOT/'outputs/state-value-pilot'
    original = json.loads((source/'config.json').read_text(encoding='utf-8'))
    events, groups = original['events'], original['groups']
    z, valid, scale, adjacency, ts, context, _ = read_data()
    partitions = ('training', 'validation', 'test'); all_events = sum([events[p] for p in partitions], [])
    slices = {}; begin = 0
    for p in partitions: slices[p] = slice(begin, begin+len(events[p])); begin += len(events[p])
    hashes = {str(path.relative_to(ROOT)): sha256(path) for path in [ROOT/'docs/waiting_diagnostic_protocol.zh-CN.md', Path(__file__),
               source/'config.json', ROOT/'outputs/replanning-diagnostic/results.json', *[source/f'choices_{v}.npz' for v in ('graph_tcn_candidate', 'mlp_baseline')]]}
    config = {'date': '2026-10-10', 'scope': 'exploratory_already_analyzed_dates', 'hashes': hashes, 'wait_minutes': 5,
              'parts': {p: len(events[p]) for p in partitions}, 'methods': METHODS, 'alphas': ALPHAS,
              'forecast_hashes': original['hashes'], 'horizon_minutes_fixed': 120}
    config = json.loads(json.dumps(config)); saved_config = args.output/'config.json'
    if saved_config.exists() and json.loads(saved_config.read_text(encoding='utf-8')) != config: raise ValueError('Diagnostic config changed')
    write_json(saved_config, config)
    if args.prepare_only: print(json.dumps(config['parts'])); return
    results = {'config': config, 'models': {}, 'checks': {'timing_and_no_prerepair_history': True, 'hidden_data_invariant': True,
               'future_data_invariant': True, 'training_only_standardization': True, 'zero_wait_reconstruction': True}}
    for variant in ('graph_tcn_candidate', 'mlp_baseline'):
        initial = {}
        with np.load(ROOT/'outputs/replanning-diagnostic'/f'choices_{variant}.npz') as saved:
            reference = {p: saved[p+'_reference_choice'] for p in partitions}
        with np.load(ROOT/'outputs/fresh-holdout-pilot'/f'arrays_{variant}.npz') as archive:
            initial['training'] = {k: np.concatenate([archive['calibration_'+k], archive[k]]) for k in ('actual', 'healthy')}
        for p in ('validation', 'test'):
            with np.load(source/f'labels_{variant}_{p}.npz') as archive: initial[p] = {k: archive[k] for k in ('actual', 'healthy')}
        ref_all = np.concatenate([reference[p] for p in partitions]); orders = branch_orders(ref_all)
        nonwaiting = np.concatenate([initial[p]['actual'] for p in partitions])[np.arange(len(all_events))[:, None], orders]
        firsts = [ORDERS[int(c)][0] for c in ref_all]
        feature_sets = {}
        for mode, wait, hide in (('immediate', 0, False), ('wait', 1, False), ('hidden', 1, True)):
            arr = [replan_features(z, valid, context, e['origin'], groups[e['group']], first, wait, adjacency, hide)
                   for e, first in zip(all_events, firsts)]
            feature_sets[mode] = [np.stack([f[i] for f in arr]) for i in (0, 1)]
        # The replan selector sees only observations that physically exist by its decision.
        for i in range(0, len(all_events), max(1, len(all_events)//36)):
            e, first = all_events[i], firsts[i]; group = groups[e['group']]
            finished = e['origin']+group['durations_steps'][first]; decision = finished+1
            a = replan_features(z, valid, context, e['origin'], group, first, 1, adjacency)
            hidden = z.copy(); hidden[decision-12:decision, group['nodes']] += 1234
            # Preserve the one admissible completed-station reading.
            hidden[finished, group['nodes'][first]] = z[finished, group['nodes'][first]]
            b = replan_features(hidden, valid, context, e['origin'], group, first, 1, adjacency)
            future = z.copy(); future[decision:] += 1234
            c = replan_features(future, valid, context, e['origin'], group, first, 1, adjacency)
            if not all(np.array_equal(x, y) and np.array_equal(x, v) for x, y, v in zip(a, b, c)): raise AssertionError('Replan information leak')
            if np.any(completion(group, orders[i, 0], 1)-completion(group, orders[i, 0], 0) != [0 if j == first else 1 for j in range(3)]):
                raise AssertionError('Waiting shift incorrect')
        waiting = evaluate_waiting(variant, all_events, groups, orders, z, valid, context, torch.tensor(scale).view(1, 1, -1), adjacency, args.output)
        with np.load(args.output/f'zero_wait_check_{variant}.npz') as check:
            if not np.allclose(check['cost'], nonwaiting[check['sample']], rtol=1e-7, atol=1e-5): raise AssertionError('Nonwaiting reconstruction differs')
        selections, coefficients, normalization, choices = {}, {}, {}, {}
        candidate_costs = {p: {'keep_plan': initial[p]['actual'][np.arange(len(events[p])), reference[p]]} for p in partitions}
        weight = weighted_rows(events['training'])
        for method in METHODS:
            mode = 'immediate' if method.startswith('immediate') else 'hidden' if method == 'wait_hidden' else 'wait'
            column = 0 if method.endswith('calendar') else 1
            raw = feature_sets[mode][column]
            arr, mean, std = standardize(raw[slices['training']], [raw[slices[p]] for p in ('validation', 'test')])
            x = dict(zip(partitions, arr)); cost_array = nonwaiting if mode == 'immediate' else waiting
            target = (cost_array[:, 0]-cost_array[:, 1])[slices['training'], None]
            best = float('inf'); grid = []
            for alpha in ALPHAS:
                coef = ridge_fit(x['training'], target, alpha, weight)
                pred = ridge_predict(x['validation'], coef)[:, 0]; choice = (pred > 0).astype(int)
                cost = float(day_macro(cost_array[slices['validation']][np.arange(len(choice)), choice], events['validation']))
                grid.append({'alpha': alpha, 'validation_cost': cost})
                if cost < best: best, best_coef, best_alpha = cost, coef, alpha
            selections[method] = {'alpha': best_alpha, 'validation_cost': best, 'grid': grid}
            coefficients[method] = best_coef; normalization[method+'_mean'] = mean; normalization[method+'_std'] = std
            for p in partitions:
                choice = (ridge_predict(x[p], best_coef)[:, 0] > 0).astype(int)
                choices[p+'_'+method] = choice
                candidate_costs[p][method] = cost_array[slices[p]][np.arange(len(choice)), choice]
        val_costs = {k: float(day_macro(v, events['validation'])) for k, v in candidate_costs['validation'].items()}
        chosen = min(('keep_plan', 'immediate_state', 'wait_state'), key=lambda k: val_costs[k])
        write_json(args.output/f'selection_{variant}.json', {'methods': selections, 'validation_costs': val_costs, 'chosen': chosen})
        np.savez_compressed(args.output/f'policy_{variant}.npz', **coefficients, **normalization)
        np.savez_compressed(args.output/f'choices_{variant}.npz', **choices, orders=orders)
        choices_hash = sha256(args.output/f'choices_{variant}.npz')
        tables = {}
        for p in partitions:
            sl = slices[p]
            candidate_costs[p]['no_wait_conditional_oracle'] = nonwaiting[sl].min(axis=1)
            candidate_costs[p]['wait_conditional_oracle'] = waiting[sl].min(axis=1)
            candidate_costs[p]['optional_wait_oracle'] = np.minimum(nonwaiting[sl].min(axis=1), waiting[sl].min(axis=1))
            tables[p] = summary(candidate_costs[p], initial[p]['healthy'], events[p], chosen)
        if choices_hash != sha256(args.output/f'choices_{variant}.npz'): raise AssertionError('Choices changed during metrics')
        results['models'][variant] = {'parts': tables, 'chosen': chosen, 'choices_hash_before_metrics': choices_hash,
            'valid_first_reading_fraction': float(day_macro(np.array([valid[e['origin']+groups[e['group']]['durations_steps'][first], groups[e['group']]['nodes'][first]]
                                            for e, first in zip(events['test'], firsts[slices['test']])]), events['test']))}
        write_json(args.output/f'results_{variant}.json', results['models'][variant])
        print(json.dumps({'variant': variant, 'chosen': chosen, 'test': tables['test']}, ensure_ascii=False), flush=True)
    results['elapsed_seconds'] = time.perf_counter()-started; write_json(args.output/'results.json', results)
    print(json.dumps({'elapsed_seconds': results['elapsed_seconds']}), flush=True)


if __name__ == '__main__': main()
