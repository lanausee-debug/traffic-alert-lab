"""Frozen-risk-head transfer check on a disjoint 24-station PEMS-BAY cohort.

Forecaster refit is necessary because GraphTCN has station-specific embeddings.
No risk-head fitting, no threshold selection, no development-station value reads.
Same-network/same-date dependence prevents an external-independent-data claim.
"""
from __future__ import annotations
import argparse
import contextlib
from datetime import datetime,timezone
import hashlib
import json
import math
from pathlib import Path
import sys
import time
from unittest.mock import patch

import h5py
import numpy as np
import torch

from pems_bay_reader import SealedPartitionReader,training_statistics
from pems_bay_windows import forecast_dataset
import fresh_holdout_pilot as forecasting
from train_pems_bay_forecaster import load_model
from train_pems_bay_risk import prepare,load_risk
from calibrate_pems_bay_alerts import frozen_scores
from congestion_alert_pilot import SCENARIOS
from congestion_risk_pilot import score,sigmoid
from pems_bay_alert_replay import alarm,replay,layout
from improve_anchored_risk import AnchoredRisk,inputs

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs/new-station-transfer-2026-10-15'
DATA=ROOT/'data/raw/pems-bay.h5'
RISK=ROOT/'outputs/pems-bay-risk'
CANDIDATE=ROOT/'outputs/anchored-risk-2026-10-15'
SALT='traffic-alert-new-station-transfer-24-2026-10-15-v1'


def read(path):return json.loads(path.read_text(encoding='utf-8'))
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def choose_ids(ids,excluded,count=24):
    candidates=sorted(set(ids)-set(excluded),key=lambda item:(hashlib.sha256(f'{SALT}|{item}'.encode()).hexdigest(),item))
    if len(candidates)<count:raise ValueError('Not enough non-development stations')
    return sorted(candidates[:count])


def validate_request(stage,partition,start,stop,bounds,consumed):
    allowed=('forecast_train','forecast_validation') if stage=='train' else ('evaluation',) if stage=='evaluate' else ()
    if partition not in allowed or (start,stop)!=bounds[partition]:raise PermissionError('Only complete declared stage partition allowed')
    if partition=='evaluation' and consumed:raise PermissionError('Evaluation source slice already consumed')


class TransferReader(SealedPartitionReader):
    def __init__(self,config,plan,stage):
        super().__init__(DATA,config)
        self.selected_ids=plan['new_station_ids'];index={item:i for i,item in enumerate(self.ids)}
        self.columns=np.array([index[item] for item in self.selected_ids],dtype=np.int64)
        assert self.columns.tolist()==plan['new_raw_columns']
        assert not set(self.selected_ids)&set(plan['development_station_ids'])
        self.stage=stage;self.consumed=False
    def _authorize(self,partition,start,stop):
        validate_request(self.stage,partition,start,stop,self.bounds,self.consumed)
    def _read_values(self,partition,start,stop):
        raw=super()._read_values(partition,start,stop)
        if partition=='evaluation':self.consumed=True
        return raw


@contextlib.contextmanager
def speed_guard(reader,trace):
    original=h5py.Dataset.__getitem__
    allowed={reader.bounds[name]:name for name in (('forecast_train','forecast_validation') if reader.stage=='train' else ('evaluation',))}
    columns=sorted(reader.columns.tolist())
    def checked(dataset,key,*args,**kwargs):
        if dataset.name=='/speed/block0_values':
            if Path(dataset.file.filename).resolve()!=DATA.resolve():raise PermissionError('Unexpected raw source')
            if not isinstance(key,tuple) or len(key)!=2 or not isinstance(key[0],slice):raise PermissionError('Unbounded speed read')
            rows=key[0];bounds=(rows.start,rows.stop)
            if bounds not in allowed or rows.step not in (None,1) or np.asarray(key[1]).tolist()!=columns:
                raise PermissionError('Speed request crosses stage rows or station cohort')
            if reader.stage=='evaluate' and trace:raise PermissionError('Repeated evaluation source read')
            trace.append({'partition':allowed[bounds],'rows':list(bounds),'sorted_columns':columns})
        return original(dataset,key,*args,**kwargs)
    with patch.object(h5py.Dataset,'__getitem__',checked):yield


def freeze_plan():
    OUT.mkdir(exist_ok=True)
    config=read(ROOT/'configs/pems_bay_validation_v1.json')
    metadata=SealedPartitionReader(DATA,config)
    development=read(ROOT/'outputs/pems-bay-binding/metadata.json')['selected_ids']
    assert metadata.selected_ids==development
    selected=choose_ids(metadata.ids,development)
    index={item:i for i,item in enumerate(metadata.ids)}
    choice=read(CANDIDATE/'selection_freeze.json')
    assert choice['selected']['method']=='anchored_bound1_0' and choice['selected']['threshold']==.505 and choice['selected']['confirmation']==1
    original=read(ROOT/'outputs/pems-bay-calibration/selection.json')
    settings={method:{key:original['methods'][method]['fine']['selected'][key] for key in ('threshold','confirmation')}
              for method in ('global_calibration','group_calibration','onset_mlp')}
    weights=[p for p in RISK.glob('*.pt')]+[CANDIDATE/f'anchored_bound1_0_seed{seed}.pt' for seed in (202,203,204)]
    sources=[Path(__file__),ROOT/'pems_bay_reader.py',ROOT/'pems_bay_windows.py',ROOT/'fresh_holdout_pilot.py',
        ROOT/'recovery_pilot.py',ROOT/'train_pems_bay_risk.py',ROOT/'calibrate_pems_bay_alerts.py',
        ROOT/'congestion_alert_pilot.py',ROOT/'congestion_risk_pilot.py',ROOT/'congestion_onset_pilot.py',
        ROOT/'congestion_objective_diagnostic.py',ROOT/'pems_bay_alert_replay.py',ROOT/'improve_anchored_risk.py',
        ROOT/'configs/pems_bay_validation_v1.json',RISK/'normalization.npz',RISK/'model_selection.json',
        CANDIDATE/'selection_freeze.json',CANDIDATE/'training_freeze.json']
    plan={'kind':'prospectively_frozen_disjoint_station_transfer_check_not_external_dataset',
        'new_station_ids':selected,'new_raw_columns':[index[item] for item in selected],
        'development_station_ids':development,'selection_salt':SALT,'selection_uses_speed_values':False,
        'new_cohort_speed_values_read_before_plan':False,
        'prior_development_speed_reads':'Recorded PEMS-BAY development stages used only original 24 columns; no claim of OS-enforced all-session access history',
        'source_file_sha256':read(ROOT/'data/pems-bay-provenance.json')['sha256'],
        'same_network_and_calendar_as_development':True,'external_independent_data':False,
        'front_end_adaptation':'New cohort mean/scale/graph from forecast_train only; 3 GraphTCNs refit with identical architecture/seeds42,43,44 and25epochs; forecast_validation selects epoch',
        'risk_head_transfer':'Original fixed global/group/onset heads and anchored candidate weights + original risk normalization; no refit',
        'candidate_settings':choice['selected'],'comparator_settings':settings,
        'partitions_used':{'forecast_train':[0,42],'forecast_validation':[42,49],'evaluation':[98,None]},
        'new_cohort_risk_train_validation_calibration_values_used':False,
        'quality_floor':.95,'quality_failure':'stop and report; do not replace stations',
        'candidate_or_threshold_changes_after_evaluation':False,
        'fixed_point_gate_vs_global':'R10 delta >=0.02 AND detection delta >=-0.02 AND false-rate delta <=0',
        'descriptive_uncertainty':'2000 paired-calendar-date bootstrap draws, seed20261015, 95% intervals conditional on fitted weights',
        'undefined_denominator_policy':'Report undefined replicates and no interval if any bootstrap denominator zero',
        'original_calibration_false_budgets':original['budgets'],
        'source_sha256':{p.relative_to(ROOT).as_posix():sha(p) for p in sources},
        'fixed_risk_weights_sha256':{p.relative_to(ROOT).as_posix():sha(p) for p in weights},
        'torch_version':torch.__version__,'numpy_version':np.__version__,'device':'cpu'}
    path=OUT/'plan.json'
    if path.exists():assert {k:v for k,v in read(path).items() if k!='frozen_at_utc'}==plan
    else:write(path,{**plan,'frozen_at_utc':datetime.now(timezone.utc).isoformat()})
    assert sha(DATA)==plan['source_file_sha256']
    return config,plan


def train(config,plan):
    if (OUT/'forecast_freeze.json').exists():
        record=read(OUT/'forecast_freeze.json')
        assert record['plan_sha256']==sha(OUT/'plan.json')
        for name,digest in record['artifacts'].items():assert sha(OUT/name)==digest
        print('New-cohort forecasting already complete, verified',flush=True);return
    reader=TransferReader(config,plan,'train');trace=[]
    with speed_guard(reader,trace):
        quality,stats=training_statistics(reader)
        write(OUT/'training_quality.json',quality)
        if not quality['passed']:
            write(OUT/'infeasible.json',{'reason':'Training availability failed','no_station_replacement':True});raise ValueError('New station cohort fails fixed quality floor')
        np.savez_compressed(OUT/'forecast_statistics.npz',**{key:stats[key] for key in ('mean','scale','adjacency','correlation')})
        write(OUT/'fault_groups.json',stats['groups'])
        training,origins=forecast_dataset(reader,'forecast_train',stats['mean'],stats['scale'])
        validation,validation_origins=forecast_dataset(reader,'forecast_validation',stats['mean'],stats['scale'])
        write(OUT/'forecast_inputs.json',{'train_windows':len(training),'validation_windows':len(validation),
            'updates_per_epoch':math.ceil(len(training)/128),'new_station_ids':reader.selected_ids,
            'normalization_graph_training_only':True,'evaluation_values_read':False})
        records=[]
        for seed in (42,43,44):
            path=OUT/f'model_tcn_seed{seed}.pt';log=OUT/f'training_seed{seed}.json'
            if path.exists() and log.exists():
                record=read(log);assert record['weight_sha256']==sha(path) and record['plan_sha256']==sha(OUT/'plan.json')
            elif path.exists() or log.exists():raise ValueError('Incomplete forecast seed preserved')
            else:
                updates=[0];original=torch.optim.Adam.step
                def tracked(optimizer,*args,**kwargs):
                    value=original(optimizer,*args,**kwargs);updates[0]+=1;return value
                with patch.object(torch.optim.Adam,'step',tracked):
                    model,record=forecasting.train_tcn(seed,training,validation,torch.tensor(stats['scale']).view(1,1,-1),stats['adjacency'],OUT)
                assert updates[0]==25*math.ceil(len(training)/128)
                record.update({'actual_optimizer_updates':updates[0],'weight_sha256':sha(path),'plan_sha256':sha(OUT/'plan.json')});write(log,record)
            records.append(record)
    write(OUT/'forecast_access_log.json',{'reader':reader.access_log,'runtime':trace,
        'evaluation_values_read':False,'development_station_values_read':False})
    artifacts=['training_quality.json','forecast_statistics.npz','fault_groups.json','forecast_inputs.json','forecast_access_log.json']
    artifacts += [f'{prefix}{seed}.{extension}' for seed in (42,43,44) for prefix,extension in (('model_tcn_seed','pt'),('training_seed','json'))]
    write(OUT/'forecast_freeze.json',{'frozen_at_utc':datetime.now(timezone.utc).isoformat(),
        'plan_sha256':sha(OUT/'plan.json'),'artifacts':{name:sha(OUT/name) for name in artifacts},
        'risk_head_or_threshold_refit':False,'evaluation_values_read':False})


def differences(candidate,reference,draws):
    result={}
    for name,cols,denominator in (('R10',(11,12),1),('detection',(3,),1),('false_rate',(4,),0)):
        a=candidate.sum(axis=1);b=reference.sum(axis=1)
        ac=candidate[:,draws,:].sum(axis=2);bc=reference[:,draws,:].sum(axis=2)
        point_valid=bool(np.all(a[:,denominator]>0)&np.all(b[:,denominator]>0))
        point=float(np.mean(a[:,cols].sum(axis=-1)/a[:,denominator]-b[:,cols].sum(axis=-1)/b[:,denominator])) if point_valid else None
        invalid=np.any((ac[:,:,denominator]<=0)|(bc[:,:,denominator]<=0),axis=0)
        if point_valid and not invalid.any():
            samples=(ac[:,:,cols].sum(axis=-1)/ac[:,:,denominator]-bc[:,:,cols].sum(axis=-1)/bc[:,:,denominator]).mean(axis=0)
            interval=np.quantile(samples,[.025,.975]).tolist()
        else:interval=None
        result[name]={'difference':point,'conditional_ci95':interval,'undefined_draws':int(invalid.sum())}
    return result


def evaluate(config,plan):
    seal=read(OUT/'forecast_freeze.json');assert seal['plan_sha256']==sha(OUT/'plan.json')
    for name,digest in seal['artifacts'].items():assert sha(OUT/name)==digest
    for name,digest in plan['fixed_risk_weights_sha256'].items():assert sha(ROOT/name)==digest
    execution={'frozen_at_utc':datetime.now(timezone.utc).isoformat(),'plan_sha256':sha(OUT/'plan.json'),
        'forecaster_freeze_sha256':sha(OUT/'forecast_freeze.json'),'candidate_settings':plan['candidate_settings'],
        'comparator_settings':plan['comparator_settings'],'new_cohort_evaluation_values_read':False}
    if (OUT/'execution_freeze.json').exists():
        assert {k:v for k,v in read(OUT/'execution_freeze.json').items() if k!='frozen_at_utc'}=={k:v for k,v in execution.items() if k!='frozen_at_utc'}
    else:write(OUT/'execution_freeze.json',execution)
    if (OUT/'results.json').exists():
        assert sha(OUT/'results.json')==read(OUT/'completion.json')['results_sha256'];print('Completed transfer evaluation verified; no repeat');return
    if (OUT/'evaluation_started.json').exists():raise ValueError('Partial evaluation preserved; do not open source again automatically')
    write(OUT/'evaluation_started.json',{'started_at_utc':datetime.now(timezone.utc).isoformat(),'execution_freeze_sha256':sha(OUT/'execution_freeze.json')})
    with np.load(OUT/'forecast_statistics.npz') as archive:stats={key:archive[key] for key in ('mean','scale','adjacency')}
    models=[load_model(seed,stats['adjacency'],OUT/f'model_tcn_seed{seed}.pt') for seed in (42,43,44)]
    reader=TransferReader(config,plan,'evaluate');trace=[]
    with speed_guard(reader,trace):
        part,names,summary=prepare(reader,'evaluation',models,stats,read(OUT/'fault_groups.json'))
    write(OUT/'evaluation_access_log.json',{'reader':reader.access_log,'runtime':trace,'source_speed_reads':len(trace),
        'development_station_values_read':False,'new_cohort_risk_train_validation_calibration_read':False})
    # Private prediction/features cache; never part of a public release.
    np.savez_compressed(OUT/'evaluation_features.npz',**part)
    old=frozen_scores(part)
    with np.load(RISK/'normalization.npz') as archive:norm={key:archive[key] for key in archive.files}
    x=inputs(part,norm,load_risk(RISK/'global_calibration.pt'),False)
    anchored=[]
    for seed in (202,203,204):
        saved=torch.load(CANDIDATE/f'anchored_bound1_0_seed{seed}.pt',weights_only=True)
        model=AnchoredRisk(saved['bound']);model.load_state_dict(saved['state_dict']);model.eval();anchored.append(model)
    scores={f'{method}__{s}':old[f'{method}__{s}'] for method in plan['comparator_settings'] for s in SCENARIOS}
    for s in SCENARIOS:scores[f'anchored_candidate__{s}']=np.mean([sigmoid(score(model,x[s])) for model in anchored],axis=0).reshape(part['truth'].shape)
    np.savez_compressed(OUT/'fixed_scores.npz',**scores)
    settings={**plan['comparator_settings'],'anchored_candidate':plan['candidate_settings']}
    rows={};daily={}
    for method,setting in settings.items():
        rows[method]={}
        for s in SCENARIOS:
            row,days,_=replay(part,alarm(scores[f'{method}__{s}'],setting['threshold'],setting['confirmation'],part),details=True,scenario=s)
            rows[method][s]=row;daily[f'{method}__{s}']=days
    np.savez_compressed(OUT/'daily.npz',**daily)
    dates=layout(part)[2]
    draws=np.random.default_rng(20261015).integers(0,len(dates),(2000,len(dates)))
    np.savez_compressed(OUT/'bootstrap_draws.npz',draws=draws,dates=dates)
    candidate=np.stack([daily[f'anchored_candidate__{s}'] for s in SCENARIOS])
    comparison={method:differences(candidate,np.stack([daily[f'{method}__{s}'] for s in SCENARIOS]),draws) for method in plan['comparator_settings']}
    metrics=('warning_recall_at_least10','warning_recall','detection_recall','false_per_valid_station_day')
    means={method:{key:float(np.mean([value[key] for value in by_s.values()])) if all(value[key] is not None for value in by_s.values()) else None for key in metrics} for method,by_s in rows.items()}
    delta=comparison['global_calibration'];point_gate=all(delta[key]['difference'] is not None for key in delta) and delta['R10']['difference']>=.02 and delta['detection']['difference']>=-.02 and delta['false_rate']['difference']<=0
    result={'stage':'fixed_risk_head_transfer_new_disjoint_stations','external_independent_data':False,
        'new_stations_not_used_for_risk_head_development':True,'same_network_and_calendar':True,
        'new_station_ids':plan['new_station_ids'],'development_station_ids':plan['development_station_ids'],
        'forecasters_refit':True,'risk_heads_refit':False,'thresholds_refit':False,
        'evaluation_dates':dates.astype(str).tolist(),'nodes':24,'events':rows['global_calibration']['natural']['events'],
        'evaluation':rows,'means':means,'comparisons':comparison,'fixed_point_gate_vs_global_passed':bool(point_gate),
        'candidate_budget_exceedance':{s:rows['anchored_candidate'][s]['false_per_valid_station_day']>plan['original_calibration_false_budgets'][s]+1e-12 if rows['anchored_candidate'][s]['false_per_valid_station_day'] is not None else None for s in SCENARIOS},
        'original_thesis_primary_test_still_failed':True,'unconditional_overall_superiority_established':False,
        'limitation':'One disjoint station cohort on the same source network and dates; front end adapted, risk head frozen. Conditional date-bootstrap does not include training or between-station/network uncertainty.'}
    write(OUT/'results.json',result)
    write(OUT/'completion.json',{'completed_at_utc':datetime.now(timezone.utc).isoformat(),'execution_freeze_sha256':sha(OUT/'execution_freeze.json'),
        'results_sha256':sha(OUT/'results.json'),'daily_sha256':sha(OUT/'daily.npz'),'scores_sha256':sha(OUT/'fixed_scores.npz'),
        'evaluation_feature_sha256':sha(OUT/'evaluation_features.npz'),'no_evaluation_grid_scan':True})
    print(json.dumps({'new_stations':24,'events':result['events'],'means':means,'point_gate_passed':point_gate},ensure_ascii=True),flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--stage',choices=('plan','train','evaluate','all'),default='all');args=parser.parse_args()
    torch.set_num_threads(1);torch.use_deterministic_algorithms(True)
    config,plan=freeze_plan()
    if args.stage in ('train','all'):train(config,plan)
    if args.stage in ('evaluate','all'):evaluate(config,plan)
    for name,digest in plan['source_sha256'].items():assert sha(ROOT/name)==digest,name
    for name,digest in plan['fixed_risk_weights_sha256'].items():assert sha(ROOT/name)==digest,name


if __name__=='__main__':main()
