"""Audit saved ablation models, rebuild choices/statistics, and export a report."""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import numpy as np
import torch

from recovery_pilot import ROOT, write_json
from multifault_pilot import sha256
from audit_congestion_pilot import compare
from congestion_alert_pilot import SCENARIOS, labels, outage_mask
from congestion_risk_pilot import pool, choose, hidden_features_check
from summarize_congestion_risk import check_validation
from congestion_ablation import (OUTPUT, OLD, SEEDS, SUBSETS, load_data, load_parts,
                                load_model, model_scores, evaluate, contrasts)

NAMES = {
    'context_only': '仅地点/日历 C', 'forecast_only': '仅预测 P',
    'forecast_context': '预测+地点/日历 P+C',
    'forecast_context_neighbor': '再加邻居 P+C+N',
    'forecast_context_neighbor_availability': '再加可用性 P+C+N+A',
    'full_without_availability': '完整删可用性 P+C+N+V',
    'full_without_context': '完整删地点/日历 P+N+V+A',
    'full': '完整 P+C+N+V+A',
}


def avg(rows, field):
    values = [rows[s][field] for s in SCENARIOS if rows[s][field] is not None]
    return float(np.mean(values)) if values else float('nan')


def create_report(result, output):
    lines = ['# 风险层特征消融：探索结果', '',
             '日期：2026-10-10。八种输入×线性/三种子MLP，共16组；所有119日此前已分析，不能称独立检验。', '',
             '固定交通预测器、标签、有效目标、日期和故障情景。不同风险层分别重训并只用校准段选择告警设置；完整模型直接复用原权重。', '',
             '## 预定两项MLP比较', '',
             '差值均为完整模型−删特征模型。召回用百分点，误报用告警数/有效站日；三情景等权平均。', '',
             '| 删除组 | 指标 | 差值 | 95%日期探索区间 | 97.5%日期探索区间 |',
             '| --- | --- | ---: | --- | --- |']
    for smaller, title in [('full_without_availability', '显式可用性 A'), ('full_without_context', '风险层地点/日历 C')]:
        c = result['contrasts'][f'mlp:full-{smaller}']
        for field, label, factor in [('warning_recall', '提前预警召回', 100), ('detection_recall', '含迟报检测召回', 100), ('false_rate', '误报/有效站日', 1)]:
            interval = lambda suffix: '['+', '.join(f'{v*factor:.3f}' for v in c[field+suffix])+']'
            lines.append(f'| {title} | {label} | {c[field+"_difference"]*factor:+.3f} | {interval("_ci95")} | {interval("_ci975")} |')
    lines += ['',
              '97.5%区间仅是针对同一指标两项比较的保守描述，并未对三个指标合计六项检验控制整体错误率。日期bootstrap也未涵盖训练随机种子的方差或跨站泛化，不消除反复使用这些日期的探索限制。', '',
              '## 全部运行点', '',
              '每组各自按校准约束选择，比较的是完整训练与运行点选择流程的条件增量，不能解释为固定阈值下特征的因果作用。误报预算约束施加在校准日期，评测可能超出。', '',
              '| 模型 | 输入组 | 维数 | 阈值/确认 | 预警召回 | 检测召回 | 误报/有效站日 | Brier | BCE |',
              '| --- | --- | ---: | --- | ---: | ---: | ---: | ---: | ---: |']
    for variant, columns in SUBSETS.items():
        for family in ('linear', 'mlp'):
            key = f'{family}_{variant}'; rows = result['evaluation'][key]
            op = result['selection']['methods'][key]['selected']
            lines.append(f'| {family} | {NAMES[variant]} | {len(columns)} | {op["threshold"]:g}/{op["confirmation"]} | {avg(rows,"warning_recall")*100:.2f}% | {avg(rows,"detection_recall")*100:.2f}% | {avg(rows,"false_per_valid_station_day"):.3f} | {avg(rows,"brier"):.5f} | {avg(rows,"bce"):.5f} |')
    lines += ['', '## 解读边界', '',
              '完整MLP相对删A模型：预警召回几乎不变，含迟报检测召回较高、误报较少，是该流程下的显式可用性增量线索；仍不能说提前预警已改善。线性模型的同项增量没有复现这组明显收益。', '',
              '仅地点/日历的MLP预警召回很低，不能替代实时输入；删C后的完整MLP检测召回几乎不变，但误报较多。前端预测器本来仍含日历/站点信息，不能由此证明完全无需地点信息或能迁移到新站点。', '',
              '删A后，预测器mask、邻居与本站缺失哨兵仍携带隐式缺测信息；删C只发生在风险层。输入维度改变也改变参数量。观测缺失为人工日缺测，速度≤30 mph持续三步是低速代理，不是实测事故或现场拥堵判定。', '',
              '简单30 mph参考的三情景平均预警/检测为20.66%/59.08%，误报1.456。完整MLP仍为21.89%/52.10%、误报1.153；本轮不改变此前“检测代价存在、预警改善未证实”的结论。没有按评测结果重新挑选一个胜出子模型。', '',
              '## 分情景完整指标', '',
              '成功预警提前量只针对成功子集，各模型成功集合不同；均值不能当同事件因果差。未知、重复与删失告警均单列，未并入误报。', '',
              '| 模型/输入 | 情景 | 预警% | 检测% | 误报/有效站日 | 漏检数 | 提前分钟 | 迟报数 | 重复数 | 未知数 | 删失告警数 | 删失事件数 |',
              '| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
    for key, rows in result['evaluation'].items():
        for s in SCENARIOS:
            r = rows[s]; lead = r['warning_lead_mean_minutes']
            lead_text = '无' if lead is None else f'{lead:.2f}'
            lines.append(f'| {key} | {s} | {r["warning_recall"]*100:.2f} | {r["detection_recall"]*100:.2f} | {r["false_per_valid_station_day"]:.3f} | {r["missed_events"]} | {lead_text} | {r["late"]:g} | {r["duplicate"]:g} | {r["unknown_alerts"]:g} | {r["censored_alerts"]:g} | {r["censored_events"]:g} |')
    lines += ['', '## 逐点评测与覆盖', '',
              '各情景目标相同：1089完整事件、73删失事件、167500有效站点窗口、有效覆盖86.70%、581.597有效站日。人工遮蔽只改变输入，不改变真实目标或有效性。', '',
              '| 模型/输入 | 情景 | 持续低速点召回% | 点精确率% | 点假阳性率% | Brier | BCE |',
              '| --- | --- | ---: | ---: | ---: | ---: | ---: |']
    for key, rows in result['evaluation'].items():
        for s in SCENARIOS:
            r = rows[s]; p = r['point_all']
            lines.append(f'| {key} | {s} | {p["recall"]*100:.2f} | {p["precision"]*100:.2f} | {p["false_positive_rate"]*100:.3f} | {r["brier"]:.5f} | {r["bce"]:.5f} |')
    lines += ['', '完整逐点故障站/其他站指标、全部相邻增量区间、校准网格保存在results.json；三种子日志和验证选权重在model_selection.json。未将逐点指标写成事件预警指标。', '',
              '## 审核及运行记录', '',
              '从32份权重重建全部概率、重算训练标准化和输入列、验证选择、8个线性正则化目标及梯度、校准网格、原始标签/分区、事件/逐点/日级统计与2000次日期重采样。完整模型与第二阶段权重哈希、概率和运行点保持一致。预测缓存已在第二阶段审核，本轮校验冻结哈希，不重跑交通模型。', '',
              '首次outputs/congestion-risk-ablation训练完成后，由于全列高级索引改变内存布局产生浮点末位差，严格概率一致检查停止。修正全列评分方式，再在v2目录复用原训练权重；未重训、未改变特征假设或按评测结果调整规则。旧目录保留，v2配置记录所复用权重的哈希。', '',
              '下一步优先诊断逐点BCE与事件起点预警目标的差异；目前先不加大网络，不据此确认原创或整体告警提升。']
    (output/'report.zh-CN.md').write_text('\n'.join(lines)+'\n', encoding='utf-8')
    plot(result, output)


def plot(result, output):
    os.environ.setdefault('MPLBACKEND', 'Agg')
    import matplotlib.pyplot as plt
    variants = list(SUBSETS)
    labels_short = ['Context', 'Forecast', 'P+C', 'P+C+N', 'P+C+N+A', 'Full without A', 'Full without C', 'Full']
    fig, axes = plt.subplots(1, 3, figsize=(13, 5.6), sharey=True)
    y = np.arange(len(variants))
    for ax, field, title, factor in zip(axes, ['warning_recall','detection_recall','false_per_valid_station_day'], ['Advance warning recall (%)','Event detection, including late (%)','False alerts / valid station-day'], [100,100,1]):
        for family, offset, color in [('linear', -.18, '#7294b4'), ('mlp', .18, '#dd8a47')]:
            values = [avg(result['evaluation'][f'{family}_{v}'], field)*factor for v in variants]
            ax.barh(y+offset, values, height=.34, color=color, label='Linear' if family=='linear' else '3-seed MLP')
        ax.set_title(title, fontsize=10); ax.grid(axis='x', alpha=.2); ax.set_axisbelow(True)
    axes[0].set_yticks(y, labels_short); axes[0].invert_yaxis()
    handles, legends = axes[0].get_legend_handles_labels()
    fig.legend(handles, legends, loc='lower center', ncol=2, frameon=False)
    fig.suptitle('Risk-head ablation: calibrated settings, same previously analyzed dates', fontsize=12)
    fig.tight_layout(rect=(0, .07, 1, .94))
    fig.savefig(output/'summary.png', dpi=170); fig.savefig(output/'summary.svg'); plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=OUTPUT)
    output = parser.parse_args().output
    torch.set_num_threads(1); torch.use_deterministic_algorithms(True)
    result = json.loads((output/'results.json').read_text(encoding='utf-8'))
    config = json.loads((output/'config.json').read_text(encoding='utf-8'))
    compare(config, result['config']); compare(config['subsets'], SUBSETS)
    audit = json.loads((output/'audit.json').read_text(encoding='utf-8'))
    assert all(sha256(ROOT/k) == v for k, v in config['sha256'].items())
    assert all(sha256(output/k) == v for k, v in audit['artifact_sha256'].items())
    data = load_data(); parts, names = load_parts(data)
    raw, _, valid, ts, _, _, _, _, day, groups = data
    for partition, a, b, stride in [('training',42,70,3), ('validation',70,77,1), ('calibration',77,91,1), ('evaluation',91,119,1)]:
        hidden_features_check(parts[partition], data)
        p = parts[partition]['natural']; ids = p['origins']
        assert np.array_equal(ids, np.arange(np.searchsorted(day,a)+12, np.searchsorted(day,b)-2, stride))
        window = ids[:,None]+np.arange(-12,3)[None]
        regular = (np.diff(ts[window],axis=1) == np.timedelta64(5,'m')).all(axis=1)
        truth, eligible, _ = labels(raw, valid, ids, regular)
        for s in SCENARIOS:
            q = parts[partition][s]
            assert np.array_equal(q['truth'],truth) and np.array_equal(q['eligible'],eligible)
            _, fault = outage_mask(valid,day,s,groups)
            assert np.array_equal(q['fault'],fault[ids-1])
    with np.load(output/'normalization.npz') as n:
        mean, std = n['mean'], n['std']
    xt, xv = pool(parts['training'],'state'), pool(parts['validation'],'state')
    checked_std = xt.std(axis=0); checked_std[checked_std<1e-5] = 1
    assert np.array_equal(xt.mean(axis=0), mean) and np.array_equal(checked_std,std)
    feature_names = json.loads((output/'features.json').read_text(encoding='utf-8'))
    compare(feature_names,{k:[names[i] for i in cols] for k,cols in SUBSETS.items()})
    y = pool(parts['training'],'truth').astype(np.float32)
    yv = pool(parts['validation'],'truth').astype(np.float32)
    logs = json.loads((output/'model_selection.json').read_text(encoding='utf-8'))
    fitted, gradients = {}, {}
    for variant, columns in SUBSETS.items():
        x = ((xt[:,columns]-mean[columns])/std[columns]).astype(np.float32)
        v = ((xv[:,columns]-mean[columns])/std[columns]).astype(np.float32)
        key = f'linear_{variant}'; model, saved = load_model(output/f'{key}.pt')
        assert saved['dimension']==len(columns) and not saved['nonlinear']
        check_validation(model,saved,v,yv); compare({k:value for k,value in saved.items() if k!='state_dict'},logs[key])
        model.zero_grad(set_to_none=True)
        objective = torch.nn.functional.binary_cross_entropy_with_logits(model(torch.tensor(x)),torch.tensor(y))+saved['selected_alpha']/2*model.layers.weight.square().sum()
        objective.backward(); gradient = max(p.grad.abs().max().item() for p in model.parameters())
        selected = next(r for r in saved['logs'] if r['alpha']==saved['selected_alpha'])
        assert np.isclose(objective.detach().item(),selected['train_objective'],rtol=1e-6,atol=1e-7)
        assert gradient<=1e-4
        gradients[key]=gradient; fitted[key]=[model]
        key=f'mlp_{variant}'; fitted[key]=[]
        for seed in SEEDS:
            model,saved=load_model(output/f'{key}_{seed}.pt')
            assert saved['dimension']==len(columns) and saved['nonlinear'] and saved['seed']==seed
            check_validation(model,saved,v,yv)
            compare({k:value for k,value in saved.items() if k!='state_dict'},next(r for r in logs[key] if r['seed']==seed))
            fitted[key].append(model)
    assert sha256(output/'linear_full.pt')==sha256(OLD/'logistic.pt')
    for seed in SEEDS:
        assert sha256(output/f'mlp_full_{seed}.pt')==sha256(OLD/f'mlp{seed}.pt')
    maximum_error=0.; daily=None
    for partition in ('calibration','evaluation'):
        rebuilt=model_scores(parts[partition],fitted,mean,std)
        with np.load(output/f'scores_{partition}.npz') as saved:
            for key,rows in rebuilt.items():
                for s,p in rows.items():
                    error=float(np.max(np.abs(p-saved[f'{key}_{s}'])))
                    maximum_error=max(maximum_error,error); assert error==0.
        with np.load(OLD/f'scores_{partition}.npz') as old:
            for family, method in [('linear','state_logistic'),('mlp','risk_mlp')]:
                for s in SCENARIOS:
                    assert np.array_equal(rebuilt[f'{family}_full'][s],old[f'{method}_{s}'])
        if partition=='calibration':
            selections={key:choose(key,rows,parts[partition],result['selection']['budgets']) for key,rows in rebuilt.items()}
            compare(selections,result['selection']['methods'])
            compare(result['selection'],json.loads((output/'selection.json').read_text(encoding='utf-8')))
            old_result=json.loads((OLD/'results.json').read_text(encoding='utf-8'))
            compare(result['selection']['budgets'],old_result['selection']['budgets'])
            for family, method in [('linear','state_logistic'),('mlp','risk_mlp')]:
                compare(selections[f'{family}_full'],old_result['selection']['methods'][method])
        else:
            summaries,daily=evaluate(rebuilt,parts[partition],selections)
            compare(summaries,result['evaluation'])
    with np.load(output/'daily_metrics.npz') as saved:
        assert set(saved.files)==set(daily)
        assert all(np.array_equal(values,saved[k]) for k,values in daily.items())
    compare(contrasts(daily),result['contrasts'])
    audit.update({'audit_status':'passed','audit_script_sha256':sha256(Path(__file__)),
                  'all_32_weights_validation_selection_and_losses_recomputed':True,
                  'all_8_linear_objectives_and_gradients_recomputed':True,'recomputed_selected_gradients':gradients,
                  'all_16_calibration_grids_and_choices_recomputed':True,
                  'raw_labels_partition_boundaries_faults_and_feature_visibility_checked':True,
                  'training_normalization_and_all_feature_subsets_recomputed':True,
                  'all_probabilities_rebuilt_from_weights':True,'max_probability_rebuild_error':maximum_error,
                  'full_weights_probabilities_and_choices_equal_previous_stage':True,
                  'all_event_point_daily_statistics_and_intervals_recomputed':True,
                  'forecast_cache_hashes_unchanged_previously_audited':True})
    write_json(output/'audit.json',audit); create_report(result,output)
    print(json.dumps({'audit':audit['audit_status'],'probability_error':maximum_error,'models':len(fitted),'max_linear_gradient':max(gradients.values()),'report':str(output/'report.zh-CN.md')},indent=2))


if __name__=='__main__':
    main()
