"""Download a public METR-LA mirror; record provenance and content hash."""
from pathlib import Path
import hashlib
import json
import urllib.request
import time

ROOT = Path(__file__).resolve().parent
URLS = [
    "https://huggingface.co/datasets/jimmygao3218/METRLA/resolve/main/metr-la.h5",
    "https://github.com/leilin-research/GCGRNN/raw/refs/heads/master/data/METR-LA_traffic_speed/metr-la.h5",
    "https://raw.githubusercontent.com/leilin-research/GCGRNN/master/data/METR-LA_traffic_speed/metr-la.h5",
]
URL = URLS[0]
path = ROOT / "data/raw/metr-la.h5"
path.parent.mkdir(parents=True, exist_ok=True)
if not path.exists():
    temporary = path.with_suffix(".download")
    for URL in URLS:
        print(f"Trying {URL}", flush=True)
        request = urllib.request.Request(URL, headers={"User-Agent": "traffic-recovery-pilot/0.1"})
        try:
            started = time.monotonic()
            with urllib.request.urlopen(request, timeout=20) as response, temporary.open("wb") as output:
                size = 0
                while chunk := response.read(64 * 1024):
                    output.write(chunk)
                    size += len(chunk)
                    if size % (1024 * 1024) == 0:
                        print(f"Downloaded {size // (1024 * 1024)} MiB", flush=True)
                    if time.monotonic() - started > 180:
                        raise TimeoutError("Transfer exceeded three-minute pilot download limit")
            break
        except Exception as error:
            print(f"Mirror failed: {type(error).__name__}: {error}", flush=True)
    else:
        raise RuntimeError("All inspected public METR-LA mirrors failed")
    if temporary.read_bytes()[:8] != b"\x89HDF\r\n\x1a\n":
        raise ValueError("Downloaded content is not an HDF5 file")
    temporary.replace(path)
digest = hashlib.sha256(path.read_bytes()).hexdigest()
metadata = {
    "dataset": "METR-LA traffic speed; public third-party mirror",
    "original_project": "https://github.com/liyaguang/DCRNN",
    "mirror_url": URL,
    "sha256": digest,
    "bytes": path.stat().st_size,
    "notes": "Raw data are ignored by Git; no dataset redistribution license is inferred from a code license.",
}
(ROOT / "data/provenance.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
print(json.dumps(metadata, indent=2), flush=True)
