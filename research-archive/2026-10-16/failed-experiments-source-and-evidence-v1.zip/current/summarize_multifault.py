"""Audit saved multi-fault arrays, generate a Chinese report and scientific plot."""
from __future__ import annotations

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from multifault_pilot import ROOT, calibrated_policies, day_interval, day_macro, sha256, summarize_policy
from recovery_pilot import write_json

OUT = ROOT/"outputs/multifault-pilot"


def main():
    result = json.loads((OUT/"results.json").read_text(encoding="utf-8"))
    config = result["config"]
    events = config["events"]
    checked = []
    for variant, scenarios in result["variants"].items():
        for scenario, previous in scenarios.items():
            saved = np.load(OUT/f"arrays_{variant}_{scenario}.npz")
            policies = json.loads((OUT/f"policies_{variant}_{scenario}.json").read_text(encoding="utf-8"))
            recomputed = calibrated_policies(events["calibration"], config["groups"], saved["calibration_actual"],
                                            saved["calibration_additive"], saved["calibration_fixed"], scenario == "equal_duration")
            if recomputed != policies:
                raise AssertionError("Saved choices must follow validation-only calibration")
            summary, choices, costs = summarize_policy(events["test"], saved["actual"], saved["additive"],
                                                       saved["outage"], policies, saved["fixed"])
            for key in ("cumulative_loss_by_policy", "joint_vs_additive_improvement", "joint_vs_additive_relative_improvement"):
                if summary[key] != previous[key]:
                    raise AssertionError(f"Point estimate changed during audit: {key}")
            # Recompute the ratio CI by resampling its denominator as well.
            summary["per_seed_same_policy"] = previous["per_seed_same_policy"]
            summary["disjoint_max_cumulative_additivity_error"] = previous["disjoint_max_cumulative_additivity_error"]
            delta = costs["shortest_time"]-costs["joint"]
            mean, interval = day_interval(delta, events["test"])
            summary["joint_vs_shortest_time_improvement"] = float(mean)
            summary["joint_vs_shortest_time_improvement_ci"] = interval.tolist()
            summary["joint_vs_shortest_time_relative_improvement"] = float(mean/day_macro(costs["shortest_time"], events["test"]))
            summary["joint_vs_offline_optimal_remaining_gap_fraction"] = (
                summary["cumulative_loss_by_policy"]["joint"]-summary["cumulative_loss_by_policy"]["offline_joint_oracle"])/summary["cumulative_loss_by_policy"]["joint"]
            scenarios[scenario] = summary
            checked.append(f"{variant}/{scenario}: validation-only policy + all point estimates + paired-date ratio CI")
    for variant, entries in config["weights_sha256"].items():
        folder = "recovery-pilot" if variant == "residual" else "recovery-pilot-no-residual"
        for seed, checksum in entries.items():
            if sha256(ROOT/"outputs"/folder/f"model_seed{seed}.pt") != checksum:
                raise AssertionError("Archived model weight changed")
    if sha256(ROOT/"docs/multifault_protocol.zh-CN.md") != config["protocol_sha256"]:
        raise AssertionError("Pre-analysis protocol changed")
    if sha256(ROOT/"data/raw/metr-la.h5") != config["data_sha256"]:
        raise AssertionError("Raw data changed")
    result["checks"]["saved_arrays_and_validation_policy_audit"] = True
    result["checks"]["protocol_data_and_model_hashes"] = True
    result["statistical_note"] = "Both numerator and denominator of relative gain are resampled with the same day clusters; intervals exploratory."
    write_json(OUT/"results.json", result)
    write_json(OUT/"audit.json", {"checks": checked, "integrity": "passed", "policy_fitting": "no test labels or counterfactual test readings"})

    primary = result["variants"]["residual"]["heterogeneous_duration"]
    replica = result["variants"]["no_residual"]["heterogeneous_duration"]
    lines = ["# 多站故障与维修安排：第二轮探索性实验", "", "日期：2026-10-10（北京时间）。", "",
             "**结论：在当前24站小预测器与合成维修情景中，联合恢复收益确实会改变部分离线选择，但它对冻结维修策略的平均改善非常小，未通过继续开发的3%资源筛选线。不能据此认定论文创新已经成立。**", "",
             "## 承接第一轮的原因", "",
             "第一轮的两个模型在恢复10分钟后已获得约94%–95%的完整历史收益，长时间历史补齐的价值尚未得到支持。本轮改检验多站信息替代/互补，并实际推进预测时刻与班组完工时间，而不是拼接不同预测时刻的单站恢复曲线。", "",
             "这不等于用测试结果反复筛选最佳设定：本轮情景、主比较与3%筛选线在运行前写入协议，但原测试周此前已经使用过，因此全部结果仍属探索性。3%没有现场业务成本依据，仅用于决定是否投入下一阶段。", "",
             "## 实验设置", "",
             "- 沿用METR-LA的24个随机站、42天分区及两种结构各3个已保存模型。没有重新训练预测器。",
             "- 12组三站同时故障：4组训练图共享输出最多、4组输出完全不重叠、4组一般随机。不是地理邻近类别或实测故障概率。",
             f"- 验证校准{len(events['calibration'])}个情景；测试维修模拟{len(events['test'])}个情景、{len(primary['days'])}个日期。固定时刻机制检查另有{primary['mechanism']['cases']}个可评案例，覆盖6个日期。",
             "- 单班组；主情景10/20/30分钟处理时间，次情景均20分钟。每个任务必须完成，观察120分钟；没有移动耗时、抢占、维修失败或真实工单。",
             "- 完工后的第一个新样本在对应采样时刻开放；预测输入只到预测时刻前一步，旧缺失历史不补回。",
             "- 主要指标是24站网络预测MAE的离散累计损失：5分钟×各次有效预测MAE。所有顺序使用相同目标mask与可评时刻。它不是车辆延误、现场费用或交通控制改善。",
             "- 可实施策略只根据已知组别、起始时段和设定工时，用验证周校准后固定；没有当前观测自适应，也不是滚动重规划。离线最优也仅限本轮6种无空闲固定顺序，不是所有动态策略的最优界。",
             "- 三种子先平均、日内情景等权、日期等权；按日期聚类bootstrap2000次。相对改善的分子与分母一起重采样。区间只描述这批固定情景的日期变化。", "",
             "## 原始目标缺失与覆盖", "",
             "每个起点计划24次预测；无有效目标的时刻统一不计分，未重新选择测试日期。4月8日和4月9日存在较多原始目标缺失，因此累计损失只覆盖可观测部分，不能解释为全120分钟的完整损失。所有策略在同一案例上的覆盖完全一致。", "",
             "| 测试日期 | 可评起点数 | 各起点有效预测次数（上限24） |", "|---|---:|---|"]
    for date in primary["days"]:
        one_group = [e for e in events["test"] if e["day"] == date and e["group"] == 0]
        lines.append(f"| {date} | {len(one_group)} | {', '.join(str(len(e['usable_steps'])) for e in one_group)} |")
    lines += ["", "## 联合收益是否影响选择", "",
             "固定预测时刻只恢复各站最近两条观测。G(S)=全部故障损失−恢复集合S后的损失；交互为G({i,j})−G({i})−G({j})。负值是误差收益上的替代，正值是互补；不是交通因果效果。", "",
             "| 模型 | 单站加总与联合最优两站选择不同 | 选择差异的平均MAE代价 | 平均绝对二阶交互 |", "|---|---:|---:|---:|"]
    for label, q in (("有残差", primary), ("去残差", replica)):
        m = q["mechanism"]
        lines.append(f"| {label} | {100*m['pair_choice_difference_fraction']:.2f}% | {m['pair_choice_actual_regret']:.6f} | {m['mean_absolute_pair_interaction']:.6f} |")
    lines += ["", "这些逐案例选择使用隐藏真实观测和未来目标评价，全部属于离线诊断，不能冒充在线策略。不同不自动意味着损失很大。", "",
              "| 主模型情景类型 | 两站选择差异比例 | 平均绝对二阶交互 |", "|---|---:|---:|"]
    for category, label in (("high_overlap", "共享输出多"), ("disjoint_outputs", "输出不重叠"), ("random", "一般随机")):
        m = primary["by_category"][category]["mechanism"]
        lines.append(f"| {label} | {100*m['pair_choice_difference_fraction']:.2f}% | {m['mean_absolute_pair_interaction']:.6f} |")
    lines += ["", "不重叠组的交互接近浮点误差，与单层图聚合模型结构一致。它是实现核验与适用边界，不是独立创新。", "",
              "## 维修策略的实际比较", "",
              "可加轨迹规划和联合轨迹规划都枚举相同6种顺序、使用相同完工时间和恢复历史；前者用单站损失变化相加，后者保留联合mask的效果。两者都只用验证周确定选择。", "",
              "| 模型与工时 | 联合相对可加累计损失改善 | 按日期95%探索性区间 |", "|---|---:|---:|"]
    plot_values, plot_intervals, plot_labels = [], [], []
    for variant, label in (("residual", "有残差"), ("no_residual", "去残差")):
        for scenario, time_label in (("heterogeneous_duration", "异质工时"), ("equal_duration", "等工时")):
            q = result["variants"][variant][scenario]
            v = q["joint_vs_additive_relative_improvement"]*100
            lo, hi = np.array(q["joint_vs_additive_relative_ci"])*100
            lines.append(f"| {label}，{time_label} | {v:+.5f}% | [{lo:+.5f}%, {hi:+.5f}%] |")
            plot_values.append(v); plot_intervals.append([lo, hi]); plot_labels.append(f"{'Residual' if variant == 'residual' else 'No residual'}\n{'10/20/30 min' if scenario == 'heterogeneous_duration' else '20/20/20 min'}")
    lines += ["", "正数表示联合规划更好，负数表示更差。本轮平均相对改善均小于0.01%；主模型异质工时虽区间不含零，仍远低于资源筛选线，去残差复核的区间包含零。", "",
              "| 异质工时下的策略 | 有残差累计损失 | 去残差累计损失 |", "|---|---:|---:|"]
    labels = {"shortest_time": "最短维修时间优先", "gain_per_time": "验证单站收益/工时", "additive": "验证可加轨迹规划", "joint": "验证联合轨迹规划", "offline_additive_oracle": "离线可加诊断（额外信息）", "offline_joint_oracle": "离线联合最优（额外信息）"}
    for name, label in labels.items():
        lines.append(f"| {label} | {primary['cumulative_loss_by_policy'][name]:.5f} | {replica['cumulative_loss_by_policy'][name]:.5f} |")
    lines += ["", f"异质工时下，联合策略相对最短工时策略的改善为{primary['joint_vs_shortest_time_relative_improvement']*100:+.5f}%（有残差）和{replica['joint_vs_shortest_time_relative_improvement']*100:+.5f}%（去残差）：均没有超过最简单的工时基线。不能只拿较弱基线报正向结果。", "",
              f"主模型联合与可加校准顺序在按日等权后{primary['calibrated_order_difference_fraction']*100:.2f}%的情景中不同；实际有{primary['cases_joint_better']}个案例更好、{primary['cases_joint_worse']}个更差，其余相同。", "",
              f"离线联合最优相对离线可加选择的平均损失差为{primary['offline_joint_vs_offline_additive_regret']:.5f}，只约占离线可加损失的{100*primary['offline_joint_vs_offline_additive_regret']/primary['cumulative_loss_by_policy']['offline_additive_oracle']:.4f}%。即使拥有每个案例的真实未来标签，交互建模增量在这套小模型中仍小。", "",
              f"另一方面，冻结联合策略到离线联合最优还有约{primary['joint_vs_offline_optimal_remaining_gap_fraction']*100:.3f}%差距。这个诊断提示当前情景下可优化空间有限；不能把离线差距当成任何在线新策略能取得的改善。", "",
              "## 对论文定位的影响", "",
              "本轮没有通过预先写定的继续筛选条件。不建议以‘长窗口连续恢复’或‘多站联合收益显著提升维修’锁定题目。可以保留恢复模拟器、可加边界和负面结果，作为后续研究与开源评估的基础。", "",
              "不能从负面结果推断所有交通检测器维护都不值得优化：当前只有24站、单层共享MLP、3故障、短评价期、合成工时和一个数据片段；网络MAE还含大量不受故障影响的预测误差。较大故障簇、不同传播结构、业务权重或真实工单可能产生不同结果，但应新建协议并用未使用过的时间段验证，不能把这些变成在本测试周上找显著结果的理由。", "",
              "当前可谨慎表达的发现是：在这组冻结预测器与规定情景下，排序差异存在，但平均决策代价很小；优化收益需要与强工时基线一起判断。这是探索性适用边界，尚不足以单独支撑所期待的方法创新。", "",
              "下一阶段的合理顺序：先用未见时间段与更强缺测预测器检查故障是否带来足够大的决策损失，再决定是否开发基于当前可见观测的条件价值估计器。一次增加一个因素并提前规定情景与指标。真实成本、拥堵识别等下游目标需要业务依据，不能临时替换主指标制造改善。", "",
              "## 文献定位补充", "",
              "信息替代、冗余和条件边际收益已有研究基础，联合选点不能当作本项目原创。[NMI–IGNNK原论文](https://arxiv.org/pdf/2609.13212)的Algorithm 1和第3节明确包含边际信息覆盖与冗余惩罚。网页摘要与本次获取的PDF在具体数值上有差异，本报告只引用其方法内容，不沿用未经版本对齐的性能数字。", "",
              "缺测mask与依赖可用性调整空间补偿也有直接先例：[ACSC–GCRN，2026-09-23](https://link.springer.com/article/10.1007/s10791-026-10611-1)，见摘要与第4节。因此本实验中的mask图预测器用作评估工具，不能宣称其组件原创。", "",
              "单维修人员、异质维修/切换耗时和rollout已见于[Tian与Shone（2026）](https://arxiv.org/abs/2602.19277)。本文若后续继续，必须限定贡献到经过实证检验的交通任务价值估计或适用边界。当前校准表不是该论文的完整复现，也不是它的替代算法。", "",
              "## 复跑与可核查文件", "", "```powershell", "& .\\.venv\\Scripts\\python.exe multifault_pilot.py --prepare-only", "& .\\.venv\\Scripts\\python.exe multifault_pilot.py", "& .\\.venv\\Scripts\\python.exe summarize_multifault.py", "```", "",
              "- `config.json`：运行前冻结的情景、协议/数据/模型哈希、分区和所有顺序。",
              "- `policies_*.json`：只用验证段的校准表与选定顺序。",
              "- `arrays_*.npz`：全部6种顺序的真实/可加累计损失与固定时刻8种子集损失，包含验证与测试数组。",
              "- `episode_results.csv`：逐案例策略、损失与差值。",
              "- `audit.json`：由已保存数组独立重算校准策略及点估计，核对协议、模型和数据哈希。",
              "- `research_summary.png`/`.svg`：汇总图。", "",
              "已通过mask隐藏值不变性、完工前历史不开放、目标mask统一、穷举最优界、输出不重叠可加性与校准策略复算。原36个归档文件在开始本轮前通过哈希核对。", ""]
    (OUT/"report.zh-CN.md").write_text("\n".join(lines), encoding="utf-8")
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.7), layout="constrained")
    v = np.array(plot_values)
    intervals = np.array(plot_intervals)
    axes[0].errorbar(np.arange(4), v, yerr=np.stack([v-intervals[:, 0], intervals[:, 1]-v]), fmt="o", capsize=5, color="#2563a6")
    axes[0].set_xticks(np.arange(4), plot_labels, fontsize=8)
    axes[0].axhline(0, color="gray", linewidth=.8)
    axes[0].set(ylabel="Relative cumulative-loss reduction (%)", title="Joint vs additive calibration\nPaired-day exploratory 95% intervals")
    categories = ["high_overlap", "random", "disjoint_outputs"]
    fractions = [100*primary["by_category"][k]["mechanism"]["pair_choice_difference_fraction"] for k in categories]
    axes[1].bar(np.arange(3), fractions, color=["#cb6b45", "#438d9a", "#7b8c9b"])
    axes[1].set_xticks(np.arange(3), ["High output overlap", "Random", "Disjoint outputs"], fontsize=8)
    axes[1].set(ylabel="Two-station choice differs (%)", title="Diagnostic choice changes\nResidual model; real hidden values available offline")
    for i, value in enumerate(fractions):
        axes[1].text(i, value+.4, f"{value:.2f}%", ha="center", fontsize=9)
    axes[1].set_ylim(0, max(fractions)*1.2+1)
    for ax in axes:
        ax.grid(axis="y", alpha=.2)
    fig.savefig(OUT/"research_summary.png", dpi=180)
    fig.savefig(OUT/"research_summary.svg")
    plt.close(fig)
    print(json.dumps({"audit": "passed", "report": str(OUT/"report.zh-CN.md"),
                      "primary_relative_gain_percent": primary["joint_vs_additive_relative_improvement"]*100,
                      "primary_relative_ci_percent": (np.array(primary["joint_vs_additive_relative_ci"])*100).tolist(),
                      "screen_passed": result["passes_exploratory_research_screen"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
