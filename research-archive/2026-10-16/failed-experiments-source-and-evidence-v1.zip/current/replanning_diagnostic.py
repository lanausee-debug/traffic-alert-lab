"""Post-hoc nested feasible-set oracle diagnostic. Not an online policy."""
import json
import numpy as np
from recovery_pilot import ROOT, write_json
from multifault_pilot import ORDERS, day_interval, day_macro, relative_day_interval, sha256
from state_value_pilot import ridge_predict


def diagnose(actual, healthy, choices, events):
    rows = np.arange(len(events))
    first = np.array([ORDERS[int(c)][0] for c in choices])
    permitted = np.array([[order[0] == station for order in ORDERS] for station in first])
    masked = np.where(permitted, actual, np.inf)
    conditional_choice = masked.argmin(axis=1)
    ref = actual[rows, choices]
    conditional = actual[rows, conditional_choice]
    oracle = actual.min(axis=1)
    if np.any(conditional > ref+1e-8) or np.any(oracle > conditional+1e-8): raise AssertionError('Nested bound broken')
    gain = ref-conditional; first_constraint_gap = conditional-oracle; all_gain = ref-oracle
    if not np.allclose(gain+first_constraint_gap, all_gain, atol=1e-10): raise AssertionError('Space identity broken')
    mean, ci = day_interval(gain, events)
    excess, excess_ci = day_interval(ref-healthy, events)
    total = float(day_macro(all_gain, events))
    return {'events': len(events), 'days': len({e['day'] for e in events}),
            'reference_cost': float(day_macro(ref, events)), 'reference_fault_added': float(excess), 'reference_fault_added_ci': excess_ci.tolist(),
            'fixed_first_oracle_cost': float(day_macro(conditional, events)), 'full_oracle_cost': float(day_macro(oracle, events)),
            'remaining_order_absolute_space': float(mean), 'remaining_order_space_ci': ci.tolist(),
            'remaining_order_fault_added_fraction': float(mean/excess) if excess > 0 else None,
            'remaining_order_fault_added_ci': relative_day_interval(gain, ref-healthy, events).tolist() if excess_ci[0] > 0 else None,
            'full_oracle_absolute_space': total, 'remaining_order_share_of_full_space': float(mean/total) if total > 0 else None,
            'first_station_constraint_absolute_gap': float(day_macro(first_constraint_gap, events)),
            'conditional_choice_change_fraction': float(day_macro((conditional_choice != choices).astype(float), events))}, conditional_choice


def main():
    source = ROOT/'outputs/state-value-pilot'; output = ROOT/'outputs/replanning-diagnostic'; output.mkdir(parents=True, exist_ok=True)
    config = json.loads((source/'config.json').read_text(encoding='utf-8'))
    protocol = ROOT/'docs/replanning_diagnostic_protocol.zh-CN.md'
    result = {'status': 'exploratory_reuse_of_already_analyzed_dates', 'protocol_sha256': sha256(protocol),
              'source_config_sha256': sha256(source/'config.json'), 'script_sha256': sha256(__file__ and ROOT/'replanning_diagnostic.py'),
              'sources': {}, 'models': {}, 'timing': {'age_at_completion': 0, 'age_one_step_after_completion': 1, 'reading_wait_minutes': 5},
              'checks': {'nested_lower_bounds': True, 'space_decomposition': True, 'no_new_independent_dates': True}}
    with np.load(source/'features.npz') as features:
        for variant in ('graph_tcn_candidate', 'mlp_baseline'):
            selection = json.loads((source/f'selection_{variant}.json').read_text(encoding='utf-8'))
            if selection['reference'] != 'calendar_ridge': raise AssertionError('Expected frozen reference changed')
            for path in (source/f'selection_{variant}.json', source/f'ridge_{variant}.npz', source/f'choices_{variant}.npz',
                         ROOT/'outputs/fresh-holdout-pilot'/f'arrays_{variant}.npz', source/f'labels_{variant}_validation.npz', source/f'labels_{variant}_test.npz'):
                result['sources'][str(path.relative_to(ROOT))] = sha256(path)
            with np.load(source/f'ridge_{variant}.npz') as coefs:
                training_choices = ridge_predict(features['training_calendar'], coefs['calendar_ridge']).argmin(axis=1)
            with np.load(ROOT/'outputs/fresh-holdout-pilot'/f'arrays_{variant}.npz') as labels:
                training = {k: np.concatenate([labels['calibration_'+k], labels[k]]) for k in ('actual', 'healthy')}
            table = {}; saved = {}
            with np.load(source/f'choices_{variant}.npz') as stored_choices:
                for part in ('training', 'validation', 'test'):
                    if part == 'training': labels = training; choice = training_choices
                    else:
                        with np.load(source/f'labels_{variant}_{part}.npz') as archive:
                            labels = {k: archive[k] for k in ('actual', 'healthy')}
                        choice = stored_choices[part+'_calendar_ridge']
                    table[part], condition = diagnose(labels['actual'], labels['healthy'], choice, config['events'][part])
                    saved[part+'_reference_choice'] = choice; saved[part+'_conditional_oracle_choice'] = condition
            result['models'][variant] = table
            np.savez_compressed(output/f'choices_{variant}.npz', **saved)
    write_json(output/'results.json', result)
    print(json.dumps(result['models'], ensure_ascii=False, indent=2))


if __name__ == '__main__': main()
