"""Report partial discrimination signal without promoting it to alarm service gains."""
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
import alarm_start_separability as probe
import calibration_fragility as common
ROOT=probe.ROOT;OUT=probe.OUT
def number(v):return '不可计算' if v is None else f'{v:.3f}'
def pct(v):return '不可计算' if v is None else f'{100*v:.1f}%'


def main():
    r=common.read(OUT/'results.json');a=common.read(OUT/'audit.json');assert a['passed']
    assert not r['natural_diagnostic_gate']['passed'] and not r['new_alarm_policy_evaluated']
    # Record the already-observed successful tool run; do not rerun unchanged tests.
    common.write(OUT/'test_receipt.json',{'recorded_at_utc':datetime.now(timezone.utc).isoformat(),
        'command':'.venv/Scripts/python.exe -m unittest discover -s tests -p test_alarm_start_separability.py -v',
        'tests_run':9,'observed_exit_code':0,'passed':True,
        'basis':'Successful tool output before main pilot fit; tests are not rerun by this report generator',
        'test_source_sha256':common.sha(ROOT/'tests/test_alarm_start_separability.py')})
    training=common.read(OUT/'training.json');samples=common.load(OUT/'training_pooled_samples.npz')
    labels={'risk_validation7':'风险验证7日','calibration_week1_7':'校准前7日','calibration_week2_7':'校准后7日'}
    methods={'constant_prior':'训练正例比例常数','fixed_risk':'原固定风险分数',
        'score_logistic':'只看风险分数的线性判别','residual_logistic':'只看历史误差的线性判别','state_logistic':'全部30项状态的线性判别'}
    lines=['# 告警起点可分性：有部分开发信号，联合诊断门槛未通过','',
        '日期：2026-10-15。**30项状态特征在三个后续开发时间块均有额外ROC AUC信号，但一周的AP略低于简单参照，未通过事先固定的联合诊断。** 没有上线告警过滤器，没有新的告警回放收益，也没有启动新站点测试。','',
        '## 本轮在问什么','',
        '原全局一次确认规则刚开启告警时，已有信息能否判断它之后会成为一次获记预警，还是一次误报告警？正例是按原匹配规则获记的代理提前5/10/15分钟预警，负例是同一规则判定的误报起点。迟报、重复、边界删失和不可判断告警均不属于这个二分类子任务。','',
        '标签当然需要之后的真值才能离线判定；但模型输入只取当时已知的预测/历史/邻站/日历/缺失状态、可观测历史残差和固定全局风险。没有把未来车速、事件时长、匹配结果、告警之后持续多久或提前量作为输入。30项中没有站点编号。','',
        '这个筛选后的任务不涵盖全部真实拥堵事件，更不涵盖所有上线告警类型。即使二分类很好，也不能直接推算系统检出率、误报预算或交通管理收益。','',
        '## 固定的训练与检查方式','',
        '只在原风险训练28日的告警起点上拟合。三情景合并450条训练记录，其中147条获记预警、303条误报，对应167个不同(node, alarm_origin)起点键；不同情景高度相关，不是450个独立事件。原全局风险头本身也曾用这28日拟合，训练成绩不作为泛化证据。','',
        '拟合三个固定L2逻辑回归探针：风险分数1维、历史残差与缺失标志2维、全部状态30维，分别只有2/3/31个参数。PyTorch float64 LBFGS，惩罚系数固定0.1；均值、尺度只从训练起点拟合，不搜索惩罚、结构或特征组合。可观测历史残差按既定规则构造，裁剪到±20 mph，缺失置0并另给缺失标志。','',
        '三个探针、归一化与分界线全部保存后，才加载本轮后续检查块。时间块是风险验证7日、校准前7日、校准后7日，按真实日历划分、窗口不跨原分区，没有随机拆样本。它们与探针拟合段在时间上分开，但**此前均被本项目用于开发，不能称新的独立测试**。','',
        '## 自然观测情景：三块结果','',
        'ROC AUC衡量把获记预警排在误报前面的能力：0.5相当于无区分的排序，1为完全分开，不能把0.818说成81.8%准确率。AP是对正例排序的另一项检查，受正例比例影响，应在同一块内比较。','',
        '| 时间块 | 获记预警/误报 | 最强简单参照AUC | 全状态AUC | 最强简单参照AP | 全状态AP |',
        '| --- | ---: | ---: | ---: | ---: | ---: |']
    for block,by_s in r['metrics'].items():
        m=by_s['natural'];gate=r['natural_diagnostic_gate']['by_natural_scenario_block'][block]
        state=m['state_logistic']
        lines.append(f"| {labels[block]} | {state['credited_warnings']}/{state['false_starts']} | {number(gate['strongest_baseline_auc'])} | {number(state['roc_auc'])} | {number(gate['strongest_baseline_AP'])} | {number(state['average_precision'])} |")
    lines+=['',
        '表中的最强简单参照，是原风险分数、只看风险分数的线性探针、只看误差的线性探针在每项指标上的较高值。它是保守的事后诊断包络，不是一条可以上线执行的“挑最好参照”规则，也不是用来选本轮模型。','',
        '预定联合诊断要求三个自然情景时间块分别满足：至少10正/10负；全状态AUC≥0.70且比参照包络至少高0.05；AP不低于参照包络。三个时间块的AUC要求均满足，但校准前7日AP=0.6122，低于参照0.6229约0.0107，所以联合诊断未通过。不删除这一项，不改门槛，不补试其他模型。','',
        '每块只有23至36条自然情景起点，且同站同日具有相关性。本轮只设点诊断，没有显著性或因果主张；有额外排序信号不等于已证实可重复泛化，也不能从未通过推断所有现有特征都没有信息。','',
        '## 自然情景各参照明细','',
        '| 时间块 | 方法 | ROC AUC | AP |',
        '| --- | --- | ---: | ---: |']
    for block,by_s in r['metrics'].items():
        for method,label in methods.items():
            m=by_s['natural'][method]
            lines.append(f"| {labels[block]} | {label} | {number(m['roc_auc'])} | {number(m['average_precision'])} |")
    lines+=['','原风险模型预测的是持续低速代理概率，不能自动当成“这次告警会获记预警”的概率。单变量探针可以学习相反的排序方向，因此不能只拿表现较弱的原分数作为参照。原分数的Brier/BCE在此改变了目标含义，不作为其原始概率校准质量的评价。','',
        '## 固定分界线会不会误删真实预警','',
        '各探针分界线只根据训练数据固定：在至少保留95%训练获记预警的条件下取最高阈值。之后各块不调分界线。下表是全状态探针对已筛选子任务的保留/排除比例，**不是重放后的告警服务指标**。','',
        '| 时间块 | 获记预警保留 | 误报起点排除 | ≥10分钟获记预警保留 |',
        '| --- | ---: | ---: | ---: |']
    for block,by_s in r['retention'].items():
        row=by_s['natural']['state_logistic']
        lines.append(f"| {labels[block]} | {pct(row['credited_warnings_retained'])} | {pct(row['false_starts_rejected'])} | {pct(row['R10_credited_starts_retained'])} |")
    lines+=['',
        '风险验证7日保留4/5条原≥10分钟代理预警，损失1条；校准前7日本来就没有该类获记预警，保留率分母为0，报告不可计算；校准后7日保留全部4条。不能把“排除了30%–41%的误报样本”直接宣传成线上误报下降相同比例，因为样本排除了迟报/重复等类型，而且过滤会改变告警匹配过程。','',
        '## 人工缺失情景','',
        '| 时间块 | 自然AUC | 单站缺失AUC | 成组缺失AUC |',
        '| --- | ---: | ---: | ---: |']
    for block,by_s in r['metrics'].items():
        values=[number(by_s[s]['state_logistic']['roc_auc']) for s in ('natural','single_outage','group_outage')]
        lines.append(f"| {labels[block]} | {' | '.join(values)} |")
    lines+=['','缺失情景只分开报告，没有据此调参，也不视为独立人群。完整AP、类别数量和保留率在results.json。','',
        '## 核查与下一步','',
        '9项针对性测试通过：未来标签/有效性/身份列不影响特征、未来输入不改变前缀、缺失残差与裁剪、任务类型排除、AUC/AP并列分数、无分母、训练分界线、固定优化收敛和分块联合门槛。独立审计重建全部样本/标签，重算训练归一化与目标梯度，核对45组AUC/AP、固定分界线、时序分区和源哈希。','',
        '此前深度前端和风险头保持原样。本轮新增的是3个小线性探针，不是新的深度网络或交通工程原创算法。原论文主检验和后续失败记录全部保留，GitHub/线上Demo仍为v7。真实特征、探针权重与错例只本地保存。','',
        '本轮能支持继续研究完整状态，而不支持直接部署过滤器。若继续，优先保持这3个判别器及其分界线固定，检查同一判别器在已看过站点缓存上的探索性稳定性；这些站点已参与前轮分析，不能再包装成独立确认。不得用该检查挑权重、阈值或改写本轮失败门槛。新的独立验证仍需另行冻结安排。本轮尚未执行站点迁移分析。','']
    (OUT/'report.zh-CN.md').write_text('\n'.join(lines),encoding='utf-8')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    blocks=list(r['metrics']);positions=np.arange(3)
    fig,axes=plt.subplots(1,2,figsize=(11,4.7),facecolor='#f5f8fa')
    for ax,(metric,title,gatekey) in zip(axes,[('roc_auc','ROC AUC (not accuracy)','strongest_baseline_auc'),('average_precision','Average precision','strongest_baseline_AP')]):
        baseline=[r['natural_diagnostic_gate']['by_natural_scenario_block'][b][gatekey] for b in blocks]
        state=[r['metrics'][b]['natural']['state_logistic'][metric] for b in blocks]
        ax.bar(positions-.17,baseline,width=.34,color='#8297ab',label='Simple baseline envelope')
        ax.bar(positions+.17,state,width=.34,color='#137c83',label='30-feature fixed probe')
        ax.set_xticks(positions,['Validation 7d','Calibration W1','Calibration W2'],fontsize=9)
        ax.set_ylim(0,1);ax.set_title(title,fontsize=12);ax.spines[['top','right']].set_visible(False)
        for x,v in zip(positions-.17,baseline):ax.text(x,v+.015,f'{v:.3f}',ha='center',fontsize=9)
        for x,v in zip(positions+.17,state):ax.text(x,v+.015,f'{v:.3f}',ha='center',fontsize=9)
    axes[0].legend(frameon=False,loc='lower left',fontsize=8)
    fig.suptitle('Alarm-start discrimination: partial signal; joint diagnostic screen FAILED',fontsize=12)
    fig.text(.5,.025,'Reused development blocks / 36, 23, 28 natural alarm starts. Conditional task only; no alarm policy gain measured.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.08,1,.91));fig.savefig(OUT/'comparison.png',dpi=150);plt.close(fig)
    print({'report':str(OUT/'report.zh-CN.md'),'tests_observed_passed':9,'diagnostic_passed':False})


if __name__=='__main__':main()
