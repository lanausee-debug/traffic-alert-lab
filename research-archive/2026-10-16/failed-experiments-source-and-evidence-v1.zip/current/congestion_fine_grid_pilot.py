"""Uniform finer calibration grids, frozen scores, and one selected evaluation replay."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import time
import numpy as np
import torch
from recovery_pilot import ROOT,write_json
from multifault_pilot import sha256
from congestion_alert_pilot import SCENARIOS,event_stats
from congestion_risk_pilot import PROB_THRESHOLDS,prepare_partition,summary_key,online_alarm
from congestion_ablation import OLD,load_data
from congestion_density_pilot import (OUTPUT as DENSITY,ONSET,METHODS,SIMPLE,saved_targets,
    evaluate_with_leads,difference,reference_method)
from congestion_calibration_diagnostic import grid_key

OUTPUT=ROOT/'outputs/congestion-fine-grid-pilot'
PROB_FINE=sorted(set(PROB_THRESHOLDS+[i/1000 for i in range(10,901,5)]))
SPEED_COARSE=[-float(v) for v in np.arange(15,60.1,2.5)]+[1000.]
SPEED_FINE=[-i/2 for i in range(30,121)]+[1000.]


def thresholds(method,fine=True):
    return (SPEED_FINE if fine else SPEED_COARSE) if method=='dense_speed' else (PROB_FINE if fine else PROB_THRESHOLDS)


def load_partition(data,name):
    a,b={'calibration':(77,91),'evaluation':(91,119)}[name]; day=data[8]
    start,end=int(np.searchsorted(day,a)),int(np.searchsorted(day,b))
    return prepare_partition(name,start,end,1,data,[],OLD)[0]


def frozen_scores(partition):
    with np.load(DENSITY/f'scores_{partition}.npz') as saved:
        return {m:{s:saved[f'{m}_{s}'] for s in SCENARIOS} for m in METHODS}


def choose_fine(method,scores,parts,budgets):
    grid=[]; candidates=[]; daily={}
    for i,t in enumerate(thresholds(method)):
        for c in (1,2):
            by_s={}
            for s in SCENARIOS:
                p=parts[s]; alarm=online_alarm(scores[s],t,c)
                stats,days,_=event_stats(p['truth'],p['eligible'],alarm,p['day_ids'])
                by_s[s]={k:stats[k] for k in ('warning_recall','false_per_valid_station_day','warning_lead_mean_minutes')}
                daily[f'{method}_{grid_key(t,c)}_{s}']=days
            feasible=all(by_s[s]['false_per_valid_station_day']<=budgets[s]+1e-12 for s in SCENARIOS)
            row={'threshold':t,'confirmation':c,'feasible':feasible,'by_scenario':by_s}; grid.append(row)
            if feasible: candidates.append(((*summary_key(list(by_s.values())),c,i),row))
    assert candidates
    return {'selected':min(candidates,key=lambda p:p[0])[1],'grid':grid},daily


def comparisons(fine_daily,coarse_daily,reference):
    a=np.stack([fine_daily[f'dense_update_mlp_{s}'] for s in SCENARIOS])
    result={}
    for key,baseline,source in [('fine_dense-coarse_dense','dense_update_mlp',coarse_daily),
                                ('fine_dense-fine_reference',reference,fine_daily)]:
        b=np.stack([source[f'{baseline}_{s}'] for s in SCENARIOS])
        result[key]={'candidate':'dense_update_mlp_fine','baseline':baseline,'baseline_grid':'coarse' if source is coarse_daily else 'fine',**difference(a,b)}
    return result


def nonmonotonic_example():
    truth=np.zeros((20,1),bool); eligible=np.ones_like(truth); scores=np.zeros((20,1),np.float32)
    scores[4:7,0]=[.3,.15,.3]; daily=np.zeros(20,int)
    a=event_stats(truth,eligible,online_alarm(scores,.1,1),daily)[0]
    b=event_stats(truth,eligible,online_alarm(scores,.2,1),daily)[0]
    assert (a['false'],b['false'])==(1,2)
    return {'lower_threshold':.1,'higher_threshold':.2,'lower_false_alerts':int(a['false']),
            'higher_false_alerts':int(b['false']),'scores_inside_run':[.3,.15,.3]}


def nonmonotonic_counts(daily):
    result={}
    for m in METHODS:
        result[m]={}
        for c in (1,2):
            values=sorted(thresholds(m))
            result[m][str(c)]={s:int((np.diff([daily[f'{m}_{grid_key(t,c)}_{s}'][:,4].sum() for t in values])>0).sum()) for s in SCENARIOS}
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__); parser.add_argument('--output',type=Path,default=OUTPUT)
    parser.add_argument('--prepare-only',action='store_true'); args=parser.parse_args(); output=args.output
    output.mkdir(parents=True,exist_ok=True)
    paths=[Path(__file__),ROOT/'docs/congestion_fine_grid_protocol.zh-CN.md',ROOT/'congestion_risk_pilot.py',
           ROOT/'congestion_alert_pilot.py',ROOT/'congestion_density_pilot.py',ROOT/'congestion_objective_diagnostic.py',
           ROOT/'congestion_onset_pilot.py',ROOT/'congestion_ablation.py',ROOT/'congestion_calibration_diagnostic.py',
           ROOT/'state_value_pilot.py',ROOT/'recovery_pilot.py',ROOT/'data/raw/metr-la.h5',
           ROOT/'outputs/recovery-pilot/config.json',ROOT/'outputs/multifault-pilot/config.json',OLD/'normalization.npz']
    for source in (OLD,ONSET,DENSITY):
        paths += [source/name for name in ('config.json','selection.json','audit.json','model_selection.json')]
        paths += list(source.glob('*.pt'))
    paths += [DENSITY/name for name in ('results.json','scores_calibration.npz','scores_evaluation.npz','daily_metrics.npz','event_records.json')]
    paths += [ONSET/f'targets_{p}.npz' for p in ('calibration','evaluation')]
    paths += [ROOT/'outputs/congestion-alert-pilot-v2'/f'predictions_{p}.npz' for p in ('calibration','evaluation')]
    config={'date':'2026-10-10','exploratory':True,'all_dates_previously_used':True,'no_training':True,'methods':METHODS,
            'fine_probability_thresholds':PROB_FINE,'fine_speed_score_thresholds':SPEED_FINE,
            'simple_candidates':SIMPLE,'primary_candidate':'dense_update_mlp','primary_metric':'warning_recall_at_least10',
            'primary_comparisons':['fine_dense-coarse_dense','fine_dense-fine_reference'],
            'sha256':{str(p.relative_to(ROOT)):sha256(p) for p in paths}}
    config=json.loads(json.dumps(config))
    if (output/'config.json').exists(): assert config==json.loads((output/'config.json').read_text(encoding='utf-8')),'Use a new output directory'
    else: write_json(output/'config.json',config)
    if args.prepare_only: print(json.dumps({'config':str(output/'config.json'),'probability_thresholds':len(PROB_FINE),'speed_thresholds':len(SPEED_FINE)})); return
    if (output/'results.json').exists(): raise ValueError('Existing result preserved')
    torch.set_num_threads(1); begun=time.perf_counter(); data=load_data()
    coarse=json.loads((DENSITY/'results.json').read_text(encoding='utf-8')); budgets=coarse['selection']['budgets']
    # No evaluation partition or scores are prepared until selection is saved.
    parts=load_partition(data,'calibration'); scores=frozen_scores('calibration'); selections={}; all_days={}
    np.savez_compressed(output/'scores_calibration.npz',**{f'{m}_{s}':p for m,rows in scores.items() for s,p in rows.items()})
    for m in METHODS:
        selections[m],days=choose_fine(m,scores[m],parts,budgets); all_days.update(days)
        old=coarse['selection']['methods'][m]
        fine_map={(r['threshold'],r['confirmation']):r for r in selections[m]['grid']}
        assert all(r==fine_map[(r['threshold'],r['confirmation'])] for r in old['grid'])
        new_mean=-summary_key(list(selections[m]['selected']['by_scenario'].values()))[0]
        old_mean=-summary_key(list(old['selected']['by_scenario'].values()))[0]; assert new_mean>=old_mean-1e-12
        op=selections[m]['selected']; print(f'fine calibration: {m}, threshold={op["threshold"]:g}, c={op["confirmation"]}, elapsed={time.perf_counter()-begun:.1f}s',flush=True)
    reference=reference_method(selections); selection={'methods':selections,'budgets':budgets,'reference':reference}
    write_json(output/'selection.json',selection); np.savez_compressed(output/'calibration_grid_daily.npz',**all_days)
    hashes={name:sha256(output/name) for name in ('selection.json','scores_calibration.npz','calibration_grid_daily.npz')}
    write_json(output/'calibration_frozen.json',{'sha256':hashes,'selected_before_evaluation_partition_prepared':True})
    cal_rows,cal_selected_daily,cal_records=evaluate_with_leads(scores,parts,saved_targets('calibration'),selections,data[3])
    print(f'calibration frozen; simple reference={reference}; preparing one selected evaluation replay',flush=True)
    evaluation=load_partition(data,'evaluation'); test=frozen_scores('evaluation')
    np.savez_compressed(output/'scores_evaluation.npz',**{f'{m}_{s}':p for m,rows in test.items() for s,p in rows.items()})
    rows,daily,records=evaluate_with_leads(test,evaluation,saved_targets('evaluation'),selections,data[3])
    with np.load(DENSITY/'daily_metrics.npz') as saved: old_daily={k:saved[k] for k in saved.files}
    result={'config':config,'selection':selection,'reference':reference,'calibration_selected':cal_rows,
            'evaluation':rows,'coarse_evaluation':coarse['evaluation'],'coarse_selection':coarse['selection'],
            'comparisons':comparisons(daily,old_daily,reference),'calibration_artifacts_frozen_before_evaluation':hashes,
            'nonmonotonicity_example':nonmonotonic_example(),'higher_threshold_adjacent_false_count_increases':nonmonotonic_counts(all_days),
            'elapsed_seconds':time.perf_counter()-begun,'new_method_originality_confirmed':False}
    write_json(output/'results.json',result); np.savez_compressed(output/'daily_metrics.npz',**daily)
    np.savez_compressed(output/'calibration_selected_daily.npz',**cal_selected_daily)
    write_json(output/'event_records.json',{'calibration':cal_records,'evaluation':records})
    audit={'audit_status':'independent recomputation pending','source_hashes_unchanged':all(sha256(ROOT/k)==v for k,v in config['sha256'].items()),
           'artifact_sha256':{p.name:sha256(p) for p in output.iterdir() if p.suffix=='.npz' or p.name in ('selection.json','calibration_frozen.json','event_records.json')}}
    assert audit['source_hashes_unchanged']; write_json(output/'audit.json',audit)
    print(json.dumps({'reference':reference,'comparisons':result['comparisons'],'seconds':result['elapsed_seconds']},indent=2))


if __name__=='__main__': main()
