"""Prepare public-safe historical research archive; never upload or delete.

Archives sources and aggregate outcome evidence. Raw data, trained weights,
sample-level caches, papers and thesis/office artifacts are excluded. Legacy
ZIP removal is separately gated on remote verification and retained content.
"""
from pathlib import Path
from datetime import datetime,timezone
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,json,re,zlib

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs/github-experiment-archive-2026-10-16'
STAGE=OUT/'upload-staging'
PATTERN=re.compile(r'traffic-recovery-lab-2026-10-(09-pilot|10-(?:congestion-[a-z-]+|fresh-holdout|multifault|replanning|state-value|topic-rescreen)|15-(?:adaptive-confirmation|alarm-start-separability|calibration-fragility|early-warning-protection|frozen-probe-transfer|new-station-transfer|recall-improvement|station-agnostic-risk)|16-(?:bypass-diagnosis|effective-alert-pilot|event-lineage-attribution|proxy-event-semantics|recovery-definition-sensitivity))\.zip$')
SECRET=re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{30,}|AKIA[0-9A-Z]{16}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)')


def sha(data):return hashlib.sha256(data).hexdigest()
def dump(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def safe_rel(name):
    name=name.replace('\\','/');parts=name.split('/')
    if parts[0]=='traffic-recovery-lab':parts=parts[1:]
    if not parts or any(x in ('','..') for x in parts) or ':' in parts[0]:raise ValueError('Unexpected archive path')
    return '/'.join(parts)


def public_source(name):
    p=Path(name)
    if p.suffix=='.py':
        if p.parent==Path('.') and not p.name.startswith(('build_thesis','build_undergraduate','render_thesis','check_thesis','check_undergraduate','prepare_github','save_github','verify_github','verify_growth','verify_web','verify_live','github_upload','finalize_github')):return True
        if len(p.parts)>=2 and p.parts[0]=='tests' and '__pycache__' not in p.parts:return True
    if len(p.parts)==2 and p.parts[0]=='configs' and p.suffix=='.json':return True
    if len(p.parts)==2 and p.parts[0]=='docs' and p.suffix=='.md':
        return p.name.endswith('_protocol.zh-CN.md') or p.name in ('thesis_proxy_semantics_note.zh-CN.md','thesis_contribution_boundary.zh-CN.md','additive_decision_boundary.zh-CN.md','observation_availability_boundary.zh-CN.md','forecast_loss_scales.zh-CN.md')
    return p.name in ('requirements.txt','requirements-lock.txt','LICENSE') and p.parent==Path('.')


def clean(data):
    if SECRET.search(data):raise ValueError('Credential-shaped material; stop public packaging')
    text=data.decode('utf-8-sig')
    # Anonymize machine paths in this public copy, never edit scientific sources.
    text=text.replace(str(ROOT),'${PROJECT_ROOT}').replace(str(ROOT).replace('\\','/'),'${PROJECT_ROOT}')
    text=re.sub(r'[A-Za-z]:[\\/]Users[\\/][^\\/\s\"\']+', '${USER_HOME}',text)
    return text.encode('utf-8')


AGG_KEYS=('stage','pilot_acceptance_passed','primary_acceptance_passed','previous_candidate_acceptance_passed',
    'original_thesis_primary_test_still_failed','independent_confirmation','independent_test_executed',
    'external_independent_data','same_network_and_calendar','new_method_validated','new_method_originality_confirmed',
    'stronger_predictor_screen_passed','repair_value_development_screen_passed','passes_exploratory_research_screen',
    'fixed_point_gate_vs_global_passed','unconditional_overall_superiority_established','identity_removal_causal_benefit_proven',
    'previous_plus2pp_R10_hypothesis_passed_by_this_pilot','calibration_events','calibration_days','events',
    'means','calibration_only_means','selected_means','reference_global','reference','verdict','limitation',
    'new_models_fitted','new_model_inference_calls','optimizer_updates','record_only_no_cache_decode','policy_changed','labels_changed',
    'online_policy_changed','original_labels_changed','definition_selected_on_results','new_acceptance_test_performed',
    'paired_success','candidate_only_not_deployment')


def aggregate(data):
    result={k:data[k] for k in AGG_KEYS if k in data}
    # Nested event/episode tables, per-station identities and sample sequences
    # are intentionally not exported, even when present in prior results.
    def bounded(v):
        if isinstance(v,dict):return {k:bounded(x) for k,x in v.items() if not any(t in k.lower() for t in ('event_records','station_ids','node_ids','origin','row','timestamp','date','samples','trace','artifact_sha'))}
        if isinstance(v,list):return [bounded(x) for x in v] if len(v)<=12 else {'omitted_list_length':len(v)}
        return v
    return bounded(result)


def main():
    if (OUT/'preparation.json').exists():raise FileExistsError('Prepared archive already exists')
    STAGE.mkdir(parents=True,exist_ok=True);payload={};origin_index=[]
    for p in sorted(ROOT.glob('*.py'))+sorted((ROOT/'tests').rglob('*.py'))+sorted((ROOT/'configs').glob('*.json'))+sorted((ROOT/'docs').glob('*.md'))+[ROOT/'requirements.txt',ROOT/'LICENSE']:
        if not p.is_file():continue
        name=p.relative_to(ROOT).as_posix()
        if public_source(name):payload['current/'+name]=clean(p.read_bytes())
    summaries={}
    excluded_stages=('github','thesis','undergraduate','synthetic-smoke','pems-bay-demo','pems-bay-pipeline-verification')
    for p in sorted((ROOT/'outputs').glob('*/results.json')):
        stage=p.parent.name
        if stage==OUT.name or any(t in stage for t in excluded_stages):continue
        original=p.read_bytes();value=json.loads(original.decode('utf-8-sig'))
        summaries[stage]=aggregate(value)
        payload['aggregate-evidence/'+stage+'.json']=(json.dumps({'source_results_sha256':sha(original),
            'aggregate_only':True,'result':summaries[stage]},ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode('utf-8')
    backups=sorted(p for p in (ROOT.parent/'checkpoints').glob('*.zip') if PATTERN.fullmatch(p.name))
    local_crc={}
    def current_matches(name,info):
        p=(ROOT/name).resolve()
        if not p.is_relative_to(ROOT.resolve()) or not p.is_file() or p.stat().st_size!=info.file_size:return False
        if name not in local_crc:
            crc=0
            with p.open('rb') as f:
                while chunk:=f.read(1048576):crc=zlib.crc32(chunk,crc)
            local_crc[name]=crc&0xffffffff
        return local_crc[name]==info.CRC
    inventory=[]
    for path in backups:
        uncovered=[];historical_count=0
        with ZipFile(path) as z:
            for info in z.infolist():
                if info.is_dir():continue
                name=safe_rel(info.filename)
                matches=current_matches(name,info)
                if not matches and public_source(name):
                    data=z.read(info);digest=sha(data);public=clean(data)
                    dest='historical-source-versions/'+digest[:20]+'/'+name
                    payload[dest]=public
                    origin_index.append({'backup':path.name,'original_path':name,'source_sha256':digest,'public_copy_path':dest,'public_copy_sha256':sha(public)})
                    historical_count+=1
                elif not matches:
                    # A ZIP can be removed only when unmatched private/history
                    # entries are either intentionally disposable metadata, or
                    # retained in current files. Do not silently discard any.
                    if name.startswith(('outputs/','data/','runs/')) and Path(name).suffix in ('.npz','.pt','.h5','.hdf5'):
                        uncovered.append({'path':name,'bytes':info.file_size,'reason':'unique private artifact not at original active path'})
                    elif Path(name).suffix.lower() in ('.docx','.pptx','.pdf'):
                        uncovered.append({'path':name,'bytes':info.file_size,'reason':'historical document not at original active path'})
        inventory.append({'name':path.name,'bytes':path.stat().st_size,'entries':len(z.infolist()),
            'historical_public_source_versions':historical_count,'uncovered_private_or_document_artifacts':uncovered,
            'eligible_for_later_deletion_after_remote_verification':not uncovered})
        print(json.dumps({'backup':path.name,'uncovered_artifacts':len(uncovered),'historical_sources':historical_count}),flush=True)
    payload['historical-source-index.json']=(json.dumps(origin_index,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    summary='''# 未通过验收的实验与相关诊断归档

这份归档保留研究代码、测试、旧版源文件和聚合失败证据。未通过验收不等于所有实验“无用”：有些诊断用于揭示失败原因。原论文联合主检验失败状态保持，没有根据新分组或事件定义把失败改为成功。

主要结论：原PEMS-BAY主检验失败；训练目标/锚定修正未形成可靠跨站优势；无站点身份模型开发门槛失败；自适应确认与低速豁免候选未通过完整要求；有效告警目标部分恢复检出但联合验收失败。后续诊断发现一个被保护的代理R15是短暂越线后的重入事件，收益依赖事件定义；过滤造成的检出损失仍在父过程第一子段。改变事件定义只重标部分误报/重复，不会自动减少告警发送次数。

所有开发范围已重复使用，相关情景共享事件，重叠子块不可当独立样本；历史跨站检查也已消耗。没有在本次归档操作中运行新科学试验。

包内 current/ 为当前研究源文件，historical-source-versions/ 为旧备份中不同版本的可公开源码，aggregate-evidence/ 为带原始结果文件SHA256的聚合证据。它不是原ZIP逐字节镜像：不包含原始交通HDF5、样本/逐事件缓存、训练权重、真实站点窗口、论文PDF或Word/PPT。代码中的原数据路径、旧权重和旧ZIP恢复流程属于历史运行方式；不能据此假定这些大文件也公开了。当前本地工作目录中的原始数据/模型/结果不会因清理冗余ZIP而删除。

研究代码需要的原数据必须从原来源按其条款获取；代码许可不授予第三方数据再分发权。未重新运行或声称从本归档可独立复现全部数值。原完整结果和数据仍以本地活动项目为准。
'''
    payload['README.zh-CN.md']=summary.encode('utf-8')
    manifest={'date':'2026-10-16','public_archive_scope':'research sources and aggregate evidence; not full binary backup',
        'privacy':'no raw datasets, trained weights, sample caches, station windows, thesis/office files or credentials',
        'source_machine_paths_anonymized_in_public_copies':True,'historical_versions':len(origin_index),
        'files':{name:{'bytes':len(data),'sha256':sha(data),'git_blob_sha1':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()} for name,data in sorted(payload.items())}}
    manifest_bytes=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    payload['archive-manifest.json']=manifest_bytes
    for name,data in payload.items():
        if SECRET.search(data):raise ValueError('Stop: credential pattern')
    bundle=STAGE/'failed-experiments-source-and-evidence.zip'
    with ZipFile(bundle,'x',compression=ZIP_DEFLATED) as z:
        for name,data in sorted(payload.items()):z.writestr(name,data)
    with ZipFile(bundle) as z:
        assert z.testzip() is None and len(z.namelist())==len(payload)
        for name,data in payload.items():assert z.read(name)==data
    (STAGE/'README.zh-CN.md').write_text(summary,encoding='utf-8')
    (STAGE/'archive-manifest.json').write_bytes(manifest_bytes)
    dump(OUT/'backup-inventory.json',inventory)
    digest=hashlib.file_digest(bundle.open('rb'),'sha256').hexdigest()
    raw=bundle.read_bytes()
    proof={'prepared_at_utc':datetime.now(timezone.utc).isoformat(),'public_confirmation_pending':True,
        'candidate_old_backup_count':len(backups),'candidate_old_backup_bytes':sum(v['bytes'] for v in inventory),
        'eligible_delete_backup_count':sum(v['eligible_for_later_deletion_after_remote_verification'] for v in inventory),
        'files_inside_public_bundle':len(payload),'bundle_bytes':len(raw),'bundle_sha256':digest,
        'bundle_git_blob_sha1':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),
        'aggregate_stages':len(summaries),'secret_pattern_scan_passed':True,'archive_crc_and_every_file_bytes_checked':True,
        'remote_published':False,'local_backups_deleted':False}
    dump(OUT/'preparation.json',proof);print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':main()
