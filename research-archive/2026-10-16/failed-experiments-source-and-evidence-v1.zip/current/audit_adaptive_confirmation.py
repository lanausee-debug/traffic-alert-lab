"""Reconstruct adaptive episodes independently and pair the affected truth events."""
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
import torch
import adaptive_confirmation as pilot
import calibration_fragility as common
from congestion_alert_pilot import SCENARIOS,runs
from pems_bay_alert_replay import replay,alarm,layout
from train_pems_bay_risk import load_risk
from evaluate_pems_bay_alerts import paired_difference

ROOT=pilot.ROOT;OUT=pilot.OUT


def reconstruct_by_raw_runs(scores,residual,part,bound):
    """Independent interval-based derivation: delay only high-residual raw-run starts."""
    raw=scores>=.46;out=np.zeros_like(raw)
    for lo,hi in layout(part)[0]:
        for node in range(raw.shape[1]):
            for a,b in runs(raw[lo:hi,node]):
                a,b=int(a+lo),int(b+lo)
                delayed=bool(np.isfinite(residual[a,node]) and residual[a,node]>bound)
                out[a+int(delayed):b,node]=True
    return out


def event_transitions(part,baseline,candidate):
    _,_,a=replay(part,baseline,details=True);_,_,b=replay(part,candidate,details=True)
    key=lambda rec:(rec['node'],rec['event_start_origin'])
    first={key(rec):rec for rec in a};second={key(rec):rec for rec in b}
    assert first.keys()==second.keys()
    transitions={};changed=[]
    for k,old in first.items():
        new=second[k]
        name=old['status']+'->'+new['status'];transitions[name]=transitions.get(name,0)+1
        old10=old['status']=='warned' and old['lead_minutes']>=10
        new10=new['status']=='warned' and new['lead_minutes']>=10
        if old['status']!=new['status'] or old['lead_minutes']!=new['lead_minutes'] or old['alarm_start_origin']!=new['alarm_start_origin']:
            changed.append({'node':int(k[0]),'event_start_origin':int(k[1]),'timestamp':old['timestamp'],
                'old_status':old['status'],'new_status':new['status'],
                'old_lead_minutes':old['lead_minutes'],'new_lead_minutes':new['lead_minutes'],
                'R10_lost':bool(old10 and not new10),'R10_gained':bool(new10 and not old10)})
    return {'complete_event_count':len(first),'status_transition_counts':transitions,
        'R10_lost':sum(r['R10_lost'] for r in changed),'R10_gained':sum(r['R10_gained'] for r in changed),
        'detection_lost':sum(first[k]['status']!='missed' and second[k]['status']=='missed' for k in first),
        'detection_gained':sum(first[k]['status']=='missed' and second[k]['status']!='missed' for k in first),
        'changed_events':changed}


def main():
    torch.set_num_threads(1)
    plan=common.read(OUT/'plan.json');r=common.read(OUT/'results.json');done=common.read(OUT/'completion.json')
    assert done['plan_sha256']==common.sha(OUT/'plan.json')
    for name,digest in plan['source_and_input_sha256'].items():assert common.sha(ROOT/name)==digest,name
    for name,digest in done['artifacts'].items():assert common.sha(OUT/name)==digest,name
    seal=common.read(OUT/'selection_freeze.json')
    assert seal['plan_sha256']==common.sha(OUT/'plan.json') and seal['results_sha256']==common.sha(OUT/'results.json')
    assert seal['declared_primary']==r['primary_rule']=='residual_gt5'
    assert seal['accepted_for_later_validation']==r['primary_acceptance_passed']
    assert not seal['sensitivity_winner_substitution']
    assert datetime.fromisoformat(plan['frozen_at_utc'])<datetime.fromisoformat(seal['frozen_at_utc'])
    norm=common.load(common.RISK/'normalization.npz');model=load_risk(common.RISK/'global_calibration.pt')
    cal=common.load(common.CAL/'calibration.npz');val=common.load(common.RISK/'risk_validation.npz')
    parts={'calibration_full14':cal,'risk_validation7':val,
        'calibration_week1_7':common.subset(cal,0,7),'calibration_week2_7':common.subset(cal,7,14)}
    active=common.load(OUT/'activations.npz');daily=common.load(OUT/'daily.npz');transitions={}
    for block,part in parts.items():
        probabilities=common.global_scores(part,norm,model);transitions[block]={}
        for method,by_s in r['evaluation'][block].items():
            for s,row in by_s.items():
                key=f'{block}__{method}__{s}'
                if method.startswith('global_'):expected=alarm(probabilities[s],.46,int(method[-1]),part)
                else:expected=reconstruct_by_raw_runs(probabilities[s],common.causal_residual(part,s),part,float(method.rsplit('gt',1)[1]))
                np.testing.assert_array_equal(active[key],expected)
                actual,days,_=replay(part,expected,details=True)
                assert row==actual;np.testing.assert_array_equal(daily[key],days)
        for s in SCENARIOS:
            before=active[f'{block}__global_c1__{s}'];after=active[f'{block}__residual_gt5__{s}']
            assert not np.any(after&~before)
            transitions[block][s]=event_transitions(part,before,after)
            a=r['evaluation'][block]['global_c1'][s];b=r['evaluation'][block]['residual_gt5'][s]
            tr=transitions[block][s]
            assert tr['detection_gained']-tr['detection_lost']==b['detected']-a['detected']
            oldcount=sum(a['warning_lead_counts'][str(v)] for v in (10,15))
            newcount=sum(b['warning_lead_counts'][str(v)] for v in (10,15))
            assert tr['R10_gained']-tr['R10_lost']==newcount-oldcount
    original=common.read(common.CAL/'selection.json')
    for method,gate in r['gates'].items():
        for block,methods in r['evaluation'].items():
            assert gate['block_checks'][block]==pilot.block_gate(methods[method],methods['global_c1'])
        m=r['means']['calibration_full14'];fa=m[method]['false_per_valid_station_day'];ref=m['global_c1']['false_per_valid_station_day']
        ten=fa<=.9*ref+1e-12
        budget={s:r['evaluation']['calibration_full14'][method][s]['false_per_valid_station_day']<=original['budgets'][s]+1e-12 for s in SCENARIOS}
        assert gate['full_calibration_false_reduction_at_least10pct']==ten
        assert gate['full_calibration_original_budget_met']==budget
        assert gate['all_conditions_passed']==(all(v['passed'] for v in gate['block_checks'].values()) and ten and all(budget.values()))
    bootstrap=common.load(OUT/'bootstrap_draws.npz');draws=bootstrap['draws']
    dates=common.layout(cal)[2];np.testing.assert_array_equal(bootstrap['dates'],dates)
    np.testing.assert_array_equal(draws,np.random.default_rng(20261015).integers(0,len(dates),(2000,len(dates))))
    ref=np.stack([daily[f'calibration_full14__global_c1__{s}'] for s in SCENARIOS])
    for method,rows in r['comparisons_calibration_vs_global_c1'].items():
        counts=np.stack([daily[f'calibration_full14__{method}__{s}'] for s in SCENARIOS])
        independent=paired_difference(counts,ref,draws)
        for old,new in [('warning10_recall','R10'),('detection_recall','detection'),('false_rate','false_rate')]:
            a=independent[old];b=rows[new]
            assert np.isclose(a['difference'],b['difference'])
            assert a['undefined_bootstrap_replicates']==b['undefined_draws']
            assert (a['ci95'] is None and b['ci95'] is None) or np.allclose(a['ci95'],b['ci95'])
    prior=common.read(ROOT/'outputs/calibration-fragility-2026-10-15/writing_archive_manifest.json')
    latest=OUT/'writing_archive_manifest.json'
    for name,meta in prior['files'].items():
        if name in ('README.md','CURRENT_STATE.zh-CN.md') and latest.exists():
            assert common.sha(ROOT/name)==common.read(latest)['files'][name]['sha256']
        else:assert common.sha(ROOT/name)==meta['sha256'],name
    common.write(OUT/'paired_event_transitions.json',transitions)
    proof={'passed':True,'checked_at_utc':datetime.now(timezone.utc).isoformat(),
        'all60_operating_replays_checked':True,'all36_adaptive_activations_independently_reconstructed':True,
        'primary_event_transitions_matched':True,'paired_bootstrap_independent_numeric_check':True,
        'source_inputs_and_prior_scientific_artifacts_unchanged':True,
        'primary_acceptance_passed':r['primary_acceptance_passed'],
        'new_station_cohort_consumed':False,'original_thesis_primary_test_still_failed':True,
        'source_sha256':common.sha(Path(__file__))}
    common.write(OUT/'audit.json',proof);print(proof)
    print({b:{s:{k:v for k,v in row.items() if k!='changed_events'} for s,row in scenes.items()} for b,scenes in transitions.items()})


if __name__=='__main__':main()
