"""Write a calibrated, development-only negative ablation result."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs/station-agnostic-risk-2026-10-15'
def read(path):return json.loads(path.read_text(encoding='utf-8'))
def pct(v):return f'{100*v:.2f}%'


def main():
    r=read(OUT/'results.json');a=read(OUT/'audit.json');d=read(OUT/'constraint_diagnostics.json')
    assert a['passed'] and not r['pilot_acceptance_passed']
    selected=r['selected'];ref=r['reference_global'];candidate=r['selected_means']
    lines=['# 去站点编号风险模型：开发数据消融实验','',
        '日期：2026-10-15。本轮只用原开发24站的风险训练、风险验证及14日校准缓存。**未通过事先固定的校准筛查，未启动第三组站点检查。**','',
        '## 改了什么','',
        '风险输入从51项降到27项：删除索引24–47的24维站点独热编号，保留预测、本站历史、邻站统计、日历、网络可用率和缺失标志。标准化沿用原风险训练段统计，只取相应列；推断时也删除身份列。','',
        '输出仍为固定全局风险logit + b×tanh(MLP修正)，修正网络27→32→16→1，每个模型1441参数。检查b=0.5和1.0，各用202/203/204三种子、1350次实际更新，共6个模型8100次更新。小批量行序列与此前51维实验一致；参数形状改变导致初始化和学习过程不同，不能声称所有潜在因素都被隔离。','',
        '每个模型只按风险验证段的union BCE选择0/225/450/900/1350检查点。目标为持续低速或即将出现起点。权重固定后才在校准段搜索阈值和确认次数。全局风险底座不训练。上游GraphTCN仍含站点专属参数，删除风险头身份不等于整个系统可直接跨路网迁移。','',
        '## 预先固定的筛查门槛','',
        '三种情景分别满足原校准误报预算、检出率不低于固定全局校准减2个百分点；在此基础上，三情景等权平均R10还须比固定全局至少高2个百分点。阈值0.01到0.90、间隔0.005，另含关闭阈值1.0001；确认次数1或2，共每家族360组设置。没有因结果不佳修改预算、门槛或增加候选。','',
        f"最佳可行候选：b=0.5，阈值{selected['threshold']}，连续{selected['confirmation']}次确认。",'',
        '## 开发校准段结果','',
        '**仅69个完整低速代理事件，三种观测情景共享事件，不能当成207个独立事件。校准数据反复用于适应性开发，这张表不是未见测试或泛化证明。**','',
        '| 方法 | ≥10分钟代理预警召回R10 | 含迟报检出率 | 误报/有效站日 |',
        '| --- | ---: | ---: | ---: |']
    for label,row in [('固定全局校准',ref),('此前含编号候选（同一校准段）',r['previous_identity_bearing_candidate']),('本轮去编号最佳可行候选',candidate)]:
        lines.append(f"| {label} | {pct(row['warning_recall_at_least10'])} | {pct(row['detection_recall'])} | {row['false_per_valid_station_day']:.6f} |")
    lines+=['',f"去编号候选相对全局：R10增加{100*(candidate['warning_recall_at_least10']-ref['warning_recall_at_least10']):.2f}个百分点，检出变化{100*(candidate['detection_recall']-ref['detection_recall']):+.2f}个百分点，误报变化{candidate['false_per_valid_station_day']-ref['false_per_valid_station_day']:+.6f}。R10相当于每种情景从4/69变为5/69；距离2个百分点验收线不足。",'',
        '| 修正幅度b | 仅误报约束通过的设置 | 仅检出约束通过的设置 | 两者同时通过 |',
        '| --- | ---: | ---: | ---: |']
    for method,row in d.items():
        lines.append(f"| {method} | {row['false_budget_only_pass']} | {row['detection_floor_only_pass']} | {row['both_pass']} |")
    lines+=['',
        'b=1.0没有同时满足误报与检出的设置。在检出达标的设置里，最小的“最差情景误报超额”仍为0.002987次/有效站日；在误报达标的设置里，最好的“最差情景检出余量”仍为−0.899个百分点（相对已放宽2个百分点的检出下限）。这些是冻结网格的事后诊断，不是新选项，也没有放宽约束。','',
        '## 结论和限制','',
        '- 简单删除显式站点编号，在本轮固定训练与搜索范围内没有产生足以继续验证的开发收益。不能把“编号导致此前迁移失败”写成已证实结论。','- 这不是“所有去身份模型都无效”的证明，也不意味着保留身份一定更好；原校准事件少且已反复使用。由于筛查失败，本轮没有估计去编号模型的新站点性能。','- 原论文联合主检验仍失败。此前新站点迁移检查也未通过，两个失败记录均保留。','- 原≥10分钟口径为L=5(s−a+1)低速代理提前量，非现场确认的拥堵起点或管理决策收益。','- 本轮没有更换线上模型或发布新的性能宣称；原论文和GitHub v7保持。','',
        '## 核查与保存','',
        '7项测试检查身份值任意改变无影响、风险层站点置换一致、特征索引与原标准化、推断不读未来标签、零修正精确复制底座/幅度限制、梯度更新和禁止读取评测分区。独立核查重算了所选权重的验证BCE、校准分数、所选告警回放、全部网格约束与选择结果，并核对了此前累计归档中的全部文件未被修改。','',
        '计划、训练权重、每种子记录、所有720组网格、分数、约束诊断、选择封存、访问记录和审计保存在本目录。下一组站点尚未选择或解码。','',
        '下一轮优先处理误报预算在新站点失准这一已观察到的问题：先在开发分区建立明确的校准与漂移诊断，再决定可检验的改进方案；不继续靠增加网络层数或重复利用已检查站点筛选模型。该安排是后续计划，本轮尚未执行。','']
    (OUT/'report.zh-CN.md').write_text('\n'.join(lines),encoding='utf-8')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    rows=[ref,r['previous_identity_bearing_candidate'],candidate]
    fig,axes=plt.subplots(1,3,figsize=(11,4.5),facecolor='#f5f8fa')
    metrics=[('warning_recall_at_least10','Proxy warning >=10 min (%)',100),('detection_recall','Detection incl. late (%)',100),('false_per_valid_station_day','False alerts / valid station-day',1)]
    for ax,(metric,title,mult) in zip(axes,metrics):
        values=[row[metric]*mult for row in rows]
        bars=ax.bar(range(3),values,color=['#8297ab','#ab8cae','#137c83'],width=.65)
        ax.set_title(title,fontsize=10)
        ax.set_xticks(range(3),['Global','Prior 51-D','New 27-D'],fontsize=9)
        ax.set_ylim(0,100 if mult==100 and metric=='detection_recall' else max(values)*1.3)
        ax.spines[['top','right']].set_visible(False)
        for bar,value in zip(bars,values):
            ax.text(bar.get_x()+bar.get_width()/2,bar.get_height(),f'{value:.2f}' if mult==100 else f'{value:.3f}',ha='center',va='bottom',fontsize=10)
    fig.suptitle('Development calibration only: explicit station-identity ablation',fontsize=12)
    fig.text(.5,.035,'69 shared proxy events / 14 reused days. Fixed +2 pp R10 screen FAILED. No new-station test.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.09,1,.91));fig.savefig(OUT/'comparison.png',dpi=150);plt.close(fig)
    print(str(OUT/'report.zh-CN.md'))


if __name__=='__main__':main()
