"""Report development-only calibration diagnostics without promotion to a new model."""
from pathlib import Path
import numpy as np
import calibration_fragility as d
ROOT=d.ROOT;OUT=d.OUT
def pct(v):return '不可计算' if v is None else f'{100*v:.2f}%'
def rate(v):return '不可计算' if v is None else f'{v:.6f}'


def main():
    r=d.read(OUT/'results.json');audit=d.read(OUT/'audit.json');assert audit['passed']
    eq=r['equivalence'];stress=r['synthetic_shift_stress']['calibration'];weeks=r['reciprocal_week_stress']
    base=stress['0.0']['means'];low=stress['-2.0']['means']
    natural=r['partitions']['calibration']['by_scenario']['natural']
    high=natural['by_available_past_residual']['above5']
    allfalse=natural['operating']['false'];exposure=natural['operating']['exposure']
    lines=['# 告警校准脆弱性诊断：开发数据的时间块与预测扰动检查','',
        '日期：2026-10-15。**本轮是诊断，没有训练或接受新模型，没有读取原评测、已检查新站点评测、下一组站点或原始HDF5。** 只用原24个开发站点风险验证7日、校准14日的缓存。这21日已参与过模型选择和反复开发，不能当成未见测试。','',
        '## 结论','',
        f"1. 固定全局风险头的阈值0.46/c1，数学上等价于三步集成预测最大车速≤{eq['equivalent_max_three_horizon_ensemble_speed_cutoff_mph']:.4f} mph。这一层是单变量单调逻辑变换，并未增加新的交通状态信息。该等价关系不适用于之前的残差MLP，也不意味着上游深度预测器没有作用。",
        f"2. 人为把所有预测车速统一调低2 mph，在14日校准段使平均误报从{base['false_per_valid_station_day']:.6f}升至{low['false_per_valid_station_day']:.6f}次/有效站日，约{low['false_per_valid_station_day']/base['false_per_valid_station_day']:.2f}倍。这只证明固定规则对这种人为扰动敏感，不能据此声称真实新站点存在−2 mph偏差。",
        '3. 同一组站点前后两周，按相同规则选出的设置分别是0.46/c1和0.22/c2。后一周规则用于前一周时，三个情景都超过目标周的误报预算，两个情景还低于目标周的检出下限。一个方向的转用失败，不代表所有时段或反方向都失败。',
        f"4. 自然情景中，可观测的一步历史残差均值为{natural['available_causal_residual']['mean_predicted_minus_observed_mph']:.3f} mph，不能支持给所有车速统一加回一个常数。另一方面，残差>5 mph区间只占{100*high['exposure_station_days']/exposure:.2f}%有效时间，却含{high['false_episode_starts']}/{int(allfalse)}次误报起点。这是小样本条件关联，可用于提出下一轮假设，尚不能证明因果或策略收益。",'',
        '## 全局校准的数学等价','',
        '缓存单变量x=−max(三步集成预测车速)/70，训练段标准化z=(x−μ)/σ，风险p=sigmoid(wz+b)。本次w为正，固定p≥0.46等价于max车速≤−70×[μ+σ×(logit(0.46)−b)/w]。已在两个分区、三种情景逐点核对两种告警完全一致。提高单变量概率校准精度不自动增加可用信息，也不自动保证事件级误报预算。','',
        '## 固定规则在两个开发分区的表现','',
        '| 分区 | 日数 | 完整低速代理事件 | R10 | 含迟报检出率 | 误报/有效站日 |',
        '| --- | ---: | ---: | ---: | ---: | ---: |']
    for name,v in r['partitions'].items():
        m=v['means'];lines.append(f"| {name} | {len(v['dates'])} | {int(v['events'])} | {pct(m['warning_recall_at_least10'])} | {pct(m['detection_recall'])} | {rate(m['false_per_valid_station_day'])} |")
    lines+=['','三种观测情景等权平均，同一分区共享同一组真值事件，不把三种情景当作独立样本。风险验证段以前用于选模型，以上是固定规则回放诊断，非新的性能检验。','',
        '## 人为车速偏移压力测试','',
        '在缓存的各预测时距上统一加δ，等价地修改全局输入；真值、有效性、风险头、阈值与确认次数均固定。δ不是估计出来的真实偏差，也不是获准部署的修正量。','',
        '| δ（mph） | R10 | 检出率 | 误报/有效站日 |',
        '| ---: | ---: | ---: | ---: |']
    for offset in d.OFFSETS:
        m=stress[str(offset)]['means'];lines.append(f"| {offset:+.0f} | {pct(m['warning_recall_at_least10'])} | {pct(m['detection_recall'])} | {rate(m['false_per_valid_station_day'])} |")
    lines+=['','调高预测车速虽然减少误报，也损失检出和提前预警；不能只展示误报降低。事件指标按告警起点匹配，过早持续的告警、告警切分/合并均可能影响检出；因此不能假定阈值改变会使所有事件指标单调改善。','',
        '## 同站点两周规则互换','',
        '校准14日按日历分成前7/后7日，保持原origin和时间映射，每块独立删失边界、重置确认。每周枚举360组全局阈值/确认设置：要求各情景误报不超过同周30 mph直接预测参考，检出不低于同周固定全局减2个百分点，然后按R10、最差检出、误报、确认和网格索引排序。选择持久化后用于另一周；两周此前均已被本项目看过，保存先后顺序不能恢复独立性。','',
        '| 选参周 | 日期 | 事件 | 可行设置 | 选定规则 |',
        '| --- | --- | ---: | ---: | --- |']
    for name,v in weeks.items():
        sel=v['selected'];lines.append(f"| {name} | {'至'.join(v['own_dates'])} | {int(v['events'])} | {v['feasible_grid_settings']}/360 | {sel['threshold']}/c{sel['confirmation']} |")
    lines+=['','| 规则来源→应用周 | R10 | 检出率 | 误报 | 目标周平均预算 | 三情景预算通过数 | 三情景检出下限通过数 |',
        '| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
    for name,v in weeks.items():
        app=v['opposite_week_application'];m=app['means'];other=weeks[app['target_week']]
        budget=float(np.mean(list(other['dense30_budgets'].values())))
        lines.append(f"| {name}→{app['target_week']} | {pct(m['warning_recall_at_least10'])} | {pct(m['detection_recall'])} | {rate(m['false_per_valid_station_day'])} | {rate(budget)} | {sum(app['false_budget_met'].values())}/3 | {sum(app['detection_floor_met'].values())}/3 |")
    lines+=['','周均预算仅便于阅读，验收逐情景进行；不能用平均值掩盖某情景超预算。两个方向结果不同，当前只能报告这两个短块的敏感性，不能估计长期漂移概率或部署保证。','',
        '## 可观测历史残差和缺失分层','',
        '在时刻t，只把上一时刻已缓存的一步预测f(t−1|历史≤t−2)与当前刚能看到的观测v(t−1)相减。要求连续5分钟、origin相邻、本站最新观测年龄为0且历史覆盖>0。缺失、旧观测或断点不补残差，不使用未来真值。这个量是已有观测上的一步残差，不能当作全部三时距预测误差或外部站点偏差。正值表示上一预测高于后来观测，可与最近一次速度突降有关。','',
        '| 自然情景历史残差 | 有效站日 | 误报起点数 | 误报/有效站日 |',
        '| --- | ---: | ---: | ---: |']
    for label,v in natural['by_available_past_residual'].items():
        lines.append(f"| {label} | {v['exposure_station_days']:.3f} | {v['false_episode_starts']} | {rate(v['false_per_valid_station_day'])} |")
    lines+=['',
        '分层分母是属于该历史状态的有效时间，分子是该状态下开启且最终按冻结口径判成误报的告警数；不能当成每条预测的误报概率。样本少、时序相关、条件与预测共同受交通状态影响，不能据分层相关性直接认定原因。','',
        '本校准段三个情景的误报起点都落在本站历史完整区间；人工缺失情景有大量无观测时间，但此处没有出现误报起点。这不证明缺失无害，可能同时伴随抑制告警和漏报；不能外推至已检查的新站点。完整分层数值保存在results.json。','',
        '自然情景逐点10等宽箱ECE约0.00285、Brier约0.00222，但全局平均误报在两个开发分区仍不同。逐点指标针对持续低速真假；事件预算针对告警起点，且低速正例稀少。小ECE不代表告警预算稳定。','',
        '## 下一轮可检验假设','',
        '优先试验“历史残差较大时增加一次确认，其余时刻保持原全局规则”的有限候选，检验能否抑制短时波动引起的误报，同时保住真实起点的检出与提前量。>5 mph来自本轮预定分层，但观察到关联后才提出这个策略，属于自适应开发；不能称为预注册的独立发现。','',
        '下一轮先冻结有限候选及按时间块检查的误报/检出/预警门槛，只用开发段筛查。没有可行增益就停止，不因失败放宽条件；有增益也只算筛查，再冻结选择和新的验证安排。当前没有实施或证明这项改法。','',
        '## 保存与核查','',
        '9项测试通过。独立核查重算全部720组周内网格、10组分区×偏移回放、阈值等价、告警分类、分层暴露量与选择。首次运行在保存明细时因NumPy整数不能直接写JSON而中止；complete_calibration_fragility.py只适配标量序列化，原冻结源码及已写计划、网格、选择和结果逐字节保持，原结果与恢复后结果一致。恢复说明与哈希单独保存。','',
        '原论文主检验和前两轮失败记录全部保留。GitHub/在线Demo仍为v7；本轮仅本地诊断，权重未重训，下一组站点未选择或读取。','']
    (OUT/'report.zh-CN.md').write_text('\n'.join(lines),encoding='utf-8')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(1,2,figsize=(11.5,4.7),facecolor='#f5f8fa')
    x=list(d.OFFSETS)
    axes[0].plot(x,[stress[str(v)]['means']['false_per_valid_station_day'] for v in x],marker='o',color='#137c83')
    axes[0].set_xlabel('Synthetic uniform speed offset (mph)')
    axes[0].set_ylabel('False alerts / valid station-day')
    axes[0].set_title('Fixed rule: synthetic sensitivity only',fontsize=11)
    for v in x:
        y=stress[str(v)]['means']['false_per_valid_station_day']
        axes[0].annotate(f'{y:.3f}',(v,y),xytext=(0,7),textcoords='offset points',ha='center',fontsize=9)
    axes[0].set_ylim(0,.32)
    apps=[weeks['week1']['opposite_week_application'],weeks['week2']['opposite_week_application']]
    false=[a['means']['false_per_valid_station_day'] for a in apps]
    budgets=[float(np.mean(list(weeks[a['target_week']]['dense30_budgets'].values()))) for a in apps]
    positions=np.arange(2)
    axes[1].bar(positions-.17,false,width=.34,label='Transferred rule',color='#137c83')
    axes[1].bar(positions+.17,budgets,width=.34,label='Target-week mean budget',color='#a4afbc')
    axes[1].set_xticks(positions,['Week1 -> Week2','Week2 -> Week1'])
    axes[1].set_ylim(0,.145);axes[1].set_ylabel('False alerts / valid station-day')
    axes[1].set_title('Reciprocal stress on reused development weeks',fontsize=11)
    axes[1].legend(frameon=False,fontsize=8)
    for ax in axes:ax.spines[['top','right']].set_visible(False)
    fig.suptitle('Calibration fragility diagnosis - no new model accepted',fontsize=13)
    fig.text(.5,.02,'Original 24 stations; development data only. Synthetic offsets do not measure real new-station bias.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.07,1,.91));fig.savefig(OUT/'diagnosis.png',dpi=150);plt.close(fig)
    print(str(OUT/'report.zh-CN.md'))


if __name__=='__main__':main()
