"""Preflight/provenance and independent arithmetic audit for the transfer check."""
import argparse
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path

import numpy as np
import torch

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs/new-station-transfer-2026-10-15'
def read(path):return json.loads(path.read_text(encoding='utf-8'))
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def base_checks():
    plan=read(OUT/'plan.json');forecast=read(OUT/'forecast_freeze.json')
    assert len(plan['new_station_ids'])==24 and not set(plan['new_station_ids'])&set(plan['development_station_ids'])
    assert forecast['plan_sha256']==sha(OUT/'plan.json') and not forecast['risk_head_or_threshold_refit']
    assert datetime.fromisoformat(plan['frozen_at_utc'])<datetime.fromisoformat(forecast['frozen_at_utc'])
    for names in (plan['source_sha256'],plan['fixed_risk_weights_sha256']):
        for name,digest in names.items():assert sha(ROOT/name)==digest,name
    for name,digest in forecast['artifacts'].items():assert sha(OUT/name)==digest,name
    quality=read(OUT/'training_quality.json');assert quality['passed'] and quality['minimum']>=.95
    access=read(OUT/'forecast_access_log.json')
    expected_columns=sorted(plan['new_raw_columns'])
    for item in access['runtime']:
        assert item['partition'] in ('forecast_train','forecast_validation') and item['sorted_columns']==expected_columns
    assert len(access['runtime'])==3 and not access['evaluation_values_read'] and not access['development_station_values_read']
    expected_seeds={f'model_tcn_seed{seed}.pt' for seed in (42,43,44)}
    assert {p.name for p in OUT.glob('*.pt')}==expected_seeds
    source_inputs=read(OUT/'forecast_inputs.json')
    for seed in (42,43,44):
        record=read(OUT/f'training_seed{seed}.json')
        assert record['actual_optimizer_updates']==25*source_inputs['updates_per_epoch']
        assert record['weight_sha256']==sha(OUT/f'model_tcn_seed{seed}.pt')
        assert record['plan_sha256']==sha(OUT/'plan.json')
        minimum=min(record['epochs'],key=lambda row:row['model_mae'])
        assert minimum['epoch']==record['selected_epoch']
    return plan,forecast


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--preflight',action='store_true');args=parser.parse_args()
    plan,forecast=base_checks()
    if args.preflight:
        assert not (OUT/'evaluation_started.json').exists(),'Preflight must precede evaluation'
        amendment=read(OUT/'identity_amendment.json')
        assert not amendment['new_cohort_evaluation_values_read_before_amendment']
        for name,digest in amendment['source_sha256'].items():assert sha(ROOT/name)==digest
        proof={'passed':True,'checked_at_utc':datetime.now(timezone.utc).isoformat(),
            'plan_sha256':sha(OUT/'plan.json'),'forecast_freeze_sha256':sha(OUT/'forecast_freeze.json'),
            'risk_heads_and_thresholds_fixed':True,'evaluation_not_started':True,
            'disjoint_logical_station_columns':True,'identity_amendment_sha256':sha(OUT/'identity_amendment.json'),
            'audit_source_sha256':sha(Path(__file__))}
        write(OUT/'preflight.json',proof);print(json.dumps(proof));return
    preflight=read(OUT/'preflight.json');assert preflight['passed'] and preflight['audit_source_sha256']==sha(Path(__file__))
    execution=read(OUT/'execution_freeze.json');started=read(OUT/'evaluation_started.json');completed=read(OUT/'completion.json')
    amendment=read(OUT/'identity_amendment.json')
    assert preflight['identity_amendment_sha256']==execution['identity_amendment_sha256']==completed['identity_amendment_sha256']==sha(OUT/'identity_amendment.json')
    assert datetime.fromisoformat(amendment['frozen_at_utc'])<datetime.fromisoformat(execution['frozen_at_utc'])
    assert execution['candidate_settings']==plan['candidate_settings'] and execution['comparator_settings']==plan['comparator_settings']
    assert execution['forecaster_freeze_sha256']==sha(OUT/'forecast_freeze.json')
    assert started['execution_freeze_sha256']==completed['execution_freeze_sha256']==sha(OUT/'execution_freeze.json')
    assert datetime.fromisoformat(forecast['frozen_at_utc'])<datetime.fromisoformat(preflight['checked_at_utc'])<datetime.fromisoformat(execution['frozen_at_utc'])<=datetime.fromisoformat(started['started_at_utc'])
    access=read(OUT/'evaluation_access_log.json')
    assert access['source_speed_reads']==1 and len(access['runtime'])==1
    assert access['runtime'][0]['partition']=='evaluation' and access['runtime'][0]['sorted_columns']==sorted(plan['new_raw_columns'])
    assert not access['development_station_values_read'] and not access['new_cohort_risk_train_validation_calibration_read']
    for name,key in (('results.json','results_sha256'),('daily.npz','daily_sha256'),('fixed_scores.npz','scores_sha256'),('evaluation_features.npz','evaluation_feature_sha256')):
        assert sha(OUT/name)==completed[key],name
    result=read(OUT/'results.json');assert not result['risk_heads_refit'] and not result['thresholds_refit'] and not result['external_independent_data']
    assert result['unseen_risk_identity_all_zero'] and result['identity_amendment_sha256']==sha(OUT/'identity_amendment.json')
    with np.load(OUT/'daily.npz') as archive:daily={key:archive[key] for key in archive.files}
    with np.load(OUT/'bootstrap_draws.npz') as archive:draws=archive['draws'];dates=archive['dates']
    expected_draws=np.random.default_rng(20261015).integers(0,len(dates),(2000,len(dates)))
    assert np.array_equal(draws,expected_draws) and dates.astype(str).tolist()==result['evaluation_dates']
    scenarios=('natural','single_outage','group_outage')
    for method,by_scenario in result['evaluation'].items():
        for scenario,row in by_scenario.items():
            total=daily[f'{method}__{scenario}'].sum(axis=0)
            assert np.isclose(total[0],row['exposure'],atol=1e-9) and total[1]==row['events']
            assert total[3]==row['detected'] and total[4]==row['false']
            if total[1]:
                assert np.isclose((total[11]+total[12])/total[1],row['warning_recall_at_least10'])
                assert np.isclose(total[3]/total[1],row['detection_recall'])
    # Use the original separately written count-bootstrap comparator as a numeric cross-check.
    from evaluate_pems_bay_alerts import paired_difference
    candidate=np.stack([daily[f'anchored_candidate__{s}'] for s in scenarios])
    mapping={'warning10_recall':'R10','detection_recall':'detection','false_rate':'false_rate'}
    for method,comparison in result['comparisons'].items():
        old=paired_difference(candidate,np.stack([daily[f'{method}__{s}'] for s in scenarios]),draws)
        for key,newkey in mapping.items():
            a=old[key];b=comparison[newkey]
            assert a['undefined_bootstrap_replicates']==b['undefined_draws']
            assert (a['difference'] is None and b['difference'] is None) or np.isclose(a['difference'],b['difference'])
            assert (a['ci95'] is None and b['conditional_ci95'] is None) or np.allclose(a['ci95'],b['conditional_ci95'])
    for filename in ('evaluation_results_freeze.json','audit_repair_and_handoff_freeze.json'):
        for name,digest in read(ROOT/'outputs/pems-bay-evaluation'/filename)['source_sha256'].items():assert sha(ROOT/name)==digest,name
    report={'passed':True,'station_overlap':0,'front_end_training_seeds':3,
        'front_end_actual_optimizer_updates':sum(read(OUT/f'training_seed{seed}.json')['actual_optimizer_updates'] for seed in (42,43,44)),
        'risk_heads_refit':False,'thresholds_refit':False,'evaluation_source_speed_reads':1,
        'paired_bootstrap_independent_numeric_comparator_passed':True,'raw_station_values_logically_selected_only':True,
        'external_independent_data':False,'original_thesis_primary_test_still_failed':True,
        'unseen_station_identity_adapter_frozen_before_evaluation':True,
        'unit_tests_passed':6,'source_sha256':sha(Path(__file__))}
    write(OUT/'audit.json',report);print(json.dumps(report))


if __name__=='__main__':main()
