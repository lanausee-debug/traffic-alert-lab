"""Post-result descriptive lead buckets and paired event transitions; no tuning."""
import argparse
import json
from pathlib import Path
import numpy as np

from recovery_pilot import ROOT,write_json
from multifault_pilot import sha256
from audit_congestion_pilot import compare
from congestion_alert_pilot import SCENARIOS
from congestion_risk_pilot import online_alarm
from congestion_ablation import load_data,load_parts
from congestion_objective_diagnostic import trace_events
from congestion_onset_pilot import OUTPUT,METHODS


def compute(output):
    result=json.loads((output/'results.json').read_text(encoding='utf-8'))
    data=load_data(); parts,_=load_parts(data); parts=parts['evaluation']
    buckets={}; event_rows={}
    with np.load(output/'scores_evaluation.npz') as scores:
        for method in METHODS:
            buckets[method]={}; event_rows[method]={}
            op=result['selection']['methods'][method]['selected']
            for s in SCENARIOS:
                p=parts[s]; alarm=online_alarm(scores[f'{method}_{s}'],op['threshold'],op['confirmation'])
                stats,daily,records,detail=trace_events(p['truth'],p['eligible'],alarm,p['day_ids'],p['origins'],data[3])
                compare(stats,{k:result['evaluation'][method][s][k] for k in stats})
                lead=detail['warning_by_lead']
                buckets[method][s]={'warning_by_lead':lead,'events':int(stats['events']),
                    'warning_recall_at_least_10_minutes':(lead['10']+lead['15'])/stats['events']}
                event_rows[method][s]={(r['node'],r['event_start_origin']):r for r in records}
    baseline='common_persistent_mlp'; candidate='onset_mlp'; transition={}; shared_deltas=[]
    statuses=('warned','late','missed')
    for s in SCENARIOS:
        a,b=event_rows[baseline][s],event_rows[candidate][s]
        assert set(a)==set(b)
        table={left:{right:0 for right in statuses} for left in statuses}
        deltas=[]
        for key in a:
            x,y=a[key],b[key]; table[x['status']][y['status']]+=1
            if x['status']==y['status']=='warned': deltas.append(y['lead_minutes']-x['lead_minutes'])
        shared_deltas.extend(deltas)
        transition[s]={'matrix_baseline_rows_candidate_columns':table,
                       'shared_warned_events':len(deltas),
                       'paired_lead_mean_difference_minutes':float(np.mean(deltas)) if deltas else None,
                       'paired_lead_difference_counts':{str(d):deltas.count(d) for d in (-10,-5,0,5,10)}}
    pooled={}
    for method,rows in buckets.items():
        lead={str(k):sum(rows[s]['warning_by_lead'][str(k)] for s in SCENARIOS) for k in (5,10,15)}
        events=sum(rows[s]['events'] for s in SCENARIOS)
        pooled[method]={'warning_by_lead':lead,'scenario_events':events,
                        'warning_recall_at_least_10_minutes':(lead['10']+lead['15'])/events}
    return {'post_result_descriptive':True,'no_model_threshold_or_event_rule_change':True,
            'buckets':buckets,'pooled':pooled,'paired_event_transitions':transition,
            'baseline':baseline,'candidate':candidate,
            'shared_warned_events':len(shared_deltas),
            'shared_warned_paired_lead_mean_difference_minutes':float(np.mean(shared_deltas)) if shared_deltas else None,
            'shared_warned_paired_lead_difference_counts':{str(d):shared_deltas.count(d) for d in (-10,-5,0,5,10)}}


def report(result,output):
    lines=['# 事后描述：新增预警落在哪个提前档位', '',
           '在主实验结果已知后补充，非预定主检验；不调模型、阈值、标签或计分，不据此重选方法。三情景共享真实事件，合计数为情景-事件。', '',
           '| 方法 | 提前5分钟 | 提前10分钟 | 提前15分钟 | 至少提前10分钟的事件召回 |',
           '| --- | ---: | ---: | ---: | ---: |']
    for method,row in result['pooled'].items():
        b=row['warning_by_lead']
        lines.append(f'| {method} | {b["5"]} | {b["10"]} | {b["15"]} | {row["warning_recall_at_least_10_minutes"]*100:.2f}% |')
    lines += ['',
              f'共同持续低速MLP与起点MLP都成功预警的子集共{result["shared_warned_events"]}个情景-事件；在同事件子集中，起点MLP−对照的平均提前量差为{result["shared_warned_paired_lead_mean_difference_minutes"]:+.2f}分钟。此条件子集不含新增预警或丢失预警，不是全事件平均收益。', '',
              '## 对同一事件的状态转移', '',
              '行是共同持续低速MLP状态，列是起点MLP状态。迟报包含0分钟计分延迟的首个迟报位置，保持原定义。', '',
              '| 情景 | 原状态 | 新预警 | 新迟报 | 新漏检 |', '| --- | --- | ---: | ---: | ---: |']
    for s,row in result['paired_event_transitions'].items():
        for status,counts in row['matrix_baseline_rows_candidate_columns'].items():
            lines.append(f'| {s} | {status} | {counts["warned"]} | {counts["late"]} | {counts["missed"]} |')
    lines += ['',
              '完整提前档位、各情景至少10分钟召回和同事件提前差分布保存在lead_diagnostic.json。没有为新指标做显著性检验或对外部数据确认，不把此事后诊断替换原主比较。', '',
              '这些时间是代理事件计分公式，并非核验的物理拥堵起点提前量。所有档位计数与原事件指标核对，重复运行复算一致。']
    (output/'lead_report.zh-CN.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')


def main():
    parser=argparse.ArgumentParser(description=__doc__); parser.add_argument('--output',type=Path,default=OUTPUT)
    output=parser.parse_args().output
    config=json.loads((output/'config.json').read_text(encoding='utf-8'))
    assert all(sha256(ROOT/k)==v for k,v in config['sha256'].items())
    artifact=output/'lead_diagnostic.json'; audit_path=output/'lead_audit.json'
    result=compute(output)
    if artifact.exists():
        compare(result,json.loads(artifact.read_text(encoding='utf-8')))
        audit=json.loads(audit_path.read_text(encoding='utf-8'))
        assert audit['script_sha256']==sha256(Path(__file__)) and audit['artifact_sha256']==sha256(artifact)
        assert all(sha256(ROOT/k)==v for k,v in audit['input_sha256'].items())
    else:
        write_json(artifact,result)
        write_json(audit_path,{'audit_status':'passed','post_result_descriptive':True,
            'all_trace_counts_equal_saved_primary_event_metrics':True,
            'matched_same_event_keys_across_models':True,
            'script_sha256':sha256(Path(__file__)),
            'input_sha256':{str(p.relative_to(ROOT)):sha256(p) for p in [output/'results.json',output/'scores_evaluation.npz',ROOT/'congestion_objective_diagnostic.py']},
            'artifact_sha256':sha256(artifact)})
    report(result,output)
    print(json.dumps({'pooled':{m:result['pooled'][m] for m in ('dense_speed','common_persistent_mlp','onset_mlp')},
                      'shared_warned_events':result['shared_warned_events'],
                      'paired_lead_difference':result['shared_warned_paired_lead_mean_difference_minutes']},indent=2))


if __name__=='__main__': main()
