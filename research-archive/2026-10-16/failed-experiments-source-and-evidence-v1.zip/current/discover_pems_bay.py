"""Inspect public distribution metadata; never deserialize traffic values."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import json
from pathlib import Path
import urllib.request

ROOT = Path(__file__).resolve().parent
ENDPOINTS = {
    'mirror_jimmy': 'https://huggingface.co/api/datasets/jimmygao3218/PEMSBAY?blobs=true',
    'mirror_witgaw': 'https://huggingface.co/api/datasets/witgaw/PEMS-BAY?blobs=true',
    'original_folder': 'https://drive.google.com/drive/folders/10FOTa6HXPqX8Pf5WRoRwcFnW9BrNZEIX',
}


def inspect(item):
    name, url = item
    try:
        request = urllib.request.Request(url, headers={'User-Agent': 'traffic-alert-validation/1.0'})
        with urllib.request.urlopen(request, timeout=25) as response:
            blob = response.read(8*1024*1024)
        if name.startswith('mirror'):
            data = json.loads(blob)
            return name, {'url': url, 'revision': data.get('sha'),
                          'files': data.get('siblings', []), 'card_data': data.get('cardData', {})}
        text = blob.decode('utf-8')
        # The folder response is distribution metadata, not the dataset itself.
        target = ROOT/'data/source-metadata/pems-bay-original-folder.html'
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text, encoding='utf-8')
        positions = [i for i in range(len(text)) if text.startswith('pems-bay', i)]
        return name, {'url': url, 'html_bytes': len(blob), 'filename_contexts':
                      [text[max(0, i-180):i+160] for i in positions[:8]]}
    except Exception as error:
        return name, {'url': url, 'error': f'{type(error).__name__}: {error}'}


if __name__ == '__main__':
    with ThreadPoolExecutor(max_workers=3) as executor:
        result = dict(executor.map(inspect, ENDPOINTS.items()))
    result['inspected_at_utc'] = datetime.now(timezone.utc).isoformat()
    path = ROOT/'data/source-metadata/pems-bay-discovery.json'
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(result, ensure_ascii=True, indent=2))
