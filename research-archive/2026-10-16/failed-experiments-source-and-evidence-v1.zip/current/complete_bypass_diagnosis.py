"""Finish frozen diagnosis after a NumPy scalar JSON serialization failure.

The scientific source, plan, features and intervals are preserved exactly.
Only NumPy scalar conversion for JSON output is added here.
"""
from datetime import datetime,timezone
import numpy as np
import bypass_diagnosis as pilot
import calibration_fragility as common


def json_native(value):
    if isinstance(value,dict):return {k:json_native(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):return [json_native(v) for v in value]
    if isinstance(value,np.generic):return value.item()
    return value


def main():
    plan=common.read(pilot.OUT/'plan.json')
    assert not (pilot.OUT/'results.json').exists() and not (pilot.OUT/'completion.json').exists()
    for n,h in plan['source_and_input_sha256'].items():assert common.sha(pilot.ROOT/n)==h,n
    common.write(pilot.OUT/'serialization_recovery.json',{'recorded_at_utc':datetime.now(timezone.utc).isoformat(),
        'initial_run_exit_code':1,'failure':'JSON encoder rejected NumPy int64 in offline episode/event records after all five blocks replayed',
        'frozen_plan_sha256':common.sha(pilot.OUT/'plan.json'),
        'scientific_source_preserved':True,'policy_features_strata_threshold_unchanged':True,
        'repair':'Recursively convert NumPy scalars to Python values only when writing JSON; rerun deterministic diagnosis with original plan',
        'serialization_wrapper_sha256':common.sha(pilot.ROOT/'complete_bypass_diagnosis.py')})
    original_write=common.write
    common.write=lambda p,v:original_write(p,json_native(v))
    pilot.freeze_plan=lambda:plan
    pilot.main()


if __name__=='__main__':main()
