"""Cumulative preservation of calibration diagnosis and recovery provenance."""
from datetime import datetime,timezone
import hashlib
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from save_station_agnostic_checkpoint import read,write,sha

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs/calibration-fragility-2026-10-15'
NAME='traffic-recovery-lab-2026-10-15-calibration-fragility'


def main():
    archive=ROOT.parent/'checkpoints'/(NAME+'.zip');receipt=archive.with_name(NAME+'-save-receipt.json')
    if archive.exists() or receipt.exists():raise FileExistsError('Preserve existing archives')
    audit=read(OUT/'audit.json');r=read(OUT/'results.json')
    assert audit['passed'] and audit['unit_tests_passed']==9 and not r['new_method_accepted']
    assert not r['new_station_cohort_consumed'] and not r['actual_cross_station_failure_cause_established']
    for name,digest in read(OUT/'completion.json')['artifacts'].items():assert sha(OUT/name)==digest
    prior_path='outputs/station-agnostic-risk-2026-10-15/writing_archive_manifest.json'
    prior=read(ROOT/prior_path)
    for name,meta in prior['files'].items():assert sha(ROOT/name)==meta['sha256'],name
    marker='# 最新检查点：校准脆弱性诊断（2026-10-15）'
    state=ROOT/'CURRENT_STATE.zh-CN.md';old=state.read_text(encoding='utf-8');assert marker not in old
    summary=('只用原开发24站的风险验证7日/校准14日，固定全局阈值0.46/c1等价最大预测车速≤30.0664 mph。'
        '人为把预测车速调低2 mph，使校准误报0.084619→0.165256，约1.95倍；这不是测得的真实跨站偏差。')
    prefix=(marker+'\n\n- '+summary+'\n'
        '- 两周各360设置：前周选0.46/c1，后周选0.22/c2。后周规则用于前周三个情景误报均超预算、仅1/3检出下限通过；反方向三个情景通过。两周已参与开发，非新测试。\n'
        '- 自然情景可观测历史一步残差均值+0.058 mph；>5 mph状态不足1%有效时间却含8/31误报起点。仅条件关联，不能据此统一加偏置或认定迁移失败原因。\n'
        '- 下一轮可试残差大时增加一次确认；必须检验检出和提前量代价。本轮未实施新策略，没有接受新模型，下一组站点未选择或读取。\n'
        '- 原冻结诊断源码在保存NumPy整数明细时中止；complete_calibration_fragility.py仅适配标量序列化，原已写计划/网格/选择/results哈希不变。原记录与恢复说明均保留。\n'
        '- 9项实际测试、720周内网格重算、10组扰动回放、告警/暴露量和源哈希审计通过。原论文与GitHub v7保持，所有历史失败记录保留。\n'
        '- 报告outputs/calibration-fragility-2026-10-15/report.zh-CN.md；接续docs/calibration_fragility_handoff.zh-CN.md。\n'
        '- 最新累计备份2026-10-15-calibration-fragility，恢复先10月11日完整基包再本累计包。\n\n以下为之前阶段记录。\n\n')
    state.write_text(prefix+old,encoding='utf-8')
    p=ROOT/'README.md';old=p.read_text(encoding='utf-8')
    p.write_text('# 最新研究：开发数据校准脆弱性诊断\n\n'
        '[完整报告](outputs/calibration-fragility-2026-10-15/report.zh-CN.md) · [接续说明](docs/calibration_fragility_handoff.zh-CN.md)\n\n'
        +summary+' 两周规则互换呈不对称失准；仅诊断，未接受新模型。论文和公开版本保持。最新累计包为2026-10-15-calibration-fragility。\n\n以下为之前阶段记录。\n\n'+old,encoding='utf-8')
    files=set(prior['files'])|{prior_path,'calibration_fragility.py','complete_calibration_fragility.py',
        'audit_calibration_fragility.py','summarize_calibration_fragility.py','save_calibration_fragility_checkpoint.py',
        'tests/test_calibration_fragility.py','docs/calibration_fragility_handoff.zh-CN.md'}
    files|={p.relative_to(ROOT).as_posix() for p in OUT.rglob('*') if p.is_file() and p.name!='writing_archive_manifest.json'}
    base_path=ROOT.parent/'checkpoints/traffic-recovery-lab-2026-10-11-event-timeline-save-receipt.json';base=read(base_path)
    assert Path(base['full_archive']).stat().st_size==base['full_archive_bytes'] and base['archive_crc_and_all_sha256_verified']
    manifest=OUT/'writing_archive_manifest.json'
    write(manifest,{'client_date':'2026-10-15','stage':'cumulative_development_calibration_diagnosis',
        'archive_name':archive.name,'restore':'October11 full base, then this supplement',
        'new_method_accepted':False,'new_station_cohort_consumed':False,'optimizer_updates':0,
        'unit_tests_passed':9,'all720_weekly_grid_replays_checked':True,
        'serialization_recovery_preserved_prior_artifacts':True,
        'prior_files_changed':['README.md','CURRENT_STATE.zh-CN.md'],
        'original_thesis_primary_test_still_failed':True,
        'public_commit_unchanged':'ab8760a3e6ea1784fea3195a0e7aadbaff6fe80d',
        'base_crc_rechecked_this_turn':False,'base_sha256_from_prior_verified_receipt':base['full_archive_sha256'],
        'files':{n:{'bytes':(ROOT/n).stat().st_size,'sha256':sha(ROOT/n)} for n in sorted(files)}})
    files.add(manifest.relative_to(ROOT).as_posix())
    with ZipFile(archive,'x',compression=ZIP_DEFLATED) as z:
        for n in sorted(files):z.write(ROOT/n,'traffic-recovery-lab/'+n)
    with ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist())==len(files)
        for n in sorted(files):
            data=z.read('traffic-recovery-lab/'+n)
            assert data==(ROOT/n).read_bytes() and hashlib.sha256(data).hexdigest()==sha(ROOT/n)
    proof={'saved_at_utc':datetime.now(timezone.utc).isoformat(),'archive':str(archive),
        'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'files':len(files),
        'crc_and_all_file_bytes_and_sha256_verified':True,'new_method_accepted':False,
        'new_station_cohort_consumed':False,'original_thesis_primary_test_still_failed':True,
        'public_version_unchanged':True,'base_prior_verified_receipt':str(base_path),'base_crc_rechecked_this_turn':False}
    write(receipt,proof);print(proof)


if __name__=='__main__':main()
