"""Train a small graph-and-time MLP on synthetic traffic, using CPU only.

This is a PyTorch teaching example, not Graph WaveNet or a new repair method.
No network access or external dataset is needed. See docs/pytorch_guide.zh-CN.md.
"""

from __future__ import annotations

import argparse
import json
import random
import sys
import time
from pathlib import Path

try:
    import numpy as np
except ModuleNotFoundError:
    np = None

try:
    import torch
    from torch import nn
    from torch.utils.data import DataLoader, TensorDataset
except ModuleNotFoundError:
    torch = None
    nn = None


def make_synthetic_traffic(steps: int, nodes: int, seed: int):
    """Deterministic given seed; values represent simulated vehicles / 5 min."""
    rng = np.random.default_rng(seed)
    clock = np.arange(steps, dtype=np.float64)[:, None]
    phase = np.linspace(0.0, 0.7, nodes)[None, :]
    daily = np.sin(2.0 * np.pi * clock / 288.0 - phase)
    shorter_cycle = np.sin(2.0 * np.pi * clock / 72.0 + phase)
    base = rng.uniform(45.0, 90.0, size=(1, nodes))
    amplitude = rng.uniform(12.0, 25.0, size=(1, nodes))
    desired = base + amplitude * daily + 5.0 * shorter_cycle
    residual = np.zeros((steps, nodes), dtype=np.float64)
    for t in range(1, steps):
        residual[t] = (
            0.60 * residual[t - 1]
            + 0.20 * np.roll(residual[t - 1], 1)
            + rng.normal(0.0, 2.0, size=nodes)
        )
    return np.maximum(desired + residual, 0.0).astype(np.float32)


def make_adjacency(nodes: int):
    """A toy ring road: self, upstream neighbor and downstream neighbor."""
    adjacency = np.eye(nodes, dtype=np.float32)
    for i in range(nodes):
        adjacency[i, (i - 1) % nodes] = 1.0
        adjacency[i, (i + 1) % nodes] = 1.0
    return adjacency / adjacency.sum(axis=1, keepdims=True)


def make_windows(normalized, start: int, stop: int, history: int, horizon: int):
    """Both input and target stay entirely inside one chronological split."""
    starts = range(start, stop - history - horizon + 1)
    pairs = [
        (normalized[t : t + history], normalized[t + history : t + history + horizon])
        for t in starts
    ]
    x = torch.from_numpy(np.stack([pair[0] for pair in pairs]))
    y = torch.from_numpy(np.stack([pair[1] for pair in pairs]))
    return TensorDataset(x, y)


def observation_mask(shape, missing_rate: float, outage_rate: float, generator):
    """Point losses plus whole-history sensor outages; independent of values."""
    point_observed = torch.rand(shape, generator=generator) >= missing_rate
    sensor_observed = torch.rand(
        (shape[0], 1, shape[2]), generator=generator
    ) >= outage_rate
    return (point_observed & sensor_observed).to(torch.float32)


def pack_features(values, mask):
    """Zero-fill in normalized space AND provide an explicit observation mask."""
    return torch.stack((values * mask, mask), dim=-1)


def last_observed(values, mask):
    """Use only input history; fallback zero means the training-set mean."""
    positions = torch.arange(values.shape[1]).view(1, -1, 1)
    indices = torch.where(mask > 0, positions, -1).amax(dim=1)
    latest = values.gather(1, indices.clamp_min(0).unsqueeze(1)).squeeze(1)
    return torch.where(indices >= 0, latest, torch.zeros_like(latest))


if nn is not None:

    class GraphTemporalMLP(nn.Module):
        """Masked graph aggregation + shared temporal MLP + history baseline.

        Input: [batch, history, sensors, 2]. Output: [batch, horizon, sensors].
        Fixed graph, no dilated convolutions and no adaptive graph: NOT Graph WaveNet.
        """

        def __init__(self, history: int, horizon: int, adjacency, hidden: int = 64):
            super().__init__()
            # Buffers move/save with the model, but the optimizer does not train them.
            self.register_buffer("adjacency", torch.as_tensor(adjacency).float())
            self.temporal = nn.Sequential(
                nn.Linear(history * 4, hidden),
                nn.ReLU(),
                nn.Linear(hidden, horizon),
            )
            self.horizon = horizon

        def forward(self, x):
            values, mask = x[..., 0], x[..., 1]
            # A[i,j] is the contribution of sensor j to sensor i.
            neighbor_sum = torch.einsum("ij,btj->bti", self.adjacency, values)
            coverage = torch.einsum("ij,btj->bti", self.adjacency, mask)
            neighbor_mean = neighbor_sum / coverage.clamp_min(1e-6)
            features = torch.stack((values, mask, neighbor_mean, coverage), dim=-1)
            # Each sensor receives its entire historical window; MLP weights are shared.
            by_sensor = features.permute(0, 2, 1, 3).flatten(start_dim=2)
            correction = self.temporal(by_sensor).permute(0, 2, 1)
            baseline = last_observed(values, mask).unsqueeze(1)
            return baseline + correction


def evaluate(model, dataset, fixed_mask, scale, batch_size: int):
    """Evaluate model and persistence on exactly the same visible observations."""
    loader = DataLoader(
        TensorDataset(*dataset.tensors, fixed_mask), batch_size=batch_size, shuffle=False
    )
    model.eval()
    model_error, baseline_error, count = 0.0, 0.0, 0
    with torch.no_grad():
        for values, target, mask in loader:
            x = pack_features(values, mask)
            prediction = model(x)
            persistence = last_observed(x[..., 0], mask).unsqueeze(1).expand_as(target)
            # Scale per-sensor errors back to the original synthetic flow units.
            model_error += ((prediction - target).abs() * scale).sum().item()
            baseline_error += ((persistence - target).abs() * scale).sum().item()
            count += target.numel()
    return {
        "model_mae": model_error / count,
        "persistence_mae": baseline_error / count,
        "prediction_count": count,
    }


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--steps", type=int, default=1152)
    parser.add_argument("--nodes", type=int, default=12)
    parser.add_argument("--history", type=int, default=12)
    parser.add_argument("--horizon", type=int, default=3)
    parser.add_argument("--hidden", type=int, default=64)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--learning-rate", type=float, default=0.001)
    parser.add_argument("--missing-rate", type=float, default=0.15)
    parser.add_argument("--outage-rate", type=float, default=0.15)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--threads", type=int, default=1)
    parser.add_argument("--output-dir", type=Path, default=Path("outputs/torch-example"))
    args = parser.parse_args(argv)
    for name in ("epochs", "history", "horizon", "hidden", "batch_size", "threads"):
        if getattr(args, name) < 1:
            parser.error(f"--{name.replace('_', '-')} must be at least 1")
    if args.nodes < 3:
        parser.error("--nodes must be at least 3")
    if not is_finite_positive(args.learning_rate):
        parser.error("--learning-rate must be finite and positive")
    if not 0 <= args.seed < 2**32:
        parser.error("--seed must be an integer in [0, 2**32)")
    for name in ("missing_rate", "outage_rate"):
        if not 0.0 <= getattr(args, name) <= 1.0:
            parser.error(f"--{name.replace('_', '-')} must be in [0, 1]")
    boundaries = (0, int(args.steps * 0.6), int(args.steps * 0.8), args.steps)
    if any(b - a < args.history + args.horizon for a, b in zip(boundaries, boundaries[1:])):
        parser.error("--steps is too small: every 60/20/20 split must fit history + horizon")
    return args


def is_finite_positive(value):
    # Keep --help / argument checking available even when NumPy is not installed.
    import math

    return math.isfinite(value) and value > 0


def run(args):
    if np is None or torch is None:
        missing = ", ".join(
            name for name, module in (("numpy", np), ("torch", torch)) if module is None
        )
        print(
            f"Missing dependency: {missing}. No training was run.\n"
            "In the Python environment you intend to use, install dependencies with:\n"
            "  python -m pip install numpy\n"
            "  python -m pip install torch --index-url https://download.pytorch.org/whl/cpu\n"
            "Then run: python torch_example.py\n"
            "PyTorch installation options: https://pytorch.org/get-started/locally/",
            file=sys.stderr,
        )
        return 2

    started = time.perf_counter()
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.set_num_threads(args.threads)
    torch.use_deterministic_algorithms(True)

    raw = make_synthetic_traffic(args.steps, args.nodes, args.seed)
    train_end, validation_end = int(args.steps * 0.6), int(args.steps * 0.8)
    # Fit normalization on training timestamps ONLY, before making any windows.
    mean = raw[:train_end].mean(axis=0)
    std = np.maximum(raw[:train_end].std(axis=0), 1e-6)
    normalized = ((raw - mean) / std).astype(np.float32)
    ranges = {
        "train": (0, train_end),
        "validation": (train_end, validation_end),
        "test": (validation_end, args.steps),
    }
    datasets = {
        name: make_windows(normalized, start, stop, args.history, args.horizon)
        for name, (start, stop) in ranges.items()
    }
    # Separate generators keep evaluation masks unchanged across epochs.
    fixed_masks = {
        name: observation_mask(
            dataset.tensors[0].shape,
            args.missing_rate,
            args.outage_rate,
            torch.Generator().manual_seed(args.seed + 1000 + i),
        )
        for i, (name, dataset) in enumerate(datasets.items())
    }
    training_generator = torch.Generator().manual_seed(args.seed + 2000)
    shuffle_generator = torch.Generator().manual_seed(args.seed + 3000)
    loader = DataLoader(
        datasets["train"], batch_size=args.batch_size, shuffle=True, generator=shuffle_generator
    )
    model = GraphTemporalMLP(
        args.history, args.horizon, make_adjacency(args.nodes), args.hidden
    )
    optimizer = torch.optim.Adam(model.parameters(), lr=args.learning_rate)
    loss_fn = nn.L1Loss()
    scale = torch.from_numpy(std).view(1, 1, -1)
    best_state, best_epoch, best_validation = None, 0, float("inf")
    history = []
    print("CPU / synthetic data / graph aggregation + temporal MLP (not Graph WaveNet)")
    print(f"Windows: { {name: len(data) for name, data in datasets.items()} }")

    for epoch in range(1, args.epochs + 1):
        model.train()
        loss_sum, sample_count = 0.0, 0
        for values, target in loader:
            mask = observation_mask(
                values.shape, args.missing_rate, args.outage_rate, training_generator
            )
            optimizer.zero_grad(set_to_none=True)
            prediction = model(pack_features(values, mask))
            loss = loss_fn(prediction, target)
            loss.backward()
            optimizer.step()
            loss_sum += loss.item() * values.shape[0]
            sample_count += values.shape[0]
        validation = evaluate(
            model, datasets["validation"], fixed_masks["validation"], scale, args.batch_size
        )
        if validation["model_mae"] < best_validation:
            best_validation = validation["model_mae"]
            best_epoch = epoch
            best_state = {key: value.detach().cpu().clone() for key, value in model.state_dict().items()}
        history.append(
            {"epoch": epoch, "train_loss_normalized": loss_sum / sample_count, **validation}
        )
        if epoch == 1 or epoch == args.epochs or epoch % 5 == 0:
            print(
                f"Epoch {epoch:02d}: normalized train L1={loss_sum / sample_count:.4f}, "
                f"validation MAE={validation['model_mae']:.3f}, "
                f"persistence MAE={validation['persistence_mae']:.3f}"
            )

    # Select using validation only. Test is evaluated once after training ends.
    model.load_state_dict(best_state)
    metrics = {
        name: evaluate(model, data, fixed_masks[name], scale, args.batch_size)
        for name, data in datasets.items()
    }
    args.output_dir.mkdir(parents=True, exist_ok=True)
    config = {key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()}
    checkpoint_path = args.output_dir / "model.pt"
    torch.save(
        {
            "model_state_dict": model.state_dict(),
            "normalization_mean": torch.from_numpy(mean),
            "normalization_std": torch.from_numpy(std),
            "config": config,
            "best_epoch": best_epoch,
            "model_name": "graph_aggregation_temporal_mlp_teaching_example",
        },
        checkpoint_path,
    )
    results = {
        "data_source": "synthetic; not a real traffic dataset",
        "device": "cpu",
        "torch_version": str(torch.__version__),
        "model": "fixed masked graph aggregation + temporal MLP; not Graph WaveNet",
        "baseline": "last observed history value; training mean if no observation",
        "mae_unit": "simulated vehicles per 5 minutes",
        "config": config,
        "time_ranges_half_open": ranges,
        "windows": {name: len(data) for name, data in datasets.items()},
        "normalization_fit_range_half_open": [0, train_end],
        "best_epoch": best_epoch,
        "metrics": metrics,
        "training_history": history,
        "elapsed_seconds": time.perf_counter() - started,
        "notes": [
            "Model and baseline use the same fixed evaluation observation masks.",
            "Training regenerates random missing-data masks every batch.",
            "Evaluation truth is used only to calculate errors, never for repair ranking.",
            "Synthetic results do not establish real-data accuracy or research novelty.",
        ],
    }
    results_path = args.output_dir / "results.json"
    results_path.write_text(json.dumps(results, indent=2, ensure_ascii=False, allow_nan=False), encoding="utf-8")
    print(f"Selected epoch {best_epoch} using validation MAE.")
    for name, metric in metrics.items():
        print(
            f"{name:10s} MAE: model={metric['model_mae']:.3f}, "
            f"persistence={metric['persistence_mae']:.3f}"
        )
    print(f"Saved {checkpoint_path.resolve()} and {results_path.resolve()}")
    print("A better score than persistence is not guaranteed; inspect the actual results.")
    return 0


if __name__ == "__main__":
    raise SystemExit(run(parse_args()))
