"""Exploratory transfer of frozen probes to an already-consumed station cohort.

Cached values only, no raw HDF5, optimizer, threshold refit, policy or new holdout.
"""
from __future__ import annotations
from datetime import datetime,timezone
import os
from pathlib import Path
import sys
from unittest.mock import patch
import numpy as np
import torch
import alarm_start_separability as probe
import calibration_fragility as common
from congestion_alert_pilot import SCENARIOS
from train_pems_bay_risk import load_risk

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs/frozen-probe-transfer-2026-10-15'
CACHE=ROOT/'outputs/new-station-transfer-2026-10-15'
PROBES=probe.OUT
INPUT_NAMES=[
    'outputs/new-station-transfer-2026-10-15/plan.json',
    'outputs/new-station-transfer-2026-10-15/completion.json',
    'outputs/new-station-transfer-2026-10-15/evaluation_features.npz',
    'outputs/new-station-transfer-2026-10-15/fixed_scores.npz',
    'outputs/alarm-start-separability-2026-10-15/training_freeze.json',
    'outputs/alarm-start-separability-2026-10-15/completion.json',
    'outputs/alarm-start-separability-2026-10-15/training.json',
    'outputs/alarm-start-separability-2026-10-15/score_logistic.npz',
    'outputs/alarm-start-separability-2026-10-15/residual_logistic.npz',
    'outputs/alarm-start-separability-2026-10-15/state_logistic.npz',
    'outputs/pems-bay-risk/normalization.npz',
    'outputs/pems-bay-risk/global_calibration.pt']
ALLOWED={str((ROOT/name).resolve()).replace('\\','/').lower() for name in INPUT_NAMES}
READS=[]


def guard(event,args):
    if event!='open' or not isinstance(args[0],(str,bytes)):return
    raw=os.fsdecode(args[0]);name=str(Path(raw).resolve()).replace('\\','/').lower()
    if name.endswith(('.h5','.hdf5')) or '/data/raw/' in name:
        raise PermissionError('Frozen transfer only allows the named consumed cache, no raw source')
    if '/outputs/' not in name:return
    target=Path(raw).resolve()
    if target.is_relative_to(OUT.resolve()):return
    mode=args[1] or '';flags=args[2] if len(args)>2 else 0
    writing=any(mark in mode for mark in ('w','a','+','x')) or bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
    if writing:raise PermissionError('Scientific inputs are read-only')
    if name not in ALLOWED:raise PermissionError('Undeclared output input: '+name)
    READS.append(name)


def prohibit_refit(*args,**kwargs):raise PermissionError('Frozen transfer forbids probe or cutoff fitting')


def weighted_discrimination(y,p,weights):
    """Tie-correct empirical AUC/AP with nonnegative date-bootstrap multiplicities."""
    y=np.asarray(y,bool);p=np.asarray(p,float);weights=np.asarray(weights,float)
    if y.shape!=p.shape or weights.shape!=y.shape or np.any(weights<0) or not np.isfinite(weights).all():
        raise ValueError('Invalid weighted metric inputs')
    positive=float(weights[y].sum());negative=float(weights[~y].sum())
    if not positive or not negative:return {'roc_auc':None,'average_precision':None}
    order=np.argsort(p,kind='stable');values=p[order];truth=y[order];w=weights[order]
    starts=np.r_[0,np.flatnonzero(np.diff(values)!=0)+1]
    pg=np.add.reduceat(w*truth,starts);ng=np.add.reduceat(w*~truth,starts)
    auc=float(np.sum(pg*(np.cumsum(ng)-ng+.5*ng))/(positive*negative))
    pd,nd=pg[::-1],ng[::-1];tp=np.cumsum(pd);total=np.cumsum(pd+nd)
    precision=np.divide(tp,total,out=np.zeros_like(tp),where=total>0)
    ap=float(np.sum(pd/positive*precision))
    return {'roc_auc':auc,'average_precision':ap}


def date_paired_bootstrap(samples,candidate,reference,dates,draws):
    date_index={str(date):i for i,date in enumerate(dates)}
    indices=np.array([date_index[str(date)] for date in samples['date']],int)
    observed_a=weighted_discrimination(samples['y'],candidate,np.ones(len(indices)))
    observed_b=weighted_discrimination(samples['y'],reference,np.ones(len(indices)))
    differences={key:[] for key in observed_a};invalid=0
    for draw in draws:
        weights=np.bincount(draw,minlength=len(dates))[indices]
        a=weighted_discrimination(samples['y'],candidate,weights)
        b=weighted_discrimination(samples['y'],reference,weights)
        if any(v is None for v in (*a.values(),*b.values())):
            invalid+=1;continue
        for key in differences:differences[key].append(a[key]-b[key])
    return {key:{'difference':observed_a[key]-observed_b[key] if observed_a[key] is not None and observed_b[key] is not None else None,
        'conditional_ci95':np.quantile(values,[.025,.975]).tolist() if not invalid and values else None,
        'undefined_draws':invalid,'draws':len(draws)} for key,values in differences.items()}


def freeze_plan():
    OUT.mkdir(exist_ok=True)
    previous=common.read(CACHE/'plan.json')
    sources=['frozen_probe_transfer.py','alarm_start_separability.py','calibration_fragility.py',
        'pems_bay_alert_replay.py','congestion_alert_pilot.py','congestion_risk_pilot.py','train_pems_bay_risk.py']
    plan={'stage':'exploratory_frozen_probe_transfer_to_previously_consumed_cohort_A',
        'cohort_already_analyzed':True,'external_independent_confirmation':False,
        'same_network_and_calendar_as_development':True,
        'same_cohort_frontend_previously_adapted':True,'new_frontend_training':False,
        'new_station_ids':previous['new_station_ids'],'development_station_ids':previous['development_station_ids'],
        'cached_source_only':True,'raw_hdf5_reopened':False,
        'fixed_models':list(probe.METHODS),'fixed_cutoffs':'original training_freeze, no new normalization/weight/cutoff selection',
        'unit':'same credited warned versus false start task; late/duplicate/unknown/censored excluded; not a complete alert policy',
        'global_alarm':'original global0.46/c1, exact match to consumed cached global scores required',
        'features':'unchanged30 features, exclude node identities; same causal past residual',
        'blocks_days_half_open':{'full83':[0,83],'first28':[0,28],'middle28':[28,56],'last27':[56,83]},
        'block_boundaries':'independent replay censoring, reset at first block origin; whole source clock mapping retained',
        'natural_diagnostic_gate':'reuse original>=10 each class, state AUC>=0.70 and baseline envelope+0.05, AP>=envelope, required for full and each subblock; not deployment acceptance',
        'fault_scenarios':'report separately, shared truth not independent populations',
        'uncertainty':'2000 paired-calendar-date bootstrap draws seed20261015 for full83, same draws across scenarios; compare frozen state versus frozen score_logistic only; no CI if any draw undefined; descriptive, conditional on fixed front end/probes and already-seen cohort',
        'baseline_envelope':'point diagnostic only, not executable selection; interval comparator fixed before cache decode',
        'retention':'use original training95%-retention cutoff; conditional rejection is not replayed false reduction',
        'on_failure':'no refit, recalibration, cohort replacement or next-cohort test; keep failure',
        'on_pass':'exploratory signal only; previous failed development gate and thesis primary remain failed; no model accepted',
        'new_alarm_policy_evaluated':False,'optimizer_updates':0,
        'input_sha256':{name:common.sha(ROOT/name) for name in INPUT_NAMES},
        'source_sha256':{name:common.sha(ROOT/name) for name in sources}}
    path=OUT/'plan.json'
    if path.exists():assert {k:v for k,v in common.read(path).items() if k!='frozen_at_utc'}==plan
    else:common.write(path,{**plan,'frozen_at_utc':datetime.now(timezone.utc).isoformat()})
    return plan


def main():
    sys.addaudithook(guard);torch.set_num_threads(1)
    plan=freeze_plan()
    if (OUT/'completion.json').exists():
        for name,digest in common.read(OUT/'completion.json')['artifacts'].items():assert common.sha(OUT/name)==digest
        print('Completed cached transfer verified; no rerun');return
    previous=common.read(CACHE/'completion.json');frozen=common.read(PROBES/'training_freeze.json')
    assert common.sha(CACHE/'evaluation_features.npz')==previous['evaluation_feature_sha256']
    assert common.sha(CACHE/'fixed_scores.npz')==previous['scores_sha256']
    for name,digest in frozen['weights'].items():assert common.sha(PROBES/name)==digest
    training=common.read(PROBES/'training.json')['training_class_counts']
    prior=sum(v['credited_warnings'] for v in training.values())/sum(v['rows'] for v in training.values())
    models={name:common.load(PROBES/(name+'.npz')) for name in probe.METHODS}
    norm=common.load(common.RISK/'normalization.npz');anchor=load_risk(common.RISK/'global_calibration.pt')
    # No values decoded until the transfer question and every input hash are frozen.
    part=common.load(CACHE/'evaluation_features.npz')
    assert len(common.layout(part)[2])==83
    for s in SCENARIOS:assert np.all(part[s+'_state'][:,:,24:48]==0),'Consumed unknown-identity cache changed'
    global_scores=common.global_scores(part,norm,anchor)
    with np.load(CACHE/'fixed_scores.npz') as saved:
        for s in SCENARIOS:np.testing.assert_array_equal(global_scores[s],saved['global_calibration__'+s])
    metrics={};retention={};counts={};predictions={};artifacts=[];full_samples=None;date_ranges={}
    with patch.object(probe,'fit_probe',prohibit_refit),patch.object(probe,'retention_threshold',prohibit_refit):
        for block,(lo,hi) in plan['blocks_days_half_open'].items():
            local=part if block=='full83' else common.subset(part,lo,hi)
            scores=global_scores if block=='full83' else common.global_scores(local,norm,anchor)
            data,excluded=probe.build_samples(local,scores)
            if block=='full83':full_samples=data
            counts[block]=excluded;metrics[block]={};retention[block]={}
            date_ranges[block]=local['timestamps'][local['origins'][[0,-1]]].astype('datetime64[D]').astype(str).tolist()
            for s,rows in data.items():
                path=OUT/(block+'__'+s+'_samples.npz');np.savez_compressed(path,**rows);artifacts.append(path.name)
                p={'constant_prior':np.full(len(rows['y']),prior),'fixed_risk':rows['global_probability'],
                    **{name:probe.predict(model,rows['x']) for name,model in models.items()}}
                metrics[block][s]={name:probe.binary_metrics(rows['y'],value) for name,value in p.items()}
                retention[block][s]={name:probe.retention_metrics(rows,p[name],frozen['cutoffs'][name]) for name in models}
                for name,value in p.items():predictions[f'{block}__{s}__{name}']=value
            print(block+': '+str({name:(v['rows'],v['roc_auc'],v['average_precision']) for name,v in metrics[block]['natural'].items()}),flush=True)
    gate=probe.separation_gate({block:value['natural'] for block,value in metrics.items()})
    dates=common.layout(part)[2]
    draws=np.random.default_rng(20261015).integers(0,len(dates),(2000,len(dates)))
    uncertainty={s:date_paired_bootstrap(full_samples[s],predictions[f'full83__{s}__state_logistic'],
        predictions[f'full83__{s}__score_logistic'],dates,draws) for s in SCENARIOS}
    result={'stage':'fixed_probe_consumed_cohort_transfer_diagnosis','metrics':metrics,'retention':retention,
        'excluded_episode_counts':counts,'block_date_ranges':date_ranges,'natural_diagnostic_gate':gate,
        'full83_state_minus_score_logistic_date_bootstrap':uncertainty,
        'cohort_already_consumed':True,'external_independent_confirmation':False,
        'frontend_previously_adapted':True,'probes_or_thresholds_refit':False,
        'original_development_diagnostic_gate_still_failed':True,'original_thesis_primary_test_still_failed':True,
        'new_alarm_policy_accepted':False,'new_alarm_policy_evaluated':False,'new_station_cohort_consumed':False,
        'limitation':'One already-analyzed cohort on same network/calendar, cached adapted forecasters; conditional task excluding several alert types. Bootstrap excludes training/station/network uncertainty; no confirmatory superiority or actual policy gains.'}
    common.write(OUT/'results.json',result)
    np.savez_compressed(OUT/'predictions.npz',**predictions);artifacts.append('predictions.npz')
    np.savez_compressed(OUT/'bootstrap_draws.npz',draws=draws,dates=dates);artifacts.append('bootstrap_draws.npz')
    common.write(OUT/'access_log.json',{'declared_input_open_paths':sorted(set(READS)),
        'named_cached_input_allowlist_enforced':True,'old_scientific_input_writes_forbidden':True,
        'raw_hdf5_opened':False,'undeclared_new_or_old_cohort_values_used':False,
        'probe_fit_and_cutoff_fit_calls_blocked':True})
    common.write(OUT/'result_freeze.json',{'frozen_at_utc':datetime.now(timezone.utc).isoformat(),
        'plan_sha256':common.sha(OUT/'plan.json'),'results_sha256':common.sha(OUT/'results.json'),
        'originating_training_freeze_sha256':common.sha(PROBES/'training_freeze.json'),
        'unchanged_probe_cutoffs':frozen['cutoffs'],'new_alarm_policy_accepted':False})
    for mapping in ('input_sha256','source_sha256'):
        for name,digest in plan[mapping].items():assert common.sha(ROOT/name)==digest,name
    artifacts+=['results.json','access_log.json','result_freeze.json']
    common.write(OUT/'completion.json',{'completed_at_utc':datetime.now(timezone.utc).isoformat(),
        'plan_sha256':common.sha(OUT/'plan.json'),'artifacts':{name:common.sha(OUT/name) for name in artifacts}})
    print({'diagnostic_gate':gate,'natural_date_bootstrap':uncertainty['natural'],'new_alarm_policy_accepted':False},flush=True)


if __name__=='__main__':main()
