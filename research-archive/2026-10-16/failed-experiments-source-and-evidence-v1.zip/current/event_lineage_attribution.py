"""Record-only attribution under the two frozen recovery definitions.

No cache decode, model inference, optimization or policy/label changes. All
groups are offline lineage descriptions, never deployable feature inputs.
"""
from datetime import datetime,timezone
from collections import Counter
from pathlib import Path
import sys
import calibration_fragility as common
import early_warning_protection as protection

ROOT=Path(__file__).resolve().parent
PRIOR=ROOT/'outputs/recovery-definition-sensitivity-2026-10-16'
OUT=ROOT/'outputs/event-lineage-attribution-2026-10-16'
METHODS=('global_c1','effective_no_bypass','effective_protected_gate')
KINDS=('warned','late','false','duplicate','censored','unknown')
GROUPS={'one_high':('first_segment','reentry_segment','parent_censored'),
    'two_high':('single_segment_process','multi_segment_process')}
PAIRS={'no_bypass_vs_global':('global_c1','effective_no_bypass'),
    'with_bypass_vs_global':('global_c1','effective_protected_gate'),
    'bypass_vs_no_bypass':('effective_no_bypass','effective_protected_gate')}


def event_key(e):return (e['node'],e['event_start_origin'])
def episode_key(e):return (e['node'],e['row'],e['length_steps'])
def detected(e):return e['status']!='missed'
def r10(e):return e['status']=='warned' and e['lead_minutes']>=10


def group_events(link):
    old={};new={}
    for m in link['old_to_new']:
        a,b=m['old'],m['new']
        if a['complete']:
            group='parent_censored' if not b['complete'] else 'first_segment' if a['event_start_origin']==b['event_start_origin'] else 'reentry_segment'
            old[event_key(a)]={'group':group,'run':a,'parent':b,'new_run_index':m['new_run_index']}
    for j,b in enumerate(link['new_runs']):
        if not b['complete']:continue
        children=[m['old'] for m in link['old_to_new'] if m['new_run_index']==j]
        assert children
        new[event_key(b)]={'group':'multi_segment_process' if len(children)>1 else 'single_segment_process',
            'run':b,'old_children':children,'new_run_index':j}
    return {'one_high':old,'two_high':new}


def metrics(events):
    n=len(events);statuses=Counter(e['status'] for e in events)
    warnings=[e for e in events if e['status']=='warned']
    return {'events':n,'detected':sum(detected(e) for e in events),'warned':statuses['warned'],
        'late':statuses['late'],'missed':statuses['missed'],'R10':sum(r10(e) for e in events),
        'R15':sum(e['lead_minutes']==15 for e in warnings),
        'detection_recall':sum(detected(e) for e in events)/n if n else None,
        'R10_recall':sum(r10(e) for e in events)/n if n else None}


def tag_episodes(episodes,catalog):
    result=[]
    for e in episodes:
        if e['kind'] in ('warned','late','duplicate'):
            matches=[v for v in catalog.values() if v['run']['node']==e['node'] and
                v['run']['start_row']-2<=e['row']<v['run']['end_row']]
            assert len(matches)==1,(e,matches)
            m=matches[0];group=m['group'];key=list(event_key(m['run']))
        else:group=None;key=None
        result.append({**e,'event_group':group,'matched_window_event_key':key})
    return result


def event_comparison(before,after,catalog,groups):
    a={event_key(e):e for e in before};b={event_key(e):e for e in after}
    assert a.keys()==b.keys()==catalog.keys()
    changed=[];summaries={}
    for group in groups:
        keys=[k for k,v in catalog.items() if v['group']==group]
        records=[]
        for k in keys:
            old,new=a[k],b[k]
            original_r10=r10(old)
            early_lost=original_r10 and not (r10(new) and new['lead_minutes']>=old['lead_minutes'])
            rec={'node':k[0],'event_start_origin':k[1],'group':group,
                'before_status':old['status'],'after_status':new['status'],
                'before_lead_minutes':old['lead_minutes'],'after_lead_minutes':new['lead_minutes'],
                'recovered_detection':not detected(old) and detected(new),
                'lost_detection':detected(old) and not detected(new),
                'R10_gained':not r10(old) and r10(new),'R10_lost':r10(old) and not r10(new),
                'original_R10_lost_or_delayed':bool(early_lost)}
            records.append(rec)
            if old['status']!=new['status'] or old['lead_minutes']!=new['lead_minutes']:changed.append(rec)
        summaries[group]={'events':len(keys),
            **{name:sum(r[name] for r in records) for name in ('recovered_detection','lost_detection','R10_gained','R10_lost','original_R10_lost_or_delayed')},
            'before':metrics([a[k] for k in keys]),'after':metrics([b[k] for k in keys])}
    return {'groups':summaries,'changed_event_records':changed}


def episode_comparison(before,after):
    a={episode_key(e):e for e in before};b={episode_key(e):e for e in after}
    assert len(a)==len(before) and len(b)==len(after)
    removed=[a[k] for k in a.keys()-b.keys()];added=[b[k] for k in b.keys()-a.keys()]
    changes=[{'node':k[0],'row':k[1],'length_steps':k[2],
        'before_kind':a[k]['kind'],'after_kind':b[k]['kind'],
        'before_event_group':a[k]['event_group'],'after_event_group':b[k]['event_group']}
        for k in sorted(a.keys()&b.keys()) if a[k]['kind']!=b[k]['kind']]
    counts=lambda rows:{kind:sum(e['kind']==kind for e in rows) for kind in KINDS}
    delta={k:sum(e['kind']==k for e in after)-sum(e['kind']==k for e in before) for k in KINDS}
    for k in KINDS:
        assert delta[k]==sum(e['kind']==k for e in added)-sum(e['kind']==k for e in removed)+sum(c['after_kind']==k for c in changes)-sum(c['before_kind']==k for c in changes)
    return {'before_episode_count':len(before),'after_episode_count':len(after),
        'net_episode_count_change':len(after)-len(before),'added_episode_types':counts(added),'removed_episode_types':counts(removed),
        'net_type_changes':delta,'shared_episode_type_changes':changes,
        'added_episode_records':sorted(added,key=episode_key),'removed_episode_records':sorted(removed,key=episode_key)}


def definition_episode_transition(one,two):
    a={episode_key(e):e for e in one};b={episode_key(e):e for e in two};assert a.keys()==b.keys()
    matrix={x:{y:0 for y in KINDS} for x in KINDS};changes=[]
    for k in sorted(a):
        x,y=a[k]['kind'],b[k]['kind'];matrix[x][y]+=1
        if x!=y:changes.append({'node':k[0],'row':k[1],'length_steps':k[2],
            'one_high_kind':x,'two_high_kind':y,
            'one_high_event_group':a[k]['event_group'],'two_high_event_group':b[k]['event_group']})
    return {'episode_count_unchanged':len(a),'kind_transition_matrix':matrix,'changed_episode_records':changes}


def freeze_plan():
    OUT.mkdir(exist_ok=True)
    names=['event_lineage_attribution.py','recovery_definition_sensitivity.py','pems_bay_alert_replay.py',
        'congestion_alert_pilot.py','calibration_fragility.py','early_warning_protection.py',
        'outputs/recovery-definition-sensitivity-2026-10-16/plan.json',
        'outputs/recovery-definition-sensitivity-2026-10-16/completion.json',
        'outputs/recovery-definition-sensitivity-2026-10-16/audit.json',
        'outputs/recovery-definition-sensitivity-2026-10-16/results.json']
    plan={'stage':'fixed_record_only_event_lineage_attribution','client_date':'2026-10-16',
        'frozen_at_utc':datetime.now(timezone.utc).isoformat(),
        'allowed_input':'only previous fixed1/2 recovery shared-support results and audit metadata; no sample cache/model decode or fresh replay',
        'first_definition_groups':{'first_segment':'old complete run shares onset with complete two-high parent',
            'reentry_segment':'old complete run starts after onset of its complete two-high parent',
            'parent_censored':'old complete run maps to censored two-high parent, kept as explicit group'},
        'second_definition_groups':{'single_segment_process':'complete two-high parent contains one old run',
            'multi_segment_process':'complete two-high parent contains >=2old runs, including censored children in counting'},
        'meaning':'first is relative to this frozen parent process, not first real congestion, first ever, or first day event',
        'groups_offline_only':True,'methods':list(METHODS),'pair_comparisons':PAIRS,
        'metrics':'event counts/detected/warned/late/missed/R10/R15 and per-event gains/losses/lead preservation; no group false-rate denominator invented',
        'alarm_burden':'episode count, all6types; assign credited/late/duplicate episodes to corresponding complete-event group; false/censored/unknown kept separate',
        'reclassification':'exact episode key(node,row,length) across definitions must match; type transition is not changed activation or notification saving',
        'policy_comparison':'added/removed episodes + shared episode type changes; reconcile net type count algebra; do not equate duplicate count drop with actual alarm suppression',
        'uncertainty':'descriptive counts on reused development; no new bootstrap, inference, fitting or candidate selection',
        'new_models_fitted':0,'optimizer_updates':0,'new_model_inference_calls':0,'policy_or_labels_changed':False,
        'new_acceptance_test':False,'original_thesis_primary_test_still_failed':True,
        'no_forbidden_values':'no rawHDF5, original evaluation, consumed transfer/station results, next cohort',
        'source_and_input_sha256':{n:common.sha(ROOT/n) for n in names}}
    if (OUT/'plan.json').exists():raise FileExistsError('Preserve planned attribution')
    common.write(OUT/'plan.json',plan);return plan


def main():
    sys.addaudithook(protection.guard);plan=freeze_plan()
    prior=common.read(PRIOR/'results.json');proof=common.read(PRIOR/'audit.json')
    assert proof['passed'] and proof['results_sha256']==common.sha(PRIOR/'results.json')
    assert not prior['previous_candidate_acceptance_passed'] and prior['original_thesis_primary_test_still_failed']
    blocks={}
    for block,data in prior['blocks'].items():
        catalog=group_events(data['lineage']);result={'shared_evidence':data['shared_evidence'],
            'event_groups':{d:[{'node':k[0],'event_start_origin':k[1],**v} for k,v in c.items()] for d,c in catalog.items()},
            'definitions':{},'definition_episode_transitions':{}}
        for definition,scenarios in data['shared_evaluation'].items():
            result['definitions'][definition]={}
            for scenario,methods in scenarios.items():
                method_results={};tagged={}
                for method,row in methods.items():
                    events=row['event_records'];assert {event_key(e) for e in events}==catalog[definition].keys()
                    tagged[method]=tag_episodes(row['episode_records'],catalog[definition])
                    groups={}
                    for group in GROUPS[definition]:
                        selected=[e for e in events if catalog[definition][event_key(e)]['group']==group]
                        episode_counts={kind:sum(e['event_group']==group and e['kind']==kind for e in tagged[method]) for kind in ('warned','late','duplicate')}
                        groups[group]={'metrics':metrics(selected),'associated_episode_counts':episode_counts}
                    m=metrics(events);op=row['operating']
                    assert m['events']==op['events'] and m['detected']==op['detected'] and m['R10']==sum(op['warning_lead_counts'][str(k)] for k in (10,15))
                    for column in ('events','detected','warned','late','missed','R10','R15'):assert sum(g['metrics'][column] for g in groups.values())==m[column]
                    counts={kind:sum(e['kind']==kind for e in tagged[method]) for kind in KINDS}
                    for kind,column in [('warned','warned'),('late','late'),('false','false'),('duplicate','duplicate'),('censored','censored_alerts'),('unknown','unknown_alerts')]:assert counts[kind]==op[column]
                    method_results[method]={'groups':groups,'overall_events':m,'episode_count':len(tagged[method]),
                        'episode_type_counts':counts,'tagged_episodes':tagged[method],'operating_unchanged':op}
                comparisons={}
                for name,(before,after) in PAIRS.items():
                    ec=event_comparison(methods[before]['event_records'],methods[after]['event_records'],catalog[definition],GROUPS[definition])
                    ac=episode_comparison(tagged[before],tagged[after])
                    if name=='bypass_vs_no_bypass':assert not ac['removed_episode_records']
                    else:assert not ac['added_episode_records']
                    comparisons[name]={'event_comparison':ec,'episode_comparison':ac}
                result['definitions'][definition][scenario]={'methods':method_results,'comparisons':comparisons}
        for scenario in data['shared_evaluation']['one_high']:
            result['definition_episode_transitions'][scenario]={method:definition_episode_transition(
                result['definitions']['one_high'][scenario]['methods'][method]['tagged_episodes'],
                result['definitions']['two_high'][scenario]['methods'][method]['tagged_episodes']) for method in METHODS}
        blocks[block]=result
        print(block+': '+str({d:{g:sum(v['group']==g for v in c.values()) for g in GROUPS[d]} for d,c in catalog.items()}),flush=True)
    common.write(OUT/'results.json',{'blocks':blocks,'record_only_no_cache_decode':True,
        'new_models_fitted':0,'optimizer_updates':0,'new_model_inference_calls':0,
        'policy_changed':False,'labels_changed':False,'independent_confirmation':False,'new_acceptance_test_performed':False,
        'original_thesis_primary_test_still_failed':True,'previous_candidate_acceptance_passed':False,
        'new_station_cohort_consumed':False,'consumed_transfer_values_used':False,
        'source_results_sha256':common.sha(PRIOR/'results.json')})
    for n,h in plan['source_and_input_sha256'].items():assert common.sha(ROOT/n)==h,n
    common.write(OUT/'access_log.json',{'runtime_output_paths':sorted(set(common.READS)),
        'only_prior_result_metadata_values_decoded':True,'forbidden_values_used':False})
    common.write(OUT/'completion.json',{'completed_at_utc':datetime.now(timezone.utc).isoformat(),
        'plan_sha256':common.sha(OUT/'plan.json'),'artifacts':{n:common.sha(OUT/n) for n in ['results.json','access_log.json']}})


if __name__=='__main__':main()
