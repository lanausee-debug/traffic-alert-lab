"""Cumulative checkpoint: predefined offline recovery semantics sensitivity."""
from datetime import datetime,timezone
from pathlib import Path
import hashlib
from zipfile import ZipFile,ZIP_DEFLATED
import recovery_definition_sensitivity as pilot
from save_station_agnostic_checkpoint import read,write,sha

ROOT=pilot.ROOT;OUT=pilot.OUT
NAME='traffic-recovery-lab-2026-10-16-recovery-definition-sensitivity'


def main():
    archive=ROOT.parent/'checkpoints'/(NAME+'.zip');receipt=archive.with_name(NAME+'-save-receipt.json')
    if archive.exists() or receipt.exists():raise FileExistsError('Preserve older archives')
    r=read(OUT/'results.json');audit=read(OUT/'audit.json');tests=read(OUT/'test_receipt.json')
    assert audit['passed'] and tests['passed'] and tests['tests_run']==9
    assert tests['test_source_sha256']==sha(ROOT/'tests/test_recovery_definition_sensitivity.py')
    assert audit['results_sha256']==sha(OUT/'results.json')
    assert r['new_models_fitted']==r['optimizer_updates']==0 and not r['online_policy_changed'] and not r['original_labels_changed']
    assert not r['previous_candidate_acceptance_passed'] and r['original_thesis_primary_test_still_failed']
    assert not r['definition_selected_on_results'] and not r['new_acceptance_test_performed']
    assert not r['new_station_cohort_consumed'] and not r['consumed_transfer_values_used']
    for name,digest in read(OUT/'completion.json')['artifacts'].items():assert sha(OUT/name)==digest
    for name,digest in read(OUT/'plan.json')['source_and_input_sha256'].items():assert sha(ROOT/name)==digest
    prior_name='outputs/proxy-event-semantics-2026-10-16/writing_archive_manifest.json';prior=read(ROOT/prior_name)
    # Preservation hashes do not decode/read outcomes from already consumed cohorts.
    for name,meta in prior['files'].items():assert sha(ROOT/name)==meta['sha256'],name
    summary=('固定两次连续回升事件定义敏感性：原18:20被救回预警并入16:20低速过程，'
        '三个固定方法都已检出，18:10告警变重复。验证有/无豁免检出和R10相同，仍多3/4/3误报；'
        '该独立预警收益依赖事件定义。')
    marker='# 最新检查点：持续恢复定义下预警保护收益消失（2026-10-16）'
    p=ROOT/'CURRENT_STATE.zh-CN.md';old=p.read_text(encoding='utf-8');assert marker not in old
    p.write_text(marker+'\n\n- '+summary+'\n'
        '- 仅离线副本改变事件结束条件，预定1 vs2条连续>30mph；起始3连低与原代理末端约定保持。原模型/阈值/线上激活/缓存truth不改，零训练更新/新模型。\n'
        '- 两定义同可判断范围：可回推自然未来三条车速，排除30±0.0001mph边界、未知/尾部；不能跨时钟或可判断范围断点。原一次结束在共同范围逐位重建旧标签。\n'
        '- 原完整训练/验证/校准198/55/69事件；共同旧定义183/52/66，新定义167/46/62。范围排除和改定义变化分开，不能把分母改变说成模型提升。\n'
        '- 新定义校准共同有/无豁免检出/R10相同，额外各1误报；训练仍有一些检出收益，不推断全部豁免都无效。\n'
        '- 9测试；独立最大连续段枚举与主状态机10套标签一致，45原完整+90共同定义回放/388原阳性段谱系及3同事件情景谱系核对，36旧激活复现。图已实际查看。\n'
        '- 原论文主检验/候选验收失败保留，没有新验收或按结果选定义；Word/PPT、GitHubv7未改。原评测、迁移、新站和HDF5值未读。\n'
        '- 报告outputs/recovery-definition-sensitivity-2026-10-16/report.zh-CN.md；接续docs/recovery_definition_sensitivity_handoff.zh-CN.md。下一轮固定两定义分首次事件与重入/重复评价，尚未执行。\n'
        '- 最新累计包2026-10-16-recovery-definition-sensitivity；先10月11日完整基包后本包，原文件/旧ZIP保留。\n\n以下为之前阶段记录。\n\n'+old,encoding='utf-8')
    p=ROOT/'README.md';old=p.read_text(encoding='utf-8')
    p.write_text('# 最新研究：预警保护收益对事件恢复定义敏感\n\n'
        '[完整报告](outputs/recovery-definition-sensitivity-2026-10-16/report.zh-CN.md) · [接续说明](docs/recovery_definition_sensitivity_handoff.zh-CN.md)\n\n'
        +summary+' 仅已复用开发数据的定义敏感性，无模型改进或独立确认。原评价/失败结论和线上规则保持。最新累计包2026-10-16-recovery-definition-sensitivity。\n\n以下为之前阶段记录。\n\n'+old,encoding='utf-8')
    files=set(prior['files'])|{prior_name,'recovery_definition_sensitivity.py','audit_recovery_definition_sensitivity.py',
        'summarize_recovery_definition_sensitivity.py','save_recovery_definition_sensitivity_checkpoint.py',
        'tests/test_recovery_definition_sensitivity.py','docs/recovery_definition_sensitivity_handoff.zh-CN.md'}
    files|={p.relative_to(ROOT).as_posix() for p in OUT.rglob('*') if p.is_file() and p.name!='writing_archive_manifest.json'}
    base_path=ROOT.parent/'checkpoints/traffic-recovery-lab-2026-10-11-event-timeline-save-receipt.json';base=read(base_path)
    assert base['archive_crc_and_all_sha256_verified'] and Path(base['full_archive']).stat().st_size==base['full_archive_bytes']
    manifest=OUT/'writing_archive_manifest.json'
    write(manifest,{'client_date':'2026-10-16','stage':'cumulative_fixed_recovery_end_definition_sensitivity',
        'archive_name':archive.name,'restore':'October11 full base, then this cumulative supplement',
        'new_models_fitted':0,'optimizer_updates':0,'online_policy_changed':False,'original_labels_changed':False,
        'offline_alternative_truth_only':True,'definition_selected_on_metrics':False,
        'independent_confirmation':False,'new_station_cohort_consumed':False,'consumed_transfer_values_decoded':False,
        'previous_acceptance_passed':False,'original_thesis_primary_test_still_failed':True,
        'unit_tests_observed_passed':9,'original_full_replays':45,'shared_definition_replays':90,
        'different_label_algorithm_independently_verified':True,'old_to_new_run_lineages_checked':388,
        'comparison_plot_visually_inspected':True,'prior_scientific_files_preserved':True,
        'prior_files_changed':['README.md','CURRENT_STATE.zh-CN.md'],
        'public_commit_unchanged':'ab8760a3e6ea1784fea3195a0e7aadbaff6fe80d',
        'base_crc_rechecked_this_turn':False,'base_sha256_from_prior_verified_receipt':base['full_archive_sha256'],
        'files':{n:{'bytes':(ROOT/n).stat().st_size,'sha256':sha(ROOT/n)} for n in sorted(files)}})
    files.add(manifest.relative_to(ROOT).as_posix())
    with ZipFile(archive,'x',compression=ZIP_DEFLATED) as z:
        for n in sorted(files):z.write(ROOT/n,'traffic-recovery-lab/'+n)
    with ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist())==len(files)
        for n in sorted(files):
            data=z.read('traffic-recovery-lab/'+n)
            assert data==(ROOT/n).read_bytes() and hashlib.sha256(data).hexdigest()==sha(ROOT/n)
    proof={'saved_at_utc':datetime.now(timezone.utc).isoformat(),'client_date':'2026-10-16',
        'archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'files':len(files),
        'crc_and_all_file_bytes_and_sha256_verified':True,'new_models_fitted':0,'online_policy_changed':False,'original_labels_changed':False,
        'new_station_cohort_consumed':False,'original_thesis_primary_test_still_failed':True,
        'public_version_unchanged':True,'base_prior_verified_receipt':str(base_path),'base_crc_rechecked_this_turn':False}
    write(receipt,proof);print(proof)


if __name__=='__main__':main()
