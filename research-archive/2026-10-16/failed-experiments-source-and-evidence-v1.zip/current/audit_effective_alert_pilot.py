"""Independently check expanded training labels, objective and full service replay."""
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
import torch
import effective_alert_pilot as pilot
import alarm_start_separability as probe
import calibration_fragility as common
import early_warning_protection as protection
from audit_early_warning_protection import independent_observed_low,interval_gate,matched_event_diagnosis
from congestion_alert_pilot import SCENARIOS
from pems_bay_alert_replay import alarm,replay,layout
from train_pems_bay_risk import load_risk
from adaptive_confirmation import block_gate
from evaluate_pems_bay_alerts import paired_difference

ROOT=pilot.ROOT;OUT=pilot.OUT


def main():
    torch.set_num_threads(1)
    plan=common.read(OUT/'plan.json');r=common.read(OUT/'results.json');done=common.read(OUT/'completion.json')
    train_seal=common.read(OUT/'training_freeze.json');selection=common.read(OUT/'selection_freeze.json')
    for name,digest in plan['source_and_input_sha256'].items():assert common.sha(ROOT/name)==digest,name
    for name,digest in done['artifacts'].items():assert common.sha(OUT/name)==digest,name
    assert done['plan_sha256']==train_seal['plan_sha256']==selection['plan_sha256']==common.sha(OUT/'plan.json')
    assert selection['training_freeze_sha256']==common.sha(OUT/'training_freeze.json')
    assert selection['results_sha256']==common.sha(OUT/'results.json')
    assert datetime.fromisoformat(plan['frozen_at_utc'])<datetime.fromisoformat(train_seal['frozen_at_utc'])<datetime.fromisoformat(selection['frozen_at_utc'])
    assert not selection['comparator_substitution'] and not r['consumed_transfer_values_used_in_this_run']
    model=common.load(OUT/'effective_model.npz');old=common.load(probe.OUT/'state_logistic.npz')
    assert train_seal['model_sha256']==common.sha(OUT/'effective_model.npz')
    for key in ('indices','mean','std'):np.testing.assert_array_equal(model[key],old[key])
    norm=common.load(common.RISK/'normalization.npz');anchor=load_risk(common.RISK/'global_calibration.pt')
    part=common.load(common.RISK/'risk_train.npz');p=common.global_scores(part,norm,anchor)
    training,counts=pilot.build_training(part,p)
    stored=common.load(OUT/'training_samples.npz')
    for key,value in training.items():np.testing.assert_array_equal(value,stored[key])
    assert counts==r['training_episode_counts']
    # Independent label mapping from scorer records, not the new sample builder.
    for s in SCENARIOS:
        _,_,events=replay(part,alarm(p[s],.46,1,part),details=True)
        matches={(e['node'],e['alarm_start_origin']):e for e in events if e['status'] in ('warned','late')}
        assert len(matches)==counts[s]['warned']+counts[s]['late']
    assert np.array_equal(training['y'],np.isin(training['kind'],['warned','late']).astype(np.int8))
    assert not np.any(np.isin(training['kind'],['duplicate','censored','unknown']))
    x=training['x'][:,model['indices']];y=training['y'];z=(x-model['mean'])/model['std']
    predicted=1/(1+np.exp(-np.clip(z@model['weight']+float(model['bias'][0]),-50,50)))
    gradient=max(float(np.max(np.abs(z.T@(predicted-y)/len(y)+.1*model['weight']))),float(abs(np.mean(predicted-y))))
    assert gradient<=1e-6 and np.isclose(gradient,r['fit']['max_abs_gradient'],atol=1e-12)
    positive=np.sort(predicted[y==1]);allowed_losses=int(np.floor(.05*len(positive)+1e-12))
    early=(training['kind']=='warned')&(training['lead_minutes']>=10)
    cutoff=min(float(positive[allowed_losses]),float(predicted[early].min()))
    assert cutoff==train_seal['cutoff']==r['cutoff']['protected_cutoff']
    assert np.all(predicted[early]>=cutoff) and np.mean(predicted[y==1]>=cutoff)>=.95
    val=common.load(common.RISK/'risk_validation.npz');cal=common.load(common.CAL/'calibration.npz')
    parts={'calibration_full14':cal,'risk_validation7':val,
        'calibration_week1_7':common.subset(cal,0,7),'calibration_week2_7':common.subset(cal,7,14)}
    oldcut=common.read(ROOT/'outputs/early-warning-protection-2026-10-15/parameter_freeze.json')['parameters']['protected_cutoff']
    active=common.load(OUT/'activations.npz');daily=common.load(OUT/'daily.npz');diagnoses={}
    for block,local in parts.items():
        scores=common.global_scores(local,norm,anchor);diagnoses[block]={}
        for s in SCENARIOS:
            observed=independent_observed_low(local,s)
            features=probe.start_features(local,s,scores[s]).reshape(-1,30)
            newp=probe.predict(model,features).reshape(local['truth'].shape)
            oldp=probe.predict(old,features).reshape(local['truth'].shape)
            baseline=alarm(scores[s],.46,1,local)
            expected={'global_c1':baseline,
                'old_warning_protected':interval_gate(scores[s],oldp,observed,local,oldcut),
                'effective_no_bypass':interval_gate(scores[s],newp,np.zeros_like(observed),local,cutoff),
                pilot.PRIMARY:interval_gate(scores[s],newp,observed,local,cutoff)}
            for method,bits in expected.items():
                key=f'{block}__{method}__{s}';np.testing.assert_array_equal(bits,active[key])
                assert not np.any(bits&~baseline)
                row,days,_=replay(local,bits,details=True)
                assert row==r['evaluation'][block][method][s];np.testing.assert_array_equal(days,daily[key])
                if method!='global_c1':assert protection.protect_original_events(local,baseline,bits)==r['original_early_event_checks'][block][method][s]
            diagnoses[block][s]=matched_event_diagnosis(local,baseline,expected[pilot.PRIMARY])
    budgets=common.read(common.CAL/'selection.json')['budgets']
    for method,gate in r['gates'].items():
        service={b:block_gate(v[method],v['global_c1']) for b,v in r['evaluation'].items()}
        assert service==gate['service_block_checks']
        early={b:all(v['all_original_R10_events_and_leads_preserved'] for v in m[method].values()) for b,m in r['original_early_event_checks'].items()}
        assert early==gate['original_early_event_identity_and_lead_preserved']
        a=r['means']['calibration_full14'][method]['false_per_valid_station_day'];b=r['means']['calibration_full14']['global_c1']['false_per_valid_station_day']
        ten=a<=.9*b+1e-12;budget={s:r['evaluation']['calibration_full14'][method][s]['false_per_valid_station_day']<=budgets[s]+1e-12 for s in SCENARIOS}
        assert ten==gate['full14_false_reduction_at_least10pct'] and budget==gate['full14_original_budget_met']
        assert gate['passed']==(all(v['passed'] for v in service.values()) and all(early.values()) and ten and all(budget.values()))
    bootstrap=common.load(OUT/'bootstrap_draws.npz');dates=layout(cal)[2];draws=bootstrap['draws']
    np.testing.assert_array_equal(bootstrap['dates'],dates)
    np.testing.assert_array_equal(draws,np.random.default_rng(20261016).integers(0,len(dates),(2000,len(dates))))
    base=np.stack([daily[f'calibration_full14__global_c1__{s}'] for s in SCENARIOS])
    for method,rows in r['paired_calibration_comparisons'].items():
        alternative=paired_difference(np.stack([daily[f'calibration_full14__{method}__{s}'] for s in SCENARIOS]),base,draws)
        for before,after in [('warning10_recall','R10'),('detection_recall','detection'),('false_rate','false_rate')]:
            a=alternative[before];b=rows[after];assert np.isclose(a['difference'],b['difference'])
            assert a['undefined_bootstrap_replicates']==b['undefined_draws']
            assert (a['ci95'] is None and b['ci95'] is None) or np.allclose(a['ci95'],b['ci95'])
    prior=common.read(ROOT/'outputs/early-warning-protection-2026-10-15/writing_archive_manifest.json')
    for name,meta in prior['files'].items():
        if name in ('README.md','CURRENT_STATE.zh-CN.md') and (OUT/'writing_archive_manifest.json').exists():
            assert common.sha(ROOT/name)==common.read(OUT/'writing_archive_manifest.json')['files'][name]['sha256']
        else:assert common.sha(ROOT/name)==meta['sha256'],name
    common.write(OUT/'matched_event_diagnosis.json',diagnoses)
    proof={'passed':True,'checked_at_utc':datetime.now(timezone.utc).isoformat(),
        'training_rows':len(y),'effective_training_positives':int(y.sum()),
        'unique_training_node_origin_pairs':len(set(zip(training['node'].tolist(),training['origin'].tolist()))),
        'new_linear_model_parameters':31,'fixed_old_training_normalization_reused':True,
        'training_labels_and_objective_gradient_and_cutoff_recomputed':True,
        'all48_operating_replays_checked':True,'all36_gated_activations_independently_reconstructed':True,
        'original_early_identity_checks_and_paired_statistics_checked':True,
        'prior_scientific_files_unchanged':True,'primary_acceptance_passed':r['primary_acceptance_passed'],
        'new_station_cohort_consumed':False,'source_sha256':common.sha(Path(__file__))}
    common.write(OUT/'audit.json',proof);print(proof)
    print({b:{s:v['newly_missed_by_original_status'] for s,v in scenes.items()} for b,scenes in diagnoses.items()})


if __name__=='__main__':main()
