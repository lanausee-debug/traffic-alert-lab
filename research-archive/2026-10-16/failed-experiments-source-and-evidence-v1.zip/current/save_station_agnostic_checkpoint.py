"""Preserve the identity ablation, including its failed development screen."""
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs/station-agnostic-risk-2026-10-15'
NAME='traffic-recovery-lab-2026-10-15-station-agnostic-risk'
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')


def main():
    archive=ROOT.parent/'checkpoints'/(NAME+'.zip')
    receipt=archive.with_name(NAME+'-save-receipt.json')
    if archive.exists() or receipt.exists():raise FileExistsError('Preserve existing archives')
    r=read(OUT/'results.json');audit=read(OUT/'audit.json')
    assert audit['passed'] and not r['pilot_acceptance_passed']
    assert not r['evaluation_values_read'] and not audit['new_station_cohort_consumed']
    assert audit['actual_optimizer_updates']==8100
    prior_path='outputs/new-station-transfer-2026-10-15/writing_archive_manifest.json'
    prior=read(ROOT/prior_path)
    for name,meta in prior['files'].items():assert sha(ROOT/name)==meta['sha256'],name
    marker='# 最新检查点：去站点编号消融（2026-10-15）'
    state=ROOT/'CURRENT_STATE.zh-CN.md';old=state.read_text(encoding='utf-8')
    assert marker not in old
    summary=('删除风险头24项站点编号，保留27项交通状态特征；训练6个有界修正模型，实际8100次更新。'
        '开发校准69个共享代理事件：固定全局R10/检出/误报为5.80%/87.44%/0.084619，'
        '去编号最佳可行为7.25%/86.96%/0.082628。R10仅增1.45个百分点，未达事先固定2个百分点门槛。')
    state.write_text(marker+'\n\n- '+summary+'\n'
        '- b=0.5有13/360组满足误报和检出约束，选阈值0.37/c2；b=1.0无同时可行组。不放宽约束，不补加候选。\n'
        '- 校准数据已反复用于开发，不能宣传为新测试优势。本轮未选择、未读取第三组站点，不能说身份已被证明是此前迁移失败原因。\n'
        '- 7项输入/模型/分区测试通过；审计重算分数、验证BCE、所选回放和网格选择，确认此前累计归档所有文件在本轮保存前未改变。\n'
        '- 原论文主检验和上一轮迁移验收均未通过；Word/PPT与线上GitHub v7不变。权重与缓存只本地保存。\n'
        '- 报告outputs/station-agnostic-risk-2026-10-15/report.zh-CN.md；接续docs/station_agnostic_risk_handoff.zh-CN.md。\n'
        '- 最新累计包2026-10-15-station-agnostic-risk；恢复先10月11日完整基包再本累计包。下一轮优先开发分区的校准/漂移诊断。\n\n以下为之前阶段记录。\n\n'+old,encoding='utf-8')
    readme=ROOT/'README.md';old=readme.read_text(encoding='utf-8')
    readme.write_text('# 最新研究：去站点编号消融未通过开发筛查\n\n'
        '[完整报告](outputs/station-agnostic-risk-2026-10-15/report.zh-CN.md) · [接续说明](docs/station_agnostic_risk_handoff.zh-CN.md)\n\n'
        +summary+' 本轮没有启动第三组站点测试，原论文与线上版本保留。最新累计包为2026-10-15-station-agnostic-risk。\n\n以下为之前阶段记录。\n\n'+old,encoding='utf-8')
    files=set(prior['files'])|{prior_path,'station_agnostic_risk.py','audit_station_agnostic_risk.py',
        'summarize_station_agnostic_risk.py','save_station_agnostic_checkpoint.py',
        'tests/test_station_agnostic_risk.py','docs/station_agnostic_risk_handoff.zh-CN.md'}
    files|={p.relative_to(ROOT).as_posix() for p in OUT.rglob('*') if p.is_file() and p.name!='writing_archive_manifest.json'}
    base_path=ROOT.parent/'checkpoints/traffic-recovery-lab-2026-10-11-event-timeline-save-receipt.json'
    base=read(base_path)
    assert Path(base['full_archive']).stat().st_size==base['full_archive_bytes']
    assert base['archive_crc_and_all_sha256_verified']
    manifest=OUT/'writing_archive_manifest.json'
    write(manifest,{'client_date':'2026-10-15','stage':'cumulative_identity_ablation_failed_development_screen',
        'archive_name':archive.name,'restore':'October11 full base, then this supplement',
        'pilot_acceptance_passed':False,'new_station_cohort_consumed':False,
        'trained_models':6,'actual_optimizer_updates':8100,'unit_tests_passed':7,
        'prior_files_changed':['README.md','CURRENT_STATE.zh-CN.md'],
        'original_thesis_primary_test_still_failed':True,
        'public_commit_unchanged':'ab8760a3e6ea1784fea3195a0e7aadbaff6fe80d',
        'base_crc_rechecked_this_turn':False,'base_sha256_from_prior_verified_receipt':base['full_archive_sha256'],
        'files':{name:{'bytes':(ROOT/name).stat().st_size,'sha256':sha(ROOT/name)} for name in sorted(files)}})
    files.add(manifest.relative_to(ROOT).as_posix())
    with ZipFile(archive,'x',compression=ZIP_DEFLATED) as z:
        for name in sorted(files):z.write(ROOT/name,'traffic-recovery-lab/'+name)
    with ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist())==len(files)
        for name in sorted(files):
            data=z.read('traffic-recovery-lab/'+name)
            assert data==(ROOT/name).read_bytes() and hashlib.sha256(data).hexdigest()==sha(ROOT/name)
    proof={'saved_at_utc':datetime.now(timezone.utc).isoformat(),'archive':str(archive),
        'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'files':len(files),
        'crc_and_all_file_bytes_and_sha256_verified':True,
        'pilot_acceptance_passed':False,'new_station_cohort_consumed':False,
        'original_thesis_primary_test_still_failed':True,'public_version_unchanged':True,
        'base_prior_verified_receipt':str(base_path),'base_crc_rechecked_this_turn':False}
    write(receipt,proof);print(json.dumps(proof))


if __name__=='__main__':main()
