"""Audit provenance, frozen inputs and chronology of the exploratory candidate."""
from datetime import datetime
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
A=ROOT/'outputs/recall-repair-2026-10-15'
B=ROOT/'outputs/anchored-risk-2026-10-15'
def read(path):return json.loads(path.read_text(encoding='utf-8'))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    for folder in (A,B):
        plan=read(folder/'plan.json')
        for name,digest in plan['input_and_source_sha256'].items():assert sha(ROOT/name)==digest,name
        guard=read(folder/'access_log.json')
        assert not guard['old_evaluation_values_read']
        assert not any('/pems-bay-evaluation/' in '/'+name for name in guard['logical_input_reads'])
        training=read(folder/'training_freeze.json');selection=read(folder/'selection_freeze.json')
        assert datetime.fromisoformat(training['frozen_at_utc'])<datetime.fromisoformat(selection['frozen_at_utc'])
        assert selection['results_sha256']==sha(folder/'results.json')
        for name,digest in training['weights'].items():assert sha(folder/name)==digest
    first=read(A/'training.json')['models'];second=read(B/'training.json')
    records=[record for methods in (first,second) for values in methods.values() for record in values]
    assert len(records)==12 and sum(record['actual_optimizer_updates'] for record in records)==16200
    # Every compared objective/bound uses the same training-row index sequence per seed.
    for seed in (202,203,204):
        signatures={record['minibatch_index_sha256'] for record in records if record['seed']==seed}
        assert len(signatures)==1
    for freeze in ('evaluation_results_freeze.json','audit_repair_and_handoff_freeze.json'):
        for name,digest in read(ROOT/'outputs/pems-bay-evaluation'/freeze)['source_sha256'].items():assert sha(ROOT/name)==digest,name
    replay_dir=B/'historical-replay';plan=read(replay_dir/'plan.json');result=read(replay_dir/'results.json');done=read(replay_dir/'completion.json')
    assert plan['selection_sha256']==sha(B/'selection_freeze.json')
    assert datetime.fromisoformat(read(B/'selection_freeze.json')['frozen_at_utc'])<datetime.fromisoformat(plan['frozen_at_utc'])
    assert not result['threshold_grid_search'] and not result['independent_confirmation']
    assert result['candidate_settings']==read(B/'selection_freeze.json')['selected']
    assert sha(replay_dir/'results.json')==done['results_sha256'] and sha(replay_dir/'daily.npz')==done['daily_sha256']
    assert read(ROOT/'outputs/pems-bay-evaluation/results.json')['verdict']['primary_metric_supported'] is False
    prior=read(ROOT/'publication/traffic-alert-lab-github-v7/release_manifest.json')
    for name,meta in prior['files'].items():
        assert sha(ROOT/'publication/traffic-alert-lab-github-v7'/name)==meta['sha256']
    audit={'passed':True,'new_risk_models_trained':12,'actual_optimizer_updates':16200,
        'matched_minibatch_draws_across_compared_objectives':True,
        'training_calibration_runtime_evaluation_read_guards_verified':True,
        'candidate_selected_before_single_historical_replay':True,
        'original_scientific_sources_inputs_and_evaluation_outputs_unchanged':True,
        'original_public_v7_unchanged':True,'original_primary_test_still_failed':True,
        'independent_confirmation':False,'unit_tests_passed':5}
    (B/'audit.json').write_text(json.dumps(audit,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(audit))


if __name__=='__main__':main()
