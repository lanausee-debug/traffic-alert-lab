"""Independent cached-speed, event-gap, lead and fixed-replay verification."""
from datetime import datetime,timezone
import sys
import numpy as np
import torch
import proxy_event_semantics as pilot
import effective_alert_pilot as previous
import calibration_fragility as common
import alarm_start_separability as probe
import early_warning_protection as protection
from audit_early_warning_protection import independent_observed_low,interval_gate
from complete_bypass_diagnosis import json_native
from congestion_alert_pilot import SCENARIOS,runs
from pems_bay_alert_replay import replay,alarm,layout
from train_pems_bay_risk import load_risk


def categories(part,scenario,row,node):
    state=part[scenario+'_state'];last='unknown';history='unknown'
    valid=(state[:,node,12]>0)&(np.abs(state[:,node,13])<1e-6)&(state[:,node,8]>0)
    low=state[:,node,8]<=np.float32(30/70)
    if valid[row]:last='low' if low[row] else 'high'
    if row>=2:
        idx=part['origins'][row-2:row+1];clock=part['timestamps'][idx]
        if np.all(np.diff(idx)==1) and np.all(np.diff(clock)==np.timedelta64(5,'m')) and valid[row-2:row+1].all():
            history='last3_low' if low[row-2:row+1].all() else 'last3_not_all_low'
    return last,history


def main():
    sys.addaudithook(protection.guard);torch.set_num_threads(1)
    root=pilot.ROOT;out=pilot.OUT;plan=common.read(out/'plan.json');r=common.read(out/'results.json')
    done=common.read(out/'completion.json')
    for n,h in plan['source_and_input_sha256'].items():assert common.sha(root/n)==h,n
    for n,h in done['artifacts'].items():assert common.sha(out/n)==h,n
    assert done['plan_sha256']==common.sha(out/'plan.json')
    assert datetime.fromisoformat(plan['frozen_at_utc'])<datetime.fromisoformat(done['completed_at_utc'])
    seal=common.read(previous.OUT/'training_freeze.json');assert r['cutoff']==seal['cutoff']
    assert r['model_sha256']==seal['model_sha256']==common.sha(previous.OUT/'effective_model.npz')
    model=common.load(previous.OUT/'effective_model.npz');norm=common.load(common.RISK/'normalization.npz')
    anchor=load_risk(common.RISK/'global_calibration.pt')
    parts={'training28':common.load(common.RISK/'risk_train.npz'),
        'risk_validation7':common.load(common.RISK/'risk_validation.npz'),
        'calibration_full14':common.load(common.CAL/'calibration.npz')}
    parts.update({'calibration_week1_7':common.subset(parts['calibration_full14'],0,7),
        'calibration_week2_7':common.subset(parts['calibration_full14'],7,14)})
    old=common.read(previous.OUT/'results.json');active=common.load(previous.OUT/'activations.npz')
    checked_points=0;checked_warnings=0;checked_events=0;checked_replays=0;checked_timelines=0
    for block,part in parts.items():
        origin=part['origins'];x=part['natural_state'];T=len(part['timestamps']);N=x.shape[1]
        speed=np.full((T,N),np.nan);low=np.zeros((T,N),bool)
        for row,t in enumerate(origin):
            valid=(x[row,:,12]>0)&(np.abs(x[row,:,13])<1e-6)&(x[row,:,8]>0)
            speed[t-1,valid]=x[row,valid,8].astype(float)*70
            low[t-1,valid]=x[row,valid,8]<=np.float32(30/70)
        known=np.isfinite(speed);future=np.stack([speed[origin+i] for i in range(3)],axis=1)
        future_known=np.isfinite(future).all(axis=1)
        ambiguity=(np.abs(future-30)<=1e-4).any(axis=1);checked=future_known&~ambiguity&part['eligible']
        futurelow=np.stack([low[origin+i] for i in range(3)],axis=1).all(axis=1)
        mismatch=np.argwhere(checked&(futurelow!=part['truth']))
        expected={'cached_origin_node_points':int(part['truth'].size),'eligible_points':int(part['eligible'].sum()),
            'three_future_cached_speeds_known':int(future_known.sum()),
            'eligible_precision_band_excluded':int((part['eligible']&future_known&ambiguity).sum()),
            'eligible_unrecoverable_points':int((part['eligible']&~future_known).sum()),
            'nonambiguous_eligible_points_checked':int(checked.sum()),'label_mismatches':len(mismatch),
            'mismatch_row_node_keys':mismatch.tolist(),
            'known_future_but_original_ineligible_points':int((future_known&~part['eligible']).sum())}
        assert expected==r['blocks'][block]['label_reconstruction'];assert len(mismatch)==0
        checked_points+=int(checked.sum())
        structure=r['blocks'][block]['shared_event_structure'];records=[]
        for seglo,seghi in layout(part)[0]:
            for node in range(N):
                for a,b in runs(part['eligible'][seglo:seghi,node]):
                    lo,hi=int(seglo+a),int(seglo+b);last=None
                    for c,d in runs(part['truth'][lo:hi,node]):
                        start,end=int(lo+c),int(lo+d)
                        gap=None if last is None else start-last[1]
                        bridge=[] if last is None else list(range(int(origin[last[1]-1])+3,int(origin[start])))
                        fully_known=bool(bridge and known[bridge,node].all())
                        records.append({'node':node,'start_row':start,'end_row':end,'event_start_origin':int(origin[start]),
                            'proxy_positive_steps':end-start,'complete':start-2>=lo and end<hi,
                            'preceding_proxy_event_gap_steps':gap,'bridge_speed_origin_indices':bridge,
                            'bridge_cached_speeds_mph':speed[bridge,node].tolist() if fully_known else None,
                            'bridge_all_known':fully_known,
                            'bridge_high_speed_samples':int((~low[bridge,node]).sum()) if fully_known else None})
                        last=(start,end)
        assert records==structure['records'];complete=[e for e in records if e['complete']]
        assert len(records)==structure['all_proxy_runs_including_censored'] and len(complete)==structure['complete_events']
        gaps=[e['preceding_proxy_event_gap_steps'] for e in complete]
        assert structure['preceding_gap_bins']=={'no_prior_proxy_run':sum(g is None for g in gaps),
            'gap3':sum(g==3 for g in gaps),'gap4to6':sum(g is not None and 4<=g<=6 for g in gaps),
            'gap7to12':sum(g is not None and 7<=g<=12 for g in gaps),'gap_gt12':sum(g is not None and g>12 for g in gaps),
            'other_gap':sum(g is not None and g<3 for g in gaps)}
        assert structure['gap3_with_known_single_high_speed']==sum(e['preceding_proxy_event_gap_steps']==3 and e['bridge_high_speed_samples']==1 for e in complete)
        checked_events+=len(complete);scores=common.global_scores(part,norm,anchor)
        lookup={int(t):i for i,t in enumerate(origin)}
        for scenario in SCENARIOS:
            p=scores[scenario];cred=probe.predict(model,probe.start_features(part,scenario,p).reshape(-1,30)).reshape(part['truth'].shape)
            choices={'global_c1':alarm(p,.46,1,part),
                'effective_no_bypass':interval_gate(p,cred,np.zeros_like(p,bool),part,seal['cutoff']),
                previous.PRIMARY:interval_gate(p,cred,independent_observed_low(part,scenario),part,seal['cutoff'])}
            for method,bits in choices.items():
                output=r['blocks'][block]['scenarios'][scenario][method]
                row,_,events=replay(part,bits,details=True)
                assert row==output['operating']
                if block!='training28':
                    assert row==old['evaluation'][block][method][scenario]
                    np.testing.assert_array_equal(bits,active[f'{block}__{method}__{scenario}'])
                assert len(events)==structure['complete_events'];warnings=[]
                for event in events:
                    if event['status']!='warned':continue
                    a,s=lookup[event['alarm_start_origin']],lookup[event['event_start_origin']];node=event['node']
                    ncat=categories(part,'natural',a,node);scat=categories(part,scenario,a,node)
                    oldclock=int((part['timestamps'][origin[s]]-part['timestamps'][origin[a]-1])/np.timedelta64(1,'m'))
                    clock=int((part['timestamps'][origin[s]]-part['timestamps'][origin[a]])/np.timedelta64(1,'m'))
                    assert oldclock==clock+5==event['lead_minutes']
                    warnings.append({'node':int(node),'event_start_origin':int(origin[s]),'alarm_start_origin':int(origin[a]),
                        'alarm_row':a,'event_row':s,'reported_proxy_lead_minutes':int(event['lead_minutes']),
                        'proxy_start_minus_origin_clock_minutes':clock,'proxy_start_minus_last_history_timestamp_minutes':oldclock,
                        'natural_last_observation':ncat[0],'natural_last3_history':ncat[1],
                        'scenario_last_observation':scat[0],'scenario_last3_history':scat[1]})
                assert warnings==output['warning_records']
                summary={}
                for group,ws in [('all_warned',warnings),('R10',[w for w in warnings if w['reported_proxy_lead_minutes']>=10]),('R15',[w for w in warnings if w['reported_proxy_lead_minutes']==15])]:
                    values={'records':len(ws),'unique_events':len({(w['node'],w['event_start_origin']) for w in ws})}
                    for which in ('natural','scenario'):
                        for label in ('low','high','unknown'):values[f'{which}_{label}']=sum(w[f'{which}_last_observation']==label for w in ws)
                        for label in ('last3_low','last3_not_all_low','unknown'):values[f'{which}_{label}']=sum(w[f'{which}_last3_history']==label for w in ws)
                    summary[group]=values
                assert summary==output['warning_history_summary']
                episodes=common.episodes(part,bits)
                counts={k:sum(e['kind']==k for e in episodes) for k in ('warned','late','false','duplicate','censored','unknown')}
                assert output['episode_type_counts']==counts
                assert json_native([e for e in episodes if e['kind']=='duplicate'])==output['duplicate_episode_records']
                assert output['false_start_spanning_later_complete_window']==sum(e['early_spanning_complete_window'] for e in episodes)
                for kind,column in [('warned','warned'),('late','late'),('false','false'),('duplicate','duplicate'),('censored','censored_alerts'),('unknown','unknown_alerts')]:assert counts[kind]==row[column]
                checked_warnings+=len(warnings);checked_replays+=1
            for timeline in r['case_timelines'][block][scenario]:
                node=timeline['node'];a=timeline['alarm_start_origin'];s=timeline['proxy_event_start_origin']
                assert timeline['reported_proxy_lead_minutes']==5*(s-a+1)
                assert [v['speed_origin'] for v in timeline['rows']]==list(range(max(0,a-6),min(T,a+7)))
                for v in timeline['rows']:
                    t=v['speed_origin'];i=lookup.get(t)
                    assert v['timestamp']==str(part['timestamps'][t]) and v['speed_known']==bool(known[t,node])
                    assert v['cached_actual_speed_mph']==(float(speed[t,node]) if known[t,node] else None)
                    assert v['actual_speed_low']==(bool(low[t,node]) if known[t,node] else None)
                    assert v['proxy_label']==(bool(part['truth'][i,node]) if i is not None else None)
                    assert v['proxy_eligible']==(bool(part['eligible'][i,node]) if i is not None else None)
                    assert v['global_probability']==(float(p[i,node]) if i is not None else None)
                    assert v['activations']=={m:bool(vv[i,node]) if i is not None else None for m,vv in choices.items()}
                checked_timelines+=1
    assert r['optimizer_updates']==r['new_models_fitted']==0 and not r['policy_modified'] and not r['proxy_labels_changed']
    assert r['original_thesis_primary_test_still_failed'] and not r['previous_candidate_acceptance_passed']
    assert not r['new_station_cohort_consumed'] and not r['consumed_transfer_values_used']
    audit={'passed':True,'audited_at_utc':datetime.now(timezone.utc).isoformat(),
        'source_and_input_hashes_preserved':True,'label_points_checked_including_overlapping_halves':checked_points,
        'label_mismatches':0,'shared_complete_events_including_overlapping_halves':checked_events,
        'operating_replays':checked_replays,'warning_records_checked_including_related_scenarios_and_methods':checked_warnings,
        'protected_case_scenario_timelines':checked_timelines,'prior_development36_activations_reproduced':True,
        'results_sha256':common.sha(out/'results.json'),'new_models_fitted':0,'policy_modified':False,
        'labels_changed':False,'original_thesis_primary_test_still_failed':True,'new_station_cohort_consumed':False,
        'forbidden_values_used':False,'runtime_output_paths':sorted(set(common.READS))}
    common.write(out/'audit.json',audit)
    print({k:v for k,v in audit.items() if k!='runtime_output_paths'})


if __name__=='__main__':main()
