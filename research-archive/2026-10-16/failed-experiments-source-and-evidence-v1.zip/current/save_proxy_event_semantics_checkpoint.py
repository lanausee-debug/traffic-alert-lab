"""Cumulative local checkpoint of fixed proxy semantics diagnosis."""
from datetime import datetime,timezone
from pathlib import Path
import hashlib
from zipfile import ZipFile,ZIP_DEFLATED
import proxy_event_semantics as pilot
from save_station_agnostic_checkpoint import read,write,sha

ROOT=pilot.ROOT;OUT=pilot.OUT
NAME='traffic-recovery-lab-2026-10-16-proxy-event-semantics'


def main():
    archive=ROOT.parent/'checkpoints'/(NAME+'.zip');receipt=archive.with_name(NAME+'-save-receipt.json')
    if archive.exists() or receipt.exists():raise FileExistsError('Keep earlier archives intact')
    r=read(OUT/'results.json');audit=read(OUT/'audit.json');tests=read(OUT/'test_receipt.json')
    assert audit['passed'] and tests['passed'] and tests['tests_run']==11
    assert tests['test_source_sha256']==sha(ROOT/'tests/test_proxy_event_semantics.py')
    assert audit['results_sha256']==sha(OUT/'results.json')
    assert r['new_models_fitted']==r['optimizer_updates']==0 and not r['policy_modified'] and not r['proxy_labels_changed']
    assert not r['previous_candidate_acceptance_passed'] and not r['new_station_cohort_consumed']
    assert not r['consumed_transfer_values_used'] and r['original_thesis_primary_test_still_failed']
    for name,digest in read(OUT/'completion.json')['artifacts'].items():assert sha(OUT/name)==digest
    for name,digest in read(OUT/'plan.json')['source_and_input_sha256'].items():assert sha(ROOT/name)==digest
    prior_name='outputs/bypass-diagnosis-2026-10-16/writing_archive_manifest.json';prior=read(ROOT/prior_name)
    # Verify all old bytes by hashing; previously consumed datasets are never decoded.
    for name,meta in prior['files'].items():assert sha(ROOT/name)==meta['sha256'],name
    summary=('代理事件分段核查：验证被保护预警对应30.1mph单次越线后的低速重启；'
        '原15分钟从最后历史观测18:05算到18:20，按告警origin18:10算为10分钟。'
        '未发现缓存可回推标签或原时间公式不一致，不能把它解读成首次实际拥堵前15分钟。')
    marker='# 最新检查点：代理事件与时间参考已核对（2026-10-16）'
    p=ROOT/'CURRENT_STATE.zh-CN.md';old=p.read_text(encoding='utf-8');assert marker not in old
    p.write_text(marker+'\n\n- '+summary+'\n'
        '- 模型、全局/有豁免/无豁免规则和旧标签固定；零优化更新/新模型。原论文主检验、候选验收失败状态保持。\n'
        '- 单条>30mph读数令包含它的三个未来低速标签阴性，足以形成代理新事件。验证6/55、校准3/69、训练13/198事件存在这种单条高观测桥；未认定它们都应合并或是测量噪声。\n'
        '- 原自然R10验证5中2末观测低速、1已有三条低速；校准4中1末观测低速、0三条低速。已有低速后的重入目标与首次拥堵需要分别说明。\n'
        '- 不重叠原开发块336687可回推非边界标签零不一致；含半块432963次检查有重复。边界±0.0001mph和无法回推时点排除，不使用预测填未知。\n'
        '- 11测试、45完整回放、391共享事件（含重叠）、899相关方法/情景预警和3同事件时间线核查通过；36旧开发激活逐位复现。时间线图已实际查看。\n'
        '- 报告outputs/proxy-event-semantics-2026-10-16/report.zh-CN.md；补充论文定义docs/thesis_proxy_semantics_note.zh-CN.md；接续docs/proxy_event_semantics_handoff.zh-CN.md。\n'
        '- 下一轮可预先固定替代结束语义作敏感性，和原定义并列；不能换定义让旧失败变通过。本轮未执行替代定义/合并或新策略。\n'
        '- 原评测/迁移/新站/HDF5值未读；原论文Word/PPT、GitHub v7保持，真实缓存明细仅本地。\n'
        '- 最新累计包2026-10-16-proxy-event-semantics；先10月11日完整基包再本包，旧科学文件与旧ZIP保留。\n\n以下为之前阶段记录。\n\n'+old,encoding='utf-8')
    p=ROOT/'README.md';old=p.read_text(encoding='utf-8')
    p.write_text('# 最新研究：代理事件分段与提前量参考核查\n\n'
        '[完整报告](outputs/proxy-event-semantics-2026-10-16/report.zh-CN.md) · [论文定义补充](docs/thesis_proxy_semantics_note.zh-CN.md) · [接续说明](docs/proxy_event_semantics_handoff.zh-CN.md)\n\n'
        +summary+' 仅固定规则的重复开发数据诊断，未改模型、标签或线上规则。最新累计包2026-10-16-proxy-event-semantics。\n\n以下为之前阶段记录。\n\n'+old,encoding='utf-8')
    files=set(prior['files'])|{prior_name,'proxy_event_semantics.py','audit_proxy_event_semantics.py',
        'summarize_proxy_event_semantics.py','save_proxy_event_semantics_checkpoint.py',
        'tests/test_proxy_event_semantics.py','docs/thesis_proxy_semantics_note.zh-CN.md','docs/proxy_event_semantics_handoff.zh-CN.md'}
    files|={p.relative_to(ROOT).as_posix() for p in OUT.rglob('*') if p.is_file() and p.name!='writing_archive_manifest.json'}
    base_path=ROOT.parent/'checkpoints/traffic-recovery-lab-2026-10-11-event-timeline-save-receipt.json';base=read(base_path)
    assert base['archive_crc_and_all_sha256_verified'] and Path(base['full_archive']).stat().st_size==base['full_archive_bytes']
    manifest=OUT/'writing_archive_manifest.json'
    write(manifest,{'client_date':'2026-10-16','stage':'cumulative_fixed_proxy_event_semantics',
        'archive_name':archive.name,'restore':'October11 full base, then this cumulative supplement',
        'new_models_fitted':0,'optimizer_updates':0,'policy_modified':False,'labels_changed':False,
        'independent_confirmation':False,'new_station_cohort_consumed':False,'consumed_transfer_values_decoded':False,
        'previous_acceptance_passed':False,'original_thesis_primary_test_still_failed':True,
        'unit_tests_observed_passed':11,'nonoverlapping_reconstructed_label_checks':336687,'label_mismatches':0,
        'operating_replays':45,'warning_records_including_related_methods_and_scenarios':899,
        'time_reference_conventions_verified':True,'timeline_plot_visually_inspected':True,
        'prior_scientific_files_preserved':True,'prior_files_changed':['README.md','CURRENT_STATE.zh-CN.md'],
        'public_commit_unchanged':'ab8760a3e6ea1784fea3195a0e7aadbaff6fe80d',
        'base_crc_rechecked_this_turn':False,'base_sha256_from_prior_verified_receipt':base['full_archive_sha256'],
        'files':{n:{'bytes':(ROOT/n).stat().st_size,'sha256':sha(ROOT/n)} for n in sorted(files)}})
    files.add(manifest.relative_to(ROOT).as_posix())
    with ZipFile(archive,'x',compression=ZIP_DEFLATED) as z:
        for n in sorted(files):z.write(ROOT/n,'traffic-recovery-lab/'+n)
    with ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist())==len(files)
        for n in sorted(files):
            data=z.read('traffic-recovery-lab/'+n)
            assert data==(ROOT/n).read_bytes() and hashlib.sha256(data).hexdigest()==sha(ROOT/n)
    proof={'saved_at_utc':datetime.now(timezone.utc).isoformat(),'client_date':'2026-10-16',
        'archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'files':len(files),
        'crc_and_all_file_bytes_and_sha256_verified':True,'new_models_fitted':0,'policy_modified':False,'labels_changed':False,
        'new_station_cohort_consumed':False,'original_thesis_primary_test_still_failed':True,
        'public_version_unchanged':True,'base_prior_verified_receipt':str(base_path),'base_crc_rechecked_this_turn':False}
    write(receipt,proof);print(proof)


if __name__=='__main__':main()
