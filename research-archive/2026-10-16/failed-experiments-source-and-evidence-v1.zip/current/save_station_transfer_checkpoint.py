"""Cumulative archive for the disjoint-station, fixed-risk-head transfer check."""
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs/new-station-transfer-2026-10-15'
NAME='traffic-recovery-lab-2026-10-15-new-station-transfer'
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def dump(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def update_headers(result,audit):
    selected=result['means']['anchored_candidate'];reference=result['means']['global_calibration']
    fmt=lambda value: '无分母' if value is None else f'{100*value:.2f}%'
    rate=lambda value: '无分母' if value is None else f'{value:.6f}'
    verdict='通过' if result['fixed_point_gate_vs_global_passed'] else '未通过'
    text=(f'固定风险头在24个与开发集零重叠的新站点检查，{len(result["evaluation_dates"])}日、{int(result["events"])}个完整低速代理事件。'
        f'候选R10={fmt(selected["warning_recall_at_least10"])}、检出={fmt(selected["detection_recall"])}、误报={rate(selected["false_per_valid_station_day"])}；'
        f'固定全局为{fmt(reference["warning_recall_at_least10"])}/{fmt(reference["detection_recall"])}/{rate(reference["false_per_valid_station_day"])}。'
        f'{verdict}事先固定的三项点估计门槛。')
    marker='# 最新检查点：新站点迁移检查（2026-10-15）'
    state=ROOT/'CURRENT_STATE.zh-CN.md';old=state.read_text(encoding='utf-8');assert marker not in old
    prefix=(marker+'\n\n- '+text+'\n'
        '- GraphTCN因站点专属参数按原规则重训前端，三种子42/43/44、各25轮；风险头、风险标准化、候选阈值0.505/c1和所有参考阈值固定。新站点风险训练/风险验证/校准段没有用于拟合。\n'
        '- 代码审查在评测前发现风险头独热身份，identity_amendment.json冻结新站点身份全0表示未知，未套用旧站点槽位；原训练文件保持冻结，评测用evaluate_station_transfer.py包装。\n'
        '- 同一路网同期，前端有适配训练，不是完整零样本或独立外部数据确认。不能把此处新站点结果与此前673事件旧数据回放混为同一成绩。\n'
        f'- 6项边界/身份/统计测试通过；前端实际更新{audit["front_end_actual_optimizer_updates"]}次；选择/权重/源读取/配对统计独立核对通过，评测源切片仅读取一次。\n'
        '- outputs/new-station-transfer-2026-10-15含计划、数据访问记录、前端权重、固定评测、报告和审计。原论文主检验仍失败，GitHub和Demo仍为v7，真实缓存和新权重只保存本地。\n'
        '- 最新累计备份2026-10-15-new-station-transfer；先10月11日完整基包再本累计包。\n\n以下为之前阶段记录。\n\n')
    state.write_text(prefix+old,encoding='utf-8')
    readme=ROOT/'README.md';old=readme.read_text(encoding='utf-8')
    prefix=('# 最新研究：新站点固定风险头迁移检查\n\n'
        '[完整报告](outputs/new-station-transfer-2026-10-15/report.zh-CN.md) · [接续说明](docs/new_station_transfer_handoff.zh-CN.md)\n\n'
        +text+' 新站点前端适配训练，风险权重/阈值固定，未见站点身份以全0表示未知。属于同一路网同期检查，不是独立外部数据确认。原论文与线上版本保持。\n\n'
        '最新累计包为2026-10-15-new-station-transfer，保留所有旧归档。\n\n以下为之前阶段记录。\n\n')
    readme.write_text(prefix+old,encoding='utf-8')


def main():
    archive=ROOT.parent/'checkpoints'/(NAME+'.zip');receipt=archive.with_name(NAME+'-save-receipt.json')
    if archive.exists() or receipt.exists():raise FileExistsError('Keep saved archives')
    prior_path='outputs/anchored-risk-2026-10-15/writing_archive_manifest.json';prior=read(ROOT/prior_path)
    for name,meta in prior['files'].items():
        if name not in {'README.md','CURRENT_STATE.zh-CN.md'}:assert sha(ROOT/name)==meta['sha256'],name
    audit=read(OUT/'audit.json');assert audit['passed'] and not audit['external_independent_data']
    result=read(OUT/'results.json');done=read(OUT/'completion.json')
    assert done['results_sha256']==sha(OUT/'results.json') and result['unseen_risk_identity_all_zero']
    assert not result['risk_heads_refit'] and not result['thresholds_refit']
    assert not set(result['new_station_ids'])&set(result['development_station_ids'])
    update_headers(result,audit)
    files=set(prior['files'])|{prior_path,'new_station_transfer.py','evaluate_station_transfer.py',
        'audit_station_transfer.py','summarize_station_transfer.py','save_station_transfer_checkpoint.py',
        'tests/test_new_station_transfer.py','docs/new_station_transfer_handoff.zh-CN.md'}
    files|={p.relative_to(ROOT).as_posix() for p in OUT.rglob('*') if p.is_file() and p.name!='writing_archive_manifest.json'}
    base_receipt=ROOT.parent/'checkpoints/traffic-recovery-lab-2026-10-11-event-timeline-save-receipt.json';base=read(base_receipt)
    assert Path(base['full_archive']).stat().st_size==base['full_archive_bytes'] and base['archive_crc_and_all_sha256_verified']
    manifest=OUT/'writing_archive_manifest.json'
    dump(manifest,{'client_date':'2026-10-15','stage':'cumulative_fixed_risk_head_new_station_transfer',
        'archive_name':archive.name,'restore':'October 11 full base, then this supplement',
        'new_stations':24,'station_overlap':0,'events':result['events'],
        'front_end_actual_optimizer_updates':audit['front_end_actual_optimizer_updates'],
        'risk_heads_refit':False,'thresholds_refit':False,'external_independent_data':False,
        'point_gate_passed':result['fixed_point_gate_vs_global_passed'],'primary_metric_supported':False,
        'public_commit_unchanged':'ab8760a3e6ea1784fea3195a0e7aadbaff6fe80d',
        'full_base_crc_rechecked_this_turn':False,
        'base_archive_sha256_from_prior_verified_receipt':base['full_archive_sha256'],
        'files':{name:{'bytes':(ROOT/name).stat().st_size,'sha256':sha(ROOT/name)} for name in sorted(files)}})
    files.add(manifest.relative_to(ROOT).as_posix())
    with ZipFile(archive,'x',compression=ZIP_DEFLATED) as z:
        for name in sorted(files):z.write(ROOT/name,'traffic-recovery-lab/'+name)
    with ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist())==len(files)
        for name in files:
            data=z.read('traffic-recovery-lab/'+name)
            assert data==(ROOT/name).read_bytes() and hashlib.sha256(data).hexdigest()==sha(ROOT/name)
    proof={'saved_at_utc':datetime.now(timezone.utc).isoformat(),'archive':str(archive),
        'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'files':len(files),
        'crc_and_all_file_bytes_and_sha256_verified':True,'new_stations':24,'station_overlap':0,
        'point_gate_passed':result['fixed_point_gate_vs_global_passed'],'external_independent_data':False,
        'original_thesis_primary_test_still_failed':True,
        'full_base_prior_receipt':str(base_receipt),'full_base_crc_rechecked_this_turn':False}
    dump(receipt,proof);print(json.dumps(proof))


if __name__=='__main__':main()
