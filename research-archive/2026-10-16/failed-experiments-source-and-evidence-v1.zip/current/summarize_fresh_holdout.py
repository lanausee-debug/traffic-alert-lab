"""Audit and report the fresh-time repair-space experiment from saved arrays."""
from __future__ import annotations

import csv
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from fresh_holdout_pilot import ROOT, primary_summary
from multifault_pilot import calibrated_policies, day_macro, sha256, summarize_policy
from recovery_pilot import write_json

OUT = ROOT/"outputs/fresh-holdout-pilot"


def percent(value, digits=3):
    return "不稳定/未定义" if value is None else f"{100*value:.{digits}f}%"


def interval(value):
    return "分母区间跨零，不报告" if value is None else f"[{100*value[0]:.3f}%, {100*value[1]:.3f}%]"


def main():
    result = json.loads((OUT/"results.json").read_text(encoding="utf-8"))
    config = result["config"]
    events = config["events"]
    checks, rows = [], []
    for variant, prior in result["models"].items():
        arrays = np.load(OUT/f"arrays_{variant}.npz")
        saved_policies = json.loads((OUT/f"policies_{variant}.json").read_text(encoding="utf-8"))
        policies = calibrated_policies(events["calibration"], config["groups"], arrays["calibration_actual"],
                                        arrays["calibration_additive"], arrays["calibration_fixed"], False)
        if policies != saved_policies["policies"]:
            raise AssertionError("Validation-only policy replay failed")
        _, _, cal_cost = summarize_policy(events["calibration"], arrays["calibration_actual"], arrays["calibration_additive"],
                                         arrays["calibration_outage"], policies, arrays["calibration_fixed"])
        names = ("shortest_time", "gain_per_time", "additive", "joint")
        cal_means = {name: float(day_macro(cal_cost[name], events["calibration"])) for name in names}
        reference = min(names, key=lambda name: cal_means[name])
        if reference != saved_policies["reference"] or cal_means != saved_policies["calibration_mean_costs"]:
            raise AssertionError("Reference strategy must be selected only on calibration")
        summary, choices, costs = primary_summary(events["test"], arrays["actual"], arrays["additive"], arrays["outage"],
                                                 arrays["fixed"], arrays["healthy"], policies, reference)
        for key, value in summary.items():
            if value != prior[key]:
                raise AssertionError(f"Saved summary differs: {variant}/{key}")
        # Same scalar gain under two scales must satisfy the exact algebraic identity.
        total = summary["cumulative_loss_by_policy"][reference]
        if summary["gain_as_fraction_of_fault_added_loss"] is not None:
            rhs = summary["gain_as_fraction_of_fault_added_loss"]*summary["reference_fault_added_loss"]/total
            if not np.isclose(rhs, summary["offline_joint_vs_reference_relative_gain"], atol=1e-12):
                raise AssertionError("Denominator decomposition failed")
        actual, additive = arrays["actual"], arrays["additive"]
        epsilon = np.max(np.abs(actual-additive), axis=1)
        additive_choice = np.argmin(additive, axis=1)
        regret = actual[np.arange(len(actual)), additive_choice]-actual.min(axis=1)
        margins = np.partition(additive, 1, axis=1)[:, 1]-additive.min(axis=1)
        separated = margins > 2*epsilon+1e-8
        if np.any(regret > 2*epsilon+1e-8) or np.any(regret[separated] > 1e-8):
            raise AssertionError("A posteriori optimization perturbation bound failed")
        residual_span = np.ptp(actual-additive, axis=1)
        centered_separated = margins > residual_span+1e-8
        if np.any(regret > residual_span+1e-8) or np.any(regret[centered_separated] > 1e-8):
            raise AssertionError("Offset-invariant perturbation bound failed")
        prior["posthoc_perturbation_diagnostic"] = {
            "mean_uniform_error_bound_twice": float(day_macro(2*epsilon, events["test"])),
            "well_separated_fraction": float(day_macro(separated.astype(float), events["test"])),
            "mean_offset_invariant_error_bound": float(day_macro(residual_span, events["test"])),
            "offset_invariant_well_separated_fraction": float(day_macro(centered_separated.astype(float), events["test"])),
            "bound_check_passed": True, "deployable_guarantee": False}
        for i, e in enumerate(events["test"]):
            rows.append({"model": variant, "day": e["day"], "hour": e["hour"], "group": e["group"],
                         "category": e["category"], "measurable_steps": len(e["usable_steps"]), "reference_policy": reference,
                         "healthy_loss": float(arrays["healthy"][i]), "outage_loss": float(arrays["outage"][i]),
                         "reference_loss": float(costs[reference][i]), "oracle_gain": float(costs[reference][i]-costs["offline_joint_oracle"][i]),
                         **{f"loss_{name}": float(value[i]) for name, value in costs.items()},
                         **{f"order_{name}": int(value[i]) for name, value in choices.items()}})
        checks.append(f"{variant}: calibration fitting, reference choice, every summary, loss-scale algebra, posthoc perturbation bound")
    if sha256(ROOT/"docs/fresh_holdout_protocol.zh-CN.md") != config["protocol_sha256"]:
        raise AssertionError("Frozen protocol changed")
    if sha256(ROOT/"data/raw/metr-la.h5") != config["data_sha256"]:
        raise AssertionError("Raw data changed")
    for seed, checksum in config["baseline_weight_hashes"].items():
        if sha256(ROOT/"outputs/recovery-pilot"/f"model_seed{seed}.pt") != checksum:
            raise AssertionError("Archived baseline changed")
    with (OUT/"episode_results.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
    candidate_hashes = {str(seed): sha256(OUT/f"model_tcn_seed{seed}.pt") for seed in (42, 43, 44)}
    write_json(OUT/"audit.json", {"checks": checks, "hashes": "passed", "status": "passed", "candidate_weight_sha256": candidate_hashes})
    result["checks"]["saved_arrays_policy_replay_and_scale_identity"] = True
    result["checks"]["posthoc_perturbation_bound"] = True
    write_json(OUT/"results.json", result)
    base, candidate = result["models"]["mlp_baseline"], result["models"]["graph_tcn_candidate"]
    labels = {"shortest_time": "最短工时", "gain_per_time": "校准单站收益/工时", "additive": "校准可加轨迹", "joint": "校准联合轨迹",
              "offline_additive_oracle": "离线可加诊断", "offline_joint_oracle": "六顺序离线联合最优"}
    lines = ["# 第三轮：新时间段、预测器候选与维修优化空间", "", "日期：2026-10-10（北京时间）。", "",
             f"候选模型在原验证周相对MLP的MAE改善为{percent(result['candidate_validation_relative_improvement'])}；5%能力筛选{'通过' if result['stronger_predictor_screen_passed'] else '未通过'}。整体研发筛选{'通过' if result['repair_value_development_screen_passed'] else '未通过'}。", "",
             "## 本轮解决了什么", "",
             "此前只用了24站小MLP和一周测试。本轮增加既有组件构成的两跳图门控时间卷积候选，并把新策略校准与新测试移到以前未分析的时间段。没有改变故障组、处理时间或按测试结果调参。", "",
             "## 时间与信息隔离", "",
             "| 用途 | 半开时间区间 |", "|---|---|"]
    for name, label in (("training", "预测器训练"), ("model_validation", "预测器选轮"), ("old_test_unused", "旧测试，本轮不用"),
                        ("new_calibration", "新策略校准"), ("new_test", "新测试")):
        a, b = config["time_ranges"][name]
        lines.append(f"| {label} | {a[:10]} 至 {b[:10]} |")
    lines += ["", "站点、均值、标准差和一跳相关性图完全沿用原训练段；TCN的两跳图为A²。新模型仅在原验证周选epoch，新策略和全局参考策略仅在新校准周拟合与选择。测试标签不参与可实施策略选顺序。", "",
              f"校准{len(events['calibration'])}个三站情景，测试{len(events['test'])}个情景、{len(base['days'])}个可评日期；12组故障，10/20/30分钟处理时间，单班组、所有任务修完，观察120分钟。时间原点每5分钟推进，只能获得完工后的新观测。", "",
              "## 预测能力", "",
              "| 预测器 | 原验证周固定缺测MAE | 新测试固定缺测MAE |", "|---|---:|---:|"]
    for label, model in (("一跳图+MLP基准", base), ("两跳图+门控TCN候选", candidate)):
        lines.append(f"| {label} | {model['mean_validation_mae']:.5f} | {model['mean_new_test_fixed_mask_mae']:.5f} |")
    lines += ["", "上述MAE采用相同人工缺测生成规则，三个训练种子误差先平均；验证与测试分别使用冻结的991/992缺测随机种子。它不同于单站故障MAE或维修累计损失。模型结构更复杂不自动更强，能力筛选只看验证成绩，不能借测试成绩改变选择。", "",
              "候选由两跳mask聚合、站点嵌入和3层膨胀门控Conv1d构成，25轮CPU训练，不是STGCN官方复现，也没有建立新网络原创性。组件基础见[STGCN原论文](https://arxiv.org/abs/1709.04875)和[作者代码](https://github.com/VeritasYin/STGCN_IJCAI-18)。", "",
              "## 优化空间：总损失与故障增量", "",
              "参考策略从四种可实施固定策略中，依据新校准周的实际累计损失选定。离线联合最优拥有未观测实际读数和未来标签，逐案例在相同6种固定顺序内选最优；它只是额外信息诊断，不是已开发出的在线算法，也不是允许等待等行动的动态全问题最优。", "",
              "| 预测器 | 校准选定参考策略 | 离线最优对总损失改善 | 按日期95%区间 |", "|---|---|---:|---|"]
    for label, model in (("MLP基准", base), ("TCN候选", candidate)):
        lines.append(f"| {label} | {labels[model['reference_selected_on_calibration']]} | {percent(model['offline_joint_vs_reference_relative_gain'])} | {interval(model['offline_joint_vs_reference_relative_ci'])} |")
    lines += ["", "主要指标仍为全部24站网络MAE的离散累计损失。观察原始目标无效的时刻统一不计，所有顺序使用相同覆盖。按日期等权，2000次配对日期bootstrap；相对值的分子分母一起重采样。", "",
              "| 预测器 | 参考策略累计损失 | 无人工故障累计损失 | 故障额外损失 | 改善占故障额外损失比例 |", "|---|---:|---:|---:|---:|"]
    for label, model in (("MLP基准", base), ("TCN候选", candidate)):
        ref = model["cumulative_loss_by_policy"][model["reference_selected_on_calibration"]]
        lines.append(f"| {label} | {ref:.4f} | {model['healthy_cumulative_loss']:.4f} | {model['reference_fault_added_loss']:.4f} | {percent(model['gain_as_fraction_of_fault_added_loss'])} |")
    lines += ["", "两种百分数的绝对改善完全相同，分母不同。Δ/J_ref=(Δ/(J_ref−J_healthy))×((J_ref−J_healthy)/J_ref)。较大的故障增量比例不表示总路网预测、成本或交通延误改善相同幅度，更不表示在线策略已经取得该结果。无人工故障基准也保留了原始自然缺失，不是完美全观测真值。", "",
              f"故障增量尺度的区间：MLP为{interval(base['gain_as_fraction_of_fault_added_loss_ci'])}，TCN为{interval(candidate['gain_as_fraction_of_fault_added_loss_ci'])}。这个尺度预先定义为辅助诊断，不能用它替换主指标并宣称原3%总损失筛选线通过。", "",
              "## 全部策略与交互建模的增量", "", "| 策略 | MLP累计损失 | TCN累计损失 |", "|---|---:|---:|"]
    for name, label in labels.items():
        lines.append(f"| {label} | {base['cumulative_loss_by_policy'][name]:.5f} | {candidate['cumulative_loss_by_policy'][name]:.5f} |")
    lines += ["", "| 预测器 | 离线联合相对离线可加额外改善（占离线可加总损失） |", "|---|---:|"]
    for label, model in (("MLP基准", base), ("TCN候选", candidate)):
        gain = model["offline_joint_vs_offline_additive_regret"]/model["cumulative_loss_by_policy"]["offline_additive_oracle"]
        lines.append(f"| {label} | {percent(gain, 4)} |")
    lines += ["", "这一差异隔离了联合收益相对可加近似的离线增量；参考策略到离线最优的空间还包含逐案例交通条件和时间变化，并不能全部归因于联合信息价值。", "",
              "## 事后可加决策边界检查", "",
              "对六种顺序，用真实联合与可加损失算ε=max|J−J_add|，可加最优选择的真实损失最多比联合最优高2ε；如果可加最优/次优间隔超过2ε，选择应一致。本轮两个预测器全部案例均通过这条标准扰动界核验。它使用真实未来损失得到ε，只是事后诊断，不是可部署策略的保证，更不是新理论。详见`docs/additive_decision_boundary.zh-CN.md`。", "",
              "## 覆盖与局限", "", "| 测试日期 | 可评起点数 | 每起点可评预测次数（上限24） |", "|---|---:|---|"]
    for day in base["days"]:
        unique = [e for e in events["test"] if e["day"] == day and e["group"] == 0]
        lines.append(f"| {day} | {len(unique)} | {', '.join(str(len(e['usable_steps'])) for e in unique)} |")
    lines += ["", "日期聚类区间不是站点或数据集总体的普遍结论。24站、三站故障、训练相关性图和合成处理时间仍限制外推；当前策略没有用当前可见观测重新决策，没有真实维修工单，也没有拥堵管理的实际收益。新测试未用于前两轮，但仍是同一数据集中的有限时间段。", "",
              "## 研究决策", "",
              "本轮不根据测试成绩增加模型、挑选故障组或改阈值。若候选未通过验证能力筛选，不能说已经在强预测器上证明了结论；若总损失筛选未通过，不能通过换分母把本轮改写成成功。", "",
              "如果故障额外损失上的离线改善较大，可以为下一阶段提出新的业务明确假设：使用当前可见观测估计方案价值，能否实际减少故障引发的累计预测损失。应另建协议，以可部署的状态相关强基线比较，保留总损失作辅助，并使用尚未分析的时间段。原理想上界不能作为新方法成绩。", "",
              "当前仍不能锁定原创算法或承诺GitHub星数。可复用产物是数据隔离、持续故障/完工后观测模拟、统一策略评估、完整离线顺序数组，以及诚实记录失败情景的框架。", "",
              "## 文件与复跑", "", "```powershell", "& .\\.venv\\Scripts\\python.exe fresh_holdout_pilot.py --prepare-only",
              "& .\\.venv\\Scripts\\python.exe fresh_holdout_pilot.py", "& .\\.venv\\Scripts\\python.exe summarize_fresh_holdout.py", "```", "",
              "配置与协议哈希在`config.json`，候选权重为`model_tcn_seed*.pt`，训练与选轮日志为`model_selection_*.json`，新校准策略为`policies_*.json`，全部顺序与无人工故障损失为`arrays_*.npz`，逐案例结果为`episode_results.csv`，核查记录为`audit.json`。", "",
              "额外说明见`docs/forecast_loss_scales.zh-CN.md`和`docs/pytorch_tcn_guide.zh-CN.md`。", ""]
    (OUT/"report.zh-CN.md").write_text("\n".join(lines), encoding="utf-8")
    fig, axes = plt.subplots(1, 3, figsize=(13, 4.1), layout="constrained")
    model_names = ["Graph MLP", "Graph TCN candidate"]
    for ax, key, ci_key, title in ((axes[0], "offline_joint_vs_reference_relative_gain", "offline_joint_vs_reference_relative_ci", "Offline space / total loss"),
                                   (axes[1], "gain_as_fraction_of_fault_added_loss", "gain_as_fraction_of_fault_added_loss_ci", "Same gain / fault-added loss")):
        models = [base, candidate]
        values = np.array([m[key]*100 if m[key] is not None else np.nan for m in models])
        ax.bar(range(2), values, color=["#557e98", "#b66b48"], alpha=.8)
        for i, model in enumerate(models):
            if model[ci_key] is not None:
                lo, hi = np.array(model[ci_key])*100
                ax.errorbar(i, values[i], yerr=np.array([[values[i]-lo], [hi-values[i]]]), color="black", fmt="none", capsize=4)
            if np.isfinite(values[i]): ax.text(i, values[i], f"{values[i]:.2f}%", ha="center", va="bottom", fontsize=9)
        ax.set_xticks(range(2), model_names, fontsize=8); ax.set(title=title, ylabel="Offline relative gain (%)")
        ax.axhline(0, color="gray", lw=.7); ax.grid(axis="y", alpha=.15)
    axes[2].bar(range(2), [base["mean_validation_mae"], candidate["mean_validation_mae"]], color=["#557e98", "#b66b48"])
    axes[2].set_xticks(range(2), model_names, fontsize=8)
    axes[2].set(title="Predictor capacity check", ylabel="Old validation fixed-mask MAE")
    axes[2].grid(axis="y", alpha=.15)
    fig.savefig(OUT/"research_summary.png", dpi=180); fig.savefig(OUT/"research_summary.svg"); plt.close(fig)
    print(json.dumps({"audit": "passed", "report": str(OUT/"report.zh-CN.md"),
                      "stronger_predictor": result["stronger_predictor_screen_passed"],
                      "development_screen": result["repair_value_development_screen_passed"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
