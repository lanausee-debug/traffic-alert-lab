"""Independently check the chronological probe, labels, metrics and training objective."""
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
import torch
import alarm_start_separability as probe
import calibration_fragility as common
from congestion_alert_pilot import SCENARIOS
from train_pems_bay_risk import load_risk

ROOT=probe.ROOT;OUT=probe.OUT


def independent_auc(y,p):
    y=np.asarray(y,bool);pos=int(y.sum());neg=len(y)-pos
    if not pos or not neg:return None
    order=np.argsort(p,kind='stable');v=p[order];ranks=np.empty(len(v),float)
    lo=0
    for hi in range(1,len(v)+1):
        if hi==len(v) or v[hi]!=v[lo]:ranks[lo:hi]=(lo+1+hi)/2;lo=hi
    return float((ranks[y[order]].sum()-pos*(pos+1)/2)/(pos*neg))


def independent_ap(y,p):
    y=np.asarray(y,bool);positives=y.sum()
    if not positives:return None
    total=0.;previous=0.
    for threshold in sorted(set(p.tolist()),reverse=True):
        selected=p>=threshold;tp=int(y[selected].sum());recall=tp/positives
        total+=(recall-previous)*tp/selected.sum();previous=recall
    return float(total)


def assert_optional_close(a,b):
    assert (a is None and b is None) or (a is not None and b is not None and np.isclose(a,b,atol=1e-12))


def main():
    torch.set_num_threads(1)
    plan=common.read(OUT/'plan.json');done=common.read(OUT/'completion.json')
    result=common.read(OUT/'results.json');trainlog=common.read(OUT/'training.json')
    seal=common.read(OUT/'training_freeze.json');end=common.read(OUT/'result_freeze.json')
    for name,digest in plan['source_and_input_sha256'].items():assert common.sha(ROOT/name)==digest,name
    assert done['plan_sha256']==seal['plan_sha256']==end['plan_sha256']==common.sha(OUT/'plan.json')
    assert end['training_freeze_sha256']==common.sha(OUT/'training_freeze.json')
    assert end['results_sha256']==common.sha(OUT/'results.json')
    assert datetime.fromisoformat(plan['frozen_at_utc'])<datetime.fromisoformat(seal['frozen_at_utc'])<datetime.fromisoformat(end['frozen_at_utc'])
    for name,digest in done['artifacts'].items():assert common.sha(OUT/name)==digest,name
    for name,digest in seal['weights'].items():assert common.sha(OUT/name)==digest,name
    assert not end['new_alarm_policy_accepted'] and not result['new_alarm_policy_evaluated']
    norm=common.load(common.RISK/'normalization.npz');anchor=load_risk(common.RISK/'global_calibration.pt')
    part=common.load(common.RISK/'risk_train.npz')
    train,excluded=probe.build_samples(part,common.global_scores(part,norm,anchor))
    packed={k:np.concatenate([v[k] for v in train.values()]) for k in train['natural']}
    savedtrain=common.load(OUT/'training_pooled_samples.npz')
    for k,v in packed.items():np.testing.assert_array_equal(v,savedtrain[k])
    assert excluded==trainlog['excluded_episode_counts']
    models={};gradientchecks={}
    for name,indices in probe.METHODS.items():
        models[name]=common.load(OUT/(name+'.npz'));m=models[name]
        np.testing.assert_array_equal(m['indices'],indices)
        x=savedtrain['x'][:,indices];y=savedtrain['y']
        np.testing.assert_array_equal(m['mean'],x.mean(axis=0))
        np.testing.assert_array_equal(m['std'],np.maximum(x.std(axis=0),1e-3))
        p=probe.predict(m,savedtrain['x']);z=(x-m['mean'])/m['std']
        gradient=max(float(np.max(np.abs(z.T@(p-y)/len(y)+probe.ALPHA*m['weight']))),float(abs(np.mean(p-y))))
        assert gradient<=1e-6
        record=trainlog['logs'][name]
        assert np.isclose(gradient,record['max_abs_gradient'],atol=1e-12)
        assert record['alpha']==.1 and not record['validation_used_for_fitting_or_selection']
        threshold=probe.retention_threshold(y,p)
        assert threshold==seal['cutoffs'][name]==trainlog['cutoffs'][name]
        assert np.mean(p[y.astype(bool)]>=threshold)>=.95
        gradientchecks[name]=gradient
    cal=common.load(common.CAL/'calibration.npz');val=common.load(common.RISK/'risk_validation.npz')
    parts={'risk_validation7':val,'calibration_week1_7':common.subset(cal,0,7),'calibration_week2_7':common.subset(cal,7,14)}
    predictions=common.load(OUT/'predictions.npz');errors={};previous_last=max(savedtrain['date'].tolist())
    for block,part in parts.items():
        data,excluded=probe.build_samples(part,common.global_scores(part,norm,anchor))
        assert result['excluded_episode_counts'][block]==excluded
        first=str(part['timestamps'][part['origins'][0]].astype('datetime64[D]'))
        last=str(part['timestamps'][part['origins'][-1]].astype('datetime64[D]'))
        assert previous_last<first;previous_last=last
        for scenario,samples in data.items():
            stored=common.load(OUT/(block+'__'+scenario+'_samples.npz'))
            for k,v in samples.items():np.testing.assert_array_equal(v,stored[k])
            assert min(samples['date'].tolist())>=first and max(samples['date'].tolist())<=last
            predicted={'constant_prior':np.full(len(samples['y']),savedtrain['y'].mean()),
                'fixed_risk':samples['global_probability'],**{name:probe.predict(m,samples['x']) for name,m in models.items()}}
            for name,p in predicted.items():
                np.testing.assert_array_equal(p,predictions[block+'__'+scenario+'__'+name])
                metrics=result['metrics'][block][scenario][name]
                assert_optional_close(independent_auc(samples['y'],p),metrics['roc_auc'])
                assert_optional_close(independent_ap(samples['y'],p),metrics['average_precision'])
                assert metrics['rows']==len(samples['y']) and metrics['credited_warnings']==int(samples['y'].sum())
                if name in models:assert result['retention'][block][scenario][name]==probe.retention_metrics(samples,p,seal['cutoffs'][name])
            p=predicted['state_logistic'];keep=p>=seal['cutoffs']['state_logistic']
            selected=np.flatnonzero(((samples['y']==1)&~keep)|((samples['y']==0)&keep))
            errors[block+'__'+scenario]=[{'node':int(samples['node'][i]),'timestamp':str(samples['timestamp'][i]),
                'target_credited_warning':bool(samples['y'][i]),'proxy_lead_minutes':int(samples['lead_minutes'][i]),
                'predicted_probability':float(p[i]),'retained_by_training_cutoff':bool(keep[i])} for i in selected]
    assert probe.separation_gate({b:v['natural'] for b,v in result['metrics'].items()})==result['natural_diagnostic_gate']
    prior=common.read(ROOT/'outputs/adaptive-confirmation-2026-10-15/writing_archive_manifest.json')
    for name,meta in prior['files'].items():
        if name in ('README.md','CURRENT_STATE.zh-CN.md') and (OUT/'writing_archive_manifest.json').exists():
            assert common.sha(ROOT/name)==common.read(OUT/'writing_archive_manifest.json')['files'][name]['sha256']
        else:assert common.sha(ROOT/name)==meta['sha256'],name
    common.write(OUT/'classification_errors.json',errors)
    proof={'passed':True,'checked_at_utc':datetime.now(timezone.utc).isoformat(),
        'training_probe_models':3,'pooled_training_rows':len(savedtrain['y']),
        'unique_training_node_origin_pairs':len(set(zip(savedtrain['node'].tolist(),savedtrain['origin'].tolist()))),
        'training_only_normalization_and_objective_gradient_checked':gradientchecks,
        'chronological_block_dates_nonoverlapping':True,'offline_labels_and_all_saved_features_rebuilt':True,
        'all45_AUC_AP_metric_pairs_independently_checked':True,
        'frozen_retention_cutoffs_and_predictions_checked':True,
        'prior_scientific_artifacts_unchanged':True,
        'development_diagnostic_gate_passed':result['natural_diagnostic_gate']['passed'],
        'new_alarm_policy_accepted':False,'new_station_cohort_consumed':False,
        'source_sha256':common.sha(Path(__file__))}
    common.write(OUT/'audit.json',proof);print(proof)


if __name__=='__main__':main()
