"""Second adaptive exploratory trial: frozen global risk plus a bounded residual.

All training/selection uses risk-train, risk-validation and calibration caches.
No evaluation or raw HDF5 access, no changes to old files.
"""
from __future__ import annotations
import copy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import time

import numpy as np
import torch
from torch import nn

import improve_alert_recall as common
from congestion_alert_pilot import SCENARIOS
from congestion_risk_pilot import RiskModel, score, sigmoid
from pems_bay_alert_replay import alarm, replay
from train_pems_bay_risk import load_risk

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs/anchored-risk-2026-10-15'
RISK=ROOT/'outputs/pems-bay-risk';CAL=ROOT/'outputs/pems-bay-calibration'
SEEDS=(202,203,204)
BOUNDS=(0.5,1.0)
CHECKS=(0,225,450,900,1350)


def write(path,value):common.write(path,value)
def read(path):return common.read(path)
def sha(path):return common.sha(path)


class AnchoredRisk(nn.Module):
    def __init__(self,bound):
        super().__init__();self.residual=RiskModel(51,True);self.bound=bound
        nn.init.zeros_(self.residual.layers[-1].weight);nn.init.zeros_(self.residual.layers[-1].bias)
    def forward(self,x):
        # Last column is the fixed global model's logit, never an observed future label.
        return x[:,-1]+self.bound*torch.tanh(self.residual(x[:,:51]))


def inputs(part,norm,global_model,supervised):
    result=[]
    for scenario in SCENARIOS:
        raw=part[f'{scenario}_state'][part['common']] if supervised else part[f'{scenario}_state'].reshape(-1,51)
        single=part[f'{scenario}_single'][part['common']] if supervised else part[f'{scenario}_single'].reshape(-1)
        x=((raw-norm['mean'])/norm['std']).astype(np.float32)
        one=((single[:,None]-norm['single_mean'])/norm['single_std']).astype(np.float32)
        base=score(global_model,one)
        result.append(np.column_stack((x,base)).astype(np.float32))
    return np.concatenate(result) if supervised else dict(zip(SCENARIOS,result))


def fit(x,y,xv,yv,seed,bound):
    torch.manual_seed(seed);model=AnchoredRisk(bound)
    xt,yt=torch.tensor(x),torch.tensor(y)
    optimizer=torch.optim.Adam(model.parameters(),lr=.001,weight_decay=.001)
    rng=torch.Generator().manual_seed(seed+17)
    initial_logits=score(model,xv)
    assert np.array_equal(initial_logits,xv[:,-1]),'Zero residual must exactly reproduce the anchor'
    value=float(np.mean(np.logaddexp(0,initial_logits)-yv*initial_logits))
    best=value;chosen=0;selected=copy.deepcopy(model.state_dict());logs=[{'step':0,'validation_union_bce':value}]
    digest=hashlib.sha256()
    for step in range(1,1351):
        model.train();ids=torch.randint(len(x),(4096,),generator=rng)
        digest.update(ids.numpy().astype(np.int32).tobytes())
        optimizer.zero_grad(set_to_none=True)
        loss=nn.functional.binary_cross_entropy_with_logits(model(xt[ids]),yt[ids]);loss.backward();optimizer.step()
        if step in CHECKS:
            logits=score(model,xv);value=float(np.mean(np.logaddexp(0,logits)-yv*logits))
            logs.append({'step':step,'validation_union_bce':value})
            if value<best:best=value;chosen=step;selected=copy.deepcopy(model.state_dict())
    model.load_state_dict(selected);model.eval()
    assert np.max(np.abs(score(model,xv)-xv[:,-1]))<=bound+1e-5
    record={'seed':seed,'bound_logit':bound,'actual_optimizer_updates':1350,'selected_step':chosen,
        'batch_size':4096,'train_rows':len(x),'validation_rows':len(xv),
        'validation_union_bce':best,'logs':logs,'minibatch_index_sha256':digest.hexdigest(),
        'parameters':sum(p.numel() for p in model.parameters()),'zero_residual_anchor_identity_checked':True}
    return model,record


def main():
    sys.addaudithook(common.audit)
    torch.set_num_threads(1);torch.use_deterministic_algorithms(True)
    OUT.mkdir(exist_ok=True)
    names=['improve_anchored_risk.py','improve_alert_recall.py','congestion_risk_pilot.py',
        'pems_bay_alert_replay.py','congestion_alert_pilot.py','outputs/recall-repair-2026-10-15/results.json',
        'outputs/pems-bay-risk/global_calibration.pt','outputs/pems-bay-risk/normalization.npz',
        'outputs/pems-bay-risk/risk_train.npz','outputs/pems-bay-risk/risk_validation.npz',
        'outputs/pems-bay-calibration/calibration.npz','outputs/pems-bay-calibration/scores_calibration.npz',
        'outputs/pems-bay-calibration/selection.json']
    plan={'stage':'adaptive_second_exploratory_trial_after_failed_mixed_targets',
        'prior_calibration_and_old_study_results_informed_design':True,
        'old_evaluation_values_read':False,'fresh_confirmation':False,
        'hypothesis':'bounded logit residual around strong frozen global model preserves ongoing-event detection while union target rewards impending starts',
        'anchor':'original frozen global calibration model',
        'inputs':'same 51 historical/prediction state features plus frozen global logit',
        'output':'global_logit + bound*tanh(MLP_51_32_16_1)',
        'initialization':'zero last layer; initial model exactly equals anchor',
        'target':'persistent_truth OR impending_onset, common-valid training rows only',
        'bounds':list(BOUNDS),'seeds':list(SEEDS),'updates_per_model':1350,'batch_size':4096,
        'checkpoint_selection':'minimum union-target BCE on risk-validation, checkpoints 0/225/450/900/1350',
        'threshold_grid':'0.01..0.9 step0.005 + 1.0001, confirmation1/2',
        'constraints':'same per-scenario original false budgets; per-scenario detection >= original global fine -0.02',
        'rank':'max mean R10; max worst detection; min mean false rate; declaration order; confirmation; grid index',
        'pilot_acceptance':'all constraints and mean R10 >= original global fine +0.02',
        'failure_policy':'no evaluation replay or constraint relaxation if calibration acceptance fails',
        'input_and_source_sha256':{name:sha(ROOT/name) for name in names}}
    if (OUT/'plan.json').exists():
        assert {k:v for k,v in read(OUT/'plan.json').items() if k!='frozen_at_utc'}==plan
    else:write(OUT/'plan.json',{**plan,'frozen_at_utc':datetime.now(timezone.utc).isoformat()})
    norm=common.load(RISK/'normalization.npz');global_model=load_risk(RISK/'global_calibration.pt')
    tr=common.load(RISK/'risk_train.npz');va=common.load(RISK/'risk_validation.npz')
    x=inputs(tr,norm,global_model,True);xv=inputs(va,norm,global_model,True)
    target=lambda part:np.tile((part['truth']|part['onset'])[part['common']],3).astype(np.float32)
    y=target(tr);yv=target(va);del tr,va
    training={};fitted={}
    for bound in BOUNDS:
        method=f'anchored_bound{str(bound).replace(".","_")}'
        fitted[method]=[];training[method]=[]
        for seed in SEEDS:
            path=OUT/f'{method}_seed{seed}.pt';record_path=path.with_suffix('.json')
            if path.exists() and record_path.exists():
                record=read(record_path);assert sha(path)==record['weight_sha256'] and record['plan_sha256']==sha(OUT/'plan.json')
                model=AnchoredRisk(bound);model.load_state_dict(torch.load(path,weights_only=True)['state_dict']);model.eval()
            elif path.exists() or record_path.exists():raise ValueError('Keep incomplete artifacts')
            else:
                start=time.perf_counter();model,record=fit(x,y,xv,yv,seed,bound)
                torch.save({'state_dict':model.state_dict(),'bound':bound},path)
                record.update({'training_seconds':time.perf_counter()-start,'weight_sha256':sha(path),'plan_sha256':sha(OUT/'plan.json')})
                write(record_path,record)
            fitted[method].append(model);training[method].append(record)
            print(f'{method} seed={seed} selected_step={record["selected_step"]} union_BCE={record["validation_union_bce"]:.6f}',flush=True)
    write(OUT/'training.json',training)
    write(OUT/'training_freeze.json',{'frozen_at_utc':datetime.now(timezone.utc).isoformat(),
        'weights':{p.name:sha(p) for p in sorted(OUT.glob('*.pt'))},'old_evaluation_values_read':False,
        'calibration_used_for_checkpoint_selection':False})
    part=common.load(CAL/'calibration.npz');xx=inputs(part,norm,global_model,False)
    old=read(CAL/'selection.json');reference=old['methods']['global_calibration']['fine']['selected']['by_scenario']
    budgets=old['budgets'];candidates=[];families={}
    for index,(method,models) in enumerate(fitted.items()):
        scores={s:np.mean([sigmoid(score(model,xx[s])) for model in models],axis=0).reshape(part['truth'].shape) for s in SCENARIOS}
        np.savez_compressed(OUT/(method+'_calibration_scores.npz'),**scores)
        rows=[]
        for gi,threshold in enumerate([round(v/1000,3) for v in range(10,901,5)]+[1.0001]):
            for confirmation in (1,2):
                by_s={s:replay(part,alarm(scores[s],threshold,confirmation,part),details=True)[0] for s in SCENARIOS}
                rows.append({'method':method,'method_index':index,'grid_index':gi,'threshold':threshold,'confirmation':confirmation,'by_scenario':by_s})
        selected=common.select(rows,reference,budgets)
        families[method]={'feasible_settings':sum(row['feasible'] for row in rows),'selected':selected}
        write(OUT/(method+'_calibration_grid.json'),rows)
        if selected:candidates.append(selected)
        print(f'{method}: feasible={families[method]["feasible_settings"]}',flush=True)
    selected=common.select(candidates,reference,budgets)
    means=lambda rows:{key:common.mean(rows,key) for key in ('warning_recall_at_least10','warning_recall','detection_recall','false_per_valid_station_day')}
    result={'stage':'adaptive_calibration_exploration','independent_test_executed':False,'old_evaluation_values_read':False,
        'calibration_events':69,'calibration_days':14,'budgets':budgets,
        'reference_global':means(reference),'original_onset':means(old['methods']['onset_mlp']['fine']['selected']['by_scenario']),
        'candidate_families':families,'selected':selected,'selected_means':means(selected['by_scenario']) if selected else None,
        'pilot_acceptance_passed':selected is not None and common.mean(selected['by_scenario'],'warning_recall_at_least10')>=common.mean(reference,'warning_recall_at_least10')+.02-1e-12,
        'next_required':'new external validation if the pilot passes; no improvement claim from reused calibration'}
    write(OUT/'results.json',result)
    write(OUT/'selection_freeze.json',{'frozen_at_utc':datetime.now(timezone.utc).isoformat(),
        'plan_sha256':sha(OUT/'plan.json'),'results_sha256':sha(OUT/'results.json'),
        'selected':{k:v for k,v in selected.items() if k!='by_scenario'} if selected else None,
        'old_evaluation_values_read':False})
    for name,digest in plan['input_and_source_sha256'].items():assert sha(ROOT/name)==digest,name
    write(OUT/'access_log.json',{'logical_input_reads':sorted(set(common.READS)),
        'evaluation_and_hdf5_runtime_open_guard_enabled':True,'old_evaluation_values_read':False,'old_input_hashes_unchanged':True})
    print(json.dumps({key:result[key] for key in ('reference_global','original_onset','selected_means','pilot_acceptance_passed')},ensure_ascii=True),flush=True)


if __name__=='__main__':main()
