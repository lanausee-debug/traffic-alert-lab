"""Independent interval/event checks and audited physical-unit context view."""
from copy import deepcopy
from datetime import datetime,timezone
import sys
import numpy as np
import torch
import bypass_diagnosis as pilot
import effective_alert_pilot as previous
import alarm_start_separability as probe
import calibration_fragility as common
import early_warning_protection as protection
from audit_early_warning_protection import independent_observed_low,interval_gate
from congestion_alert_pilot import SCENARIOS,runs
from pems_bay_alert_replay import replay,layout,alarm
from train_pems_bay_risk import load_risk
from complete_bypass_diagnosis import json_native


def correct_context_units(result):
    """Source schema uses /20 for standard deviations, /70 for speed levels.

    Preserve original output; create a corrected report-only view. Count/strata,
    policy, scores and thresholds are untouched by these two unit corrections.
    """
    result=deepcopy(result)
    for scenes in result['blocks'].values():
        for d in scenes.values():
            for run in d['added_runs']:
                c=run['context']
                for key in ('own_std_mph','forecast_seed_std5_mph'):c[key]*=20/70
    result['context_std_units_corrected_from_source_schema']=True
    return result


def main():
    sys.addaudithook(protection.guard);torch.set_num_threads(1)
    out=pilot.OUT;root=pilot.ROOT;plan=common.read(out/'plan.json');done=common.read(out/'completion.json')
    original=common.read(out/'results.json');r=correct_context_units(original)
    for n,h in plan['source_and_input_sha256'].items():assert common.sha(root/n)==h,n
    for n,h in done['artifacts'].items():assert common.sha(out/n)==h,n
    assert done['plan_sha256']==common.sha(out/'plan.json')
    assert datetime.fromisoformat(plan['frozen_at_utc'])<datetime.fromisoformat(done['completed_at_utc'])
    seal=common.read(previous.OUT/'training_freeze.json');assert seal['cutoff']==r['fixed_cutoff']
    assert common.sha(previous.OUT/'effective_model.npz')==seal['model_sha256']==r['model_sha256']
    model=common.load(previous.OUT/'effective_model.npz');norm=common.load(common.RISK/'normalization.npz')
    anchor=load_risk(common.RISK/'global_calibration.pt')
    parts={'training28':common.load(common.RISK/'risk_train.npz'),
        'risk_validation7':common.load(common.RISK/'risk_validation.npz'),
        'calibration_full14':common.load(common.CAL/'calibration.npz')}
    parts.update({'calibration_week1_7':common.subset(parts['calibration_full14'],0,7),
        'calibration_week2_7':common.subset(parts['calibration_full14'],7,14)})
    old=common.read(previous.OUT/'results.json');acts=common.load(previous.OUT/'activations.npz')
    counts={'scenario_blocks':0,'operating_replays':0,'raw_decisions':0,'event_records':0,'changed_events':0}
    for block,part in parts.items():
        scores=common.global_scores(part,norm,anchor)
        for s in SCENARIOS:
            d=r['blocks'][block][s];x=part[s+'_state'];p=scores[s]
            cred=probe.predict(model,probe.start_features(part,s,p).reshape(-1,30)).reshape(part['truth'].shape)
            observed=independent_observed_low(part,s)
            no=interval_gate(p,cred,np.zeros_like(observed),part,r['fixed_cutoff'])
            yes=interval_gate(p,cred,observed,part,r['fixed_cutoff'])
            base=alarm(p,.46,1,part)
            expected=[]
            for lo,hi in layout(part)[0]:
                for node in range(p.shape[1]):
                    for a,b in runs((yes&~no)[lo:hi,node]):expected.append((int(a+lo),int(b+lo),node))
            assert expected==[(e['row'],e['end_row'],e['node']) for e in d['added_runs']]
            fragments=common.episodes(part,yes);bykind={k:0 for k in pilot.KINDS}
            for run in d['added_runs']:
                a,b,node=run['row'],run['end_row'],run['node'];c=run['context']
                assert observed[a,node] and cred[a,node]<r['fixed_cutoff']
                assert run['origin']==int(part['origins'][a]) and run['timestamp']==str(part['timestamps'][part['origins'][a]])
                fs=[f for f in fragments if f['node']==node and a<=f['row']<b]
                assert json_native(fs)==run['scored_fragments']
                for f in fs:bykind[f['kind']]+=1
                np.testing.assert_allclose(c['observed_last3_mph'],x[a-2:a+1,node,8].astype(float)*70,atol=1e-10)
                for name,index,scale in [('own_mean_mph',9,70),('own_trend_scaled',10,1),('own_std_mph',11,20),
                        ('own_coverage',12,1),('own_age_scaled',13,1),('forecast5_mph',0,70),('forecast10_mph',1,70),
                        ('forecast15_mph',2,70),('forecast_seed_std5_mph',3,20),('neighbor_last_mph',15,70),
                        ('neighbor_coverage',19,1),('network_coverage',48,1)]:
                    assert np.isclose(c[name],float(x[a,node,index])*scale,rtol=0,atol=1e-10),name
                residual=float((x[a-1,node,0]-x[a,node,8])*70)
                assert np.isclose(c['past_residual_mph'],residual,rtol=0,atol=1e-10)
                assert c['global_probability']==float(p[a,node]) and c['effective_probability']==float(cred[a,node])
                assert c['score_deficit']==r['fixed_cutoff']-float(cred[a,node])
                rs='missing' if c['past_residual_mph'] is None else '<-5' if residual<-5 else '[-5,0)' if residual<0 else '[0,5]' if residual<=5 else '>5'
                assert run['strata']=={'residual':rs,'forecast_all_low':'all<=30' if max(c['forecast5_mph'],c['forecast10_mph'],c['forecast15_mph'])<=30 else 'some>30',
                    'score_deficit':'<=0.05' if c['score_deficit']<=.05 else '>0.05'}
            event_maps={}
            for method,bits in [('global_c1',base),('effective_no_bypass',no),(previous.PRIMARY,yes)]:
                row,_,events=replay(part,bits,details=True);assert row==d['operating'][method]
                event_maps[method]={(e['node'],e['event_start_origin']):e for e in events}
                if block!='training28':
                    assert row==old['evaluation'][block][method][s]
                    np.testing.assert_array_equal(bits,acts[f'{block}__{method}__{s}'])
                counts['operating_replays']+=1
            bm=event_maps['global_c1'];nm=event_maps['effective_no_bypass'];ym=event_maps[previous.PRIMARY]
            assert bm.keys()==nm.keys()==ym.keys();changes=[]
            for k,e in ym.items():
                if nm[k]==e:continue
                indices=[i for i,v in enumerate(d['added_runs']) if v['node']==k[0] and e['alarm_start_origin'] is not None and v['origin']<=e['alarm_start_origin']<=int(part['origins'][v['end_row']-1])]
                origin=bm[k];before=nm[k]
                restored=(origin['status']=='warned' and origin['lead_minutes']>=10 and e['status']=='warned' and e['lead_minutes']>=origin['lead_minutes'] and
                    not (before['status']=='warned' and before['lead_minutes']>=origin['lead_minutes']))
                changes.append({'node':k[0],'event_start_origin':k[1],'without':before,'with':e,'original':origin,
                    'bypass_raw_run_indices':indices,'restored_original_R10_identity_and_lead':restored,
                    'recovered_detection':before['status']=='missed' and e['status']!='missed'})
            assert json_native(changes)==d['changed_events']
            a=d['operating']['effective_no_bypass'];b=d['operating'][previous.PRIMARY];summary=d['summary']
            assert summary['added_raw_runs']==summary['unique_raw_node_origin_keys']==len(expected)
            assert summary['added_scored_fragment_types']==bykind
            assert summary['changed_event_records']==len(changes)
            assert summary['restored_original_R10']==sum(e['restored_original_R10_identity_and_lead'] for e in changes)
            assert summary['recovered_detections']==sum(e['recovered_detection'] for e in changes)
            for metric,column in [('R10_increase','warning_recall_at_least10'),('detection_increase','detection_recall'),('false_rate_increase','false_per_valid_station_day')]:
                assert summary[metric]==b[column]-a[column]
            assert np.isclose(b['false']-a['false'],bykind['false'])
            for feature,bins in d['strata'].items():
                for label,value in bins.items():
                    indices=[i for i,v in enumerate(d['added_runs']) if v['strata'][feature]==label]
                    assert value['raw_runs']==len(indices)
                    for kind in ('false','warned','late'):
                        assert value[kind+'_fragments']==sum(f['kind']==kind for i in indices for f in d['added_runs'][i]['scored_fragments'])
                    assert value['restored_original_R10']==sum(e['restored_original_R10_identity_and_lead'] and any(i in indices for i in e['bypass_raw_run_indices']) for e in changes)
            counts['scenario_blocks']+=1;counts['raw_decisions']+=len(expected);counts['event_records']+=len(bm);counts['changed_events']+=len(changes)
    assert not r['previous_candidate_acceptance_passed'] and r['original_thesis_primary_test_still_failed']
    assert r['new_models_fitted']==0 and not r['policy_modified'] and not r['new_station_cohort_consumed'] and not r['consumed_transfer_values_used']
    common.write(out/'audited_results.json',json_native(r))
    common.write(out/'context_unit_corrections.json',{'recorded_at_utc':datetime.now(timezone.utc).isoformat(),
        'original_results_sha256':common.sha(out/'results.json'),'audited_results_sha256':common.sha(out/'audited_results.json'),
        'schema_source':'congestion_risk_pilot.features: own_std/20 and seed_std/20; speed levels/70',
        'correction':'Two context-only standard-deviation fields multiply by20/70; original results retained',
        'policy_features_scores_cutoff_counts_strata_unchanged':True,'auditor_sha256':common.sha(root/'audit_bypass_diagnosis.py')})
    common.write(out/'audit.json',{'passed':True,'audited_at_utc':datetime.now(timezone.utc).isoformat(),**counts,
        'audited_results_sha256':common.sha(out/'audited_results.json'),'scientific_source_plan_preserved':True,
        'context_physical_units_corrected_and_independently_checked':True,'frozen_prior45_replays_reproduced':True,
        'previous_development36_activations_reproduced':True,'new_models_fitted':0,'policy_modified':False,
        'new_station_cohort_consumed':False,'original_thesis_primary_test_still_failed':True,
        'audit_guard_output_paths':sorted(set(common.READS))})
    print(counts)


if __name__=='__main__':main()
