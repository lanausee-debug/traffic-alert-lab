"""Frozen onset models: probability ranking, calibration grids and 2x2 attribution."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import time
import numpy as np
import torch
from recovery_pilot import ROOT,write_json
from multifault_pilot import sha256
from congestion_alert_pilot import SCENARIOS
from congestion_risk_pilot import PROB_THRESHOLDS,prepare_partition,score,sigmoid,online_alarm
from congestion_ablation import OLD,SEEDS,load_data,load_model
from congestion_onset_pilot import OUTPUT as ONSET,onset_targets
from congestion_density_pilot import OUTPUT as DENSITY
from congestion_objective_diagnostic import trace_events

OUTPUT=ROOT/'outputs/congestion-calibration-diagnostic'
METHODS=('onset_mlp','sparse_update_mlp','dense_update_mlp')
BINS=np.array([0,.01,.02,.03,.05,.075,.1,.15,.2,.25,.3,.4,.5,.6,.7,.8,.9,1.])
QUANTILES=(0,.1,.25,.5,.75,.9,.99,1.)
FIELDS=('warning_recall','warning10_recall','detection_recall','false_per_valid_station_day')


def model_path(method,seed):
    return ONSET/f'onset_mlp_{seed}.pt' if method=='onset_mlp' else DENSITY/f'{method}_{seed}.pt'


def load_partitions(data):
    parts={}; targets={}; day=data[8]
    for name,a,b in [('validation',70,77),('calibration',77,91)]:
        start,end=int(np.searchsorted(day,a)),int(np.searchsorted(day,b))
        parts[name],_=prepare_partition(name,start,end,1,data,[],OLD)
        p=parts[name]['natural']; t,m=onset_targets(data,p['origins'],start,end)
        targets[name]={'truth':t,'eligible':m,'origins':p['origins']}
    return parts,targets


def scores_from_weights(parts,mu,std):
    fitted={m:[load_model(model_path(m,seed))[0] for seed in SEEDS] for m in METHODS}
    result={}
    for partition,by_s in parts.items():
        result[partition]={m:{} for m in METHODS}
        for s,p in by_s.items():
            x=((p['state'].reshape(-1,51)-mu)/std).astype(np.float32)
            for m,models in fitted.items():
                result[partition][m][s]=np.mean([sigmoid(score(model,x)) for model in models],axis=0).reshape(p['truth'].shape)
    return result


def ranking(p,y):
    order=np.argsort(-p,kind='stable'); pp=p[order]; yy=y[order].astype(np.int64)
    end=np.r_[np.flatnonzero(pp[:-1]!=pp[1:]),len(pp)-1]
    tp=np.cumsum(yy)[end]; fp=end+1-tp; pos=int(y.sum()); neg=len(y)-pos
    ap=float(np.sum(np.diff(np.r_[0,tp])/pos*tp/(end+1)))
    auc=float(np.trapezoid(np.r_[0,tp/pos],np.r_[0,fp/neg]))
    return {'average_precision':ap,'roc_auc':auc}


def probability_diagnostic(p,truth,mask):
    p=p[mask].astype(np.float64); y=truth[mask].astype(np.int64)
    ids=np.searchsorted(BINS,p,side='right')-1; ids=np.clip(ids,0,len(BINS)-2)
    bins=[]; ece=0.
    for i in range(len(BINS)-1):
        chosen=ids==i; count=int(chosen.sum()); predicted=float(p[chosen].mean()) if count else None
        observed=float(y[chosen].mean()) if count else None
        if count: ece+=count/len(p)*abs(predicted-observed)
        bins.append({'lower':float(BINS[i]),'upper':float(BINS[i+1]),'count':count,'positive_count':int(y[chosen].sum()),
                     'mean_probability':predicted,'positive_fraction':observed})
    return {'valid_points':len(p),'positive_points':int(y.sum()),'positive_fraction':float(y.mean()),
            'mean_probability':float(p.mean()),'bce':float(np.mean(-y*np.log(np.clip(p,1e-7,1-1e-7))-(1-y)*np.log(np.clip(1-p,1e-7,1)))),
            'brier':float(np.mean((p-y)**2)),'ece_fixed_bins':ece,'reliability':bins,
            'positive_quantiles':np.quantile(p[y==1],QUANTILES).tolist(),
            'negative_quantiles':np.quantile(p[y==0],QUANTILES).tolist(),**ranking(p,y)}


def operating_detail(scores,parts,threshold,confirmation,ts):
    rows={}; daily={}; records={}
    for s,p in parts.items():
        alarm=online_alarm(scores[s],threshold,confirmation)
        stats,days,trace,detail=trace_events(p['truth'],p['eligible'],alarm,p['day_ids'],p['origins'],ts)
        stats['warning10_recall']=(detail['warning_by_lead']['10']+detail['warning_by_lead']['15'])/stats['events']
        rows[s]={'stats':stats,'diagnostic':detail}; daily[s]=days; records[s]=trace
    summary={field:float(np.mean([r['stats'][field] for r in rows.values()])) for field in FIELDS}
    return {'threshold':threshold,'confirmation':confirmation,'by_scenario':rows,'mean':summary},daily,records


def grid_key(threshold,confirmation):
    return f'{threshold:g}_c{confirmation}'


def decomposition(grid):
    out={}
    for candidate in METHODS[1:]:
        a0=grid['onset_mlp'][grid_key(.15,1)]['mean']; a1=grid['onset_mlp'][grid_key(.2,1)]['mean']
        b0=grid[candidate][grid_key(.15,1)]['mean']; b1=grid[candidate][grid_key(.2,1)]['mean']
        fields={}
        for k in FIELDS:
            model=.5*((b0[k]-a0[k])+(b1[k]-a1[k])); threshold=.5*((a1[k]-a0[k])+(b1[k]-b0[k]))
            fields[k]={'total_difference':b1[k]-a0[k],'symmetric_model_component':model,'symmetric_threshold_component':threshold,
                       'model_first_path':[b0[k]-a0[k],b1[k]-b0[k]],'threshold_first_path':[a1[k]-a0[k],b1[k]-a1[k]]}
        out[candidate]=fields
    return out


def compute(scores,parts,targets,selection,ts):
    probability={}; grid={}; daily={}; fixed_records={}
    for partition in ('validation','calibration'):
        probability[partition]={}; t=targets[partition]
        for m in METHODS:
            probability[partition][m]={s:probability_diagnostic(scores[partition][m][s],t['truth'],t['eligible']) for s in SCENARIOS}
            probability[partition][m]['pooled']=probability_diagnostic(
                np.concatenate([scores[partition][m][s] for s in SCENARIOS]),np.tile(t['truth'],(3,1)),np.tile(t['eligible'],(3,1)))
    for m in METHODS:
        grid[m]={}; fixed_records[m]={}
        for threshold in PROB_THRESHOLDS:
            for c in (1,2):
                key=grid_key(threshold,c)
                row,days,records=operating_detail(scores['calibration'][m],parts['calibration'],threshold,c,ts)
                row['budget_excess_by_scenario']={s:row['by_scenario'][s]['stats']['false_per_valid_station_day']-selection['budgets'][s] for s in SCENARIOS}
                row['feasible']=all(v<=1e-12 for v in row['budget_excess_by_scenario'].values())
                row['maximum_budget_fraction']=max(row['by_scenario'][s]['stats']['false_per_valid_station_day']/selection['budgets'][s] for s in SCENARIOS)
                grid[m][key]=row
                daily.update({f'{m}_{key}_{s}':v for s,v in days.items()})
                if c==1 and threshold in (.15,.2): fixed_records[m][key]=records
        print(f'calibration grid rebuilt: {m}',flush=True)
    return {'probability':probability,'calibration_grid':grid,'decomposition':decomposition(grid)},daily,fixed_records


def main():
    parser=argparse.ArgumentParser(description=__doc__); parser.add_argument('--output',type=Path,default=OUTPUT)
    parser.add_argument('--prepare-only',action='store_true'); args=parser.parse_args(); output=args.output
    output.mkdir(parents=True,exist_ok=True)
    paths=[Path(__file__),ROOT/'docs/congestion_calibration_diagnostic_protocol.zh-CN.md',ROOT/'congestion_risk_pilot.py',
           ROOT/'congestion_alert_pilot.py',ROOT/'congestion_objective_diagnostic.py',ROOT/'congestion_ablation.py',
           ROOT/'congestion_onset_pilot.py',ROOT/'congestion_density_pilot.py',ROOT/'data/raw/metr-la.h5',
           ROOT/'state_value_pilot.py',ROOT/'recovery_pilot.py',ROOT/'outputs/recovery-pilot/config.json',
           ROOT/'outputs/multifault-pilot/config.json',OLD/'normalization.npz',OLD/'predictions_validation.npz',
           ROOT/'outputs/congestion-alert-pilot-v2/predictions_calibration.npz']
    for source in (ONSET,DENSITY):
        paths += [source/name for name in ('config.json','selection.json','model_selection.json','scores_calibration.npz',
                                         'targets_validation.npz','targets_calibration.npz')]
    paths += [model_path(m,seed) for m in METHODS for seed in SEEDS]
    config={'date':'2026-10-10','posthoc_exploratory':True,'no_training':True,'no_new_evaluation_replays':True,
            'methods':METHODS,'probability_bins':BINS.tolist(),'quantile_levels':QUANTILES,
            'grid':PROB_THRESHOLDS,'confirmations':[1,2],'common_thresholds':[.15,.20],
            'sha256':{str(p.relative_to(ROOT)):sha256(p) for p in paths}}
    config=json.loads(json.dumps(config))
    if (output/'config.json').exists(): assert config==json.loads((output/'config.json').read_text(encoding='utf-8')),'Use a new output directory'
    else: write_json(output/'config.json',config)
    if args.prepare_only: print(json.dumps({'config':str(output/'config.json')})); return
    if (output/'results.json').exists(): raise ValueError('Existing result preserved')
    torch.set_num_threads(1); torch.use_deterministic_algorithms(True); begun=time.perf_counter()
    data=load_data(); parts,targets=load_partitions(data)
    with np.load(OLD/'normalization.npz') as n: mu,std=n['mean'],n['std']
    scores=scores_from_weights(parts,mu,std)
    for partition,by_m in scores.items():
        np.savez_compressed(output/f'scores_{partition}.npz',**{f'{m}_{s}':p for m,rows in by_m.items() for s,p in rows.items()})
    selection=json.loads((DENSITY/'selection.json').read_text(encoding='utf-8'))
    result,daily,records=compute(scores,parts,targets,selection,data[3])
    result.update({'config':config,'selected_operating_points':{m:selection['methods'][m]['selected'] for m in METHODS},
                   'budgets':selection['budgets'],'elapsed_seconds':time.perf_counter()-begun})
    write_json(output/'results.json',result); np.savez_compressed(output/'daily_metrics.npz',**daily)
    write_json(output/'fixed_threshold_event_records.json',records)
    audit={'audit_status':'independent recomputation pending','source_hashes_unchanged':all(sha256(ROOT/k)==v for k,v in config['sha256'].items()),
           'artifact_sha256':{p.name:sha256(p) for p in output.iterdir() if p.suffix=='.npz' or p.name=='fixed_threshold_event_records.json'}}
    assert audit['source_hashes_unchanged']; write_json(output/'audit.json',audit)
    print(json.dumps({'seconds':result['elapsed_seconds'],'decomposition':result['decomposition']},indent=2))


if __name__=='__main__': main()
