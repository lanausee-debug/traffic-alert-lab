"""Cumulative local checkpoint of both exploratory trials and fixed historical replay."""
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs/anchored-risk-2026-10-15'
NAME='traffic-recovery-lab-2026-10-15-recall-improvement'
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def dump(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def main():
    archive=ROOT.parent/'checkpoints'/(NAME+'.zip');receipt=archive.with_name(NAME+'-save-receipt.json')
    if archive.exists() or receipt.exists():raise FileExistsError('Keep saved archives')
    prior_path='outputs/github-web-2026-10-15/writing_archive_manifest.json'
    prior=read(ROOT/prior_path)
    for name,meta in prior['files'].items():
        if name not in {'README.md','CURRENT_STATE.zh-CN.md'}:assert sha(ROOT/name)==meta['sha256'],name
    audit=read(OUT/'audit.json')
    assert audit['passed'] and audit['original_primary_test_still_failed'] and not audit['independent_confirmation']
    assert audit['new_risk_models_trained']==12 and audit['actual_optimizer_updates']==16200
    replay=read(OUT/'historical-replay/results.json')
    assert not replay['threshold_grid_search'] and replay['candidate_fixed_before_this_stage']
    files=set(prior['files'])|{prior_path,'improve_alert_recall.py','improve_anchored_risk.py',
        'replay_anchored_candidate.py','summarize_recall_improvement.py','audit_recall_improvement.py',
        'save_recall_improvement_checkpoint.py','tests/test_anchored_risk.py','docs/recall_improvement_handoff.zh-CN.md'}
    for folder in (ROOT/'outputs/recall-repair-2026-10-15',OUT):
        files|={p.relative_to(ROOT).as_posix() for p in folder.rglob('*') if p.is_file() and p.name!='writing_archive_manifest.json'}
    base_receipt=ROOT.parent/'checkpoints/traffic-recovery-lab-2026-10-11-event-timeline-save-receipt.json'
    base=read(base_receipt)
    assert Path(base['full_archive']).stat().st_size==base['full_archive_bytes'] and base['archive_crc_and_all_sha256_verified']
    manifest=OUT/'writing_archive_manifest.json'
    dump(manifest,{'client_date':'2026-10-15','stage':'cumulative_recall_improvement_exploration',
        'archive_name':archive.name,'restore':'October 11 full base, then this cumulative supplement',
        'public_commit_unchanged':'ab8760a3e6ea1784fea3195a0e7aadbaff6fe80d',
        'primary_metric_supported':False,'independent_confirmation':False,
        'new_risk_models_trained':12,'actual_optimizer_updates':16200,
        'candidate':'anchored_bound1_0 threshold0.505 confirmation1 ensemble202/203/204',
        'full_base_crc_rechecked_this_turn':False,
        'base_archive_sha256_from_prior_verified_receipt':base['full_archive_sha256'],
        'files':{name:{'bytes':(ROOT/name).stat().st_size,'sha256':sha(ROOT/name)} for name in sorted(files)}})
    files.add(manifest.relative_to(ROOT).as_posix())
    with ZipFile(archive,'x',compression=ZIP_DEFLATED) as z:
        for name in sorted(files):z.write(ROOT/name,'traffic-recovery-lab/'+name)
    with ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist())==len(files)
        for name in files:
            data=z.read('traffic-recovery-lab/'+name)
            assert data==(ROOT/name).read_bytes() and hashlib.sha256(data).hexdigest()==sha(ROOT/name)
    result={'saved_at_utc':datetime.now(timezone.utc).isoformat(),'archive':str(archive),
        'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'files':len(files),
        'crc_and_all_file_bytes_and_sha256_verified':True,'new_risk_models_trained':12,
        'actual_optimizer_updates':16200,'primary_metric_supported':False,'independent_confirmation':False,
        'public_commit_unchanged':'ab8760a3e6ea1784fea3195a0e7aadbaff6fe80d',
        'full_base_prior_receipt':str(base_receipt),'full_base_crc_rechecked_this_turn':False}
    dump(receipt,result);print(json.dumps(result))


if __name__=='__main__':main()
