"""Two fixed event-end definitions on shared offline evidence support.

Start: three successive speeds <=30mph, backdate to first low sample.
End: one vs TWO successive speeds >30mph, backdate to first high sample.
Convert physical interval [q,h) to proxy span [q,h-2), preserving original
three-reading endpoint convention. Unconfirmed ends stay right censored.
This is an offline label sensitivity, never a changed online policy/target fit.
"""
from datetime import datetime,timezone
from pathlib import Path
import sys
import numpy as np
import torch
import proxy_event_semantics as semantics
import effective_alert_pilot as previous
import calibration_fragility as common
import early_warning_protection as protection
import alarm_start_separability as probe
from complete_bypass_diagnosis import json_native
from congestion_alert_pilot import SCENARIOS,runs
from pems_bay_alert_replay import alarm,replay,layout
from train_pems_bay_risk import load_risk

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs/recovery-definition-sensitivity-2026-10-16'
METHODS=('global_c1','effective_no_bypass',previous.PRIMARY)
DEFINITIONS={'one_high':1,'two_high':2}


def evidence_support(part):
    speed,known,low=semantics.cached_speed(part)
    ids=part['origins'][:,None]+np.arange(3)
    available=known[ids].all(axis=1)
    near_threshold=(np.abs(speed[ids]-30)<=1e-4).any(axis=1)
    support=part['eligible']&available&~near_threshold
    return speed,low,support,{'original_station_day_exposure':float(part['eligible'].sum()/288),
        'shared_station_day_exposure':float(support.sum()/288),
        'original_valid_points':int(part['eligible'].sum()),'shared_valid_points':int(support.sum()),
        'original_eligible_but_future_cache_unknown':int((part['eligible']&~available).sum()),
        'original_eligible_known_but_precision_band':int((part['eligible']&available&near_threshold).sum())}


def recovery_truth(part,support,low,recovery_steps):
    """Offline hysteresis labels; no alarms, predictions, model or score input."""
    if recovery_steps not in (1,2):raise ValueError('Only two predefined definitions')
    truth=np.zeros_like(support);records=[]
    origins=part['origins']
    for seglo,seghi in layout(part)[0]:
        for node in range(support.shape[1]):
            for a,b in runs(support[seglo:seghi,node]):
                lo,hi=int(seglo+a),int(seglo+b);first=int(origins[lo]);last=int(origins[hi-1])+3
                active=False;low_count=0;high_count=0;start=None
                def emit(end,confirmed):
                    proxy_end=end-2 if confirmed else int(origins[hi-1])+1
                    assert proxy_end>start
                    left=int(start-first+lo);right=int(proxy_end-first+lo)
                    truth[max(left,lo):min(right,hi),node]=True
                    records.append({'node':node,'eligible_start_row':lo,'eligible_end_row':hi,
                        'physical_start_origin':start,'first_recovery_high_origin':end if confirmed else None,
                        'recovery_confirmation_origin':end+recovery_steps-1 if confirmed else None,
                        'proxy_start_row':left,'proxy_end_row':right,
                        'proxy_start_origin':start,'proxy_end_origin_exclusive':proxy_end,
                        'end_confirmed':bool(confirmed)})
                for t in range(first,last):
                    is_low=bool(low[t,node])
                    if not active:
                        low_count=low_count+1 if is_low else 0
                        if low_count==3:
                            start=t-2;active=True;high_count=0
                    else:
                        high_count=0 if is_low else high_count+1
                        if high_count==recovery_steps:
                            emit(t-recovery_steps+1,True)
                            active=False;low_count=0;high_count=0;start=None
                if active:emit(last,False)
    return truth,records


def proxy_runs(part,truth,support):
    records=[]
    for seglo,seghi in layout(part)[0]:
        for node in range(truth.shape[1]):
            for a,b in runs(support[seglo:seghi,node]):
                lo,hi=int(seglo+a),int(seglo+b)
                for c,d in runs(truth[lo:hi,node]):
                    s,e=int(lo+c),int(lo+d)
                    records.append({'node':node,'start_row':s,'end_row':e,
                        'event_start_origin':int(part['origins'][s]),
                        'event_end_origin_exclusive':int(part['origins'][e-1])+1,
                        'complete':bool(s-2>=lo and e<hi)})
    return records


def lineage(part,old_truth,new_truth,support):
    assert not np.any(old_truth&support&~new_truth)
    old=proxy_runs(part,old_truth,support);new=proxy_runs(part,new_truth,support)
    mapping=[]
    for e in old:
        matches=[j for j,v in enumerate(new) if v['node']==e['node'] and v['start_row']<=e['start_row'] and e['end_row']<=v['end_row']]
        assert len(matches)==1
        j=matches[0];mapping.append({'old':e,'new_run_index':j,'new':new[j]})
    # Include left/right censored runs in lineage; do not silently ignore them.
    return {'old_runs':old,'new_runs':new,'old_to_new':mapping,
        'old_complete_events':sum(e['complete'] for e in old),'new_complete_events':sum(e['complete'] for e in new),
        'new_runs_with_multiple_old_runs':sum(sum(m['new_run_index']==j for m in mapping)>1 for j in range(len(new))),
        'old_complete_mapped_to_new_censored':sum(m['old']['complete'] and not m['new']['complete'] for m in mapping),
        'old_complete_mapped_to_earlier_start':sum(m['old']['complete'] and m['new']['event_start_origin']<m['old']['event_start_origin'] for m in mapping)}


def freeze_plan():
    OUT.mkdir(exist_ok=True)
    names=['recovery_definition_sensitivity.py','proxy_event_semantics.py','pems_bay_alert_replay.py',
        'congestion_alert_pilot.py','congestion_objective_diagnostic.py','calibration_fragility.py',
        'congestion_risk_pilot.py','alarm_start_separability.py','early_warning_protection.py','train_pems_bay_risk.py',
        'outputs/pems-bay-risk/risk_train.npz','outputs/pems-bay-risk/risk_validation.npz',
        'outputs/pems-bay-risk/global_calibration.pt','outputs/pems-bay-risk/normalization.npz',
        'outputs/pems-bay-calibration/calibration.npz',
        'outputs/effective-alert-pilot-2026-10-16/effective_model.npz',
        'outputs/effective-alert-pilot-2026-10-16/training_freeze.json',
        'outputs/effective-alert-pilot-2026-10-16/activations.npz',
        'outputs/effective-alert-pilot-2026-10-16/results.json',
        'outputs/proxy-event-semantics-2026-10-16/results.json',
        'outputs/bypass-diagnosis-2026-10-16/audited_results.json']
    plan={'stage':'offline_two_high_recovery_event_definition_sensitivity','client_date':'2026-10-16',
        'frozen_at_utc':datetime.now(timezone.utc).isoformat(),
        'question':'Does the protected restart event and fixed-policy comparison persist when an end requires two consecutive high readings?',
        'prior_semantic_diagnosis_informed_question':True,'independent_confirmation':False,
        'allowed':'original train28, reused validation7, reused calibration14 and its halves; no raw/evaluation/station transfer values',
        'fixed_models_and_methods':list(METHODS),'new_models':0,'optimizer_updates':0,'online_policy_changed':False,
        'definitions':{'one_high':'start3consecutive<=30; end1consecutive>30',
            'two_high':'same start3consecutive<=30; end2consecutive>30; isolated high followed by low does not reset active event'},
        'threshold_search':False,'recovery_count_search_beyond_fixed1vs2':False,
        'shared_support':'original eligible AND all3 future cached natural speeds known AND outside30+/-0.0001mph precision band; one shared support for all scenarios/methods/definitions',
        'missing_or_clock_or_eligibility_gap':'reset; cannot join; left/right events explicitly censored',
        'interval_alignment':'physical[q,h) -> proxy[q,h-2) after confirmed recovery; start retroactive first of3 low, end retroactive first of1/2 high; unresolved end extends to support edge and is right censored',
        'one_high_equivalence':'must reproduce old truth on shared support before evaluating alternative',
        'fixed_matching':'old start-only one-to-one/censor/unknown/duplicate rules and old last-history lead convention; only truth/event definition changes in isolated copies',
        'exposure':'same support/exposure; report originalfull vs originalshared effects separately, not as performance improvement',
        'lineage':'map every old proxy run into new superset event, include censored and merged starts',
        'case':'previous bypass-restored originalR10 cases only; link to earlier/merged new event and fixed method status',
        'no_candidate_acceptance_or_rewrite':'old thesis/candidate failures and labels unchanged; no policy or definition selected on metrics',
        'outputs_private':True,'source_and_input_sha256':{n:common.sha(ROOT/n) for n in names}}
    if (OUT/'plan.json').exists():raise FileExistsError('Preserve frozen sensitivity plan')
    common.write(OUT/'plan.json',plan);return plan


def main():
    sys.addaudithook(protection.guard);torch.set_num_threads(1);plan=freeze_plan()
    seal=common.read(previous.OUT/'training_freeze.json')
    assert common.sha(previous.OUT/'effective_model.npz')==seal['model_sha256']
    model=common.load(previous.OUT/'effective_model.npz');norm=common.load(common.RISK/'normalization.npz')
    anchor=load_risk(common.RISK/'global_calibration.pt')
    parts={'training28':common.load(common.RISK/'risk_train.npz'),
        'risk_validation7':common.load(common.RISK/'risk_validation.npz'),
        'calibration_full14':common.load(common.CAL/'calibration.npz')}
    parts.update({'calibration_week1_7':common.subset(parts['calibration_full14'],0,7),
        'calibration_week2_7':common.subset(parts['calibration_full14'],7,14)})
    old=common.read(previous.OUT/'results.json');old_active=common.load(previous.OUT/'activations.npz')
    previous_diag=common.read(ROOT/'outputs/proxy-event-semantics-2026-10-16/results.json')
    bypass=common.read(ROOT/'outputs/bypass-diagnosis-2026-10-16/audited_results.json')
    blocks={};arrays={};dailies={}
    for block,part in parts.items():
        speed,low,support,info=evidence_support(part)
        labels={};physical={}
        for name,k in DEFINITIONS.items():labels[name],physical[name]=recovery_truth(part,support,low,k)
        np.testing.assert_array_equal(labels['one_high'][support],part['truth'][support])
        assert not np.any(labels['one_high']&~labels['two_high'])
        link=lineage(part,labels['one_high'],labels['two_high'],support)
        arrays[block+'__support']=support
        for name,v in labels.items():arrays[block+'__'+name]=v
        scores=common.global_scores(part,norm,anchor)
        blocks[block]={'shared_evidence':info,'physical_records':physical,'lineage':link,
            'original_full':{},'shared_evaluation':{name:{} for name in DEFINITIONS},'case_lineage':{}}
        for scenario in SCENARIOS:
            p=scores[scenario]
            cred=probe.predict(model,probe.start_features(part,scenario,p).reshape(-1,30)).reshape(part['truth'].shape)
            choices={'global_c1':alarm(p,.46,1,part),
                'effective_no_bypass':protection.episode_gate(p,cred,part['origins'],part['timestamps'],seal['cutoff']),
                previous.PRIMARY:protection.episode_gate(p,cred,part['origins'],part['timestamps'],seal['cutoff'],protection.observed_past_low(part,scenario))}
            blocks[block]['original_full'][scenario]={}
            for method,bits in choices.items():
                row,_,_=replay(part,bits,details=True)
                assert row==previous_diag['blocks'][block]['scenarios'][scenario][method]['operating']
                if block!='training28':
                    assert row==old['evaluation'][block][method][scenario]
                    np.testing.assert_array_equal(bits,old_active[f'{block}__{method}__{scenario}'])
                blocks[block]['original_full'][scenario][method]=row
            event_maps={}
            for definition,truth in labels.items():
                local={**part,'eligible':support,'truth':truth};event_maps[definition]={}
                blocks[block]['shared_evaluation'][definition][scenario]={}
                for method,bits in choices.items():
                    row,days,events=replay(local,bits,details=True)
                    assert int(row['events'])==link['old_complete_events' if definition=='one_high' else 'new_complete_events']
                    blocks[block]['shared_evaluation'][definition][scenario][method]={'operating':row,'event_records':events,
                        'episode_records':common.episodes(local,bits)}
                    event_maps[definition][method]={(e['node'],e['event_start_origin']):e for e in events}
                    dailies[f'{block}__{definition}__{scenario}__{method}']=days
            cases=[]
            for case in bypass['blocks'][block][scenario]['changed_events']:
                if not case['restored_original_R10_identity_and_lead']:continue
                key=(case['node'],case['event_start_origin'])
                mapping=[v for v in link['old_to_new'] if v['old']['node']==key[0] and v['old']['event_start_origin']==key[1]]
                if not mapping:
                    cases.append({'original_node_event_key':list(key),'on_shared_support':False});continue
                m=mapping[0];newkey=(key[0],m['new']['event_start_origin'])
                cases.append({'original_node_event_key':list(key),'on_shared_support':True,'old_run':m['old'],'new_run':m['new'],
                    'one_high_methods':{method:event_maps['one_high'][method].get(key) for method in METHODS},
                    'two_high_methods':{method:event_maps['two_high'][method].get(newkey) for method in METHODS}})
            blocks[block]['case_lineage'][scenario]=cases
        print(block+': '+str({'support':info,'event_counts':(link['old_complete_events'],link['new_complete_events']),
            'merged_runs':link['new_runs_with_multiple_old_runs'],
            'means':{d:{m:common.mean_metrics({s:rows[s][m]['operating'] for s in SCENARIOS}) for m in METHODS} for d,rows in blocks[block]['shared_evaluation'].items()}}),flush=True)
    result={'blocks':blocks,'model_sha256':seal['model_sha256'],'cutoff':seal['cutoff'],
        'new_models_fitted':0,'optimizer_updates':0,'online_policy_changed':False,'original_labels_changed':False,
        'alternative_truth_used_offline_only':True,'independent_confirmation':False,'definition_selected_on_results':False,
        'original_thesis_primary_test_still_failed':True,'previous_candidate_acceptance_passed':old['primary_acceptance_passed'],
        'new_station_cohort_consumed':False,'consumed_transfer_values_used':False,'new_acceptance_test_performed':False}
    common.write(OUT/'results.json',json_native(result))
    np.savez_compressed(OUT/'shared_labels.npz',**arrays);np.savez_compressed(OUT/'daily.npz',**dailies)
    for n,h in plan['source_and_input_sha256'].items():assert common.sha(ROOT/n)==h,n
    common.write(OUT/'access_log.json',{'runtime_output_paths':sorted(set(common.READS)),
        'forbidden_values_used':False,'runtime_guard_enabled':True})
    common.write(OUT/'completion.json',{'completed_at_utc':datetime.now(timezone.utc).isoformat(),
        'plan_sha256':common.sha(OUT/'plan.json'),
        'artifacts':{n:common.sha(OUT/n) for n in ['results.json','shared_labels.npz','daily.npz','access_log.json']}})


if __name__=='__main__':main()
