"""Chronological development probe of credited warning versus false alarm starts.

Probe labels use the frozen offline scorer; feature extraction never reads labels.
This conditional discrimination task excludes late/duplicate/censored/unknown
starts and is not an evaluated alarm-filtering policy or independent test.
"""
from __future__ import annotations
from datetime import datetime,timezone
from pathlib import Path
import sys
import numpy as np
import torch
import calibration_fragility as common
from congestion_alert_pilot import SCENARIOS
from pems_bay_alert_replay import alarm,replay
from train_pems_bay_risk import load_risk

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs/alarm-start-separability-2026-10-15'
KEEP=np.r_[0:24,48:51]
ALPHA=.1
METHODS={'score_logistic':[29],'residual_logistic':[27,28],'state_logistic':list(range(30))}
FEATURE_NAMES=['forecast5','forecast10','forecast15','seed_std5','seed_std10','seed_std15','forecast_max','forecast_range',
    'own_last','own_mean','own_trend','own_std','own_coverage','own_age','own_low_fraction',
    'neighbor_last','neighbor_mean','neighbor_trend','neighbor_std','neighbor_coverage',
    'calendar0','calendar1','calendar2','calendar3','network_coverage','own_unavailable','own_partial',
    'past_residual_clipped_mph','past_residual_missing','frozen_global_logit']


def start_features(part,scenario,probabilities):
    """Only historical/predicted state and a causal past residual; no future targets."""
    state=part[scenario+'_state'];residual=common.causal_residual(part,scenario)
    available=np.isfinite(residual)
    p=np.clip(probabilities.astype(np.float64),1e-9,1-1e-9)
    result=np.concatenate((state[:,:,KEEP].astype(np.float64),
        np.where(available,np.clip(residual,-20,20),0)[:,:,None],
        (~available).astype(float)[:,:,None],np.log(p/(1-p))[:,:,None]),axis=-1)
    assert result.shape[-1]==30 and np.isfinite(result).all()
    return result


def build_samples(part,probabilities):
    data={};excluded={}
    for scenario in SCENARIOS:
        active=alarm(probabilities[scenario],.46,1,part)
        _,_,truth_events=replay(part,active,details=True)
        warning_map={(rec['node'],rec['alarm_start_origin']):rec for rec in truth_events if rec['status']=='warned'}
        episodes=common.episodes(part,active)
        chosen=[rec for rec in episodes if rec['kind'] in ('false','warned')]
        excluded[scenario]={kind:sum(rec['kind']==kind for rec in episodes) for kind in ('false','warned','late','duplicate','censored','unknown')}
        rows=np.array([rec['row'] for rec in chosen],int);nodes=np.array([rec['node'] for rec in chosen],int)
        y=np.array([rec['kind']=='warned' for rec in chosen],np.int8)
        leads=[];event_origins=[]
        for rec in chosen:
            event=warning_map[(rec['node'],int(part['origins'][rec['row']]))] if rec['kind']=='warned' else None
            leads.append(int(event['lead_minutes']) if event else -1)
            event_origins.append(int(event['event_start_origin']) if event else -1)
        timestamps=part['timestamps'][part['origins'][rows]]
        data[scenario]={'x':start_features(part,scenario,probabilities[scenario])[rows,nodes],
            'y':y,'lead_minutes':np.array(leads,int),'node':nodes,'row':rows,
            'origin':part['origins'][rows],'event_origin':np.array(event_origins,int),
            'date':timestamps.astype('datetime64[D]').astype(str),
            'timestamp':timestamps.astype(str),'global_probability':probabilities[scenario][rows,nodes].astype(float)}
        assert int(y.sum())==excluded[scenario]['warned']
        assert len(y)-int(y.sum())==excluded[scenario]['false']
    return data,excluded


def binary_metrics(y,p):
    y=np.asarray(y,dtype=bool);p=np.asarray(p,dtype=float)
    n=len(y);pos=int(y.sum());neg=n-pos
    auc=None
    if pos and neg:
        a=p[y][:,None];b=p[~y][None,:]
        auc=float(np.mean((a>b).astype(float)+.5*(a==b)))
    ap=None
    if pos:
        order=np.argsort(-p,kind='stable');sorted_y=y[order];sorted_p=p[order]
        ends=np.r_[np.flatnonzero(np.diff(sorted_p)!=0),n-1]
        tp=np.cumsum(sorted_y)[ends];precision=tp/(ends+1)
        ap=float(np.sum(np.diff(np.r_[0,tp])/pos*precision))
    clipped=np.clip(p,1e-12,1-1e-12);target=y.astype(float)
    return {'rows':n,'credited_warnings':pos,'false_starts':neg,
        'positive_fraction':pos/n if n else None,'roc_auc':auc,'average_precision':ap,
        'brier':float(np.mean((p-y)**2)) if n else None,
        'bce':float(np.mean(-target*np.log(clipped)-(1-target)*np.log1p(-clipped))) if n else None}


def fit_probe(x,y,indices):
    x=x[:,indices]
    mean=x.mean(axis=0);std=np.maximum(x.std(axis=0),1e-3)
    z=(x-mean)/std
    xt=torch.tensor(z,dtype=torch.float64);yt=torch.tensor(y,dtype=torch.float64)
    layer=torch.nn.Linear(len(indices),1,dtype=torch.float64)
    with torch.no_grad():
        layer.weight.zero_();layer.bias.fill_(float(np.log(y.mean()/(1-y.mean()))))
    optimizer=torch.optim.LBFGS(layer.parameters(),lr=1.,max_iter=500,max_eval=1000,
        tolerance_grad=1e-10,tolerance_change=1e-13,line_search_fn='strong_wolfe')
    calls=0
    def closure():
        nonlocal calls
        calls+=1;optimizer.zero_grad(set_to_none=True)
        loss=torch.nn.functional.binary_cross_entropy_with_logits(layer(xt).squeeze(-1),yt)+ALPHA/2*layer.weight.square().sum()
        loss.backward();return loss
    optimizer.step(closure);loss=float(closure().detach())
    gradient=float(max(p.grad.abs().max().item() for p in layer.parameters()))
    if gradient>1e-6:raise ValueError('Fixed probe solver not converged; retain failed artifacts, do not tune')
    result={'indices':indices,'mean':mean,'std':std,'weight':layer.weight.detach().numpy().reshape(-1),'bias':layer.bias.detach().numpy()}
    return result,{'dimension':len(indices),'parameters':len(indices)+1,'alpha':ALPHA,
        'solver':'LBFGS_float64_fixed_penalty','optimizer_step_calls':1,
        'closure_evaluations':calls,'LBFGS_iterations':int(optimizer.state[layer.weight]['n_iter']),
        'objective':loss,'max_abs_gradient':gradient,'training_rows':len(y),
        'training_credited_warnings':int(y.sum()),'validation_used_for_fitting_or_selection':False}


def predict(model,x):
    z=(x[:,model['indices']]-model['mean'])/model['std']
    logits=z@model['weight']+float(model['bias'][0])
    return 1/(1+np.exp(-np.clip(logits,-50,50)))


def retention_threshold(y,p):
    """Largest empirical cutoff keeping >=95% training credited warnings."""
    positive=np.sort(p[np.asarray(y,dtype=bool)])
    if not len(positive):raise ValueError('No positive training examples')
    allowed_losses=int(np.floor(.05*len(positive)+1e-12))
    return float(positive[allowed_losses])


def retention_metrics(samples,p,threshold):
    keep=p>=threshold;y=samples['y'].astype(bool);ten=y&(samples['lead_minutes']>=10)
    ratio=lambda count,den:float(count/den) if den else None
    return {'threshold_frozen_on_training':threshold,
        'credited_warnings_retained':ratio((keep&y).sum(),y.sum()),
        'false_starts_rejected':ratio((~keep&~y).sum(),(~y).sum()),
        'R10_credited_starts_retained':ratio((keep&ten).sum(),ten.sum()),
        'alarm_service_effect_measured':False}


def separation_gate(blocks):
    checks={}
    baselines=('fixed_risk','score_logistic','residual_logistic')
    for name,methods in blocks.items():
        state=methods['state_logistic'];base=[methods[m] for m in baselines]
        defined=all(v['roc_auc'] is not None and v['average_precision'] is not None for v in [state]+base)
        enough=state['credited_warnings']>=10 and state['false_starts']>=10
        best_auc=max(v['roc_auc'] for v in base) if defined else None
        best_ap=max(v['average_precision'] for v in base) if defined else None
        checks[name]={'sufficient_class_counts':enough,'defined':defined,
            'roc_auc_at_least0_70':bool(defined and state['roc_auc']>=.70),
            'roc_auc_gain_at_least0_05_vs_baseline_envelope':bool(defined and state['roc_auc']>=best_auc+.05-1e-12),
            'AP_not_below_baseline_envelope':bool(defined and state['average_precision']>=best_ap-1e-12),
            'strongest_baseline_auc':best_auc,'strongest_baseline_AP':best_ap}
    return {'passed':all(all(v[k] for k in ('sufficient_class_counts','defined','roc_auc_at_least0_70','roc_auc_gain_at_least0_05_vs_baseline_envelope','AP_not_below_baseline_envelope')) for v in checks.values()),
        'by_natural_scenario_block':checks,'not_an_alarm_policy_acceptance':True}


def freeze_plan():
    OUT.mkdir(exist_ok=True)
    names=['alarm_start_separability.py','calibration_fragility.py','pems_bay_alert_replay.py',
        'congestion_alert_pilot.py','congestion_risk_pilot.py','train_pems_bay_risk.py',
        'outputs/pems-bay-risk/risk_train.npz','outputs/pems-bay-risk/risk_validation.npz',
        'outputs/pems-bay-risk/normalization.npz','outputs/pems-bay-risk/global_calibration.pt',
        'outputs/pems-bay-calibration/calibration.npz','outputs/pems-bay-calibration/selection.json']
    plan={'stage':'adaptive_chronological_development_start_separability_probe',
        'prior_failed_rules_informed_question':True,'external_independent_confirmation':False,
        'unit':'frozen global_c1 alarm starts; credited warned versus false only; late/duplicate/censored/unknown excluded by offline labels',
        'positive':'credited warning with proxy lead5/10/15min','negative':'false episode under frozen start-matching scorer',
        'fit_partition':'original24 risk_train28days; pool all3 scenarios equally, not3 independent populations',
        'checks_in_chronological_order':['risk_validation7','calibration_week1_7','calibration_week2_7'],
        'all_check_blocks_previously_used_in_development':True,
        'no_random_split_or_cross_partition_windows':True,'train_global_risk_previously_fitted_on_risk_train':True,
        'features':FEATURE_NAMES,'explicit_station_identity_excluded':True,
        'residual':'prior one-step forecast minus fresh previous observation; clipped[-20,20]mph; missing->0 plus flag',
        'methods':METHODS,'baselines':['constant_training_prior','fixed_global_risk','score_logistic','residual_logistic'],
        'fit':'float64 ridge logistic, alpha0.1, training-only normalization, no regularization/model search, convergence required',
        'frozen_retention_cutoff':'each fitted probe cutoff maximizes threshold retaining>=95% training credited warnings; no later block tuning',
        'metrics':'tie-correct ROC AUC and grouped-threshold average precision; conditional class retention is not a replayed policy gain',
        'uncertainty':'point diagnostic gate only, no significance claim; class counts and per-block/per-scenario outcomes must be reported',
        'natural_scenario_diagnostic_gate':'each later block>=10 positives and10 negatives; state AUC>=0.70 and>=max(fixed risk,score probe,residual probe)+0.05; AP>=their best AP',
        'baseline_envelope':'diagnostic hindsight upper envelope per metric only, not an executable selected baseline',
        'fault_scenarios':'report separately; not independent confirmation or data for tuning',
        'on_failure':'stop proposed rule tuning, keep outcomes, no fresh station test or alternate probe',
        'on_pass':'only a development information signal; must evaluate all alarm types in a separately frozen downstream policy and new validation',
        'no_new_deep_network_training':True,'new_station_values_used':False,
        'source_and_input_sha256':{n:common.sha(ROOT/n) for n in names}}
    path=OUT/'plan.json'
    if path.exists():assert {k:v for k,v in common.read(path).items() if k!='frozen_at_utc'}==plan
    else:common.write(path,{**plan,'frozen_at_utc':datetime.now(timezone.utc).isoformat()})
    return plan


def main():
    sys.addaudithook(common.guard)
    torch.set_num_threads(1);torch.use_deterministic_algorithms(True);plan=freeze_plan()
    if (OUT/'completion.json').exists():
        for n,h in common.read(OUT/'completion.json')['artifacts'].items():assert common.sha(OUT/n)==h
        print('Completed probe verified; no refit');return
    norm=common.load(common.RISK/'normalization.npz');anchor=load_risk(common.RISK/'global_calibration.pt')
    tr=common.load(common.RISK/'risk_train.npz')
    train,train_excluded=build_samples(tr,common.global_scores(tr,norm,anchor))
    xx=np.concatenate([v['x'] for v in train.values()]);yy=np.concatenate([v['y'] for v in train.values()]).astype(float)
    if len(np.unique(yy))!=2:raise ValueError('Training task has only one class; no substitutions')
    packed_train={k:np.concatenate([v[k] for v in train.values()]) for k in train['natural']}
    models={};logs={};cutoffs={};artifacts=[]
    for name,indices in METHODS.items():
        models[name],logs[name]=fit_probe(xx,yy,indices)
        pred=predict(models[name],xx);cutoffs[name]=retention_threshold(yy,pred)
        path=OUT/(name+'.npz');np.savez_compressed(path,**models[name]);artifacts.append(path.name)
        print(name+': '+str(logs[name]),flush=True)
    common.write(OUT/'training.json',{'logs':logs,'cutoffs':cutoffs,'training_class_counts':{s:binary_metrics(v['y'],np.full(len(v['y']),yy.mean())) for s,v in train.items()},
        'excluded_episode_counts':train_excluded,'no_later_block_values_used':True})
    common.write(OUT/'training_freeze.json',{'frozen_at_utc':datetime.now(timezone.utc).isoformat(),
        'plan_sha256':common.sha(OUT/'plan.json'),'weights':{n:common.sha(OUT/n) for n in artifacts},
        'cutoffs':cutoffs,'later_check_blocks_loaded':False})
    # Do not load later block feature/label values until all three probes are fixed.
    val=common.load(common.RISK/'risk_validation.npz');cal=common.load(common.CAL/'calibration.npz')
    blocks={'risk_validation7':val,'calibration_week1_7':common.subset(cal,0,7),'calibration_week2_7':common.subset(cal,7,14)}
    metrics={};retention={};counts={};samples={};predictions={}
    for block,part in blocks.items():
        data,excluded=build_samples(part,common.global_scores(part,norm,anchor));counts[block]=excluded
        metrics[block]={};retention[block]={}
        for s,rows in data.items():
            samples[block+'__'+s]=rows
            probabilities={'constant_prior':np.full(len(rows['y']),yy.mean()),'fixed_risk':rows['global_probability'],
                **{name:predict(model,rows['x']) for name,model in models.items()}}
            metrics[block][s]={name:binary_metrics(rows['y'],p) for name,p in probabilities.items()}
            retention[block][s]={name:retention_metrics(rows,probabilities[name],cutoffs[name]) for name in models}
            for name,p in probabilities.items():predictions[f'{block}__{s}__{name}']=p
        print(block+': '+str({m:(v['rows'],v['roc_auc'],v['average_precision']) for m,v in metrics[block]['natural'].items()}),flush=True)
    gate=separation_gate({b:rows['natural'] for b,rows in metrics.items()})
    result={'stage':'chronological_development_start_separability','metrics':metrics,'retention':retention,
        'excluded_episode_counts':counts,'natural_diagnostic_gate':gate,
        'independent_confirmation':False,'new_alarm_policy_evaluated':False,'new_station_cohort_consumed':False,
        'original_thesis_primary_test_still_failed':True,
        'limitation':'Conditional alarm-start task excludes late/duplicate/unknown/censored starts; all later blocks previously reused. Discrimination/retention are not actual alarm-service improvements.'}
    common.write(OUT/'results.json',result)
    for tag,rows in {'training_pooled':packed_train,**samples}.items():
        path=OUT/(tag+'_samples.npz');np.savez_compressed(path,**rows);artifacts.append(path.name)
    np.savez_compressed(OUT/'predictions.npz',**predictions);artifacts.append('predictions.npz')
    common.write(OUT/'access_log.json',{'runtime_open_paths':sorted(set(common.READS)),
        'evaluation_and_raw_hdf5_guard_enabled':True,'evaluation_or_raw_hdf5_values_used':False})
    common.write(OUT/'result_freeze.json',{'frozen_at_utc':datetime.now(timezone.utc).isoformat(),
        'plan_sha256':common.sha(OUT/'plan.json'),'training_freeze_sha256':common.sha(OUT/'training_freeze.json'),
        'results_sha256':common.sha(OUT/'results.json'),'new_alarm_policy_accepted':False})
    for n,h in plan['source_and_input_sha256'].items():assert common.sha(ROOT/n)==h,n
    artifacts+=['training.json','training_freeze.json','results.json','access_log.json','result_freeze.json']
    common.write(OUT/'completion.json',{'completed_at_utc':datetime.now(timezone.utc).isoformat(),
        'plan_sha256':common.sha(OUT/'plan.json'),'artifacts':{n:common.sha(OUT/n) for n in artifacts}})
    print({'development_diagnostic_gate':gate,'new_alarm_policy_accepted':False},flush=True)


if __name__=='__main__':main()
