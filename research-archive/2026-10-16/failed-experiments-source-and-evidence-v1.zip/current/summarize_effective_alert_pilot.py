"""Report expanded effective-alert training and the remaining failed service gate."""
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
import effective_alert_pilot as pilot
import calibration_fragility as common
ROOT=pilot.ROOT;OUT=pilot.OUT
def pct(v):return '不可计算' if v is None else f'{100*v:.2f}%'


def main():
    r=common.read(OUT/'results.json');audit=common.read(OUT/'audit.json')
    assert audit['passed'] and not r['primary_acceptance_passed']
    common.write(OUT/'test_receipt.json',{'recorded_at_utc':datetime.now(timezone.utc).isoformat(),
        'client_date':'2026-10-16','tests_run':7,'observed_exit_code':0,'passed':True,
        'command':'.venv/Scripts/python.exe -m unittest discover -s tests -p test_effective_alert_pilot.py -v',
        'basis':'Observed successful tool output before real training and replay; no repeat execution by report generator',
        'initial_fixture_note':'Before real pilot, fixed test-only Unicode array width that truncated warned to warn. Scientific sample builder and fitting implementation unchanged.',
        'test_source_sha256':common.sha(ROOT/'tests/test_effective_alert_pilot.py')})
    diagnoses=common.read(OUT/'matched_event_diagnosis.json')
    full=r['means']['calibration_full14'];baseline=full['global_c1'];old=full['old_warning_protected'];main=full[pilot.PRIMARY]
    reduction=1-main['false_per_valid_station_day']/baseline['false_per_valid_station_day']
    methods={'global_c1':'原全局一次确认','old_warning_protected':'上轮只训练预警的保护方案',
        'effective_no_bypass':'新有效告警模型，无低速豁免',pilot.PRIMARY:'主方案：新有效告警模型+原豁免'}
    lines=['# 补齐迟报正例：检出损失改善，但开发验收仍未通过','',
        '日期：2026-10-16。**将有检出价值的迟報纳入正例后，14日校准检出率由上轮81.64%提高到85.99%，原R10事件及提前量保持；但误报减少仅5.88%，部分短块检出仍损失过多，联合条件未通过。**','',
        '## 本轮补了什么','',
        '上一轮训练只含获记提前预警与误報，却在完整告警策略中也过滤迟報。新训练正例为原固定全局0.46/c1被评分器获记的预警或迟報，负例为误報起点。重复、删失、不可判断仍不作训练标签；它们全部参与后续完整回放，不能忽略服务影响。','',
        '特征仍是30项历史/预测/邻站/日历/可用率信息及可观测过去一步残差，无站点编号、未来真值、事件时长、提前量、告警类型或之后持续多久。原深度车速预测前端与全局风险头均保持。','',
        '新模型只有31个参数，PyTorch float64 L2逻辑回归，惩罚0.1固定、LBFGS求解。沿用旧模型训练专用均值和尺度，未重新标准化，未搜索结构、惩罚或模型。标签范围扩大同时带来更多训练样本；不能把差异称为纯粹隔离的标签因果效应。','',
        '## 训练与参数封存','',
        '只用原风险训练28日，共800条情景记录：147条获记预警、350条迟報、303条误報，497条有效告警正例。不同情景相关，只有298个不同(node, alarm_origin)键，不能当800个独立事件。原全局风险模型本身也曾在该训练段拟合，训练成绩不作泛化证据。','',
        f"分界线只按训练集确定：至少保留95%有效正例的最高分界线为{r['cutoff']['training95pct_effective_cutoff']:.15f}；原84条R10训练记录的最低分为{r['cutoff']['training_R10_minimum_probability']:.15f}。取两者较小值{r['cutoff']['protected_cutoff']:.15f}，实际保留95.17%训练有效正例及全部原R10训练记录。新旧分数对应不同目标，分界线数值不能直接比较成“更严格/更宽松”。",'',
        '模型、参数、归一化、训练样本与分界线写入training_freeze后，才加载风险验证7日及校准14日进行本轮回放。所有这些开发块此前已被项目使用，且过去跨站失败影响了问题选择，不能当独立确认。程序拒绝原评测、迁移/跨站结果缓存和原HDF5，本轮没有读取新或已消耗站点的值。','',
        '在线原风险阳性段起点只判断一次；通过分界线则保留整个原段，否则拒绝整段，不中途重进。主方案继续用原最近三条新鲜观测持续≤30 mph的豁免；不读未来有效性或标签。预定无豁免对照不允许替换失败的主方案。','',
        '## 原验收条件保持','',
        '仍需每个时间范围、每种情景误報不增、R10不降、检出下降不超过2个百分点；逐事件保留原R10身份及其原提前量。完整14日还须平均误報至少减少10%、逐情景在原预算内。没有因改善了一部分损失而放宽条件，也不声称通过原论文主检验或早先+2pp R10目标。','',
        '## 完整校准14日','',
        '69个完整低速代理事件，三种情景共享事件，下表为三情景等权平均。','',
        '| 方法 | R10 | 含迟報检出 | 误報/有效站日 |',
        '| --- | ---: | ---: | ---: |']
    for name,label in methods.items():
        m=full[name];lines.append(f"| {label} | {pct(m['warning_recall_at_least10'])} | {pct(m['detection_recall'])} | {m['false_per_valid_station_day']:.6f} |")
    lines+=['',f"主方案相对上轮检出提高{100*(main['detection_recall']-old['detection_recall']):.2f}个百分点；相对原全局仍低{100*(baseline['detection_recall']-main['detection_recall']):.2f}个百分点。误報仅减少{100*reduction:.2f}%，未达10%，并略高于上轮主方案。不能只突出检出恢复而说所有指标都改善。",'',
        '## 时间块与原早预警','',
        '| 时间块 | 原→新检出 | 原→新R10 | 原→新误報 | 主方案块内服务约束 | 原早期身份与提前量 |',
        '| --- | --- | --- | --- | --- | --- |']
    for block,rows in r['means'].items():
        a=rows['global_c1'];b=rows[pilot.PRIMARY];g=r['gates'][pilot.PRIMARY]
        lines.append(f"| {block} | {pct(a['detection_recall'])}→{pct(b['detection_recall'])} | {pct(a['warning_recall_at_least10'])}→{pct(b['warning_recall_at_least10'])} | {a['false_per_valid_station_day']:.6f}→{b['false_per_valid_station_day']:.6f} | {'通过' if g['service_block_checks'][block]['passed'] else '未通过'} | {'保持' if g['original_early_event_identity_and_lead_preserved'][block] else '丢失/延后'} |")
    lines+=['',
        '校准前7日每个情景少检出1/37事件，即2.70个百分点，超过2个百分点下限；风险验证自然情景少检出2/55事件，即3.64个百分点。平均值接近达标不能掩盖某情景超限。短块事件少，一次漏检就可能超过门槛；此处如实报告，不把离散性当放宽规则的理由。','',
        '完整14日包含其前后子块，不计为更多独立样本。原校准前周没有R10预警，保护在该周是无正例的空约束，不能作强保证。其余原R10事件与原代理提前量全部保持。','',
        '## 剩余漏检与对照','',
        '| 时间块 | 自然：原迟報→漏检 | 单站缺失 | 成组缺失 |',
        '| --- | ---: | ---: | ---: |']
    for block,scenes in diagnoses.items():
        values=[str(scenes[s]['newly_missed_by_original_status']['late']) for s in ('natural','single_outage','group_outage')]
        lines.append(f"| {block} | {' | '.join(values)} |")
    lines+=['',
        '本轮新增漏检仍全部来自原迟報，未丢失原获记预警。完整14日由上轮每情景新增4个迟報漏检减少到1个；补入迟報训练与损失恢复相符，但不能证明目标范围是唯一原因，也不能保证跨站改善。','',
        '无低速豁免对照在完整14日减少约11.76%误報，保住该段早期预警且检出仅低1.45个百分点；但风险验证块各情景损失1条原R10预警，并且检出也不足。它没有通过跨块联合要求，没有被替换成主方案。低速豁免有保护作用，也会保留一些误報；不能只挑较有利的一段或一个对照作为最终成绩。','',
        '## 配对日期的描述区间','',
        '14日2000次共同按日期抽样，种子20261016，条件于固定模型和已重复使用开发数据；不包括模型拟合、跨站/跨网不确定性。','',
        '| 主方案−原全局 | 点差 | 95%描述区间 |',
        '| --- | ---: | --- |']
    for metric,mult in [('R10',100),('detection',100),('false_rate',1)]:
        row=r['paired_calibration_comparisons'][pilot.PRIMARY][metric];ci=row['ci95']
        lines.append(f"| {metric}{'（百分点）' if mult==100 else ''} | {row['difference']*mult:+.4f} | [{ci[0]*mult:.4f}, {ci[1]*mult:.4f}] |")
    lines+=['','区间到0，不声称新的确认性优势。原论文主检验失败状态仍然保留。','',
        '## 工程核查与后续','',
        '7项针对性测试在真实训练前通过：预警/迟報正例、误報负例及排除类型，标签/身份不进入特征，原归一化固定、求解收敛、无早预警不可行及训练专用保护分界线、禁止评测和迁移访问。独立核查重建800训练记录、标签、目标梯度和分界线，按连续原风险段重建36组过滤、核对48组完整回放与逐事件保护，配对计数由另一实现核对。','',
        '一份31参数新线性模型已保存，原深度前端、原风险/旧判别器不覆盖。论文、Word/PPT和GitHub v7保持。本轮全部结果、失败对照和误差明细只本地保存，没有进入任何站点测试。','',
        '下一轮若继续，先分析低速豁免保留的误報与它保护的真实预警在当时已有信息下能否区分，保持本轮模型和分界线固定作诊断；不要看到这次结果就增加候选或改门槛。后续任何新策略仍须单独冻结并完整回放，新确认数据需要另外安排。本轮尚未执行该豁免误差诊断。','']
    (OUT/'report.zh-CN.md').write_text('\n'.join(lines),encoding='utf-8')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    chosen=['global_c1','old_warning_protected','effective_no_bypass',pilot.PRIMARY]
    fig,axes=plt.subplots(1,3,figsize=(13,4.7),facecolor='#f5f8fa')
    for ax,(metric,title,mult) in zip(axes,[('warning_recall_at_least10','Proxy warning >=10 min (%)',100),('detection_recall','Detection incl. late (%)',100),('false_per_valid_station_day','False alerts / valid station-day',1)]):
        vals=[full[m][metric]*mult for m in chosen]
        bars=ax.bar(range(4),vals,width=.65,color=['#8297ab','#b6a1a6','#bdac70','#137c83'])
        ax.set_xticks(range(4),['Original','Old target','New / no bypass','New primary'],fontsize=8)
        ax.set_ylim(0,100 if metric=='detection_recall' else max(vals)*1.35)
        ax.set_title(title,fontsize=10);ax.spines[['top','right']].set_visible(False)
        for bar,value in zip(bars,vals):ax.text(bar.get_x()+bar.get_width()/2,bar.get_height(),f'{value:.2f}' if mult==100 else f'{value:.3f}',ha='center',va='bottom',fontsize=9)
    fig.suptitle('Include late detections: partial recovery, joint development screen still FAILED',fontsize=12)
    fig.text(.5,.025,'Reused original development calibration / 69 shared proxy events. Other time blocks fail; no station test.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.08,1,.91));fig.savefig(OUT/'comparison.png',dpi=150);plt.close(fig)
    print({'report':str(OUT/'report.zh-CN.md'),'tests_observed_passed':7,'primary_passed':False})


if __name__=='__main__':main()
