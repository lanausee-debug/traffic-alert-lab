"""Independent arithmetic/source audit; replays synthetic and weekly selections."""
from datetime import datetime,timezone
import io
from pathlib import Path
import unittest
import numpy as np
import torch
import calibration_fragility as d
from congestion_alert_pilot import SCENARIOS
from pems_bay_alert_replay import alarm,replay
from train_pems_bay_risk import load_risk
from improve_alert_recall import select

ROOT=d.ROOT;OUT=d.OUT


def main():
    torch.set_num_threads(1)
    plan=d.read(OUT/'plan.json');result=d.read(OUT/'results.json');done=d.read(OUT/'completion.json')
    assert done['plan_sha256']==d.sha(OUT/'plan.json')
    for name,digest in plan['source_and_input_sha256'].items():assert d.sha(ROOT/name)==digest,name
    for name,digest in done['artifacts'].items():assert d.sha(OUT/name)==digest,name
    repair=d.read(OUT/'serialization_recovery.json')
    assert repair['source_sha256']==d.sha(ROOT/'complete_calibration_fragility.py')
    for name,digest in repair['partial_artifacts_preserved_sha256'].items():assert d.sha(OUT/name)==digest
    assert d.read(OUT/'serialization_recovery_audit.json')['passed']
    assert not result['new_method_accepted'] and not result['new_station_cohort_consumed']
    assert not result['actual_cross_station_failure_cause_established']
    norm=d.load(d.RISK/'normalization.npz');model=load_risk(d.RISK/'global_calibration.pt')
    setting=result['equivalence']['threshold'];records=d.read(OUT/'episode_records.json')
    daily=d.load(OUT/'fixed_daily.npz')
    parts={name:d.load(path) for name,path in [('risk_validation',d.RISK/'risk_validation.npz'),('calibration',d.CAL/'calibration.npz')]}
    for name,part in parts.items():
        probabilities=d.global_scores(part,norm,model)
        for s in SCENARIOS:
            row=result['partitions'][name]['by_scenario'][s]['operating']
            counts=daily[name+'__'+s].sum(axis=0)
            assert np.isclose(counts[0],row['exposure']) and counts[1]==row['events']
            assert counts[4]==row['false'] and counts[3]==row['detected']
            assert np.isclose((counts[11]+counts[12])/counts[1],row['warning_recall_at_least10'])
            assert records[name+'__'+s]==d.episodes(part,alarm(probabilities[s],setting['threshold'],setting['confirmation'],part))
            analytic=part[s+'_state'][:,:,6]*70<=result['equivalence']['equivalent_max_three_horizon_ensemble_speed_cutoff_mph']
            np.testing.assert_array_equal(analytic,alarm(probabilities[s],setting['threshold'],1,part))
            summary=result['partitions'][name]['by_scenario'][s]
            assert summary['point_probability']==d.probability_summary(part,probabilities[s])
            for key in ('by_own_history_availability','by_available_past_residual'):
                assert np.isclose(sum(v['exposure_station_days'] for v in summary[key].values()),row['exposure'])
                assert sum(v['false_episode_starts'] for v in summary[key].values())==row['false']
        for offset in d.OFFSETS:
            shifted=d.global_scores(part,norm,model,offset)
            rows,_,_=d.operating(part,shifted,setting)
            assert rows==result['synthetic_shift_stress'][name][str(offset)]['by_scenario']
    cal=parts['calibration']
    weekly=result['reciprocal_week_stress']
    choices=d.read(OUT/'weekly_choice_freeze.json')
    for name,lo,hi in [('week1',0,7),('week2',7,14)]:
        part=d.subset(cal,lo,hi);p=d.global_scores(part,norm,model)
        grid=d.read(OUT/(name+'_grid.json'))
        assert len(grid)==360
        # Audit all grid values against replays, not merely the selected maximum.
        for i,row in enumerate(grid):
            assert row['grid_index']==i//2 and row['confirmation']==1+i%2
            by_s,_,_=d.operating(part,p,row)
            assert by_s==row['by_scenario']
        selected=select(grid,weekly[name]['fixed_global'],weekly[name]['dense30_budgets'])
        assert selected==weekly[name]['selected']==choices['selected'][name]
        assert sum(r['feasible'] for r in grid)==weekly[name]['feasible_grid_settings']
        for s in SCENARIOS:
            dense=replay(part,alarm(part[s+'_single']*70,-30,1,part),details=True)[0]
            assert dense['false_per_valid_station_day']==weekly[name]['dense30_budgets'][s]
        other='week2' if name=='week1' else 'week1';lo2,hi2=(7,14) if other=='week2' else (0,7)
        target=d.subset(cal,lo2,hi2)
        rows,_,_=d.operating(target,d.global_scores(target,norm,model),selected)
        app=weekly[name]['opposite_week_application'];assert rows==app['by_scenario']
        for s in SCENARIOS:
            assert app['false_budget_met'][s]==(rows[s]['false_per_valid_station_day']<=weekly[other]['dense30_budgets'][s]+1e-12)
            assert app['detection_floor_met'][s]==(rows[s]['detection_recall']>=weekly[other]['fixed_global'][s]['detection_recall']-.02-1e-12)
    # Prior scientific files are immutable; allow only checkpoint headers on a later rerun.
    prior_path=ROOT/'outputs/station-agnostic-risk-2026-10-15/writing_archive_manifest.json'
    latest_path=OUT/'writing_archive_manifest.json'
    prior=d.read(prior_path)
    for name,meta in prior['files'].items():
        if name in ('README.md','CURRENT_STATE.zh-CN.md') and latest_path.exists():
            assert d.sha(ROOT/name)==d.read(latest_path)['files'][name]['sha256']
        else:assert d.sha(ROOT/name)==meta['sha256'],name
    stream=io.StringIO()
    suite=unittest.defaultTestLoader.discover(str(ROOT/'tests'),pattern='test_calibration_fragility.py')
    tests=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    assert tests.wasSuccessful() and tests.testsRun==9,stream.getvalue()
    d.write(OUT/'test_results.json',{'tests_run':tests.testsRun,'passed':tests.wasSuccessful(),'output':stream.getvalue()})
    proof={'passed':True,'checked_at_utc':datetime.now(timezone.utc).isoformat(),
        'unit_tests_passed':tests.testsRun,'all720_weekly_grid_replays_checked':True,
        'all10_synthetic_shift_replays_checked':True,'speed_threshold_equivalence_checked':True,
        'episode_classification_and_exposure_counts_checked':True,
        'serialization_recovery_preserved_previous_artifacts':True,
        'prior_archive_scientific_files_unchanged':True,
        'evaluation_or_raw_data_used':False,'new_method_accepted':False,
        'source_sha256':d.sha(Path(__file__))}
    d.write(OUT/'audit.json',proof);print(proof)


if __name__=='__main__':main()
