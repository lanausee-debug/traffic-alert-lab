"""Independent record aggregation and reconciliation; no cache/model decode."""
from datetime import datetime,timezone
from collections import Counter
import sys
import event_lineage_attribution as pilot
import calibration_fragility as common
import early_warning_protection as protection


def main():
    sys.addaudithook(protection.guard)
    root=pilot.ROOT;out=pilot.OUT;plan=common.read(out/'plan.json');r=common.read(out/'results.json')
    done=common.read(out/'completion.json');source=common.read(pilot.PRIOR/'results.json')
    assert r['source_results_sha256']==common.sha(pilot.PRIOR/'results.json')
    for n,h in plan['source_and_input_sha256'].items():assert common.sha(root/n)==h,n
    for n,h in done['artifacts'].items():assert common.sha(out/n)==h,n
    assert done['plan_sha256']==common.sha(out/'plan.json')
    assert datetime.fromisoformat(plan['frozen_at_utc'])<datetime.fromisoformat(done['completed_at_utc'])
    counts={'method_aggregations_checked':0,'event_records_checked_including_related_blocks_and_methods':0,
        'episode_records_checked_including_related_blocks_and_methods':0,'pair_comparisons_checked':0,'definition_transition_tables_checked':0}
    for block,prior in source['blocks'].items():
        d=r['blocks'][block];link=prior['lineage'];assert d['shared_evidence']==prior['shared_evidence']
        catalog={definition:{} for definition in ('one_high','two_high')}
        for item in link['old_to_new']:
            a,b=item['old'],item['new']
            if not a['complete']:continue
            label='parent_censored' if not b['complete'] else 'reentry_segment' if a['start_row']>b['start_row'] else 'first_segment'
            value={'group':label,'run':a,'parent':b,'new_run_index':item['new_run_index']}
            catalog['one_high'][(a['node'],a['event_start_origin'])]=value
        for j,b in enumerate(link['new_runs']):
            if not b['complete']:continue
            children=[m['old'] for m in link['old_to_new'] if m['new_run_index']==j]
            value={'group':'single_segment_process' if len(children)==1 else 'multi_segment_process',
                'run':b,'old_children':children,'new_run_index':j}
            catalog['two_high'][(b['node'],b['event_start_origin'])]=value
        for definition,cat in catalog.items():
            assert d['event_groups'][definition]==[{'node':k[0],'event_start_origin':k[1],**v} for k,v in cat.items()]
            for scenario,methods in prior['shared_evaluation'][definition].items():
                current=d['definitions'][definition][scenario]
                for method,input_ in methods.items():
                    result=current['methods'][method];events=input_['event_records'];eps=input_['episode_records'];op=input_['operating']
                    assert result['operating_unchanged']==op
                    assert set(cat)=={(e['node'],e['event_start_origin']) for e in events}
                    checked_tags=[]
                    for ep in eps:
                        matches=[]
                        if ep['kind'] in ('warned','late','duplicate'):
                            matches=[(k,v) for k,v in cat.items() if v['run']['node']==ep['node'] and v['run']['start_row']-2<=ep['row']<v['run']['end_row']]
                            assert len(matches)==1
                        group=matches[0][1]['group'] if matches else None;key=list(matches[0][0]) if matches else None
                        checked_tags.append({**ep,'event_group':group,'matched_window_event_key':key})
                    assert checked_tags==result['tagged_episodes']
                    selected_groups={g:[e for e in events if cat[(e['node'],e['event_start_origin'])]['group']==g] for g in pilot.GROUPS[definition]}
                    for group,selected in list(selected_groups.items())+[('ALL',events)]:
                        n=len(selected);warned=sum(e['status']=='warned' for e in selected)
                        detected=sum(e['status'] in ('warned','late') for e in selected)
                        ten=sum(e['status']=='warned' and e['lead_minutes'] in (10,15) for e in selected)
                        expected={'events':n,'detected':detected,'warned':warned,'late':sum(e['status']=='late' for e in selected),
                            'missed':sum(e['status']=='missed' for e in selected),'R10':ten,
                            'R15':sum(e['status']=='warned' and e['lead_minutes']==15 for e in selected),
                            'detection_recall':detected/n if n else None,'R10_recall':ten/n if n else None}
                        if group=='ALL':assert result['overall_events']==expected
                        else:
                            assert result['groups'][group]['metrics']==expected
                            assert result['groups'][group]['associated_episode_counts']=={k:sum(e['event_group']==group and e['kind']==k for e in checked_tags) for k in ('warned','late','duplicate')}
                    assert result['episode_count']==len(eps)
                    assert result['episode_type_counts']=={k:sum(e['kind']==k for e in eps) for k in pilot.KINDS}
                    counts['method_aggregations_checked']+=1;counts['event_records_checked_including_related_blocks_and_methods']+=len(events)
                    counts['episode_records_checked_including_related_blocks_and_methods']+=len(eps)
                for name,(before,after) in pilot.PAIRS.items():
                    comparison=current['comparisons'][name]
                    a={(e['node'],e['event_start_origin']):e for e in methods[before]['event_records']}
                    b={(e['node'],e['event_start_origin']):e for e in methods[after]['event_records']}
                    changed=[]
                    for group in pilot.GROUPS[definition]:
                        keys=[k for k,v in cat.items() if v['group']==group];records=[]
                        for k in keys:
                            x,y=a[k],b[k];dx=x['status']!='missed';dy=y['status']!='missed'
                            tx=x['status']=='warned' and x['lead_minutes']>=10;ty=y['status']=='warned' and y['lead_minutes']>=10
                            rec={'node':k[0],'event_start_origin':k[1],'group':group,
                                'before_status':x['status'],'after_status':y['status'],'before_lead_minutes':x['lead_minutes'],'after_lead_minutes':y['lead_minutes'],
                                'recovered_detection':not dx and dy,'lost_detection':dx and not dy,
                                'R10_gained':not tx and ty,'R10_lost':tx and not ty,
                                'original_R10_lost_or_delayed':bool(tx and not (ty and y['lead_minutes']>=x['lead_minutes']))}
                            records.append(rec)
                            if x['status']!=y['status'] or x['lead_minutes']!=y['lead_minutes']:changed.append(rec)
                        got=comparison['event_comparison']['groups'][group]
                        assert got['events']==len(keys)
                        for k in ('recovered_detection','lost_detection','R10_gained','R10_lost','original_R10_lost_or_delayed'):assert got[k]==sum(e[k] for e in records)
                        assert got['before']==current['methods'][before]['groups'][group]['metrics']
                        assert got['after']==current['methods'][after]['groups'][group]['metrics']
                        assert got['after']['detected']-got['before']['detected']==got['recovered_detection']-got['lost_detection']
                        assert got['after']['R10']-got['before']['R10']==got['R10_gained']-got['R10_lost']
                    assert comparison['event_comparison']['changed_event_records']==changed
                    ae={(e['node'],e['row'],e['length_steps']):e for e in current['methods'][before]['tagged_episodes']}
                    be={(e['node'],e['row'],e['length_steps']):e for e in current['methods'][after]['tagged_episodes']}
                    removed=[ae[k] for k in sorted(ae.keys()-be.keys())];added=[be[k] for k in sorted(be.keys()-ae.keys())]
                    changes=[{'node':k[0],'row':k[1],'length_steps':k[2],'before_kind':ae[k]['kind'],'after_kind':be[k]['kind'],
                        'before_event_group':ae[k]['event_group'],'after_event_group':be[k]['event_group']}
                        for k in sorted(ae.keys()&be.keys()) if ae[k]['kind']!=be[k]['kind']]
                    ac=comparison['episode_comparison']
                    assert ac['added_episode_records']==added and ac['removed_episode_records']==removed
                    assert ac['shared_episode_type_changes']==changes
                    assert ac['before_episode_count']==len(ae) and ac['after_episode_count']==len(be)
                    assert ac['net_episode_count_change']==len(added)-len(removed)
                    for kind in pilot.KINDS:
                        assert ac['added_episode_types'][kind]==sum(e['kind']==kind for e in added)
                        assert ac['removed_episode_types'][kind]==sum(e['kind']==kind for e in removed)
                        delta=sum(e['kind']==kind for e in be.values())-sum(e['kind']==kind for e in ae.values())
                        assert ac['net_type_changes'][kind]==delta==sum(e['kind']==kind for e in added)-sum(e['kind']==kind for e in removed)+sum(e['after_kind']==kind for e in changes)-sum(e['before_kind']==kind for e in changes)
                    counts['pair_comparisons_checked']+=1
        for scenario,methods in d['definition_episode_transitions'].items():
            for method,t in methods.items():
                a={(e['node'],e['row'],e['length_steps']):e for e in d['definitions']['one_high'][scenario]['methods'][method]['tagged_episodes']}
                b={(e['node'],e['row'],e['length_steps']):e for e in d['definitions']['two_high'][scenario]['methods'][method]['tagged_episodes']}
                assert a.keys()==b.keys() and len(a)==t['episode_count_unchanged']
                assert t['kind_transition_matrix']=={x:{y:sum(a[k]['kind']==x and b[k]['kind']==y for k in a) for y in pilot.KINDS} for x in pilot.KINDS}
                changes=[{'node':k[0],'row':k[1],'length_steps':k[2],'one_high_kind':a[k]['kind'],'two_high_kind':b[k]['kind'],
                    'one_high_event_group':a[k]['event_group'],'two_high_event_group':b[k]['event_group']}
                    for k in sorted(a) if a[k]['kind']!=b[k]['kind']]
                assert changes==t['changed_episode_records'];counts['definition_transition_tables_checked']+=1
    assert r['new_models_fitted']==r['optimizer_updates']==r['new_model_inference_calls']==0
    assert not r['policy_changed'] and not r['labels_changed'] and not r['new_acceptance_test_performed']
    assert r['original_thesis_primary_test_still_failed'] and not r['previous_candidate_acceptance_passed']
    assert not r['new_station_cohort_consumed'] and not r['consumed_transfer_values_used']
    assert not any(p.endswith(('.npz','.pt','.h5','.hdf5')) for p in common.READS)
    audit={'passed':True,'audited_at_utc':datetime.now(timezone.utc).isoformat(),**counts,
        'all_group_totals_and_identity_changes_reconciled':True,'all_episode_set_and_reclassification_counts_reconciled':True,
        'definition_change_does_not_change_notification_episode_set':True,
        'results_sha256':common.sha(out/'results.json'),'record_only_no_model_or_sample_cache_decode':True,
        'source_and_input_hashes_preserved':True,'new_models_fitted':0,'new_model_inference_calls':0,
        'original_thesis_primary_test_still_failed':True,'runtime_output_paths':sorted(set(common.READS))}
    common.write(out/'audit.json',audit);print({k:v for k,v in audit.items() if k!='runtime_output_paths'})


if __name__=='__main__':main()
