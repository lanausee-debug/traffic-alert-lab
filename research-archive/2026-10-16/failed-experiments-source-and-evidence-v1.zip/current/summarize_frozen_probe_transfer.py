"""Report consumed-cohort discrimination separately from early-warning retention."""
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
import frozen_probe_transfer as transfer
import calibration_fragility as common
ROOT=transfer.ROOT;OUT=transfer.OUT
def num(v):return '不可计算' if v is None else f'{v:.3f}'
def pct(v):return '不可计算' if v is None else f'{100*v:.1f}%'


def main():
    r=common.read(OUT/'results.json');audit=common.read(OUT/'audit.json')
    assert audit['passed'] and r['natural_diagnostic_gate']['passed'] and not r['new_alarm_policy_accepted']
    lead=common.read(OUT/'posthoc_proxy_lead_retention.json')['by_block_and_scenario']['full83']['natural']
    common.write(OUT/'test_receipt.json',{'recorded_at_utc':datetime.now(timezone.utc).isoformat(),
        'command':'.venv/Scripts/python.exe -m unittest discover -s tests -p test_frozen_probe_transfer.py -v',
        'tests_run':7,'observed_exit_code':0,'passed':True,
        'basis':'Observed successful tool output before frozen cache transfer; no repeat execution by report generator',
        'initial_test_fixture_note':'Before pilot, corrected test expectation: inverse ROC ranking has AUC0 but AP need not0. Weighted implementation unchanged; final7 tests passed.',
        'test_source_sha256':common.sha(ROOT/'tests/test_frozen_probe_transfer.py')})
    names={'full83':'全83日','first28':'前28日','middle28':'中间28日','last27':'后27日'}
    full=r['metrics']['full83'];retention=r['retention']['full83']
    lines=['# 固定判别器跨站探索：区分能力保持，早期预警保护不足','',
        '日期：2026-10-15。**这组已分析过的24站缓存上，固定30维判别器通过预定排序诊断；但固定分界线只保留自然情景70.2%的原≥10分钟代理预警，不能直接用来过滤告警。**','',
        '## 数据和方案边界','',
        '使用上一轮迁移检查已经保存的PEMS-BAY另一组24站、83日缓存。它们与原开发24站零重叠，但此前已看过并用于提出研究问题，是已消耗的探索性证据，不能再次当成未见测试。仍是同一路网同期，不是独立外部数据集。','',
        '这组站点的GraphTCN在之前检查中曾按原规则适配训练。本轮直接使用那次预测和特征缓存，没有新训练前端，也没有重新打开原始HDF5。上一轮3个判别器的系数、训练均值/尺度、训练分界线全部固定；程序对模型拟合和分界线拟合入口主动报错，输入只允许预先列出的缓存与元数据，旧科学文件禁止写入。','',
        '全局0.46/c1告警分数与原缓存逐点完全一致。30维输入与上一轮完全相同，排除站点编号，包括可观测的过去一步残差；没有事件持续时间、告警之后长度、未来真值或代理提前量。','',
        '二分类任务仍只包括原全局告警中的获记5/10/15分钟代理预警和误报起点。迟报、重复、删失和未知不进入此子任务。它不是对所有真实交通事件的识别，也不是告警过滤策略的服务回放。','',
        '## 自然观测：排序诊断','',
        '固定规则下，自然情景有620条获记预警、869条误报起点，共1489条条件任务样本。另有663条迟报、465条重复告警被排除。83日全段以及预定前28/中28/后27日分别计算；分块重置边界与删失，合计不应被视作额外独立样本。','',
        '| 时间范围 | 日期 | 正例/负例 | 最强简单参照AUC | 全状态AUC | 参照AP | 全状态AP |',
        '| --- | --- | ---: | ---: | ---: | ---: | ---: |']
    for block,scenarios in r['metrics'].items():
        state=scenarios['natural']['state_logistic'];check=r['natural_diagnostic_gate']['by_natural_scenario_block'][block]
        lines.append(f"| {names[block]} | {'至'.join(r['block_date_ranges'][block])} | {state['credited_warnings']}/{state['false_starts']} | {num(check['strongest_baseline_auc'])} | {num(state['roc_auc'])} | {num(check['strongest_baseline_AP'])} | {num(state['average_precision'])} |")
    lines+=['',
        '沿用上轮诊断线：每个范围至少10正/10负；状态AUC≥0.70且领先简单参照包络至少0.05；AP不低于包络。本组已消耗站点的全段及三个子段均通过。包络是原风险分数、只看风险和只看残差探针按指标取高，仅作保守诊断，不是可上线选参方案。','',
        'AUC表示正例排在负例前的能力，不是准确率；AP受正例比例影响。上轮原开发校准前周AP仍低于参照，原开发联合诊断仍然未通过；本次通过不追溯改写该失败，也不改写论文原主检验。','',
        '## 三种观测情景的全83日表现','',
        '| 情景 | 正例/负例 | 状态AUC | 状态AP | 风险单变量AUC | 残差单变量AUC |',
        '| --- | ---: | ---: | ---: | ---: | ---: |']
    for s,methods in full.items():
        state=methods['state_logistic'];lines.append(f"| {s} | {state['credited_warnings']}/{state['false_starts']} | {num(state['roc_auc'])} | {num(state['average_precision'])} | {num(methods['score_logistic']['roc_auc'])} | {num(methods['residual_logistic']['roc_auc'])} |")
    lines+=['','三种情景共享源路网与事件，不能把样本数量加起来充当独立样本。此处固定状态特征显现的额外区分能力，比只按单个历史误差设规则更值得研究；仍不能把它叫作独立验证的总体优势或原创交通算法。','',
        '## 固定分界线没有保护好早期预警','',
        '沿用原训练段至少保留95%获记预警所选的分界线0.24053665549216505。没有按本组站点结果重新校准。下列保留与排除只针对已筛选子任务，不是实际误报率变化。','',
        '| 情景 | 获记预警保留 | 误报起点排除 | 原≥10分钟代理预警保留 |',
        '| --- | ---: | ---: | ---: |']
    for s,methods in retention.items():
        state=methods['state_logistic'];lines.append(f"| {s} | {pct(state['credited_warnings_retained'])} | {pct(state['false_starts_rejected'])} | {pct(state['R10_credited_starts_retained'])} |")
    lines+=['',
        '自然情景虽然排除435/869个误报起点，同时也拒绝83/620条原获记预警，且其中64条原来满足≥10分钟代理提前量。因此不能只宣传“排除了一半误报”。没有改变在线告警或完成全类型策略回放，也不能把该排除率当成误报/站日减半。','',
        '以下是结果后的描述分层，未据其改变模型、分界线或验收条件：','',
        '| 原代理提前量 | 原获记预警数 | 保留 | 拒绝 | 保留率 |',
        '| --- | ---: | ---: | ---: | ---: |']
    for minutes,row in lead.items():
        lines.append(f"| {minutes}分钟 | {row['original_credited_warnings']} | {row['retained']} | {row['rejected']} | {pct(row['fraction_retained'])} |")
    lines+=['',
        '“预测会成为任意获记预警”与“保护早期预警”不是同一个目标。这里5分钟预警保留95.3%，15分钟只保留59.2%，直接显示当前分界线对早期预警保护不足。这个分层不能单独证明训练损失或某个特征造成了差异；需要在开发数据中另行检验目标/约束如何保护提前量。','',
        '≥10/15分钟沿用L=5(s−a+1)的低速代理口径，不是现场核实的真实拥堵起点。','',
        '## 日期配对的不确定性描述','',
        '全83日2000次共同抽取日历日期，种子20261015，同一组抽样索引用于三个情景。候选与参照也使用相同日期。参照在缓存解码前固定为只看风险的线性探针，不是事后挑的包络。若任何次抽样类别分母为0，不补零或静默删样本，而是不报区间。','',
        '| 自然情景：状态−固定风险单变量探针 | 点差 | 条件95%区间 |',
        '| --- | ---: | --- |']
    for metric,row in r['full83_state_minus_score_logistic_date_bootstrap']['natural'].items():
        ci=row['conditional_ci95'];lines.append(f"| {metric} | {row['difference']:+.3f} | [{ci[0]:.3f}, {ci[1]:.3f}] |")
    lines+=['',
        '区间只描述已固定前端、判别器与已看过站点上的日期波动，不含训练、跨站点、跨路网不确定性，也没有恢复数据独立性。不能因区间为正就宣传新的确认性结论。','',
        '## 核查、保存与下一步','',
        '7项测试通过：缓存白名单与科学输入只读、禁止重新拟合/定分界线、加权指标等价于显式重复样本、并列分数/零权重、同日配对与不可计算抽样。独立审计重建12组样本和标签，核对60组AUC/AP；将全部6000组情景×日期抽样显式展开，再独立重算区间；权重、分界线、旧分数和此前科学文件哈希均保持。','',
        '缓存来源计划和哈希在本轮解码前固定；原始数据未重开，没有新站点被消耗。原论文主检验与前几轮失败均保留，GitHub/线上Demo仍v7，权重和真实逐站明细只在本地。','',
        '后续优先在原开发数据中把“保护≥10/15分钟代理预警”写成明确约束，研究目标与决策的匹配，而非看到本组拒绝率后降低分界线。任何新方案仍需另行冻结，已分析的这组站点不能再作未见确认集。本轮没有实施该保护方案或接受新告警策略。','']
    (OUT/'report.zh-CN.md').write_text('\n'.join(lines),encoding='utf-8')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(1,2,figsize=(12,4.9),facecolor='#f5f8fa')
    blocks=list(names);positions=np.arange(4)
    baseline=[r['natural_diagnostic_gate']['by_natural_scenario_block'][b]['strongest_baseline_auc'] for b in blocks]
    state=[r['metrics'][b]['natural']['state_logistic']['roc_auc'] for b in blocks]
    axes[0].bar(positions-.17,baseline,width=.34,color='#8297ab',label='Simple baseline envelope')
    axes[0].bar(positions+.17,state,width=.34,color='#137c83',label='Frozen state probe')
    axes[0].set_xticks(positions,['Full83','First28','Middle28','Last27'])
    axes[0].set_ylim(0,1);axes[0].set_title('Natural scenario: ROC AUC (not accuracy)',fontsize=11)
    axes[0].legend(frameon=False,fontsize=8,loc='lower left')
    for x,v in zip(positions+.17,state):axes[0].text(x,v+.015,f'{v:.3f}',ha='center',fontsize=9)
    values=[lead[str(minutes)]['fraction_retained']*100 for minutes in (5,10,15)]
    bars=axes[1].bar(range(3),values,width=.65,color=['#137c83','#b38c64','#c16c68'])
    axes[1].set_xticks(range(3),['5 min proxy','10 min proxy','15 min proxy'])
    axes[1].set_ylim(0,110);axes[1].set_ylabel('Original credited warnings retained (%)')
    axes[1].set_title('Frozen cutoff: early warnings are lost',fontsize=11)
    for bar,value in zip(bars,values):axes[1].text(bar.get_x()+bar.get_width()/2,bar.get_height()+1,f'{value:.1f}%',ha='center',fontsize=10)
    for ax in axes:ax.spines[['top','right']].set_visible(False)
    fig.suptitle('Consumed-cohort exploration: ranking transfers; early-warning protection does not',fontsize=12)
    fig.text(.5,.025,'Same network/calendar; adapted front end cached earlier. Already-analyzed cohort; no independent policy validation.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.08,1,.91));fig.savefig(OUT/'comparison.png',dpi=150);plt.close(fig)
    print({'report':str(OUT/'report.zh-CN.md'),'diagnostic_passed':True,'new_alarm_policy_accepted':False})


if __name__=='__main__':main()
