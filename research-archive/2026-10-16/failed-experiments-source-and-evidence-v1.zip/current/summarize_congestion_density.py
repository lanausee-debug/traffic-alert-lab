"""Audit nested grids, fixed update budgets, saved models, and event lead bins."""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import numpy as np
import torch
from recovery_pilot import ROOT,write_json
from multifault_pilot import sha256
from audit_congestion_pilot import compare
from congestion_alert_pilot import SCENARIOS,outage_mask,infer,event_stats
from fresh_holdout_pilot import MaskedGraphTCN
from congestion_risk_pilot import RiskModel,pool,score,choose,online_alarm,hidden_features_check
from congestion_ablation import OLD,SEEDS,load_data,load_parts,load_model
from summarize_congestion_risk import check_validation
from summarize_congestion_onset import independent_targets,NAMES,mean
from summarize_congestion_objective import check_event_records
from congestion_onset_pilot import PARTITIONS,supervised_data
from congestion_density_pilot import (OUTPUT,ONSET,METHODS,PREVIOUS_METHODS,NEW_METHODS,BATCH,UPDATES,CHECKS,
    dense_training,saved_targets,previous_scores,new_scores,reference_method,evaluate_with_leads,
    comparisons,paired_success,state_signature,sampler_signature)

NAMES={**NAMES,'sparse_update_linear':'15分钟起点线性（原权重）',
       'dense_update_linear':'5分钟起点线性','sparse_update_mlp':'15分钟等更新起点MLP',
       'dense_update_mlp':'5分钟等更新起点MLP'}


def forecast_audit(data,sparse,dense,output):
    raw,z,valid,ts,context,mu,scale,adj,day,groups=data
    origins=dense['natural']['origins']; shared=np.searchsorted(origins,sparse['natural']['origins'])
    future=origins[:,None]+np.arange(3)[None]
    expected=(raw[future]<=30).all(axis=1)
    window=origins[:,None]+np.arange(-12,3)[None]
    regular=(np.diff(ts[window],axis=1)==np.timedelta64(5,'m')).all(axis=1)
    eligible=(valid[future]>0).all(axis=1)&regular[:,None]
    assert np.array_equal(expected,dense['natural']['truth'])
    assert np.array_equal(eligible,dense['natural']['eligible'])
    missing=np.ones(len(origins),bool); missing[shared]=False
    new_ids=np.flatnonzero(missing)
    sample=new_ids[np.linspace(0,len(new_ids)-1,8,dtype=int)]
    models=[]
    for seed in (42,43,44):
        model=MaskedGraphTCN(12,3,adj)
        model.load_state_dict(torch.load(ROOT/'outputs/fresh-holdout-pilot'/f'model_tcn_seed{seed}.pt',weights_only=True)['state_dict'])
        model.eval(); models.append(model)
    maximum=0.
    with np.load(OLD/'predictions_training.npz') as old,np.load(output/'predictions_training_dense.npz') as cache:
        assert np.array_equal(cache['origins'],origins)
        for key in ('truth','eligible','day_ids','dates'):
            assert np.array_equal(cache[key],dense['natural'][key])
        for s in SCENARIOS:
            mask,fault=outage_mask(valid,day,s,groups)
            assert np.array_equal(cache[f'fault_{s}'],fault[origins-1])
            assert np.array_equal(cache[f'predictions_{s}'][:,shared],old[f'predictions_{s}'])
            rebuilt=infer(models,z,mask,origins[sample],context,mu,scale)
            error=float(np.max(np.abs(rebuilt-cache[f'predictions_{s}'][:,sample])))
            maximum=max(maximum,error); assert error<=2e-4
    return {'all_shared_forecasts_byte_equal':True,'new_forecast_requests_checked':8*3*3,
            'maximum_new_forecast_rebuild_error_mph':maximum}


def report(result,logs,output):
    rows=result['evaluation']; ref=result['reference']; budgets=result['selection']['budgets']
    lines=['# 训练取样密度：相同更新预算下，尚未确认长提前量增益','',
           '日期：2026-10-10。全部日期以前分析过；当前是探索实验。主指标在本轮运行前固定为至少提前10分钟的事件预警召回，计分提前量仍为代理事件定义。','',
           '## 两个预定比较','',
           '| 对照 | 指标 | 5分钟MLP−对照 | 95%日期区间 | 97.5%日期区间 |',
           '| --- | --- | ---: | --- | --- |']
    for c in result['comparisons'].values():
        for key,label,factor in [('warning10_recall','至少提前10分钟召回（百分点）',100),
                                 ('warning_recall','全部预警召回（百分点）',100),
                                 ('detection_recall','含迟报检测（百分点）',100),('false_rate','误报/有效站日',1)]:
            ci=lambda k: '['+', '.join(f'{v*factor:.3f}' for v in c[k])+']'
            extra=ci(key+'_ci975') if key+'_ci975' in c else '—'
            lines.append(f'| {NAMES[c["baseline"]]} | {label} | {c[key+"_difference"]*factor:+.3f} | {ci(key+"_ci95")} | {extra} |')
    lines += ['', '日期配对bootstrap共2000次，三情景共同抽取同一日期。97.5%仅用于主指标两个比较，不控制辅助指标或历史反复探索。区间条件于当前三种子集成，不含重训练方差，不是独立验证。','',
              '## 全部13组方法','',
              '| 方法 | 阈值/确认 | ≥10分钟召回 | 全部预警 | 含迟报检测 | 误报/有效站日 | 成功子集平均提前分钟 | 5/10/15分钟数量（三情景合计） |',
              '| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |']
    for m in METHODS:
        op=result['selection']['methods'][m]['selected']; r=rows[m]
        threshold=-op['threshold'] if m=='dense_speed' else op['threshold']
        counts='/'.join(str(sum(r[s]['warning_lead_counts'][str(v)] for s in SCENARIOS)) for v in (5,10,15))
        lines.append(f'| {NAMES[m]} | {threshold:g}/{op["confirmation"]} | {mean(r,"warning_recall_at_least10")*100:.2f}% | {mean(r,"warning_recall")*100:.2f}% | {mean(r,"detection_recall")*100:.2f}% | {mean(r,"false_per_valid_station_day"):.3f} | {mean(r,"warning_lead_mean_minutes"):.2f} | {counts} |')
    lines += ['',f'简单参考仅按原校准目标选定，仍为{NAMES[ref]}；没有改成按≥10分钟召回选点。所有评测事件分母及匹配规则保持不变。三情景共享1089个完整事件，合计3267个情景-事件不是独立事件数。','',
              '## 控制了什么','',
              '| 训练网格 | 唯一有效点 | 三情景训练池 | 唯一起点阳性 | 三情景阳性 |',
              '| --- | ---: | ---: | ---: | ---: |']
    for density,r in result['training_pools'].items():
        lines.append(f'| {density} | {r["unique_valid_points"]} | {r["training_points"]} | {r["unique_positive_points"]} | {r["positive_points"]} |')
    lines += ['', f'两组MLP每步均匀有放回抽取{BATCH}点，均执行{UPDATES}次Adam更新，共{BATCH*UPDATES}次样本抽取；同种子相同初始化。51→32→16→1、学习率0.001、weight decay 0.001、未加权BCE及225/450/900/1350验证检查点相同。风险输入、起点标签、原归一化、冻结预测器和校准规则相同。','',
              '5分钟池包含全部15分钟池，新时间位置才新增预测，旧位置三种子预测逐值一致；共享风险特征在1e−6内核对后使用旧值。更多数据不等于更多独立事件，邻近起点高度相关。','',
              '本轮有放回抽样与上一轮逐轮无放回打乱不同，因此上一轮起点MLP仅是历史对照。密度归因必须比较本轮两组等更新MLP，不能拿5分钟结果直接对上一轮15分钟模型。初始化和更新预算相同，也不保证最终模型/运行点相同。','',
              '线性模型单列；15分钟线性逐字节复用旧权重，5分钟线性以完整池LBFGS优化，验证选正则化。每次全批次成本不同，不称线性等算力比较。MLP只控制更新和每批样本数，不声称总墙钟时间相等。','',
              '## 保存权重的验证选择','',
              '| 模型 | 种子或alpha | 选中更新步 | 验证BCE |',
              '| --- | --- | ---: | ---: |']
    for key,records in logs.items():
        if key.endswith('linear'):
            lines.append(f'| {NAMES[key]} | {records["selected_alpha"]:g} | LBFGS | {records["validation_bce"]:.6f} |')
        else:
            for r in records:
                lines.append(f'| {NAMES[key]} | {r["seed"]} | {r["selected_step"]} | {r["validation_bce"]:.6f} |')
    lines += ['', '## 分情景运行点与经验预算','',
              '| 方法 | 情景 | ≥10分钟% | 全预警% | 检测% | 误报/站日 | 校准预算 | 评测超预算 | 迟报 | 漏检 | 重复 | 未知 | 删失告警 |',
              '| --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: |']
    for m in METHODS:
        for s in SCENARIOS:
            r=rows[m][s]
            lines.append(f'| {NAMES[m]} | {s} | {r["warning_recall_at_least10"]*100:.2f} | {r["warning_recall"]*100:.2f} | {r["detection_recall"]*100:.2f} | {r["false_per_valid_station_day"]:.3f} | {budgets[s]:.3f} | {"是" if r["false_per_valid_station_day"]>budgets[s] else "否"} | {r["late"]:g} | {r["missed_events"]} | {r["duplicate"]:g} | {r["unknown_alerts"]:g} | {r["censored_alerts"]:g} |')
    lines += ['', '经验误报预算仅在校准段约束，不是在线保证。新标签逐点Brier/BCE、故障站逐点分数等辅助量均保留在results.json，没有改变告警计分覆盖或按未来有效性关闭在线告警。','',
              '## 同时预警成功的事件','']
    for c in result['paired_success'].values():
        lines.append(f'- 5分钟MLP与{NAMES[c["baseline"]]}共有{c["shared_warned_scenario_events"]}个成功情景-事件；条件同事件平均提前差{c["mean_paired_lead_difference_minutes"]:+.3f}分钟。')
    lines += ['', '以上只在共同成功子集上配对，不代表全部事件收益，不能作因果解释。各方法成功子集的无条件平均提前量也不能直接相减推断更早。','',
              '## 审核及研究判断','',
              '原始读数独立Y转移与六读数有效性重算、密集网格包含性、全部共享预测、新增72个预测请求、标准化和不可见输入扰动核查通过。8份保存权重的验证选择、初始化和批次索引摘要、固定更新预算、线性目标/梯度、全部新概率、13组校准网格、39组事件/日级统计及两项日期区间已复算。','',
              '本轮主指标相对15分钟对照的区间包含零，相对简单速度参考下降；不能宣称加密取样改善至少提前10分钟预警，更不能宣称整体告警提升或方法原创。辅助全部预警增益不能替代主指标。','',
              '下一步先检查等更新模型与旧模型为什么在校准选择和风险曲线上分化，固定模型做诊断，不据评测重选运行点。若另改训练或后处理，应单独冻结协议；最终确认需要未使用的数据。']
    (output/'report.zh-CN.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    plot(result,output)


def plot(result,output):
    os.environ.setdefault('MPLBACKEND','Agg')
    import matplotlib.pyplot as plt
    names=['Speed rule','Global cal.','Group cal.','Original linear','Original MLP',
           'Common BCE linear','Common BCE MLP','Old onset linear','Old onset MLP',
           '15-min onset linear','15-min equal-update MLP','5-min onset linear','5-min equal-update MLP']
    colors=['#c1c5ca']*9+['#6d92ad','#6d92ad','#bd7951','#bd7951']
    fig,axes=plt.subplots(1,4,figsize=(16,7.5),sharey=True)
    for ax,key,title,factor in zip(axes,['warning_recall_at_least10','warning_recall','detection_recall','false_per_valid_station_day'],
        ['Warning >=10 min (%)','All advance warning (%)','Detection incl. late (%)','False / valid station-day'],[100,100,100,1]):
        values=[mean(result['evaluation'][m],key)*factor for m in METHODS]
        ax.barh(np.arange(len(METHODS)),values,color=colors,height=.7)
        ax.set_title(title,fontsize=10); ax.grid(axis='x',alpha=.2); ax.set_axisbelow(True); ax.set_xlim(0,max(values)*1.2)
        for i,v in enumerate(values): ax.text(v+max(values)*.015,i,f'{v:.2f}',va='center',fontsize=8)
    axes[0].set_yticks(np.arange(len(METHODS)),names); axes[0].invert_yaxis()
    fig.suptitle('Training density: 1,350 updates x 4,096 draws for each MLP',fontsize=13)
    fig.text(.53,.018,'Calibrated operating points; previously analyzed dates; fixed proxy event scoring.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.04,1,.95)); fig.savefig(output/'summary.png',dpi=170); fig.savefig(output/'summary.svg'); plt.close(fig)


def main():
    parser=argparse.ArgumentParser(description=__doc__); parser.add_argument('--output',type=Path,default=OUTPUT)
    output=parser.parse_args().output; torch.set_num_threads(1); torch.use_deterministic_algorithms(True)
    result=json.loads((output/'results.json').read_text(encoding='utf-8'))
    config=json.loads((output/'config.json').read_text(encoding='utf-8')); compare(config,result['config'])
    audit=json.loads((output/'audit.json').read_text(encoding='utf-8'))
    assert all(sha256(ROOT/k)==v for k,v in config['sha256'].items())
    assert all(sha256(output/k)==v for k,v in audit['artifact_sha256'].items())
    data=load_data(); parts,names=load_parts(data)
    dense,names2,info=dense_training(data,parts['training'],output)
    compare(names,names2); compare(names,json.loads((output/'features.json').read_text(encoding='utf-8')))
    day=data[8]; start,end=int(np.searchsorted(day,42)),int(np.searchsorted(day,70))
    assert np.array_equal(dense['natural']['origins'],np.arange(start+12,end-2))
    targets={}
    for partition,a,b,stride in list(PARTITIONS)+[('training_dense',42,70,1)]:
        part=dense if partition=='training_dense' else parts[partition]
        origins=part['natural']['origins']; lo,hi=int(np.searchsorted(day,a)),int(np.searchsorted(day,b))
        assert np.array_equal(origins,np.arange(lo+12,hi-2,stride))
        truth,eligible=independent_targets(data,origins,lo,hi)
        targets[partition]={'truth':truth,'eligible':eligible,'origins':origins}
        with np.load(output/f'targets_{partition}.npz') as saved:
            assert all(np.array_equal(v,saved[k]) for k,v in targets[partition].items())
        assert not truth[~eligible].any() and not (eligible&~part['natural']['eligible']).any()
        if partition!='training_dense': assert sha256(output/f'targets_{partition}.npz')==sha256(ONSET/f'targets_{partition}.npz')
        hidden_features_check(part,data)
    forecast_checks=forecast_audit(data,parts['training'],dense,output)
    with np.load(output/'normalization.npz') as n: mu,std=n['mean'],n['std']
    train=pool(parts['training'],'state'); st=train.std(axis=0); st[st<1e-5]=1
    assert np.array_equal(train.mean(axis=0),mu) and np.array_equal(st,std)
    assert sha256(output/'normalization.npz')==sha256(OLD/'normalization.npz')
    xv,yv=supervised_data(parts['validation'],targets['validation'],mu,std)
    logs=json.loads((output/'model_selection.json').read_text(encoding='utf-8'))
    fitted={}; gradients={}; initials={}
    for density,part,target in [('sparse',parts['training'],targets['training']),('dense',dense,targets['training_dense'])]:
        x,y=supervised_data(part,target,mu,std)
        summary={'training_points':len(x),'positive_points':int(y['onset'].sum()),'unique_valid_points':len(x)//3,'unique_positive_points':int(y['onset'].sum())//3}
        compare(summary,result['training_pools'][density])
        key=f'{density}_update_linear'; model,saved=load_model(output/f'{key}.pt')
        compare({k:v for k,v in saved.items() if k!='state_dict'},logs[key]); check_validation(model,saved,xv,yv['onset'])
        model.zero_grad(set_to_none=True)
        objective=torch.nn.functional.binary_cross_entropy_with_logits(model(torch.tensor(x)),torch.tensor(y['onset']))+saved['selected_alpha']/2*model.layers.weight.square().sum()
        objective.backward(); gradient=max(p.grad.abs().max().item() for p in model.parameters()); assert gradient<=1e-4
        selected=next(r for r in saved['logs'] if r['alpha']==saved['selected_alpha'])
        assert np.isclose(objective.detach().item(),selected['train_objective'],rtol=1e-6,atol=1e-7)
        gradients[key]=gradient; fitted[key]=[model]
        if density=='sparse': assert sha256(output/f'{key}.pt')==sha256(ONSET/'onset_linear.pt')
        key=f'{density}_update_mlp'; fitted[key]=[]; initials[density]=[]
        for seed in SEEDS:
            model,saved=load_model(output/f'{key}_{seed}.pt')
            compare({k:v for k,v in saved.items() if k!='state_dict'},next(r for r in logs[key] if r['seed']==seed))
            assert saved['dimension']==51 and saved['nonlinear'] and saved['seed']==seed
            assert saved['training_rows']==len(x) and saved['validation_rows']==len(xv)
            assert saved['batch_size']==BATCH and saved['total_updates']==UPDATES and saved['training_draws']==BATCH*UPDATES
            assert saved['checkpoint_steps']==list(CHECKS) and [r['step'] for r in saved['logs']]==list(CHECKS)
            best=min(saved['logs'],key=lambda r:r['validation_bce']); assert best['step']==saved['selected_step']
            l=score(model,xv); bce=float(np.mean(np.logaddexp(0,l)-yv['onset']*l))
            assert np.isclose(bce,saved['validation_bce'],rtol=1e-6,atol=1e-7) and best['validation_bce']==saved['validation_bce']
            torch.manual_seed(seed); initial=RiskModel(51,True)
            assert state_signature(initial.state_dict())==saved['initial_parameters_sha256']
            assert sampler_signature(len(x),seed)==saved['minibatch_index_sha256']
            initials[density].append(saved['initial_parameters_sha256']); fitted[key].append(model)
    assert initials['dense']==initials['sparse']
    old=json.loads((ONSET/'results.json').read_text(encoding='utf-8'))
    compare(result['selection']['budgets'],old['selection']['budgets']); maxerror=0.; verified=0
    for partition in ('calibration','evaluation'):
        rebuilt=previous_scores(partition); rebuilt.update(new_scores(parts[partition],fitted,mu,std))
        with np.load(output/f'scores_{partition}.npz') as cached:
            assert len(cached.files)==len(METHODS)*3
            for m,by_s in rebuilt.items():
                for s,p in by_s.items():
                    error=float(np.max(np.abs(p-cached[f'{m}_{s}']))); maxerror=max(maxerror,error); assert error==0.
        if partition=='calibration':
            selections={m:choose(m,rebuilt[m],parts[partition],result['selection']['budgets']) for m in METHODS}
            compare(selections,result['selection']['methods']); assert reference_method(selections)==result['reference']
            for m in PREVIOUS_METHODS: compare(selections[m],old['selection']['methods'][m])
            compare(result['selection'],json.loads((output/'selection.json').read_text(encoding='utf-8')))
        else:
            rows,daily,records=evaluate_with_leads(rebuilt,parts[partition],targets[partition],selections,data[3])
            compare(rows,result['evaluation'])
            for m in METHODS:
                for s in SCENARIOS:
                    p=parts[partition][s]; op=selections[m]['selected']; alarm=online_alarm(rebuilt[m][s],op['threshold'],op['confirmation'])
                    check_event_records(records[m][s],p,alarm,data[3]); verified+=len(records[m][s])
                    stats,core=event_stats(p['truth'],p['eligible'],alarm,p['day_ids'])[:2]
                    compare(stats,{k:rows[m][s][k] for k in stats}); assert np.array_equal(core,daily[f'{m}_{s}'][:,:10])
                    for lead in (5,10,15):
                        assert sum(r['lead_minutes']==lead for r in records[m][s])==daily[f'{m}_{s}'][:,9+lead//5].sum()
                    if m in PREVIOUS_METHODS: compare({k:rows[m][s][k] for k in old['evaluation'][m][s]},old['evaluation'][m][s])
            with np.load(output/'daily_metrics.npz') as cached:
                assert set(cached.files)==set(daily) and all(np.array_equal(v,cached[k]) for k,v in daily.items())
    compare(comparisons(daily,result['reference']),result['comparisons'])
    compare(paired_success(records,'dense_update_mlp','sparse_update_mlp'),result['paired_success']['dense-sparse'])
    compare(paired_success(records,'dense_update_mlp',result['reference']),result['paired_success']['dense-reference'])
    write_json(output/'event_records.json',records)
    audit.update({'audit_status':'passed','audit_script_sha256':sha256(Path(__file__)),**forecast_checks,
                  'nested_grids_raw_onset_targets_and_six_reading_masks_checked':True,
                  'original_normalization_and_hidden_input_invariance_checked':True,
                  'all_8_weights_validation_selection_losses_and_fixed_budgets_checked':True,
                  'initial_weight_and_all_minibatch_index_hashes_recomputed':True,
                  'linear_objectives_gradients_recomputed':gradients,'maximum_probability_rebuild_error':maxerror,
                  'all_13_calibration_grids_reference_old_results_and_daily_metrics_checked':True,
                  'independent_event_records_verified':verified,'all_lead_bins_and_paired_bootstrap_comparisons_recomputed':True})
    audit['artifact_sha256']['event_records.json']=sha256(output/'event_records.json')
    write_json(output/'audit.json',audit); report(result,logs,output)
    print(json.dumps({'audit':'passed','probability_error':maxerror,'event_records':verified,**forecast_checks,'report':str(output/'report.zh-CN.md')},indent=2))


if __name__=='__main__': main()
