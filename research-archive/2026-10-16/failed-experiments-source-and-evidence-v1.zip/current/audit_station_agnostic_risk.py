"""Recompute feature ablation scores, checkpoint choices, and calibration constraints."""
from datetime import datetime,timezone
import copy
import json
from pathlib import Path
import numpy as np
import torch
import station_agnostic_risk as experiment
import improve_alert_recall as common
from congestion_alert_pilot import SCENARIOS
from congestion_risk_pilot import score,sigmoid
from pems_bay_alert_replay import alarm,replay
from train_pems_bay_risk import load_risk

ROOT=Path(__file__).resolve().parent
OUT=experiment.OUT
read=common.read
sha=common.sha
write=common.write


def main():
    torch.set_num_threads(1)
    plan=read(OUT/'plan.json');result=read(OUT/'results.json')
    training=read(OUT/'training.json');freeze=read(OUT/'training_freeze.json')
    choice=read(OUT/'selection_freeze.json');access=read(OUT/'access_log.json')
    assert plan['keep_original_feature_indices']==list(range(24))+[48,49,50]
    for name,digest in plan['source_and_input_sha256'].items():assert sha(ROOT/name)==digest,name
    assert choice['plan_sha256']==freeze['plan_sha256']==sha(OUT/'plan.json')
    assert choice['results_sha256']==sha(OUT/'results.json')
    assert datetime.fromisoformat(plan['frozen_at_utc'])<datetime.fromisoformat(freeze['frozen_at_utc'])<datetime.fromisoformat(choice['frozen_at_utc'])
    assert not access['evaluation_or_raw_hdf5_values_read'] and access['runtime_forbidden_open_guard_enabled']
    assert not any('evaluation' in p or 'transfer' in p for p in access['logical_development_loads'])
    for name,digest in freeze['weights'].items():assert sha(OUT/name)==digest
    assert len(freeze['weights'])==6
    norm=common.load(experiment.RISK/'normalization.npz')
    anchor=load_risk(experiment.RISK/'global_calibration.pt')
    validation=common.load(experiment.RISK/'risk_validation.npz')
    xv=experiment.inputs(validation,norm,anchor,True)
    yv=np.tile((validation['truth']|validation['onset'])[validation['common']],3).astype(np.float32)
    part=common.load(experiment.CAL/'calibration.npz');xx=experiment.inputs(part,norm,anchor)
    old=read(experiment.CAL/'selection.json')
    reference=old['methods']['global_calibration']['fine']['selected']['by_scenario']
    budgets=old['budgets'];candidates=[];diagnostics={};count=0;step_count=0
    previous=ROOT/'outputs/anchored-risk-2026-10-15'
    for index,(method,records) in enumerate(training.items()):
        models=[]
        for record in records:
            count+=1;step_count+=record['actual_optimizer_updates']
            assert record['parameters']==1441 and record['actual_optimizer_updates']==1350
            assert record['plan_sha256']==sha(OUT/'plan.json')
            assert min(record['logs'],key=lambda row:row['validation_union_bce'])['step']==record['selected_step']
            path=OUT/f'{method}_seed{record["seed"]}.pt'
            assert record['weight_sha256']==sha(path)
            saved=torch.load(path,weights_only=True)
            assert saved['keep_indices']==experiment.KEEP.tolist()
            model=experiment.StationAgnosticRisk(saved['bound'])
            model.load_state_dict(saved['state_dict']);model.eval();models.append(model)
            logits=score(model,xv)
            bce=float(np.mean(np.logaddexp(0,logits)-yv*logits))
            assert np.isclose(bce,record['validation_union_bce'],rtol=1e-6,atol=1e-8)
            assert np.max(np.abs(logits-xv[:,-1]))<=saved['bound']+1e-5
            old_record=read(previous/f'anchored_bound{str(saved["bound"]).replace(".","_")}_seed{record["seed"]}.json')
            assert record['minibatch_index_sha256']==old_record['minibatch_index_sha256']
        with np.load(OUT/(method+'_calibration_scores.npz')) as archive:
            scores={s:archive[s] for s in SCENARIOS}
        for s in SCENARIOS:
            recomputed=np.mean([sigmoid(score(model,xx[s])) for model in models],axis=0).reshape(part['truth'].shape)
            np.testing.assert_array_equal(scores[s],recomputed)
        rows=read(OUT/(method+'_calibration_grid.json'))
        expected_grid=[round(v/1000,3) for v in range(10,901,5)]+[1.0001]
        assert len(rows)==2*len(expected_grid)
        for gi,t in enumerate(expected_grid):
            for ci,c in enumerate((1,2)):
                row=rows[2*gi+ci]
                assert row['threshold']==t and row['confirmation']==c and row['method_index']==index
                assert row['grid_index']==gi
        selected=common.select(rows,reference,budgets)
        assert selected==result['candidate_families'][method]['selected']
        assert sum(row['feasible'] for row in rows)==result['candidate_families'][method]['feasible_settings']
        if selected:
            candidates.append(selected)
            for s in SCENARIOS:
                recomputed=replay(part,alarm(scores[s],selected['threshold'],selected['confirmation'],part),details=True)[0]
                assert recomputed==selected['by_scenario'][s]
        false_ok=lambda row:all(row['by_scenario'][s]['false_per_valid_station_day']<=budgets[s]+1e-12 for s in SCENARIOS)
        detection_ok=lambda row:all(row['by_scenario'][s]['detection_recall']>=reference[s]['detection_recall']-.02-1e-12 for s in SCENARIOS)
        fa_rows=[r for r in rows if false_ok(r)]
        det_rows=[r for r in rows if detection_ok(r)]
        diagnostics[method]={'grid_settings':len(rows),'false_budget_only_pass':len(fa_rows),
            'detection_floor_only_pass':len(det_rows),'both_pass':sum(r['feasible'] for r in rows),
            'minimum_worst_false_excess_among_detection_pass':min(max(r['by_scenario'][s]['false_per_valid_station_day']-budgets[s] for s in SCENARIOS) for r in det_rows) if det_rows else None,
            'maximum_worst_detection_margin_among_false_pass':max(min(r['by_scenario'][s]['detection_recall']-(reference[s]['detection_recall']-.02) for s in SCENARIOS) for r in fa_rows) if fa_rows else None,
            'diagnostic_only_no_new_candidate_or_gate':True}
    assert common.select(candidates,reference,budgets)==result['selected']
    selected=result['selected']
    acceptance=selected is not None and common.mean(selected['by_scenario'],'warning_recall_at_least10')>=common.mean(reference,'warning_recall_at_least10')+.02-1e-12
    assert bool(acceptance)==result['pilot_acceptance_passed']==choice['pilot_acceptance_passed']
    assert choice['selected']=={k:v for k,v in selected.items() if k!='by_scenario'}
    for key,value in result['selected_means'].items():assert np.isclose(common.mean(selected['by_scenario'],key),value)
    # Preservation check: none of the previously archived project files was changed.
    prior=read(ROOT/'outputs/new-station-transfer-2026-10-15/writing_archive_manifest.json')
    for name,meta in prior['files'].items():assert sha(ROOT/name)==meta['sha256'],name
    write(OUT/'constraint_diagnostics.json',diagnostics)
    proof={'passed':True,'checked_at_utc':datetime.now(timezone.utc).isoformat(),
        'trained_models':count,'actual_optimizer_updates':step_count,
        'parameters_per_model':1441,'matching_minibatch_sequences_to_prior_51_feature_trial':True,
        'selected_checkpoint_bce_and_fixed_scores_recomputed':True,
        'threshold_grid_constraints_and_selected_replay_checked':True,
        'all_prior_archive_files_unchanged_before_save':True,
        'pilot_acceptance_passed':bool(acceptance),'new_station_cohort_consumed':False,
        'source_sha256':sha(Path(__file__))}
    write(OUT/'audit.json',proof)
    print(json.dumps({'audit':proof,'diagnostics':diagnostics}))


if __name__=='__main__':main()
