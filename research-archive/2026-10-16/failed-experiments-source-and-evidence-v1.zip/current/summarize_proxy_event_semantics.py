"""Save auditable label/lead semantics, timeline plot and thesis wording note."""
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
import proxy_event_semantics as pilot
import calibration_fragility as common


def main():
    out=pilot.OUT;root=pilot.ROOT;r=common.read(out/'results.json');audit=common.read(out/'audit.json')
    assert audit['passed'] and audit['results_sha256']==common.sha(out/'results.json')
    common.write(out/'test_receipt.json',{'recorded_at_utc':datetime.now(timezone.utc).isoformat(),
        'tests_run':11,'passed':True,'observed_exit_code':0,
        'basis':'Observed successful 11-test execution, including new start-only/duplicate/censor boundary cases; report does not rerun tests',
        'command':'.venv/Scripts/python.exe -m unittest discover -s tests -p test_proxy_event_semantics.py -v',
        'test_source_sha256':common.sha(root/'tests/test_proxy_event_semantics.py')})
    labels={'training28':'训练28日','risk_validation7':'验证7日','calibration_full14':'校准14日',
        'calibration_week1_7':'校准前7日','calibration_week2_7':'校准后7日'}
    case=r['case_timelines']['risk_validation7']['natural'][0]
    points={v['speed_origin']:v for v in case['rows']}
    assert case['alarm_start_origin']==506 and case['proxy_event_start_origin']==508
    lines=['# 代理事件与提前量核查：30.1 mph的一次越线形成新事件','',
        '日期：2026-10-16。**被低速豁免保护的预警，来自原低速过程的一次越线后的新代理事件：18:15速度30.1 mph使三次低速标签中断，18:20再次开始标签阳性。当前实现与已写明的定义一致；它不能直接作为提前发现首次现实拥堵的证据。**','',
        '## 检查范围和冻结条件','',
        '原24站的风险训练28日、已复用验证7日和校准14日，以及校准两个7日子块。原深度前端、风险模型、有效告警模型及分界线、原全局/有豁免/无豁免规则全部保持。本轮零训练更新、零新模型、零候选选择，标签和验收门槛不改。','',
        '解码开发缓存前封存诊断计划；只回推自然情景中有新鲜末次观测的历史车速，缓存origin=t的own_last对应v(t−1)。未来段车速仅用来离线解释标签，未反馈给模型或决策。时钟断点、缓存尾部和缺观测保留为未知，不用预测值补成真实车速。','',
        '## 原标签和评分到底衡量什么','',
        'Y(t)=1 当且仅当 v(t)、v(t+1)、v(t+2) 都≤30 mph；三条读数有效且窗口时间连续时才纳入评分。事件是有效时段内Y的连续阳性段，完整事件还要求前两个标签可判断并有右端结束。','',
        '所以，若某个真实观测v(h)>30 mph，包含它的Y(h−2)、Y(h−1)、Y(h)都会为0。一次越线就能造成三个标签阴性点，把前后低速读数各组成的标签阳性段拆成两个代理事件。这个确定性关系已用专门构造例子验证，并在真实缓存中检查。它不证明这次越线是传感器噪声，也不证明短暂回升应被当作同一次现实拥堵；本轮没有现场标注可作这种判定。','',
        '告警仍按阳性段起点一对一匹配，只有起点落在事件s−2到e−1之间才获记。首次匹配后，同一事件内又出现的告警起点是重复；过早开始的告警即使后来覆盖预警窗，也可能记成误报、事件记为漏检。这是当前评价协议的选择，不能与“只要有覆盖就检出”的指标混用。','',
        '## 被保护的唯一事件：完整时钟对齐','',
        '原node12（数组编号，非地理标注）、事件origin508；原告警起点origin506。三种缺失情景共用同一真实事件，并不是三个独立案例。以下为自然情景缓存车速，保留一位小数仅供展示；实际比较在原缓存精度上执行。','',
        '| 时刻 | 原生索引 | 车速 mph | 三次低速代理标签Y | 原告警 | 无豁免 | 有豁免 |',
        '| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
    for p in case['rows']:
        active=p['activations'];v=p['cached_actual_speed_mph']
        lines.append(f"| {p['timestamp'][11:16]} | {p['speed_origin']} | {v:.1f} | {int(p['proxy_label'])} | {int(active['global_c1'])} | {int(active['effective_no_bypass'])} | {int(active['effective_protected_gate'])} |")
    lines+=['',
        '关键的18:15观测为30.1000005 mph（缓存反标准化近似值），只比门槛高0.1 mph。这足以使18:05、18:10、18:15三个Y标签为0；18:20、18:25、18:30读数再次都低于门槛，Y在18:20重启。上一个阳性段末点18:00，其三读数窗仍全低速。下一段因此独立计为一个新代理事件。','',
        '在告警origin18:10，最后三条历史观测为17:55的26.8、18:00的27.2和18:05的26.5 mph，低速豁免可凭当时已有信息放行。18:15的30.1 mph属于之后才出现的观测，本轮仅用于离线解释，告警没有偷看它。不能因为之后发生越线，就把当时低速历史改写为“此前畅通”。','',
        '## 15分钟和10分钟是两种时间参考','',
        '既有评分提前量 L=5(s−a+1)，a是告警origin，s是标签事件起点。这等价于从最后一条历史观测的时间戳计算到事件起点；对本例即18:05→18:20=15分钟。若从告警所标记的origin时刻18:10计算，则18:10→18:20=10分钟。','',
        '45次固定回放中的899条获记预警情景/方法记录均已核对，两种时间差固定相差5分钟；未发现公式与现有定义不符的索引偏差。这里没有记录真实系统的计算完成、信息发布时间或现场交通人员收到告警的时刻，所以既有L不应写成实测可用处置时间。不能随意换参考起点后，把新指标与旧R10/R15分数直接比较。','',
        '## 这类分段在开发数据中有多少','',
        '以下每个时间范围只计一次共享代理事件，不按三情景重复计算。三个标签阴性间隔对应15分钟的标签起点间隔；它不表示真实车速已连续畅通15分钟，可能只含一个5分钟样本越线。','',
        '| 范围 | 完整代理事件 | 前一个阳性段后有3个阴性标签 | 已回推出单次高速度读数造成间隔 | 4–6个阴性标签 | 7–12个 | 超过12个 | 无同有效段前序事件 |',
        '| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
    for block,v in r['blocks'].items():
        e=v['shared_event_structure'];g=e['preceding_gap_bins']
        lines.append(f"| {labels[block]} | {e['complete_events']} | {g['gap3']} | {e['gap3_with_known_single_high_speed']} | {g['gap4to6']} | {g['gap7to12']} | {g['gap_gt12']} | {g['no_prior_proxy_run']} |")
    lines+=['',
        '验证7日有6/55个、校准14日有3/69个完整代理事件紧接一次高车速读数形成的分段。原训练有13/198个。未搜索新的合并时长、阈值或恢复次数；不能说这些事件都应合并，也不能通过换标签让原方法通过验收。校准两半与完整14日重叠，不能加总当更多证据。','',
        '## 原提前预警时已经看到低速的比例','',
        '下表仅取原全局规则、自然情景，报告的是原代理R10，不是首次现实拥堵的检出率。“最后已有读数低速”与“已有三条连续低速”分列；三种情景相关，因此不把记录加成独立事件。','',
        '| 范围 | 原R10获记事件 | 末次已有观测≤30 mph | 最近三条已有观测均低速 | 原R15 | 原R15且已有三条低速 |',
        '| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
    for block in ('training28','risk_validation7','calibration_full14'):
        s=r['blocks'][block]['scenarios']['natural']['global_c1']['warning_history_summary'];a=s['R10'];b=s['R15']
        lines.append(f"| {labels[block]} | {a['records']} | {a['natural_low']} | {a['natural_last3_low']} | {b['records']} | {b['natural_last3_low']} |")
    lines+=['',
        '验证自然情景原5个R10事件中2个告警开始时末次已有观测低速，其中1个已有连续三条低速；这个事件正是上一轮豁免救回的R15。校准自然情景原4个R10中1个末次已有观测低速，但没有已有三条连续低速的R10。不能把“此前低速”简单视为无用预警：它可能针对未来再次持续低速；应把这种目标与首次进入拥堵分别定义并呈现。','',
        '## 误报和重复的解释边界','',
        '| 自然情景范围 | 原规则误报 | 其中过早开始、后来覆盖完整事件窗口 | 原重复 | 无豁免重复 | 有豁免重复 |',
        '| --- | ---: | ---: | ---: | ---: | ---: |']
    for block in ('training28','risk_validation7','calibration_full14'):
        ss=r['blocks'][block]['scenarios']['natural'];b=ss['global_c1'];no=ss['effective_no_bypass'];yes=ss['effective_protected_gate']
        lines.append(f"| {labels[block]} | {b['episode_type_counts']['false']} | {b['false_start_spanning_later_complete_window']} | {b['episode_type_counts']['duplicate']} | {no['episode_type_counts']['duplicate']} | {yes['episode_type_counts']['duplicate']} |")
    lines+=['',
        '自然验证22次原误报中4次告警起点过早，但随后阳性段跨入某个完整事件的可匹配窗口。标签/告警分段方式会影响误报、重复和漏检的含义。本轮完整记录，不把这4次事后改作正确告警；同样，重复没有计作误报，但用户仍可能收到多次通知，项目展示不应只用误报率表示全部告警负担。','',
        '## 标签重建与工程核查','',
        '| 范围 | 非边界可回推标签检查数 | 30mph附近精度带排除 | 缓存不足/断点/尾部未知 | 不一致数 |',
        '| --- | ---: | ---: | ---: | ---: |']
    for block,v in r['blocks'].items():
        q=v['label_reconstruction'];lines.append(f"| {labels[block]} | {q['nonambiguous_eligible_points_checked']} | {q['eligible_precision_band_excluded']} | {q['eligible_unrecoverable_points']} | {q['label_mismatches']} |")
    total=sum(r['blocks'][b]['label_reconstruction']['nonambiguous_eligible_points_checked'] for b in ('training28','risk_validation7','calibration_full14'))
    lines+=['',
        f'三个不重叠开发范围共核查{total:,}个原生时间×站点标签，没有不一致；包括校准两半的工作量是432,963次标签检查，后者有重叠不能作独立样本量。车速从float32历史特征反推，±0.0001 mph精度带的边界值被明确排除；本轮未读原HDF5，不声称替代原float64原始数据核验。真实案例30.1的偏离远大于该精度带，标签分段不能归因于这个反标准化舍入误差。','',
        '11项测试通过，覆盖一次越线造成三次标签阴性、低速历史后的R15重启、两种时钟参考、缓存偏移/尾部/未知/精度边界、断点与历史因果性，以及过早覆盖但未获记、同一事件重复、边界删失三种匹配案例。独立实现核对45次完整回放、391条共享完整事件（含重叠子块）、899条相关方法/情景预警记录和3条同事件情景时间线，36组旧开发激活逐位一致。','',
        '原论文主检验失败、上一轮候选验收失败均保持。模型、标签、线上GitHub v7、Word/PPT没有修改。真实缓存与明细本地保存。','',
        '## 下一轮建议','',
        '先在固定规则下把告警目标分清：从此前非低速进入持续低速，和已有低速之后短暂越线再进入持续低速。若检验“至少两条连续高车速观测才认为前一事件结束”等替代定义，须事先固定它，只作为标签语义敏感性分析，同时保留原评价；不能拿改定义后的成绩替换原失败结论。此处只是下一轮可检验方案，本轮未执行替代定义或新事件合并。','',
        '论文定义补充单独保存为docs/thesis_proxy_semantics_note.zh-CN.md，可在后续论文修订时引用。本轮不覆盖旧正文，方便追踪结论与版本。','']
    (out/'report.zh-CN.md').write_text('\n'.join(lines),encoding='utf-8')
    note='''# 可用于后续论文修订的指标定义补充

本研究的事件真值为“持续低速代理事件”，而非经现场确认的拥堵起始事件。对5分钟采样序列，设Y(t)=1{v(t)≤30,v(t+1)≤30,v(t+2)≤30}，仅在三次观测有效且时间连续时评价。事件由有效时段内Y的连续阳性段定义；其前两个标签可判断并且右端结束已知时，纳入完整事件评价。

一条高于30mph的观测即可使三个包含它的标签阴性，从而分割前后两个持续低速代理事件。故某次获记提前告警可能在历史已有低速观测时发出，针对后续再次持续低速，而不代表对首次现实拥堵的提前发现。短暂越线是否意味着现实拥堵结束需进一步的交通语义及外部标注支持；本文不将其先验认定为测量噪声或真实畅通。

模型在origin=a使用a−12至a−1的历史观测，预测a至a+2。原评价提前量L=5(s−a+1)分钟，其中s为代理事件起点，时间参考为最后历史观测a−1；按origin=a的标记时刻计算，间隔为5(s−a)分钟。实验应分别说明这两种参考；未记录现场发布时间或计算完成时刻，不将L等同于实测可用处置时间。

事件匹配采用告警阳性段起点的一对一匹配。起点必须落入[s−2,e)窗口；同一事件后续起点作重复，过早起点即使后来覆盖窗口仍可能作误报。误报率未涵盖全部重复通知负担，故应同时报告重复告警、迟报和删失。

2026-10-16开发诊断发现：验证自然情景5个原R10事件中2个告警起点的末次已有观测低速，1个已有连续三条低速；被豁免保护的15分钟代理预警所对应事件，是一次30.1mph读数越线后的新标签阳性段。其15分钟从18:05最后历史观测计算到18:20代理事件起点；从18:10告警origin计算是10分钟。这是已复用开发数据的定义诊断，不是模型优势、独立外部验证或首次拥堵预警能力的确认。

原标签、评分实现和失败结论保持。任何替代事件定义须另外预先固定，只作敏感性分析并与原指标并列，不能为获得有利结果而事后合并事件。详见outputs/proxy-event-semantics-2026-10-16/report.zh-CN.md。
'''
    (root/'docs/thesis_proxy_semantics_note.zh-CN.md').write_text(note,encoding='utf-8')
    (root/'docs/proxy_event_semantics_handoff.zh-CN.md').write_text('''# 接续：代理事件分段和提前量（2026-10-16）

本轮已完成并保存固定规则语义诊断。用户本科论文题目《面向观测缺失的交通拥堵告警风险校准与事件级决策方法研究》，standing preference保存。原论文主检验/上轮候选验收仍失败。

源码proxy_event_semantics.py / audit_proxy_event_semantics.py / summarize_proxy_event_semantics.py / save_proxy_event_semantics_checkpoint.py；报告outputs/proxy-event-semantics-2026-10-16/report.zh-CN.md，results/audit/plan/completion/test_receipt和timeline.png。补充定义docs/thesis_proxy_semantics_note.zh-CN.md，未修改旧正文Word/PPT或线上。

关键案例原验证node12, event508, alarm506：17:55/18:00/18:05已有速度26.8/27.2/26.5；18:15样本30.1仅高0.1mph，导致Y(18:05/18:10/18:15)=0，18:20新代理事件开始。一条高样本会制造三个阴性标签。之前已有低速，不能说首次实际拥堵前预警。30.1是未来离线证据，在线豁免不使用它。三情景是同一真实事件。

原L=5(s−a+1)从最后历史观测时间算，18:05→18:20=15；从告警origin18:10算则10分钟。899相关方法/情景预警记录时间参考一致，不是发现原实现索引bug，不能直接改旧R10。未记录现场实际发布时间。

完整代理事件训练198/验证55/校准69；有前序且三阴性标签（已回推单次高样本桥）13/6/3。原自然R10训练30中18末观测低、3已有三条低；验证5中2末观测低、1已有三条低；校准4中1末观测低、0三条低。

仅使用原开发缓存natural fresh own_last(t)=v(t−1)回推，未知保留，近30±0.0001mph精度带排除；三个不重叠块336687标签零不一致，包括半块432963检查有重复。11测试、45回放、391共享事件（有半块重叠）、899预警记录、3同事件情景时间线独立核查；36旧后续开发激活逐位复现。零优化更新/新模型/标签改动。原始HDF5/评测/跨站/新站值禁读。

下一轮可预先固定一种事件结束语义（例如两条连续高车速读数），只作语义敏感性并与旧定义并列；或先按既有历史分别统计首次进入与短暂回升后重入。不能通过改标签让旧失败变通过；不能看到样本拼条件选新豁免阈值。上述新定义/新分组/新策略本轮都未执行，需要另封存。保持原模型SHA1bea8ed689c6ac23dbcdec44212aed4bb3402ebb26a5f73f95aca7b92f9e6f21与分界线0.4388462325645476。

最新累计包traffic-recovery-lab-2026-10-16-proxy-event-semantics.zip，先10月11日完整基包后本包；旧包和所有科学文件保留，仅根README和CURRENT_STATE加本轮说明。基包CRC本轮未重查，依赖既有已验证回执。
''',encoding='utf-8')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import matplotlib.dates as mdates
    times=np.array([p['timestamp'] for p in case['rows']],dtype='datetime64[ns]')
    speeds=np.array([p['cached_actual_speed_mph'] for p in case['rows']])
    fig,axes=plt.subplots(2,1,figsize=(12,6.5),sharex=True,gridspec_kw={'height_ratios':[2,1]},facecolor='#f5f8fa')
    axes[0].plot(times,speeds,'o-',color='#247b83',label='Observed speed reconstructed from frozen natural cache')
    axes[0].axhline(30,color='#a86356',ls='--',label='30 mph threshold')
    axes[0].scatter(times[7],speeds[7],s=100,color='#b74848',zorder=4)
    axes[0].annotate('30.1 mph: ONE crossing\ncreates THREE negative proxy labels',xy=(times[7],speeds[7]),
        xytext=(times[3],34),arrowprops={'arrowstyle':'->','color':'#b74848'},fontsize=10)
    axes[0].set_ylabel('Speed (mph)');axes[0].set_ylim(15,38);axes[0].legend(loc='lower right',fontsize=8)
    axes[1].step(times,[int(p['proxy_label']) for p in case['rows']],where='post',color='#247b83',label='Proxy label: next three speeds <=30')
    alarmtimes=[times[i] for i,p in enumerate(case['rows']) if p['activations']['effective_protected_gate']]
    axes[1].scatter(alarmtimes,np.full(len(alarmtimes),1.35),marker='v',color='#5b7dad',label='Fixed primary alarm active')
    axes[1].set_ylim(-.15,1.85);axes[1].set_yticks([0,1],['0','1']);axes[1].set_ylabel('Proxy Y');axes[1].legend(loc='lower left',fontsize=8)
    # Case window starts at origin500: last observation505, alarm506, onset508.
    for ax in axes:
        ax.axvline(times[5],ls=':',color='#6e859d',lw=1)
        ax.axvline(times[6],ls='--',color='#6e859d',lw=1)
        ax.axvline(times[8],ls='--',color='#947655',lw=1)
        ax.spines[['top','right']].set_visible(False)
    axes[1].text(times[5],1.65,'Last history\n18:05',ha='right',fontsize=8)
    axes[1].text(times[6],1.65,'Alarm origin\n18:10',ha='left',fontsize=8)
    axes[1].text(times[8],1.65,'New proxy event\n18:20',ha='left',fontsize=8)
    axes[1].xaxis.set_major_formatter(mdates.DateFormatter('%H:%M'))
    fig.suptitle('Protected proxy R15: brief threshold crossing, not demonstrated first congestion onset',fontsize=12)
    fig.text(.5,.02,'Last-history clock: 18:05 to18:20 =15 min. Origin clock: 18:10 to18:20 =10 min. One shared reused-development event.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.05,1,.94));fig.savefig(out/'timeline.png',dpi=150);plt.close(fig)
    print({'report':str(out/'report.zh-CN.md'),'nonoverlapping_label_checks':total,'tests':11})


if __name__=='__main__':main()
