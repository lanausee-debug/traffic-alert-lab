"""Report the failed primary pilot and preserve actual targeted test results."""
import io
from pathlib import Path
import unittest
import numpy as np
import adaptive_confirmation as pilot
import calibration_fragility as common
ROOT=pilot.ROOT;OUT=pilot.OUT
def pct(value):return '不可计算' if value is None else f'{100*value:.2f}%'


def main():
    r=common.read(OUT/'results.json');audit=common.read(OUT/'audit.json')
    assert audit['passed'] and not r['primary_acceptance_passed']
    stream=io.StringIO()
    suite=unittest.defaultTestLoader.discover(str(ROOT/'tests'),pattern='test_adaptive_confirmation.py')
    tests=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    assert tests.wasSuccessful() and tests.testsRun==11,stream.getvalue()
    common.write(OUT/'test_results.json',{'tests_run':tests.testsRun,'passed':True,'output':stream.getvalue()})
    transitions=common.read(OUT/'paired_event_transitions.json')
    full=r['means']['calibration_full14'];before=full['global_c1'];after=full[pilot.PRIMARY]
    reduction=1-after['false_per_valid_station_day']/before['false_per_valid_station_day']
    lines=['# 历史残差触发的新告警二次确认：开发筛查未通过','',
        '日期：2026-10-15。**固定主规则>5 mph未通过预先冻结的开发验收。** 没有训练新网络、修改原模型、调整风险阈值或启动新站点测试。','',
        '## 本轮检验的问题','',
        '上一轮在开发数据发现较大历史残差时误报起点集中。本轮检验：仅在这类状态准备新开告警时要求两次确认，能否减少误报而不损失真实起点的服务。该思路在看到上一轮关联后提出，属于自适应开发，不是独立发现。','',
        '使用原全局风险p≥0.46。时刻t的残差为上一时刻一步预测f(t−1|历史≤t−2)−刚能观察到的车速v(t−1)，仅在5分钟连续、origin相邻、本站最新观测有效且年龄为0时可用。主规则为残差严格>5 mph且当前未激活告警时，要求上一时刻风险也达标；其余时刻按原一次确认。已经激活的告警只在原风险不再达标时结束，不因残差波动切碎。无残差时退回原一次确认；时钟断点重置状态。','',
        '原全局一次确认、全局统一两次确认为参考；>3和>7 mph仅用于预定敏感性检查，不得替代失败的>5主规则。没有搜索新的概率阈值、补加候选或改变验收线。','',
        '## 预先冻结的验收','',
        '- 14日完整校准段：平均误报至少减少10%，各情景不超过原校准预算。','- 完整校准段及三个7日开发块分别检查：每个情景误报不高于原全局一次确认，R10不下降，检出下降不超过2个百分点。','- 任一条件不满足或分母不可计算即不通过。若主规则失败，不改用敏感性检查中的另一规则。','- 本轮目标是“降低误报且保护检出/提前量”，与之前“R10至少增加2个百分点”是不同假设；不能写成本轮通过了之前未通过的目标。','',
        '## 14日校准结果','',
        '69个完整低速代理事件，三种观测情景共享真值；以下为三情景等权平均。原风险验证7日和本校准14日均被项目用于过选择或反复开发，不能当成新的独立测试。','',
        '| 方法 | R10 | 含迟报检出率 | 误报/有效站日 |',
        '| --- | ---: | ---: | ---: |']
    labels={'global_c1':'原全局一次确认','global_c2':'统一两次确认','residual_gt3':'>3 mph（敏感性）','residual_gt5':'>5 mph（主规则）','residual_gt7':'>7 mph（敏感性）'}
    for method,label in labels.items():
        row=full[method];lines.append(f"| {label} | {pct(row['warning_recall_at_least10'])} | {pct(row['detection_recall'])} | {row['false_per_valid_station_day']:.6f} |")
    lines+=['',f"主规则误报减少{100*reduction:.2f}%，未达10%；R10保持{pct(after['warning_recall_at_least10'])}，检出下降{100*(before['detection_recall']-after['detection_recall']):.2f}个百分点。自然/单站/成组缺失情景误报分别31→29、30→28、24→22；这些不是三组独立事件，不能把少报的告警加起来当独立证据。",'',
        '## 时间块检查','',
        '| 时间块 | 事件数 | R10：原→主规则 | 检出：原→主规则 | 误报：原→主规则 | 块内三项约束 |',
        '| --- | ---: | --- | --- | --- | --- |']
    for block,methods in r['means'].items():
        a=methods['global_c1'];b=methods[pilot.PRIMARY];events=int(r['evaluation'][block]['global_c1']['natural']['events'])
        cells=[pct(a['warning_recall_at_least10'])+'→'+pct(b['warning_recall_at_least10']),
            pct(a['detection_recall'])+'→'+pct(b['detection_recall']),
            f"{a['false_per_valid_station_day']:.6f}→{b['false_per_valid_station_day']:.6f}"]
        passed=r['gates'][pilot.PRIMARY]['block_checks'][block]['passed']
        lines.append(f"| {block} | {events} | {' | '.join(cells)} | {'通过' if passed else '未通过'} |")
    lines+=['','完整校准14日包含其前/后两个7日块，不能重复计作更多独立样本。风险验证7日主规则的R10三情景各损失2/55个代理事件，成组缺失检出下降超过2个百分点；校准后一周三个情景各损失1/32个检出事件，下降3.125个百分点，均未守住块内门槛。','',
        '## 真实事件为什么受影响','',
        '逐个对齐同一站点、同一起点的完整事件：在完整校准段，自然/单站情景各有4个原本提前报出的事件变为迟报，成组缺失有3个；三个情景各有1个原迟报事件变为漏报。R10在完整校准段没有变化，并不代表所有提前预警服务都保持。','',
        '风险验证块中，每个情景有2个原满足≥10分钟代理提前量的事件失去该资格；自然/单站各有1个原检出事件变为漏报，成组缺失有2个。较大历史残差既可能出现在短时波动，也可能出现在真实低速起点，直接多等一帧可能延后或完全抑制短告警。当前结果不支持“看到大残差就延后”的通用做法。','',
        '这不意味着前一轮分层统计计算错了：关联成立与可操作的改进策略成立是不同问题。也不能据此断言所有状态相关确认都无效；本轮只检验了已冻结的三种残差阈值及既定规则。','',
        '## 校准日期配对的描述区间','',
        '2000次共同抽取14个日期，种子20261015，各情景使用相同日期索引。以下95%区间条件于原模型，数据已反复参与开发，因此只用于描述，不是新的确认性检验。R10在该14日的配对差均为0；这不证明其他时段或总体无损。','',
        '| 主规则−原全局 | 点估计 | 95%描述区间 |',
        '| --- | ---: | --- |']
    for key,mult in [('R10',100),('detection',100),('false_rate',1)]:
        row=r['comparisons_calibration_vs_global_c1'][pilot.PRIMARY][key]
        ci=row['ci95'];lines.append(f"| {key}{'（百分点）' if mult==100 else ''} | {row['difference']*mult:+.4f} | [{ci[0]*mult:.4f}, {ci[1]*mult:.4f}] |")
    lines+=['','误报差区间包含0，当前也没有描述性证据支持稳定误报收益。>3与>7敏感性规则同样未通过联合筛查，没有用其中任何一项替换主规则。','',
        '## 工程与研究状态','',
        '11项针对性测试通过：包括无/大残差退化到一次/两次确认、已有告警不被切碎、时间断点、严格>5边界、未来输入变化不影响前缀、缺失/未来真值不进入残差、不可计算分母和服务约束，以及多确认一帧确实可能损失10分钟预警的反例。','',
        '独立审计按原风险连续段重建全部36组动态激活，而非重用在线递推实现；60组告警回放、逐事件状态转移、日期配对统计、来源哈希与原科学文件保持均核对通过。','',
        '原论文主检验失败状态保留，论文与公开GitHub/在线Demo仍为v7。本轮只保存开发试验，没有修改线上规则或宣称模型获得稳定提升。','',
        '下一步先检验“误报起点与真实起点在当时已有信息下是否可区分”，采用明确时间分块和强简单基准。若现有特征没有额外可重复的判别能力，就停止追加同类确认参数，转向补充有依据的信息或缩小论文结论；不继续在已见评测上筛选。此可分性分析本轮尚未执行。','']
    (OUT/'report.zh-CN.md').write_text('\n'.join(lines),encoding='utf-8')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(1,3,figsize=(12,4.6),facecolor='#f5f8fa')
    methods=['global_c1','global_c2',pilot.PRIMARY]
    for ax,(metric,title,mult) in zip(axes,[('warning_recall_at_least10','Proxy warning >=10 min (%)',100),('detection_recall','Detection incl. late (%)',100),('false_per_valid_station_day','False alerts / valid station-day',1)]):
        vals=[full[m][metric]*mult for m in methods]
        bars=ax.bar(range(3),vals,color=['#8297ab','#ae9cba','#137c83'],width=.65)
        ax.set_xticks(range(3),['Original c1','Always c2','Adaptive >5'],fontsize=9)
        ax.set_title(title,fontsize=10);ax.spines[['top','right']].set_visible(False)
        ax.set_ylim(0,100 if metric=='detection_recall' else max(vals)*1.35)
        for bar,value in zip(bars,vals):ax.text(bar.get_x()+bar.get_width()/2,bar.get_height(),f'{value:.2f}' if mult==100 else f'{value:.3f}',ha='center',va='bottom',fontsize=10)
    fig.suptitle('Adaptive start confirmation: declared primary screen FAILED',fontsize=13)
    fig.text(.5,.025,'Reused development calibration only / 69 shared proxy events. Other development block loses warning recall.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.08,1,.91));fig.savefig(OUT/'comparison.png',dpi=150);plt.close(fig)
    print({'report':str(OUT/'report.zh-CN.md'),'tests_passed':tests.testsRun,'primary_passed':False})


if __name__=='__main__':main()
