"""Adaptive identity-feature ablation. Development partitions only; no test access.

Removing explicit identity does not make the whole pipeline station independent:
the upstream GraphTCN still has node-specific parameters and needs adaptation.
"""
from __future__ import annotations
import copy
from datetime import datetime, timezone
import hashlib
from pathlib import Path
import sys
import time

import numpy as np
import torch
from torch import nn

import improve_alert_recall as common
from congestion_alert_pilot import SCENARIOS
from congestion_risk_pilot import RiskModel, score, sigmoid
from pems_bay_alert_replay import alarm, replay
from train_pems_bay_risk import load_risk

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs/station-agnostic-risk-2026-10-15'
RISK=ROOT/'outputs/pems-bay-risk'
CAL=ROOT/'outputs/pems-bay-calibration'
KEEP=np.r_[0:24,48:51]
SEEDS=(202,203,204)
BOUNDS=(0.5,1.0)
CHECKS=(0,225,450,900,1350)
READS=[]
sha=common.sha
read=common.read
write=common.write


def guard(event,args):
    if event!='open' or not isinstance(args[0],(str,bytes)):return
    name=str(args[0]).replace('\\','/').lower()
    if (name.endswith(('.h5','.hdf5')) or '/data/raw/' in name or
        any(token in name for token in ('/pems-bay-evaluation/', '/new-station-transfer-',
                                        '/station-agnostic-transfer-', '/historical-replay/'))):
        raise PermissionError('Identity ablation may only use development risk partitions')
    if name.endswith(('.npz','.pt','.json')) and '/outputs/' in name:
        READS.append(name)


class StationAgnosticRisk(nn.Module):
    def __init__(self,bound):
        super().__init__()
        self.bound=bound
        self.residual=RiskModel(len(KEEP),True)
        nn.init.zeros_(self.residual.layers[-1].weight)
        nn.init.zeros_(self.residual.layers[-1].bias)
    def forward(self,x):
        if x.shape[-1]!=28:raise ValueError('Expected 27 state features plus anchor logit')
        return x[:,-1]+self.bound*torch.tanh(self.residual(x[:,:27]))


def inputs(part,norm,anchor,supervised=False):
    values=[]
    for scenario in SCENARIOS:
        raw=part[f'{scenario}_state']
        single=part[f'{scenario}_single']
        raw=raw[part['common']] if supervised else raw.reshape(-1,51)
        single=single[part['common']] if supervised else single.reshape(-1)
        state=((raw[:,KEEP]-norm['mean'][KEEP])/norm['std'][KEEP]).astype(np.float32)
        one=((single[:,None]-norm['single_mean'])/norm['single_std']).astype(np.float32)
        values.append(np.column_stack((state,score(anchor,one))).astype(np.float32))
    return np.concatenate(values) if supervised else dict(zip(SCENARIOS,values))


def freeze_plan():
    OUT.mkdir(exist_ok=True)
    names=['station_agnostic_risk.py','improve_alert_recall.py','congestion_risk_pilot.py',
        'train_pems_bay_risk.py','pems_bay_alert_replay.py','congestion_alert_pilot.py',
        'outputs/pems-bay-risk/global_calibration.pt','outputs/pems-bay-risk/normalization.npz',
        'outputs/pems-bay-risk/risk_train.npz','outputs/pems-bay-risk/risk_validation.npz',
        'outputs/pems-bay-calibration/calibration.npz','outputs/pems-bay-calibration/selection.json',
        'outputs/anchored-risk-2026-10-15/results.json',
        'outputs/anchored-risk-2026-10-15/selection_freeze.json']
    plan={'stage':'adaptive_explicit_station_identity_ablation_after_failed_cohort_A_transfer',
        'prior_failed_test_informed_design':True,'independent_confirmation':False,
        'allowed_partitions':['risk_train','risk_validation','calibration'],
        'forbidden':'raw HDF5, original evaluation, cohort A transfer caches/results, any next-cohort evaluation',
        'hypothesis':'removing explicit node one-hot may reduce identity shortcut dependence; benefit is not assumed',
        'keep_original_feature_indices':KEEP.tolist(),'removed_indices':list(range(24,48)),
        'architecture':'frozen_global_logit + bound*tanh(MLP_27_32_16_1)',
        'normalization':'slice original risk-train-only normalization; no refit',
        'target':'persistent_truth OR impending_onset on common-valid rows, pooled 3 scenarios',
        'bounds':list(BOUNDS),'seeds':list(SEEDS),'updates_per_model':1350,'batch_size':4096,
        'optimizer':'Adam lr0.001 weight_decay0.001, identical minibatch sampling to prior identity-bearing trial',
        'checkpoint_selection':'minimum risk-validation union BCE at 0/225/450/900/1350',
        'threshold_grid':'0.01..0.90 step0.005 plus1.0001; confirmation1/2',
        'constraints':'each scene false rate <= original calibration budget; detection >= original global fine minus0.02',
        'rank':'max mean R10, max worst detection, min mean false rate, family declaration order, confirmation, grid index',
        'pilot_acceptance':'all scene constraints and mean R10 >= original global fine +0.02',
        'on_failure':'stop; do not loosen gate, add candidates, or consume third station cohort',
        'on_success':'freeze choice; choose third 24-station cohort by metadata hash excluding all48 previously used stations; new front-end fit only first42/7 days; one evaluation after all seals',
        'explicit_identity_removed_only':True,'whole_pipeline_zero_shot':False,
        'source_and_input_sha256':{name:sha(ROOT/name) for name in names},
        'torch_version':torch.__version__,'numpy_version':np.__version__}
    path=OUT/'plan.json'
    if path.exists():assert {k:v for k,v in read(path).items() if k!='frozen_at_utc'}==plan
    else:write(path,{**plan,'frozen_at_utc':datetime.now(timezone.utc).isoformat()})
    return plan


def fit(x,y,xv,yv,seed,bound):
    torch.manual_seed(seed)
    model=StationAgnosticRisk(bound)
    xt,yt=torch.tensor(x),torch.tensor(y)
    optimizer=torch.optim.Adam(model.parameters(),lr=.001,weight_decay=.001)
    rng=torch.Generator().manual_seed(seed+17)
    logits=score(model,xv)
    assert np.array_equal(logits,xv[:,-1])
    best=float(np.mean(np.logaddexp(0,logits)-yv*logits))
    selected=copy.deepcopy(model.state_dict());chosen=0
    logs=[{'step':0,'validation_union_bce':best}]
    digest=hashlib.sha256();updates=0
    for step in range(1,1351):
        model.train();ids=torch.randint(len(x),(4096,),generator=rng)
        digest.update(ids.numpy().astype(np.int32).tobytes())
        optimizer.zero_grad(set_to_none=True)
        loss=nn.functional.binary_cross_entropy_with_logits(model(xt[ids]),yt[ids])
        loss.backward();optimizer.step();updates+=1
        if step in CHECKS:
            logits=score(model,xv);bce=float(np.mean(np.logaddexp(0,logits)-yv*logits))
            logs.append({'step':step,'validation_union_bce':bce})
            if bce<best:best=bce;chosen=step;selected=copy.deepcopy(model.state_dict())
    model.load_state_dict(selected);model.eval()
    assert np.max(np.abs(score(model,xv)-xv[:,-1]))<=bound+1e-5
    return model,{'seed':seed,'bound_logit':bound,'actual_optimizer_updates':updates,
        'selected_step':chosen,'batch_size':4096,'train_rows':len(x),'validation_rows':len(xv),
        'validation_union_bce':best,'logs':logs,'minibatch_index_sha256':digest.hexdigest(),
        'parameters':sum(p.numel() for p in model.parameters())}


def main():
    sys.addaudithook(guard)
    torch.set_num_threads(1);torch.use_deterministic_algorithms(True)
    plan=freeze_plan()
    norm=common.load(RISK/'normalization.npz');anchor=load_risk(RISK/'global_calibration.pt')
    tr=common.load(RISK/'risk_train.npz');va=common.load(RISK/'risk_validation.npz')
    x=inputs(tr,norm,anchor,True);xv=inputs(va,norm,anchor,True)
    target=lambda part:np.tile((part['truth']|part['onset'])[part['common']],3).astype(np.float32)
    y,yv=target(tr),target(va);del tr,va
    training={};fitted={}
    for bound in BOUNDS:
        method='agnostic_bound'+str(bound).replace('.','_')
        fitted[method]=[];training[method]=[]
        for seed in SEEDS:
            path=OUT/f'{method}_seed{seed}.pt';record_path=path.with_suffix('.json')
            if path.exists() and record_path.exists():
                record=read(record_path)
                assert sha(path)==record['weight_sha256'] and record['plan_sha256']==sha(OUT/'plan.json')
                model=StationAgnosticRisk(bound)
                model.load_state_dict(torch.load(path,weights_only=True)['state_dict']);model.eval()
            elif path.exists() or record_path.exists():raise ValueError('Incomplete artifacts preserved')
            else:
                started=time.perf_counter();model,record=fit(x,y,xv,yv,seed,bound)
                torch.save({'state_dict':model.state_dict(),'bound':bound,'keep_indices':KEEP.tolist()},path)
                record.update({'training_seconds':time.perf_counter()-started,
                    'weight_sha256':sha(path),'plan_sha256':sha(OUT/'plan.json')})
                write(record_path,record)
            fitted[method].append(model);training[method].append(record)
            print(f'{method} seed={seed} selected_step={record["selected_step"]} BCE={record["validation_union_bce"]:.6f}',flush=True)
    write(OUT/'training.json',training)
    write(OUT/'training_freeze.json',{'frozen_at_utc':datetime.now(timezone.utc).isoformat(),
        'plan_sha256':sha(OUT/'plan.json'),'weights':{p.name:sha(p) for p in sorted(OUT.glob('*.pt'))},
        'calibration_used_for_checkpoint_selection':False})
    part=common.load(CAL/'calibration.npz');xx=inputs(part,norm,anchor)
    old=read(CAL/'selection.json');budgets=old['budgets']
    reference=old['methods']['global_calibration']['fine']['selected']['by_scenario']
    candidates=[];families={}
    for index,(method,models) in enumerate(fitted.items()):
        scores={s:np.mean([sigmoid(score(model,xx[s])) for model in models],axis=0).reshape(part['truth'].shape) for s in SCENARIOS}
        np.savez_compressed(OUT/(method+'_calibration_scores.npz'),**scores)
        rows=[]
        for gi,threshold in enumerate([round(v/1000,3) for v in range(10,901,5)]+[1.0001]):
            for confirmation in (1,2):
                by_s={s:replay(part,alarm(scores[s],threshold,confirmation,part),details=True)[0] for s in SCENARIOS}
                rows.append({'method':method,'method_index':index,'grid_index':gi,
                    'threshold':threshold,'confirmation':confirmation,'by_scenario':by_s})
        selected=common.select(rows,reference,budgets)
        families[method]={'feasible_settings':sum(row['feasible'] for row in rows),'selected':selected}
        write(OUT/(method+'_calibration_grid.json'),rows)
        if selected:candidates.append(selected)
        print(f'{method}: feasible={families[method]["feasible_settings"]}',flush=True)
    selected=common.select(candidates,reference,budgets)
    means=lambda rows:{key:common.mean(rows,key) for key in ('warning_recall_at_least10','warning_recall','detection_recall','false_per_valid_station_day')}
    previous=read(ROOT/'outputs/anchored-risk-2026-10-15/results.json')
    result={'stage':'identity_ablation_development_calibration','independent_test_executed':False,
        'evaluation_values_read':False,'calibration_events':int(replay(part,alarm(np.zeros(part['truth'].shape),1.,1,part),details=True)[0]['events']),
        'calibration_days':14,'budgets':budgets,'reference_global':means(reference),
        'previous_identity_bearing_candidate':previous['selected_means'],
        'candidate_families':families,'selected':selected,
        'selected_means':means(selected['by_scenario']) if selected else None,
        'pilot_acceptance_passed':selected is not None and common.mean(selected['by_scenario'],'warning_recall_at_least10')>=common.mean(reference,'warning_recall_at_least10')+.02-1e-12,
        'identity_removal_causal_benefit_proven':False,
        'limitation':'Repeated adaptive development on only14 calibration days; no claim of transfer or external independent confirmation. Upstream model remains station specific.'}
    write(OUT/'results.json',result)
    write(OUT/'selection_freeze.json',{'frozen_at_utc':datetime.now(timezone.utc).isoformat(),
        'plan_sha256':sha(OUT/'plan.json'),'results_sha256':sha(OUT/'results.json'),
        'selected':{k:v for k,v in selected.items() if k!='by_scenario'} if selected else None,
        'pilot_acceptance_passed':result['pilot_acceptance_passed'],'evaluation_values_read':False})
    for name,digest in plan['source_and_input_sha256'].items():assert sha(ROOT/name)==digest,name
    write(OUT/'access_log.json',{'logical_development_loads':sorted(set(common.READS)),
        'runtime_output_open_paths':sorted(set(READS)),
        'runtime_forbidden_open_guard_enabled':True,'old_input_hashes_unchanged':True,
        'evaluation_or_raw_hdf5_values_read':False})
    print({k:result[k] for k in ('reference_global','selected_means','pilot_acceptance_passed')},flush=True)


if __name__=='__main__':main()
