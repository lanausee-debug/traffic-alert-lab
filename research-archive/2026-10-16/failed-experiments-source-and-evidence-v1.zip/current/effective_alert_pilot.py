"""Include credited late detections in training; preserve early-event constraints.

One fixed new ridge logistic model. Training-only threshold, original normalizer,
same episode policy and development gate; no transfer-cache or raw-data access.
"""
from __future__ import annotations
from datetime import datetime,timezone
from pathlib import Path
import sys
import numpy as np
import torch
import alarm_start_separability as probe
import calibration_fragility as common
import early_warning_protection as protection
from congestion_alert_pilot import SCENARIOS
from pems_bay_alert_replay import alarm,replay,layout
from train_pems_bay_risk import load_risk
from adaptive_confirmation import block_gate,paired_counts

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs/effective-alert-pilot-2026-10-16'
PRIMARY='effective_protected_gate'
ALPHA=.1


def build_training(part,probabilities):
    data={};counts={}
    for s in SCENARIOS:
        active=alarm(probabilities[s],.46,1,part)
        _,_,events=replay(part,active,details=True)
        event_map={(r['node'],r['alarm_start_origin']):r for r in events if r['status'] in ('warned','late')}
        episodes=common.episodes(part,active)
        rows=[r for r in episodes if r['kind'] in ('warned','late','false')]
        at=np.array([r['row'] for r in rows],int);node=np.array([r['node'] for r in rows],int)
        kind=np.array([r['kind'] for r in rows])
        lead=[];event_origins=[]
        for rec in rows:
            event=event_map[(rec['node'],int(part['origins'][rec['row']]))] if rec['kind']!='false' else None
            lead.append(int(event['lead_minutes']) if event and event['status']=='warned' else 0 if event else -1)
            event_origins.append(int(event['event_start_origin']) if event else -1)
        times=part['timestamps'][part['origins'][at]]
        data[s]={'x':probe.start_features(part,s,probabilities[s])[at,node],
            'y':(kind!='false').astype(np.int8),'kind':kind,'lead_minutes':np.array(lead,int),
            'node':node,'row':at,'origin':part['origins'][at],'event_origin':np.array(event_origins,int),
            'date':times.astype('datetime64[D]').astype(str),'timestamp':times.astype(str)}
        counts[s]={k:sum(r['kind']==k for r in episodes) for k in ('warned','late','false','duplicate','censored','unknown')}
    return {key:np.concatenate([v[key] for v in data.values()]) for key in data['natural']},counts


def fit_effective(training,old_model):
    """Reuse old training-only scaling to avoid a simultaneous normalization change."""
    x=training['x'];y=training['y'].astype(float)
    if len(np.unique(y))!=2:raise ValueError('One training class; fixed plan infeasible')
    indices=old_model['indices'].copy();assert indices.tolist()==list(range(30))
    mean=old_model['mean'].copy();std=old_model['std'].copy()
    xt=torch.tensor((x[:,indices]-mean)/std,dtype=torch.float64);yt=torch.tensor(y,dtype=torch.float64)
    layer=torch.nn.Linear(30,1,dtype=torch.float64)
    with torch.no_grad():layer.weight.zero_();layer.bias.fill_(float(np.log(y.mean()/(1-y.mean()))))
    optimizer=torch.optim.LBFGS(layer.parameters(),lr=1.,max_iter=500,max_eval=1000,
        tolerance_grad=1e-10,tolerance_change=1e-13,line_search_fn='strong_wolfe')
    calls=0
    def closure():
        nonlocal calls
        calls+=1;optimizer.zero_grad(set_to_none=True)
        loss=torch.nn.functional.binary_cross_entropy_with_logits(layer(xt).squeeze(-1),yt)+ALPHA/2*layer.weight.square().sum()
        loss.backward();return loss
    optimizer.step(closure);objective=float(closure().detach())
    gradient=float(max(p.grad.abs().max().item() for p in layer.parameters()))
    if gradient>1e-6:raise ValueError('Fixed solver not converged; no alpha search or tolerance relaxation')
    model={'indices':indices,'mean':mean,'std':std,'weight':layer.weight.detach().numpy().reshape(-1),'bias':layer.bias.detach().numpy()}
    return model,{'parameters':31,'alpha':ALPHA,'optimizer_step_calls':1,
        'closure_evaluations':calls,'LBFGS_iterations':int(optimizer.state[layer.weight]['n_iter']),
        'objective':objective,'max_abs_gradient':gradient,'training_rows':len(y),
        'training_effective_starts':int(y.sum()),'training_false_starts':int((y==0).sum()),
        'old_training_only_normalization_reused':True,'later_values_used':False}


def training_cutoff(training,model):
    probabilities=probe.predict(model,training['x'])
    effective=training['y']==1;early=(training['kind']=='warned')&(training['lead_minutes']>=10)
    if not early.any():raise ValueError('No training early warnings; fixed plan infeasible')
    retained95=probe.retention_threshold(training['y'],probabilities)
    cutoff=min(retained95,float(probabilities[early].min()))
    assert np.all(probabilities[early]>=cutoff)
    assert np.mean(probabilities[effective]>=cutoff)>=.95
    return cutoff,{'training95pct_effective_cutoff':retained95,
        'training_R10_minimum_probability':float(probabilities[early].min()),'protected_cutoff':cutoff,
        'training_R10_rows':int(early.sum()),'training_R15_rows':int(((training['kind']=='warned')&(training['lead_minutes']==15)).sum()),
        'effective_training_fraction_retained':float(np.mean(probabilities[effective]>=cutoff)),
        'all_training_original_R10_retained':True,'later_values_used':False}


def freeze_plan():
    OUT.mkdir(exist_ok=True)
    names=['effective_alert_pilot.py','alarm_start_separability.py','early_warning_protection.py',
        'calibration_fragility.py','adaptive_confirmation.py','pems_bay_alert_replay.py',
        'congestion_alert_pilot.py','congestion_risk_pilot.py','train_pems_bay_risk.py',
        'outputs/pems-bay-risk/risk_train.npz','outputs/pems-bay-risk/risk_validation.npz',
        'outputs/pems-bay-risk/normalization.npz','outputs/pems-bay-risk/global_calibration.pt',
        'outputs/pems-bay-calibration/calibration.npz','outputs/pems-bay-calibration/selection.json',
        'outputs/alarm-start-separability-2026-10-15/state_logistic.npz',
        'outputs/early-warning-protection-2026-10-15/parameter_freeze.json']
    plan={'stage':'adaptive_original_development_effective_alert_label_expansion',
        'client_date':'2026-10-16','previous_failures_informed_target':True,'independent_confirmation':False,
        'primary':PRIMARY,'positive_training_types':['warned','late'],'negative_training_type':'false',
        'excluded_training_types':['duplicate','censored','unknown'],
        'feature_set':'same30 historical/predicted/availability features and causal residual; no future label/lead/type input',
        'normalization':'reuse original frozen warning-only model training mean/std, unchanged',
        'fit':'one31parameter ridge logistic, PyTorchfloat64 LBFGS, alpha0.1 fixed, no validation/model search, gradient<=1e-6',
        'training':'original risk_train28days global0.46/c1 episode starts pooled3scenarios; not independent scenarios',
        'cutoff':'min(max cutoff retaining>=95% effective training positives, minimum score of all original trainingR10 positives), training only',
        'online_policy':'reuse full-run start-only gate, never reconsider veto midrun; primary keeps original observed-last3-low bypass; no future truth or eligibility used',
        'comparators':['original_global_c1','old_warning_only_protected_gate','new_effective_gate_without_bypass'],
        'ablation_substitution_for_primary':False,
        'full_replay_blocks':['calibration_full14','risk_validation7','calibration_week1_7','calibration_week2_7'],
        'primary_gate':'unchanged: each block/scene false<=globalc1, R10>=globalc1, detection>=globalc1-0.02 AND every originalR10 event preserves identity and proxy lead; full14 mean false reduction>=10% and original per-scene budgets',
        'all_development_blocks_previously_reused':True,'new_thesis_primary_or_old_plus2pp_R10_claim':False,
        'no_raw_original_evaluation_or_consumed_transfer_values':'runtime protection.guard; only original development used',
        'on_failure':'preserve all results, no cutoff/model/label/bypass tuning or fresh/consumed station replay',
        'on_pass':'freeze exploratory candidate for separately planned validation; no deployment or station validation this round',
        'uncertainty':'full14 paired date count bootstrap2000, seed20261016; reused-data descriptive intervals only',
        'source_and_input_sha256':{name:common.sha(ROOT/name) for name in names}}
    path=OUT/'plan.json'
    if path.exists():assert {k:v for k,v in common.read(path).items() if k!='frozen_at_utc'}==plan
    else:common.write(path,{**plan,'frozen_at_utc':datetime.now(timezone.utc).isoformat()})
    return plan


def main():
    sys.addaudithook(protection.guard);torch.set_num_threads(1);torch.use_deterministic_algorithms(True)
    plan=freeze_plan()
    if (OUT/'completion.json').exists():
        for n,h in common.read(OUT/'completion.json')['artifacts'].items():assert common.sha(OUT/n)==h
        print('Completed effective-target pilot verified; no repeat fit');return
    norm=common.load(common.RISK/'normalization.npz');anchor=load_risk(common.RISK/'global_calibration.pt')
    old_model=common.load(probe.OUT/'state_logistic.npz')
    train_part=common.load(common.RISK/'risk_train.npz')
    training,counts=build_training(train_part,common.global_scores(train_part,norm,anchor));del train_part
    if (OUT/'effective_model.npz').exists():raise ValueError('Partial training preserved; no automatic overwrite')
    model,fit_record=fit_effective(training,old_model);cutoff,cutoff_record=training_cutoff(training,model)
    np.savez_compressed(OUT/'effective_model.npz',**model);np.savez_compressed(OUT/'training_samples.npz',**training)
    common.write(OUT/'training.json',{'fit':fit_record,'cutoff':cutoff_record,'episode_counts':counts})
    common.write(OUT/'training_freeze.json',{'frozen_at_utc':datetime.now(timezone.utc).isoformat(),
        'plan_sha256':common.sha(OUT/'plan.json'),'model_sha256':common.sha(OUT/'effective_model.npz'),
        'training_samples_sha256':common.sha(OUT/'training_samples.npz'),
        'training_record_sha256':common.sha(OUT/'training.json'),'cutoff':cutoff,'later_blocks_loaded':False})
    print({'fit':fit_record,'cutoff':cutoff_record,'training_counts':counts},flush=True)
    old_cutoff=common.read(ROOT/'outputs/early-warning-protection-2026-10-15/parameter_freeze.json')['parameters']['protected_cutoff']
    val=common.load(common.RISK/'risk_validation.npz');cal=common.load(common.CAL/'calibration.npz')
    parts={'calibration_full14':cal,'risk_validation7':val,
        'calibration_week1_7':common.subset(cal,0,7),'calibration_week2_7':common.subset(cal,7,14)}
    rows={};daily={};activations={};early_checks={}
    for block,part in parts.items():
        probabilities=common.global_scores(part,norm,anchor)
        methods=['global_c1','old_warning_protected','effective_no_bypass',PRIMARY]
        rows[block]={m:{} for m in methods};early_checks[block]={m:{} for m in methods if m!='global_c1'}
        for s in SCENARIOS:
            x=probe.start_features(part,s,probabilities[s]).reshape(-1,30)
            new_p=probe.predict(model,x).reshape(part['truth'].shape);old_p=probe.predict(old_model,x).reshape(part['truth'].shape)
            bypass=protection.observed_past_low(part,s);baseline=alarm(probabilities[s],.46,1,part)
            choices={'global_c1':baseline,
                'old_warning_protected':protection.episode_gate(probabilities[s],old_p,part['origins'],part['timestamps'],old_cutoff,bypass),
                'effective_no_bypass':protection.episode_gate(probabilities[s],new_p,part['origins'],part['timestamps'],cutoff),
                PRIMARY:protection.episode_gate(probabilities[s],new_p,part['origins'],part['timestamps'],cutoff,bypass)}
            for method,active in choices.items():
                key=f'{block}__{method}__{s}'
                rows[block][method][s],daily[key],_=replay(part,active,details=True)
                activations[key]=active
                if method!='global_c1':early_checks[block][method][s]=protection.protect_original_events(part,baseline,active)
        print(block+': '+str({m:common.mean_metrics(v) for m,v in rows[block].items()}),flush=True)
    means={b:{m:common.mean_metrics(v) for m,v in methods.items()} for b,methods in rows.items()}
    budgets=common.read(common.CAL/'selection.json')['budgets'];gates={}
    for method in ('old_warning_protected','effective_no_bypass',PRIMARY):
        service={b:block_gate(methods[method],methods['global_c1']) for b,methods in rows.items()}
        early={b:all(v['all_original_R10_events_and_leads_preserved'] for v in m[method].values()) for b,m in early_checks.items()}
        c=means['calibration_full14'][method]['false_per_valid_station_day'];ref=means['calibration_full14']['global_c1']['false_per_valid_station_day']
        ten=c<=.9*ref+1e-12
        budget={s:rows['calibration_full14'][method][s]['false_per_valid_station_day']<=budgets[s]+1e-12 for s in SCENARIOS}
        gates[method]={'service_block_checks':service,'original_early_event_identity_and_lead_preserved':early,
            'full14_false_reduction_at_least10pct':bool(ten),'full14_original_budget_met':budget,
            'passed':all(v['passed'] for v in service.values()) and all(early.values()) and bool(ten) and all(budget.values()),
            'comparator_only':method!=PRIMARY}
    dates=layout(cal)[2];draws=np.random.default_rng(20261016).integers(0,len(dates),(2000,len(dates)))
    baseline=np.stack([daily[f'calibration_full14__global_c1__{s}'] for s in SCENARIOS])
    comparisons={m:paired_counts(np.stack([daily[f'calibration_full14__{m}__{s}'] for s in SCENARIOS]),baseline,draws) for m in gates}
    result={'stage':'effective_alert_label_expansion_original_development_replay','primary':PRIMARY,
        'fit':fit_record,'cutoff':cutoff_record,'training_episode_counts':counts,
        'evaluation':rows,'means':means,'original_early_event_checks':early_checks,
        'gates':gates,'paired_calibration_comparisons':comparisons,'primary_acceptance_passed':gates[PRIMARY]['passed'],
        'candidate_only_not_deployment':True,'independent_confirmation':False,
        'deep_predictors_refit':False,'new_linear_models_fitted':1,
        'original_thesis_primary_test_still_failed':True,'new_station_cohort_consumed':False,
        'consumed_transfer_values_used_in_this_run':False,
        'limitation':'Adaptive development; additional late-positive rows and target expansion occur together, not a pure isolated label-effect proof. All replay blocks previously reused; no unseen validation.'}
    common.write(OUT/'results.json',result)
    np.savez_compressed(OUT/'daily.npz',**daily);np.savez_compressed(OUT/'activations.npz',**activations)
    np.savez_compressed(OUT/'bootstrap_draws.npz',draws=draws,dates=dates)
    common.write(OUT/'selection_freeze.json',{'frozen_at_utc':datetime.now(timezone.utc).isoformat(),
        'plan_sha256':common.sha(OUT/'plan.json'),'training_freeze_sha256':common.sha(OUT/'training_freeze.json'),
        'results_sha256':common.sha(OUT/'results.json'),'declared_primary':PRIMARY,
        'accepted_for_future_validation':bool(result['primary_acceptance_passed']),
        'comparator_substitution':False,'new_or_consumed_station_values_read':False})
    for n,h in plan['source_and_input_sha256'].items():assert common.sha(ROOT/n)==h,n
    common.write(OUT/'access_log.json',{'runtime_open_paths':sorted(set(common.READS)),
        'raw_and_original_eval_and_consumed_transfer_guard_enabled':True,'forbidden_values_used':False})
    names=['effective_model.npz','training_samples.npz','training.json','training_freeze.json','results.json',
        'daily.npz','activations.npz','bootstrap_draws.npz','selection_freeze.json','access_log.json']
    common.write(OUT/'completion.json',{'completed_at_utc':datetime.now(timezone.utc).isoformat(),
        'plan_sha256':common.sha(OUT/'plan.json'),'artifacts':{n:common.sha(OUT/n) for n in names}})
    print({'primary_acceptance_passed':result['primary_acceptance_passed'],'primary_gate':gates[PRIMARY]},flush=True)


if __name__=='__main__':main()
