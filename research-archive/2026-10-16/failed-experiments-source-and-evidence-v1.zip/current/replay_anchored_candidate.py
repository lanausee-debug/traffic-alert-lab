"""Single fixed-candidate replay on ALREADY USED evaluation data; exploratory only.

This does not change or repeat the thesis's frozen primary test.
"""
from datetime import datetime, timezone
import json
from pathlib import Path
import sys

import numpy as np
import torch

from improve_anchored_risk import AnchoredRisk, inputs
from congestion_alert_pilot import SCENARIOS
from congestion_risk_pilot import score, sigmoid
from pems_bay_alert_replay import alarm, replay
from train_pems_bay_risk import load_risk
from improve_alert_recall import mean, sha, write, read

ROOT=Path(__file__).resolve().parent
CANDIDATE=ROOT/'outputs/anchored-risk-2026-10-15'
OUT=CANDIDATE/'historical-replay'
OLD=ROOT/'outputs/pems-bay-evaluation'


def guard(event,args):
    if event=='open' and isinstance(args[0],(str,bytes)):
        name=str(args[0]).lower()
        if name.endswith(('.h5','.hdf5')):raise PermissionError('No raw HDF5 access in historical replay')


def main():
    sys.addaudithook(guard);torch.set_num_threads(1);torch.use_deterministic_algorithms(True)
    OUT.mkdir(exist_ok=True)
    selection=read(CANDIDATE/'selection_freeze.json')
    result=read(CANDIDATE/'results.json')
    assert sha(CANDIDATE/'results.json')==selection['results_sha256'] and result['pilot_acceptance_passed']
    training=read(CANDIDATE/'training_freeze.json')
    for name,digest in training['weights'].items():assert sha(CANDIDATE/name)==digest
    chosen=selection['selected']
    assert chosen is not None and chosen['method']=='anchored_bound1_0'
    weight_files=[CANDIDATE/f'{chosen["method"]}_seed{seed}.pt' for seed in (202,203,204)]
    plan={'kind':'single_frozen_candidate_historical_replay_not_independent_test',
        'old_evaluation_informed_problem_choice':True,'no_evaluation_grid_search':True,
        'candidate_frozen_before_this_replay':True,'selection_sha256':sha(CANDIDATE/'selection_freeze.json'),
        'method':chosen['method'],'threshold':chosen['threshold'],'confirmation':chosen['confirmation'],
        'source_sha256':{p.relative_to(ROOT).as_posix():sha(p) for p in [Path(__file__),ROOT/'improve_anchored_risk.py',ROOT/'pems_bay_alert_replay.py']},
        'weight_sha256':{p.name:sha(p) for p in weight_files},
        'no_model_or_setting_changes_after_reading_historical_replay':True,
        'report_all_scenarios_and_all_primary_service_metrics':True,
        'comparators':['global_calibration_fine','group_calibration_fine','onset_mlp_fine'],
        'independent_validation_still_required':True}
    if (OUT/'plan.json').exists():
        assert {k:v for k,v in read(OUT/'plan.json').items() if k!='frozen_at_utc'}==plan
    else:write(OUT/'plan.json',{**plan,'frozen_at_utc':datetime.now(timezone.utc).isoformat()})
    if (OUT/'results.json').exists():
        frozen=read(OUT/'completion.json');assert frozen['results_sha256']==sha(OUT/'results.json')
        print('Existing single replay verified; no repeat');return
    original=read(OLD/'results.json');prep=read(OLD/'preparation.json')
    cache=OLD/'evaluation.npz'
    assert sha(cache)==prep['cache_sha256']==original['artifact_sha256']['evaluation.npz']
    with np.load(cache) as archive:
        names=['origins','timestamps','truth','eligible']+[s+'_state' for s in SCENARIOS]+[s+'_single' for s in SCENARIOS]
        part={key:archive[key] for key in names}
    with np.load(ROOT/'outputs/pems-bay-risk/normalization.npz') as archive:norm={k:archive[k] for k in archive.files}
    anchor=load_risk(ROOT/'outputs/pems-bay-risk/global_calibration.pt')
    models=[]
    for path in weight_files:
        saved=torch.load(path,weights_only=True);model=AnchoredRisk(saved['bound']);model.load_state_dict(saved['state_dict']);model.eval();models.append(model)
    x=inputs(part,norm,anchor,False)
    rows={};daily={};alert_burden={}
    for scenario in SCENARIOS:
        scores=np.mean([sigmoid(score(model,x[scenario])) for model in models],axis=0).reshape(part['truth'].shape)
        bits=alarm(scores,chosen['threshold'],chosen['confirmation'],part)
        row,day,_=replay(part,bits,details=True)
        rows[scenario]=row;daily[scenario]=day
        eligible=part['eligible']
        alert_burden[scenario]={'alarm_active_fraction_of_evaluable_ticks':float(bits[eligible].mean()),
            'positive_tick_recall':row['point_all']['recall'],'pointwise_false_positive_rate':row['point_all']['false_positive_rate']}
        assert row['events']==673
    baselines={method:original['evaluation'][method]['fine'] for method in ('global_calibration','group_calibration','onset_mlp')}
    metrics=('warning_recall_at_least10','warning_recall','detection_recall','false_per_valid_station_day')
    means={name:{key:mean(values,key) for key in metrics} for name,values in {**baselines,'anchored_candidate':rows}.items()}
    budget=result['budgets']
    output={'stage':'historical_replay_exploratory_not_independent_confirmation',
        'old_evaluation_values_read_in_this_stage':True,'threshold_grid_search':False,
        'candidate_fixed_before_this_stage':True,'independent_confirmation':False,
        'original_thesis_primary_test_still_failed':True,'original_outputs_changed':False,
        'events':673,'days':83,'scenarios':3,'candidate_settings':chosen,
        'candidate_by_scenario':rows,'means':means,'alarm_burden':alert_burden,
        'differences_vs_global':{key:means['anchored_candidate'][key]-means['global_calibration'][key] for key in metrics},
        'historical_budget_exceedance':{s:{'candidate_rate':rows[s]['false_per_valid_station_day'],
            'calibration_budget':budget[s],'exceeded':rows[s]['false_per_valid_station_day']>budget[s]+1e-12} for s in SCENARIOS},
        'limitation':'Old test has been examined previously; point estimates are exploratory, not a replacement primary result.'}
    write(OUT/'results.json',output);np.savez_compressed(OUT/'daily.npz',**daily)
    write(OUT/'completion.json',{'completed_at_utc':datetime.now(timezone.utc).isoformat(),
        'plan_sha256':sha(OUT/'plan.json'),'results_sha256':sha(OUT/'results.json'),
        'daily_sha256':sha(OUT/'daily.npz'),'no_training_or_threshold_selection_this_stage':True})
    assert sha(cache)==prep['cache_sha256']
    print(json.dumps({'historical_replay_only':True,'means':means,'differences_vs_global':output['differences_vs_global']},ensure_ascii=True))


if __name__=='__main__':main()
