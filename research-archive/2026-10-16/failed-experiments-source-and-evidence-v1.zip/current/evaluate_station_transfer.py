"""Pre-evaluation amendment: unseen stations have unknown (all-zero) identity.

Forecasters have their own trained new-station embeddings. Frozen risk-head
one-hot features must NOT pretend a new station is an old station at that slot.
"""
import argparse
from datetime import datetime,timezone
from pathlib import Path
from unittest.mock import patch

import numpy as np
import torch

import new_station_transfer as transfer

ROOT=transfer.ROOT
OUT=transfer.OUT


def unknown_identity(part,names):
    if names[24:48]!=[f'node{i}' for i in range(24)]:raise ValueError('Unexpected identity feature layout')
    for scenario in transfer.SCENARIOS:
        features=part[scenario+'_state']
        if features.shape[-1]!=51 or features.shape[-2]!=24:raise ValueError('Unexpected cohort feature shape')
        features[...,24:48]=0
    return part


def amendment():
    path=OUT/'identity_amendment.json'
    value={'kind':'pre_evaluation_input_identity_correction',
        'original_plan_sha256':transfer.sha(OUT/'plan.json'),
        'reason':'Code review found node one-hot identity in frozen risk features as well as forecaster embeddings. New station slots are not old station identities.',
        'risk_identity_encoding':'Set raw state feature node0..node23 all to zero for unseen stations, then apply original risk normalization unchanged.',
        'applies_to':'All state-feature risk models, including original onset and anchored candidate; single-score global/group heads do not use identity.',
        'risk_weights_thresholds_and_gate_unchanged':True,
        'new_cohort_evaluation_values_read_before_amendment':False,
        'new_forecaster_training_unchanged':True,
        'source_sha256':{'evaluate_station_transfer.py':transfer.sha(Path(__file__)),
                         'new_station_transfer.py':transfer.sha(ROOT/'new_station_transfer.py')}}
    if path.exists():
        old=transfer.read(path)
        assert {key:item for key,item in old.items() if key!='frozen_at_utc'}==value
    else:
        assert not (OUT/'evaluation_started.json').exists() and not (OUT/'results.json').exists()
        transfer.write(path,{**value,'frozen_at_utc':datetime.now(timezone.utc).isoformat()})
    return path


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--freeze-only',action='store_true');args=parser.parse_args()
    torch.set_num_threads(1);torch.use_deterministic_algorithms(True)
    path=amendment()
    if args.freeze_only:
        print('Unknown station identity correction frozen before evaluation; no speed reads');return
    config,plan=transfer.freeze_plan()
    if (OUT/'results.json').exists():
        result=transfer.read(OUT/'results.json');done=transfer.read(OUT/'completion.json')
        assert result['unseen_risk_identity_all_zero'] and transfer.sha(OUT/'results.json')==done['results_sha256']
        assert done['identity_amendment_sha256']==transfer.sha(path)
        print('Existing amended transfer evaluation verified; no repeated speed read');return
    assert transfer.read(OUT/'preflight.json')['passed']
    original_prepare=transfer.prepare;original_write=transfer.write
    amendment_sha=transfer.sha(path)
    def adapted_prepare(*args,**kwargs):
        part,names,summary=original_prepare(*args,**kwargs)
        unknown_identity(part,names)
        summary['unseen_risk_identity_all_zero']=True
        return part,names,summary
    def bound_write(destination,value):
        if destination.name in ('execution_freeze.json','results.json','completion.json'):
            value={**value,'identity_amendment_sha256':amendment_sha,
                'unseen_risk_identity_all_zero':True,'no_new_station_to_old_identity_slot_mapping':True}
        original_write(destination,value)
    with patch.object(transfer,'prepare',adapted_prepare),patch.object(transfer,'write',bound_write):
        transfer.evaluate(config,plan)
    for name,digest in plan['source_sha256'].items():assert transfer.sha(ROOT/name)==digest
    for name,digest in plan['fixed_risk_weights_sha256'].items():assert transfer.sha(ROOT/name)==digest


if __name__=='__main__':main()
