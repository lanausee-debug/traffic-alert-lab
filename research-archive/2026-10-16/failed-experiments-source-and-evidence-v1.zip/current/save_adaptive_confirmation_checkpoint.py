"""Cumulative archive of the failed declared adaptive-confirmation pilot."""
from datetime import datetime,timezone
from pathlib import Path
import hashlib
from zipfile import ZipFile,ZIP_DEFLATED
from save_station_agnostic_checkpoint import read,write,sha

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs/adaptive-confirmation-2026-10-15'
NAME='traffic-recovery-lab-2026-10-15-adaptive-confirmation'


def main():
    archive=ROOT.parent/'checkpoints'/(NAME+'.zip');receipt=archive.with_name(NAME+'-save-receipt.json')
    if archive.exists() or receipt.exists():raise FileExistsError('Preserve existing archives')
    r=read(OUT/'results.json');audit=read(OUT/'audit.json');tests=read(OUT/'test_results.json')
    assert audit['passed'] and tests['passed'] and tests['tests_run']==11
    assert not r['primary_acceptance_passed'] and not r['new_station_cohort_consumed']
    assert not read(OUT/'selection_freeze.json')['sensitivity_winner_substitution']
    for name,digest in read(OUT/'completion.json')['artifacts'].items():assert sha(OUT/name)==digest
    prior_path='outputs/calibration-fragility-2026-10-15/writing_archive_manifest.json';prior=read(ROOT/prior_path)
    for name,meta in prior['files'].items():assert sha(ROOT/name)==meta['sha256'],name
    summary=('主规则为可观测历史一步残差>5 mph时仅对新告警多确认一次；已有告警不切碎、风险阈值0.46固定。'
        '完整开发校准R10保持5.80%，检出87.44%→85.99%，误报0.084619→0.078646（仅降7.06%，未达10%）；'
        '另7日开发块R10=9.09%→5.45%，未通过预先冻结的联合筛查。')
    marker='# 最新检查点：动态确认筛查未通过（2026-10-15）'
    p=ROOT/'CURRENT_STATE.zh-CN.md';old=p.read_text(encoding='utf-8');assert marker not in old
    p.write_text(marker+'\n\n- '+summary+'\n'
        '- >3/>7 mph仅敏感性检查，同样未通过，没有替换主规则或改变门槛。本轮误报目的与此前+2pp R10假设分开记录，不冒充前轮主检验通过。\n'
        '- 完整校准各情景少2次误报但各漏检1个事件；风险验证各情景失去2/55个R10预警，成组缺失多漏检2/55。校准后周各少检出1/32，均超2pp保护线。\n'
        '- 11项实际测试、36组动态激活独立区间重建、60组回放、逐事件转移及配对统计核对通过。误报差95%描述区间包含0。\n'
        '- 仅用已参与开发的风险验证7日和校准14日，没有新网络训练、没有选择或解码新站点。原论文与GitHub v7保持，既有失败记录全部保留。\n'
        '- 报告outputs/adaptive-confirmation-2026-10-15/report.zh-CN.md；接续docs/adaptive_confirmation_handoff.zh-CN.md。下一步先检查既有因果特征区分误报/真起点的能力。\n'
        '- 最新累计包2026-10-15-adaptive-confirmation，恢复先10月11日完整基包再本累计包。\n\n以下为之前阶段记录。\n\n'+old,encoding='utf-8')
    p=ROOT/'README.md';old=p.read_text(encoding='utf-8')
    p.write_text('# 最新研究：残差触发动态确认未通过开发筛查\n\n'
        '[完整报告](outputs/adaptive-confirmation-2026-10-15/report.zh-CN.md) · [接续说明](docs/adaptive_confirmation_handoff.zh-CN.md)\n\n'
        +summary+' 仅开发结果，未更新线上规则。最新累计包为2026-10-15-adaptive-confirmation。\n\n以下为之前阶段记录。\n\n'+old,encoding='utf-8')
    files=set(prior['files'])|{prior_path,'adaptive_confirmation.py','audit_adaptive_confirmation.py',
        'summarize_adaptive_confirmation.py','save_adaptive_confirmation_checkpoint.py',
        'tests/test_adaptive_confirmation.py','docs/adaptive_confirmation_handoff.zh-CN.md'}
    files|={p.relative_to(ROOT).as_posix() for p in OUT.rglob('*') if p.is_file() and p.name!='writing_archive_manifest.json'}
    base_path=ROOT.parent/'checkpoints/traffic-recovery-lab-2026-10-11-event-timeline-save-receipt.json';base=read(base_path)
    assert Path(base['full_archive']).stat().st_size==base['full_archive_bytes'] and base['archive_crc_and_all_sha256_verified']
    manifest=OUT/'writing_archive_manifest.json'
    write(manifest,{'client_date':'2026-10-15','stage':'cumulative_failed_adaptive_confirmation_pilot',
        'archive_name':archive.name,'restore':'October11 full base, then this supplement',
        'declared_primary':'residual_gt5','primary_acceptance_passed':False,
        'new_station_cohort_consumed':False,'optimizer_updates':0,'unit_tests_passed':11,
        'all36_adaptive_activations_independently_reconstructed':True,'all60_operating_replays_checked':True,
        'prior_files_changed':['README.md','CURRENT_STATE.zh-CN.md'],
        'original_thesis_primary_test_still_failed':True,
        'public_commit_unchanged':'ab8760a3e6ea1784fea3195a0e7aadbaff6fe80d',
        'base_crc_rechecked_this_turn':False,'base_sha256_from_prior_verified_receipt':base['full_archive_sha256'],
        'files':{n:{'bytes':(ROOT/n).stat().st_size,'sha256':sha(ROOT/n)} for n in sorted(files)}})
    files.add(manifest.relative_to(ROOT).as_posix())
    with ZipFile(archive,'x',compression=ZIP_DEFLATED) as z:
        for n in sorted(files):z.write(ROOT/n,'traffic-recovery-lab/'+n)
    with ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist())==len(files)
        for n in sorted(files):
            data=z.read('traffic-recovery-lab/'+n)
            assert data==(ROOT/n).read_bytes() and hashlib.sha256(data).hexdigest()==sha(ROOT/n)
    proof={'saved_at_utc':datetime.now(timezone.utc).isoformat(),'archive':str(archive),
        'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'files':len(files),
        'crc_and_all_file_bytes_and_sha256_verified':True,'primary_acceptance_passed':False,
        'new_station_cohort_consumed':False,'original_thesis_primary_test_still_failed':True,
        'public_version_unchanged':True,'base_prior_verified_receipt':str(base_path),'base_crc_rechecked_this_turn':False}
    write(receipt,proof);print(proof)


if __name__=='__main__':main()
