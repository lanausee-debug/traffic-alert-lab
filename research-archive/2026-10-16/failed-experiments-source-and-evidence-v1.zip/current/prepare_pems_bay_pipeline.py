"""Build the immutable source/design seed needed for isolated PEMS-BAY reruns."""
from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
TARGET = ROOT / 'pipeline_seed'


def sha(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def load(name):
    return json.loads((ROOT / name).read_text(encoding='utf-8'))


def main():
    execution = load('outputs/pems-bay-evaluation/execution_freeze.json')
    design = load('outputs/pems-bay-validation-plan/design_freeze.json')
    # The seed contains original source/design and earlier METR-LA evidence,
    # never fitted PEMS-BAY stages, predictions, weights, caches or raw data.
    names = {name for name in execution['source_sha256']
             if name.endswith('.py') or name.startswith('configs/') or name.startswith('docs/')}
    names.update(design['source_sha256'])
    names.update({'outputs/pems-bay-validation-plan/design_freeze.json',
                  'data/pems-bay-provenance.json', 'data/source-metadata/pems-bay-discovery.json',
                  'complete_pems_bay_evaluation_audit.py', 'run_pems_bay_pipeline.py'})
    # Legacy module imports also contain helpers not listed by the original
    # execution seal. Include their entire local import closure, without editing it.
    pending = [name for name in names if name.endswith('.py')]
    visited = set()
    while pending:
        name = pending.pop()
        if name in visited:
            continue
        visited.add(name)
        tree = ast.parse((ROOT / name).read_text(encoding='utf-8-sig'), filename=name)
        for node in ast.walk(tree):
            modules = [alias.name for alias in node.names] if isinstance(node, ast.Import) else (
                [node.module] if isinstance(node, ast.ImportFrom) and node.level == 0 and node.module else [])
            for module in modules:
                candidate = module.split('.')[0] + '.py'
                if (ROOT / candidate).is_file() and candidate not in names:
                    names.add(candidate)
                    pending.append(candidate)
    for name in names:
        if name.startswith('outputs/pems-bay-') and name != 'outputs/pems-bay-validation-plan/design_freeze.json':
            raise ValueError(f'Fitted PEMS-BAY material in seed: {name}')
        if Path(name).suffix in {'.h5', '.pt', '.npz', '.zip'}:
            raise ValueError(f'Binary training material in seed: {name}')
        expected = execution['source_sha256'].get(name, design['source_sha256'].get(name))
        if expected is not None and sha(ROOT / name) != expected:
            raise ValueError(f'Frozen original changed: {name}')
    forecast = load('outputs/pems-bay-forecaster/results.json')
    risk = load('outputs/pems-bay-risk/results.json')
    calibration = load('outputs/pems-bay-calibration/selection.json')
    evaluation = load('outputs/pems-bay-evaluation/results.json')
    reference = {
        'kind': 'previously_analyzed_v1_numerical_reference_not_fresh_confirmation',
        'forecast_validation': forecast['validation'],
        'selected_forecast_epochs': [{k: row[k] for k in ('seed', 'selected_epoch')} for row in forecast['model_selection']],
        'risk_validation': risk['validation'], 'calibration_budgets': calibration['budgets'],
        'settings': {method: {grid: {k: row['selected'][k] for k in ('threshold', 'confirmation', 'grid_index')}
                              for grid, row in grids.items()} for method, grids in calibration['methods'].items()},
        'evaluation_dates': evaluation['evaluation_dates'], 'evaluation': evaluation['evaluation'],
        'comparisons': evaluation['comparisons'], 'verdict': evaluation['verdict'],
        'original_results_sha256': sha(ROOT / 'outputs/pems-bay-evaluation/results.json'),
    }
    blobs = {name: (ROOT / name).read_bytes() for name in sorted(names)}
    blobs['reference_metrics.json'] = (json.dumps(reference, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    manifest = {
        'kind': 'immutable_reproduction_seed', 'dataset_already_analyzed': True,
        'copied_fitted_pems_bay_stages': False, 'original_source_files_edited': False,
        'local_import_closure_included': True,
        'original_execution_freeze_sha256': sha(ROOT / 'outputs/pems-bay-evaluation/execution_freeze.json'),
        'files': {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name, data in blobs.items()},
    }
    blobs['seed_manifest.json'] = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    if TARGET.exists():
        actual = {p.relative_to(TARGET).as_posix() for p in TARGET.rglob('*') if p.is_file()}
        if actual != set(blobs):
            raise ValueError('Existing seed differs; preserve it and prepare a new version')
        for name, data in blobs.items():
            if (TARGET / name).read_bytes() != data:
                raise ValueError(f'Existing seed changed: {name}')
    else:
        for name, data in blobs.items():
            path = TARGET / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
    print(json.dumps({'seed': str(TARGET), 'files': len(blobs),
                      'bytes': sum(len(v) for v in blobs.values()), 'fitted_pems_bay_artifacts_copied': False}))


if __name__ == '__main__':
    main()
