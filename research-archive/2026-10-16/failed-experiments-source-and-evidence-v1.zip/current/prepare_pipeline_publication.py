"""Package the tested pipeline and the earlier results capsule; no upload."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
TARGET = ROOT / 'publication/traffic-alert-lab-pipeline-v1'
RUN = ROOT / 'runs/pems-bay-reproduction-001'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def main():
    state = read(RUN / 'pipeline_records/state.json')
    comparison = read(RUN / 'pipeline_records/reproduction_comparison.json')
    if state['status'] != 'completed' or not comparison['matches_original_metrics']:
        raise ValueError('Do not package an unverified full pipeline as verified')
    execution = read(RUN / 'pipeline_records/portable_execution_manifest.json')
    if execution['runner_sha256'] != digest((ROOT / 'run_pems_bay_pipeline.py').read_bytes()):
        raise ValueError('Runner differs from the tested execution')
    original_capsule = ROOT / 'publication/traffic-alert-lab-v1'
    original_manifest = read(original_capsule / 'publication_manifest.json')
    blobs = {}
    for name, metadata in original_manifest['files'].items():
        if name in ('README.md', '.gitignore'):
            continue
        data = (original_capsule / name).read_bytes()
        if len(data) != metadata['bytes'] or digest(data) != metadata['sha256']:
            raise ValueError(f'Original result capsule changed: {name}')
        blobs[name] = data
    seed = ROOT / 'pipeline_seed'
    seed_manifest = read(seed / 'seed_manifest.json')
    for name, metadata in seed_manifest['files'].items():
        data = (seed / name).read_bytes()
        if len(data) != metadata['bytes'] or digest(data) != metadata['sha256']:
            raise ValueError(f'Seed changed: {name}')
        blobs['pipeline_seed/' + name] = data
    blobs['pipeline_seed/seed_manifest.json'] = (seed / 'seed_manifest.json').read_bytes()
    for name in ('run_pems_bay_pipeline.py', 'tests/test_pems_pipeline.py',
                 'docs/pems_bay_pipeline_reproduction.zh-CN.md', 'docs/github_reproduction.zh-CN.md'):
        blobs[name] = (ROOT / name).read_bytes()
    blobs['README.md'] = (ROOT / 'docs/github_pipeline_readme_draft.md').read_bytes()
    blobs['.gitignore'] = b'.venv/\n__pycache__/\n.mplconfig/\n.tmp/\nruns/\ndata/raw/\n*.pyc\n*.pt\n*.npz\n*.h5\n*.zip\n'
    forecast = read(RUN / 'outputs/pems-bay-forecaster/results.json')
    risk_selection = read(RUN / 'outputs/pems-bay-risk/model_selection.json')
    training_updates = {
        'forecaster_updates_by_seed': {str(row['seed']): row['optimizer_updates'] for row in forecast['model_selection']},
        'risk_mlp_updates_by_method': {method: [row['actual_optimizer_updates'] for row in risk_selection[method]]
                                       for method in ('persistent_mlp', 'onset_mlp')},
    }
    entry_tests = read(ROOT / 'outputs/pems-bay-pipeline-verification/entry_tests.json')
    if not entry_tests['passed'] or entry_tests['test_source_sha256'] != digest(blobs['tests/test_pems_pipeline.py']):
        raise ValueError('Entry test evidence differs from packaged tests')
    blobs['verification/entry_tests.json'] = (ROOT / 'outputs/pems-bay-pipeline-verification/entry_tests.json').read_bytes()
    verification = {
        'kind': 'local_full_pipeline_verification_record',
        'completed_at_utc': state['completed_at_utc'], 'status': state['status'],
        'completed_steps': state['completed_steps'],
        'step_attempts': [{k: row[k] for k in ('step', 'status', 'exit_code', 'seconds', 'log_sha256')}
                          for row in state['step_runs']],
        'runner_sha256': execution['runner_sha256'], 'seed_manifest_sha256': execution['seed_manifest_sha256'],
        'dataset_sha256': execution['raw_source_sha256'],
        'environment': {k: v for k, v in execution['environment'].items() if k != 'executable'},
        'comparison': comparison,
        'actual_training_updates': training_updates,
        'source_state_sha256': digest((RUN / 'pipeline_records/state.json').read_bytes()),
        'source_execution_manifest_sha256': digest((RUN / 'pipeline_records/portable_execution_manifest.json').read_bytes()),
        'source_logs_included': False,
        'source_paths_omitted': True,
        'not_proof_of_record_authenticity': True,
    }
    blobs['verification/pipeline_verification.json'] = (json.dumps(verification, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    blobs['verification/report.zh-CN.md'] = (RUN / 'pipeline_records/report.zh-CN.md').read_bytes()
    if any(Path(name).suffix in {'.h5', '.pt', '.npz', '.zip'} or name.startswith('runs/') for name in blobs):
        raise ValueError('Training data, cache, weight or run directory leaked into candidate')
    manifest = {'stage': 'local_pipeline_publication_candidate_not_uploaded',
        'full_training_pipeline_verified_on_recorded_environment': True,
        'raw_data_or_weights_included': False, 'fresh_independent_validation': False,
        'files': {name: {'bytes': len(data), 'sha256': digest(data)} for name, data in blobs.items()}}
    blobs['publication_manifest.json'] = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    if TARGET.exists():
        actual = {p.relative_to(TARGET).as_posix() for p in TARGET.rglob('*') if p.is_file()}
        if actual != set(blobs):
            raise ValueError('Existing candidate differs; preserve it and use a new version')
        for name, data in blobs.items():
            if (TARGET / name).read_bytes() != data:
                raise ValueError(f'Existing candidate differs: {name}')
    else:
        for name, data in blobs.items():
            path = TARGET / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
    archive = TARGET.parent / 'traffic-alert-lab-pipeline-v1-publication-candidate.zip'
    if not archive.exists():
        with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as packed:
            for name, data in blobs.items():
                packed.writestr('traffic-alert-lab-pipeline-v1/' + name, data)
    with zipfile.ZipFile(archive) as packed:
        assert packed.testzip() is None
        assert set(packed.namelist()) == {'traffic-alert-lab-pipeline-v1/' + name for name in blobs}
        for name, data in blobs.items():
            assert packed.read('traffic-alert-lab-pipeline-v1/' + name) == data, name
    print(json.dumps({'candidate': str(TARGET), 'files': len(blobs), 'archive': str(archive),
        'archive_bytes': archive.stat().st_size, 'integrity': 'CRC + every archived byte verified', 'uploaded': False}))


if __name__ == '__main__':
    main()
