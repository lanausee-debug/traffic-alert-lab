"""Write lineage attribution and alarm burden report from immutable records."""
from datetime import datetime,timezone
import event_lineage_attribution as pilot
import calibration_fragility as common


def main():
    root=pilot.ROOT;out=pilot.OUT;r=common.read(out/'results.json');audit=common.read(out/'audit.json')
    assert audit['passed'] and audit['results_sha256']==common.sha(out/'results.json')
    common.write(out/'test_receipt.json',{'recorded_at_utc':datetime.now(timezone.utc).isoformat(),
        'tests_run':7,'passed':True,'observed_exit_code':0,
        'basis':'Observed successful 7-test tool output before frozen record attribution; report does not rerun tests',
        'command':'.venv/Scripts/python.exe -m unittest discover -s tests -p test_event_lineage_attribution.py -v',
        'test_source_sha256':common.sha(root/'tests/test_event_lineage_attribution.py')})
    labels={'training28':'训练28日','risk_validation7':'验证7日','calibration_full14':'校准14日',
        'calibration_week1_7':'校准前7日','calibration_week2_7':'校准后7日'}
    methods={'global_c1':'原全局规则','effective_no_bypass':'无豁免过滤','effective_protected_gate':'有豁免过滤'}
    groupnames={'first_segment':'父过程第一子段','reentry_segment':'后续重入子段','parent_censored':'父过程删失',
        'single_segment_process':'只含一个旧子段的父过程','multi_segment_process':'包含多个旧子段的父过程'}
    lines=['# 告警收益归因：重入保护和首次检出损失必须分开','',
        '日期：2026-10-16。**验证段低速豁免救回的唯一预警属于后续重入子段，没有救回父过程的第一子段；现有有豁免过滤相对全局规则损失的检出却在第一子段。更换事件定义只是重新归类告警，并没有减少实际告警片段数。**','',
        '这是对既有冻结回放记录的分组核查，本轮没有加载样本缓存或模型、没有新增推理、重训、阈值搜索或告警规则。所有分组都是离线描述，不能直接作为在线输入。','',
        '## 预先固定的分组含义','',
        '沿用单次越线结束与连续两次回升结束两套事件定义、相同共同可判断范围和全部既有告警。把两次回升定义下的代理事件称为父过程，单次越线定义的代理事件称为子段。','',
        '- 第一子段：完整旧子段与完整父过程起点相同。',
        '- 后续重入子段：完整旧子段起点晚于其完整父过程起点。',
        '- 父过程删失：完整旧子段映射到左/右删失父过程，单列保留。',
        '- 两次回升定义下完整父过程，再按它包含一个或多个旧子段分组。','',
        '这里“第一”只表示这个固定父过程中的相对顺序，不是每一天第一场拥堵、站点历史上首次拥堵，更不是现场确认的首次现实拥堵。不把后续子段的预警当成首次起点预警。','',
        '| 范围 | 第一子段 | 后续重入子段 | 父过程删失的旧完整子段 | 单子段完整父过程 | 多子段完整父过程 |',
        '| --- | ---: | ---: | ---: | ---: | ---: |']
    for block,d in r['blocks'].items():
        c={definition:{g:sum(v['group']==g for v in d['event_groups'][definition]) for g in pilot.GROUPS[definition]} for definition in pilot.GROUPS}
        lines.append(f"| {labels[block]} | {c['one_high']['first_segment']} | {c['one_high']['reentry_segment']} | {c['one_high']['parent_censored']} | {c['two_high']['single_segment_process']} | {c['two_high']['multi_segment_process']} |")
    lines+=['',
        '以上同一范围的事件只计一次，不乘三情景。校准两个7日子块与14日重叠，不能加成更多独立样本。旧完整子段与新完整父过程的分母不同，不能把两边事件数直接相加或用百分比差宣称模型提高。','',
        '## 验证自然情景：收益到底在哪一组','',
        '| 单次越线分组 | 事件数 | 原全局检出 | 无豁免检出 | 有豁免检出 | 原/无/有豁免R10个数 |',
        '| --- | ---: | ---: | ---: | ---: | --- |']
    for group in pilot.GROUPS['one_high']:
        ms=r['blocks']['risk_validation7']['definitions']['one_high']['natural']['methods']
        values=[ms[m]['groups'][group]['metrics'] for m in pilot.METHODS]
        lines.append(f"| {groupnames[group]} | {values[0]['events']} | {values[0]['detected']} | {values[1]['detected']} | {values[2]['detected']} | {' / '.join(str(v['R10']) for v in values)} |")
    lines+=['',
        '第一子段46个，原规则检出39个，两种过滤都只检出37个；保护豁免没有挽回其中任何一个损失。重入子段6个，原规则检出6个，无豁免检出5个，有豁免恢复为6个。那一个恢复的是此前已追踪的node12、origin508事件，也是原R15记录。三种情景共享它，不是三个独立获益事件。','',
        '在连续两次回升定义下，验证41个单子段父过程原自然规则检出34个，两种过滤均32个；5个多子段父过程三个方法均全部检出。现有过滤的检出损失集中在单子段父过程，并不能解释为只删掉了已经告警过的重复。','',
        '## 三情景的逐事件收益与损失','',
        '下表固定单次越线定义，前两列为“有豁免过滤−原全局规则”的新增漏检；后三列为“有豁免−无豁免”的恢复检出。早期身份与原提前量另外核查，15分钟变10分钟即使仍属于R10，也会记为原提前量受损。','',
        '| 范围 | 情景 | 过滤造成第一子段漏检 | 过滤造成重入子段漏检 | 豁免恢复第一子段 | 豁免恢复重入子段 | 豁免恢复父删失子段 |',
        '| --- | --- | ---: | ---: | ---: | ---: | ---: |']
    scenenames={'natural':'自然','single_outage':'单站缺失','group_outage':'成组缺失'}
    for block in ('training28','risk_validation7','calibration_full14'):
        for scenario,rows in r['blocks'][block]['definitions']['one_high'].items():
            lose=rows['comparisons']['with_bypass_vs_global']['event_comparison']['groups']
            gain=rows['comparisons']['bypass_vs_no_bypass']['event_comparison']['groups']
            lines.append(f"| {labels[block]} | {scenenames[scenario]} | {lose['first_segment']['lost_detection']} | {lose['reentry_segment']['lost_detection']} | {gain['first_segment']['recovered_detection']} | {gain['reentry_segment']['recovered_detection']} | {gain['parent_censored']['recovered_detection']} |")
    lines+=['',
        '验证第一子段新增漏检分别2、0、1个，均由原迟报变成漏检；完整校准共同范围每个情景损失1个第一子段，豁免没有增加任何分组的检出。原R10身份与提前量保持，但这不等于首次检出完全保持。训练段豁免各恢复2个第一子段和1个重入子段；不能把训练收益当成泛化确认，也不能说豁免在所有数据都无效。','',
        '校准自然情景第一子段62个，原全局检出58个，两种过滤均57个；3个重入子段都检出2个，另一个映射父删失的旧子段保持检出。原全局与有豁免过滤的差异不是通过删失组隐藏的，所有组都保留在总数核对中。','',
        '## 不是少标了误报，就少发了告警','',
        '同一个方法在两种事件定义下，所有告警片段的(node,row,length_steps)键逐项相同：模型输出、激活和评分可判断范围均未变，只是评分标签改变。片段数是当前协议内的告警起点负担代理，项目并未记录真实用户端通知日志。','',
        '| 自然情景/有豁免方法 | 事件定义 | 告警片段总数 | 预警 | 迟报 | 误报 | 重复 | 删失 | 不可判断 |',
        '| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
    for block in ('risk_validation7','calibration_full14'):
        for definition in ('one_high','two_high'):
            m=r['blocks'][block]['definitions'][definition]['natural']['methods']['effective_protected_gate'];k=m['episode_type_counts']
            lines.append(f"| {labels[block]} | {'一次越线' if definition=='one_high' else '两次回升'} | {m['episode_count']} | {k['warned']} | {k['late']} | {k['false']} | {k['duplicate']} | {k['censored']} | {k['unknown']} |")
    lines+=['',
        '验证自然情景有豁免方法的片段总数始终78。误报20→18，是两条旧误报改判为重复；另有一条旧预警和五条旧迟报改判重复，所以重复14→22。告警没有因此少发8次。','',
        '校准自然情景片段总数始终114，误报28→27是其中一条改判迟报；两条旧迟报改判重复，一条改为不可判断。所有六种类型的转移矩阵逐项存档，不能只选择下降的误报列。','',
        '## 豁免实际多放行了哪些片段','',
        '以下采用两次回升定义，比较有豁免和无豁免。新增片段、同一片段的类型改变分别计数；本次真实记录中后者为0，因此下列新增类型可以直接相加为新增片段数。框架也用构造例子测试了“新增更早告警令保留片段改为重复”的情形，避免一般情况下错误相加。','',
        '| 范围 | 情景 | 额外片段 | 预警 | 迟报 | 误报 | 重复 | 删失/不可判断 |',
        '| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |']
    for block in ('risk_validation7','calibration_full14'):
        for scenario,rows in r['blocks'][block]['definitions']['two_high'].items():
            c=rows['comparisons']['bypass_vs_no_bypass']['episode_comparison'];a=c['added_episode_types']
            lines.append(f"| {labels[block]} | {scenenames[scenario]} | {c['net_episode_count_change']} | {a['warned']} | {a['late']} | {a['false']} | {a['duplicate']} | {a['censored']+a['unknown']} |")
    lines+=['',
        '验证三情景实际多13、14、11个片段，全部为误报或重复，对应误报3/4/3、重复10/10/8。校准多11/10/9个片段，其中误报各1个、重复8/7/8个，前两个情景另有删失1和不可判断1。不能把删失或不可判断悄悄按正确通知计算。','',
        '## 当前过滤相对原全局规则减少了什么','',
        '自然验证有豁免方法从原全局81个片段减至78个，少的是1次误报和2次原迟报，不减少重复；自然校准从117减至114，少2次误报和1次原迟报，也不减少重复。当前方法的误报收益伴随有效检出损失，不能命名为“只去重、保首次”的方案。','',
        '以上是共同可判断范围结果。原完整范围与共同范围排除造成的事件数、告警数差异已经在上一轮单独报告，本轮不把这些排除当方法抑制通知的效果。','',
        '## 核查和边界','',
        '7项测试通过，覆盖第一/重入/父删失分类，空组不可定义，R15延至R10仍算身份提前量受损，重复与误报的不同分母，同片段重新分类不算新增告警，固定激活下类型转移，以及拒绝跨不同事件集合比较。','',
        '独立逐记录核查90组方法汇总、90组成对比较、45个跨定义转移表；共核对6336条事件记录和10600条告警片段记录，包含相关方法、三种情景、重叠校准子块及训练段，不能作为独立样本量。所有分组与整体计数、逐事件得失、片段新增/删除与重新分类代数一致。','',
        '只解码上一轮已冻结结果JSON，没有打开样本缓存或权重，没有新模型推理/优化；原评测、跨站/迁移、新站、HDF5值都未读。原标签/模型/线上规则、论文Word/PPT与GitHubv7保持。原论文主检验失败和候选验收失败状态保持，不因分组后某列更好而改写。','',
        '## 下一轮的具体方向','',
        '当前证据更适合先检验告警发送层的会话去重：保留固定风险状态和原首次通知，以不丢失、不延后首次检出为约束，检查能否减少后续重复通知；需要只用当时可见观测、明确缺测时如何处理，并另行预先冻结单一方案和完整评价。','',
        '这只是下一轮实验方向，本轮没有实现新的通知策略，也没有证明它能兼顾原R10、首次检出和误报。不能使用本轮离线父过程身份作为在线去重条件。','']
    (out/'report.zh-CN.md').write_text('\n'.join(lines),encoding='utf-8')
    (root/'docs/event_lineage_attribution_handoff.zh-CN.md').write_text('''# 接续：分组收益和真实告警负担（2026-10-16）

本轮用户“下一轮”已完成record-only归因。没有样本缓存/权重解码、模型推理或重训，不修改规则、标签或原失败结论。论文本科，《面向观测缺失的交通拥堵告警风险校准与事件级决策方法研究》。

沿用上一轮两定义和共同可判断范围。旧完整事件按其two-high父过程分第一子段（同起点）、重入子段（晚于父起点）、父删失（独立单列）。新完整父过程按含一个/多个旧阳性段分组。“第一”不是现场首次现实拥堵。离线谱系不能作在线特征。

验证46第一+6重入，校准62第一+3重入+1父删失；训练167第一+8重入+8父删失。验证自然第一原global检出39/46、无/有豁免均37/46；重入6/6→5/6→6/6。三情景豁免恢复都只在同一个重入R15事件，首次子段恢复0。现有有豁免过滤相对global漏第一2/0/1；校准每情景第一漏1，重入无变化。新two-high父过程验证单子段41中原自然检出34、两过滤32；多子段5均检出。不能说现有过滤只删重复。

告警定义改变不改片段集合。验证自然有豁免总片段78不变，误报20→18（2条改判重复），一预警/五迟报也改重复，重复14→22。校准总114不变，误报28→27是改迟报，两个迟报改重复、一个变不可判断，重复20→22。

two-high下，豁免相对无豁免验证实际多13/14/11片段=3/4/3误报+10/10/8重复，无检出或R10收益。校准多11/10/9=各1误报+8/7/8重复，前2情景还各1删失+1不可判断。训练仍有部分恢复检出，不推断全部场景无用。

自然现有有豁免过滤vsglobal：验证81→78片段少1误报和2迟报，校准117→114少2误报1迟报，重复不减。定义重标不等于少发通知；实际用户通知日志不存在，这里只有评分告警片段代理。

文件event_lineage_attribution.py/audit_event_lineage_attribution.py/summarize_event_lineage_attribution.py/save_event_lineage_attribution_checkpoint.py；tests/test_event_lineage_attribution.py。输出outputs/event-lineage-attribution-2026-10-16：plan/results/audit/completion/access_log/test_receipt/report/comparison.png。7测试；独立核对90方法汇总/90成对/45类型转移，6336事件和10600片段是含训练/相关情景/方法/重叠半块工作量，不作独立样本。

下一轮可预先冻结单一告警发送层会话去重试验：固定风险状态和首次通知，以不丢失不延后首次检出为约束，严格用当时已有观测处理恢复/缺测/断点；对比新增/减少通知与首次身份提前量，不准借离线父过程去重。本轮新通知策略未实现，性能未验证。不要看到本轮结果继续搜索规则或改定义把旧失败变通过。

原模型SHA1bea8ed689c6ac23dbcdec44212aed4bb3402ebb26a5f73f95aca7b92f9e6f21及分界线0.4388462325645476固定。Word/PPT/GitHubv7不变，禁原评测/迁移/新站/HDF5值。最新累计包traffic-recovery-lab-2026-10-16-event-lineage-attribution.zip；先10月11日完整基包再本包，旧文件/ZIP保留，只README和CURRENT_STATE加说明；基包CRC本轮未重查。
''',encoding='utf-8')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(1,2,figsize=(12.8,4.9),facecolor='#f5f8fa')
    colors=['#91a3b6','#bca16f','#247e86'];methodlabels=['Global','No bypass','With bypass']
    for i,method in enumerate(pilot.METHODS):
        rows=r['blocks']['risk_validation7']['definitions']['one_high']['natural']['methods'][method]['groups']
        values=[rows[g]['metrics']['detected'] for g in ('first_segment','reentry_segment')]
        bars=axes[0].bar([i*.23-.23,1+i*.23-.23],values,width=.22,color=colors[i],label=methodlabels[i])
        for bar,value in zip(bars,values):axes[0].text(bar.get_x()+bar.get_width()/2,bar.get_height(),str(value),ha='center',va='bottom',fontsize=9)
    axes[0].set_xticks([0,1],['First child / 46 events','Reentry child / 6 events']);axes[0].set_ylim(0,48)
    axes[0].set_ylabel('Detected shared-support events');axes[0].set_title('Natural validation: first vs reentry',fontsize=11)
    axes[0].legend(fontsize=8,loc='upper right')
    bottom=[0,0]
    for kind,color,label in [('warned','#247e86','Warning'),('late','#789eb0','Late'),('false','#bb5555','False'),('duplicate','#bbab7c','Duplicate'),('censored','#91949a','Censored'),('unknown','#c5c9cd','Unknown')]:
        vals=[r['blocks']['risk_validation7']['definitions'][d]['natural']['methods']['effective_protected_gate']['episode_type_counts'][kind] for d in ('one_high','two_high')]
        axes[1].bar([0,1],vals,bottom=bottom,color=color,label=label,width=.6)
        bottom=[a+b for a,b in zip(bottom,vals)]
    axes[1].set_xticks([0,1],['1-high end','2-high end']);axes[1].set_ylabel('Alarm episodes (fixed primary activations)')
    axes[1].set_ylim(0,115);axes[1].set_title('Same 78 alarm episodes, different labels',fontsize=11)
    axes[1].legend(fontsize=8,ncol=2,loc='upper right')
    for i,v in enumerate(bottom):axes[1].text(i,v,str(v),ha='center',va='bottom',fontsize=10)
    for ax in axes:ax.spines[['top','right']].set_visible(False)
    fig.suptitle('Fixed-record attribution / reused development only / no model or policy change',fontsize=12)
    fig.text(.5,.02,'First means first child of a frozen proxy parent, not field-confirmed onset. Reclassification is not notification reduction.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.06,1,.92));fig.savefig(out/'comparison.png',dpi=150);plt.close(fig)
    print({'report':str(out/'report.zh-CN.md'),'tests':7,'new_inference_calls':0})


if __name__=='__main__':main()
