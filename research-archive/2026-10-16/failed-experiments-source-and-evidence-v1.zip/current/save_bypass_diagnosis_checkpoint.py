"""Cumulative local save; preserve prior scientific sources and failed results."""
from datetime import datetime,timezone
import hashlib
from zipfile import ZipFile,ZIP_DEFLATED
import bypass_diagnosis as pilot
from save_station_agnostic_checkpoint import read,write,sha

ROOT=pilot.ROOT;OUT=pilot.OUT
NAME='traffic-recovery-lab-2026-10-16-bypass-diagnosis'


def main():
    archive=ROOT.parent/'checkpoints'/(NAME+'.zip');receipt=archive.with_name(NAME+'-save-receipt.json')
    if archive.exists() or receipt.exists():raise FileExistsError('Preserve all earlier archives')
    r=read(OUT/'audited_results.json');audit=read(OUT/'audit.json');tests=read(OUT/'test_receipt.json')
    assert audit['passed'] and tests['passed'] and tests['tests_run']==8
    assert tests['test_source_sha256']==sha(ROOT/'tests/test_bypass_diagnosis.py')
    assert audit['audited_results_sha256']==sha(OUT/'audited_results.json')
    assert r['new_models_fitted']==0 and not r['policy_modified'] and not r['previous_candidate_acceptance_passed']
    assert not r['new_station_cohort_consumed'] and not r['consumed_transfer_values_used']
    assert r['original_thesis_primary_test_still_failed']
    for name,digest in read(OUT/'completion.json')['artifacts'].items():assert sha(OUT/name)==digest
    for name,digest in read(OUT/'plan.json')['source_and_input_sha256'].items():assert sha(ROOT/name)==digest
    prior_name='outputs/effective-alert-pilot-2026-10-16/writing_archive_manifest.json';prior=read(ROOT/prior_name)
    # Byte hashing of previously consumed assets is preservation only; no decode/replay.
    for name,meta in prior['files'].items():assert sha(ROOT/name)==meta['sha256'],name
    summary=('固定模型/阈值诊断低速豁免：验证各情景恢复同一个原15分钟代理预警，额外误报3/4/3；'
        '校准14日额外误报2/2/1且无新增检出。简单预定分箱没有干净分离，未修改策略。')
    marker='# 最新检查点：低速豁免保护与误报代价（2026-10-16）'
    p=ROOT/'CURRENT_STATE.zh-CN.md';old=p.read_text(encoding='utf-8');assert marker not in old
    p.write_text(marker+'\n\n- '+summary+'\n'
        '- 零训练更新/新模型，原有效分界线0.4388462325645476与模型SHA1bea8ed689c6ac23dbcdec44212aed4bb3402ebb26a5f73f95aca7b92f9e6f21固定。原论文主检验和上轮联合门槛仍失败。\n'
        '- 三情景共享同一个预警事件，不是三个独立真事件；校准两个7日子块与14日重叠。重复告警也需记录负担。\n'
        '- 被保护预警起点已有26.8/27.2/26.5mph三条低速观测，15分钟是未来三低速标签事件的代理提前量，不等于实际拥堵发生前15分钟。\n'
        '- 8测试通过；15情景块45完整回放、196额外段和1173事件记录独立核查，36原后续开发激活逐位复现。累计数含训练和重叠/相关块。\n'
        '- 初次JSON写出失败只由独立包装器修数字；原源码/计划保留。两项上下文标准差单位在audited_results纠正，原results和单位修正回执保留；模型输入/策略/分箱/计数不变。\n'
        '- 报告outputs/bypass-diagnosis-2026-10-16/report.zh-CN.md；接续docs/bypass_diagnosis_handoff.zh-CN.md。下一轮先核查代理标签的分段/重复/提前量语义，尚未执行。\n'
        '- 未读取原评测、跨站值、原HDF5或新站。Word/PPT、线上GitHub v7保持；真实模型和明细本地保存。\n'
        '- 最新累计包2026-10-16-bypass-diagnosis；恢复先10月11日完整基包再本累计包。\n\n以下为之前阶段记录。\n\n'+old,encoding='utf-8')
    p=ROOT/'README.md';old=p.read_text(encoding='utf-8')
    p.write_text('# 最新研究：低速豁免有保护收益，也有误报代价\n\n'
        '[完整报告](outputs/bypass-diagnosis-2026-10-16/report.zh-CN.md) · [接续说明](docs/bypass_diagnosis_handoff.zh-CN.md)\n\n'
        +summary+' 仅重复开发数据诊断，未验证新规则。15分钟为代理提前量。最新累计包2026-10-16-bypass-diagnosis。\n\n以下为之前阶段记录。\n\n'+old,encoding='utf-8')
    files=set(prior['files'])|{prior_name,'bypass_diagnosis.py','complete_bypass_diagnosis.py',
        'audit_bypass_diagnosis.py','summarize_bypass_diagnosis.py','save_bypass_diagnosis_checkpoint.py',
        'tests/test_bypass_diagnosis.py','docs/bypass_diagnosis_handoff.zh-CN.md'}
    files|={p.relative_to(ROOT).as_posix() for p in OUT.rglob('*') if p.is_file() and p.name!='writing_archive_manifest.json'}
    base_path=ROOT.parent/'checkpoints/traffic-recovery-lab-2026-10-11-event-timeline-save-receipt.json';base=read(base_path)
    assert base['archive_crc_and_all_sha256_verified'] and __import__('pathlib').Path(base['full_archive']).stat().st_size==base['full_archive_bytes']
    manifest=OUT/'writing_archive_manifest.json'
    write(manifest,{'client_date':'2026-10-16','stage':'cumulative_fixed_observed_low_bypass_diagnosis',
        'archive_name':archive.name,'restore':'October11 full base, then this cumulative supplement',
        'new_models_fitted':0,'policy_modified':False,'independent_confirmation':False,
        'new_station_cohort_consumed':False,'consumed_transfer_values_decoded':False,
        'previous_acceptance_passed':False,'original_thesis_primary_test_still_failed':True,
        'unit_tests_observed_passed':8,'independently_checked_scenario_blocks':15,
        'operating_replays':45,'extra_raw_decisions_including_related_blocks':196,
        'serialization_recovery_and_context_unit_corrections_preserved':True,
        'prior_scientific_files_preserved':True,'prior_files_changed':['README.md','CURRENT_STATE.zh-CN.md'],
        'public_commit_unchanged':'ab8760a3e6ea1784fea3195a0e7aadbaff6fe80d',
        'base_crc_rechecked_this_turn':False,'base_sha256_from_prior_verified_receipt':base['full_archive_sha256'],
        'files':{n:{'bytes':(ROOT/n).stat().st_size,'sha256':sha(ROOT/n)} for n in sorted(files)}})
    files.add(manifest.relative_to(ROOT).as_posix())
    with ZipFile(archive,'x',compression=ZIP_DEFLATED) as z:
        for n in sorted(files):z.write(ROOT/n,'traffic-recovery-lab/'+n)
    with ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist())==len(files)
        for n in sorted(files):
            data=z.read('traffic-recovery-lab/'+n)
            assert data==(ROOT/n).read_bytes() and hashlib.sha256(data).hexdigest()==sha(ROOT/n)
    proof={'saved_at_utc':datetime.now(timezone.utc).isoformat(),'client_date':'2026-10-16',
        'archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'files':len(files),
        'crc_and_all_file_bytes_and_sha256_verified':True,'new_models_fitted':0,'policy_modified':False,
        'new_station_cohort_consumed':False,'original_thesis_primary_test_still_failed':True,
        'public_version_unchanged':True,'base_prior_verified_receipt':str(base_path),'base_crc_rechecked_this_turn':False}
    write(receipt,proof);print(proof)


if __name__=='__main__':main()
