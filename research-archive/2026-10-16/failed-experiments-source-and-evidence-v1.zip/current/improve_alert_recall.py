"""Exploratory recall repair using risk train/validation/calibration caches only.

Old evaluation is never accessed. Existing scientific files are not modified.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import time

import numpy as np
import torch

from congestion_alert_pilot import SCENARIOS
from congestion_density_pilot import fit_uniform
from congestion_risk_pilot import score, sigmoid
from pems_bay_alert_replay import alarm, replay
from train_pems_bay_risk import load_risk

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs/recall-repair-2026-10-15'
RISK=ROOT/'outputs/pems-bay-risk'
CAL=ROOT/'outputs/pems-bay-calibration'
SEEDS=(202,203,204)
MIXES=(0.5,0.75)
READS=[]


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def read(path):
    READS.append(path.relative_to(ROOT).as_posix())
    return json.loads(path.read_text(encoding='utf-8'))


def audit(event,args):
    if event!='open' or not isinstance(args[0],(str,bytes)):return
    name=str(args[0]).replace('\\','/').lower()
    if '/pems-bay-evaluation/' in name or name.endswith(('.h5','.hdf5')) or '/data/raw/' in name:
        raise PermissionError('Recall-repair exploration cannot access evaluation or raw HDF5')


def load(path,expected=None):
    if expected is not None and sha(path)!=expected:raise ValueError('Changed cached input: '+str(path))
    READS.append(path.relative_to(ROOT).as_posix())
    with np.load(path) as data:return {key:data[key] for key in data.files}


def freeze_plan():
    OUT.mkdir(exist_ok=True)
    names=['improve_alert_recall.py','congestion_density_pilot.py','congestion_risk_pilot.py',
        'pems_bay_alert_replay.py','congestion_alert_pilot.py','congestion_objective_diagnostic.py',
        'configs/pems_bay_validation_v1.json','outputs/pems-bay-risk/risk_train.npz',
        'outputs/pems-bay-risk/risk_validation.npz','outputs/pems-bay-risk/normalization.npz',
        'outputs/pems-bay-risk/scores_risk_validation.npz','outputs/pems-bay-calibration/calibration.npz',
        'outputs/pems-bay-calibration/scores_calibration.npz','outputs/pems-bay-calibration/selection.json']
    plan={'stage':'exploratory_recall_repair_not_independent_confirmation',
        'allowed_partitions':['risk_train','risk_validation','calibration'],
        'old_evaluation_values_read':False,'raw_hdf5_read':False,
        'prior_evaluation_informed_problem_choice':True,
        'hypotheses':['mixed persistent/onset supervision recovers missed ongoing events',
                      'global calibrated alarm fallback can preserve detection while onset alarms add warning'],
        'architecture':'unchanged RiskModel 51->32->16->1',
        'target':'state_weight * persistent_truth + (1-state_weight) * impending_onset',
        'state_weights':list(MIXES),'seeds':list(SEEDS),'updates_per_model':1350,'batch_size':4096,
        'checkpoint_selection':'minimum own mixed-target unweighted risk-validation BCE at 225/450/900/1350',
        'normalization':'original frozen risk-train-only normalization',
        'head_grid':{'thresholds':'0.01..0.90 step 0.005 plus off 1.0001','confirmations':[1,2]},
        'fallback':'OR(global_calibration original fine alarm, onset_mlp alarm)',
        'fallback_onset_thresholds':[0.10,0.15,0.20,0.25,0.30,0.40,0.50,0.60,0.70,0.80,0.90,1.0001],
        'fallback_confirmations':[1,2],
        'constraints':'each scenario false rate <= original calibration budget; each scenario detection >= original global fine minus 0.02',
        'rank':'max mean R10, max worst-scenario detection, min mean false rate, method declaration order, confirmation, grid index',
        'pilot_acceptance':'constraints satisfied and mean calibration R10 >= original global fine + 0.02',
        'no_feasible_head':'report infeasible; do not loosen constraints or add candidates',
        'future_test':'requires new dates/stations or external dataset; reused evaluation cannot confirm improvement',
        'torch_version':torch.__version__,'numpy_version':np.__version__,
        'input_and_source_sha256':{name:sha(ROOT/name) for name in names}}
    path=OUT/'plan.json'
    if path.exists():
        old=read(path)
        assert {k:v for k,v in old.items() if k!='frozen_at_utc'}==plan,'Keep old experiment; use a new directory for a changed plan'
    else:write(path,{**plan,'frozen_at_utc':datetime.now(timezone.utc).isoformat()})
    return plan


def verify_inputs(plan):
    for name,digest in plan['input_and_source_sha256'].items():assert sha(ROOT/name)==digest,name
    for partition in ('risk_train','risk_validation'):
        metadata=read(RISK/(partition+'.json'))
        assert sha(RISK/(partition+'.npz'))==metadata['cache_sha256']
    metadata=read(CAL/'preparation.json')
    assert sha(CAL/'calibration.npz')==metadata['cache_sha256']
    frozen=read(CAL/'calibration_choice_freeze.json')
    for name in ('selection.json','scores_calibration.npz'):
        assert sha(CAL/name)==frozen['artifact_sha256'][name]


def training(plan):
    tr=load(RISK/'risk_train.npz');va=load(RISK/'risk_validation.npz')
    norm=load(RISK/'normalization.npz')
    pool=lambda part:np.concatenate([part[f'{scenario}_state'][part['common']] for scenario in SCENARIOS])
    x=((pool(tr)-norm['mean'])/norm['std']).astype(np.float32)
    xv=((pool(va)-norm['mean'])/norm['std']).astype(np.float32)
    targets={name:{kind:np.tile(part[kind][part['common']],3).astype(np.float32) for kind in ('truth','onset')}
             for name,part in (('train',tr),('validation',va))}
    summary={'train_pooled_rows':len(x),'validation_pooled_rows':len(xv),
        'train_persistent_fraction':float(targets['train']['truth'].mean()),
        'train_onset_fraction':float(targets['train']['onset'].mean()),
        'calibration_features_used_for_training':False,'models':{}}
    del tr,va
    for mix in MIXES:
        method=f'mixed_state{int(mix*100)}'
        y=mix*targets['train']['truth']+(1-mix)*targets['train']['onset']
        yv=mix*targets['validation']['truth']+(1-mix)*targets['validation']['onset']
        summary['models'][method]=[]
        for seed in SEEDS:
            path=OUT/f'{method}_seed{seed}.pt';record_path=path.with_suffix('.json')
            if path.exists() and record_path.exists():
                record=read(record_path);assert record['weight_sha256']==sha(path)
                assert record['plan_sha256']==sha(OUT/'plan.json')
            elif path.exists() or record_path.exists():raise ValueError('Incomplete training artifacts preserved')
            else:
                started=time.perf_counter();updates=[0];original=torch.optim.Adam.step
                def tracked(optimizer,*args,**kwargs):
                    value=original(optimizer,*args,**kwargs);updates[0]+=1;return value
                from unittest.mock import patch
                with patch.object(torch.optim.Adam,'step',tracked):
                    model,record=fit_uniform(x,y,xv,yv,seed,path)
                assert updates[0]==1350
                record.update({'actual_optimizer_updates':updates[0],'weight_sha256':sha(path),
                    'state_target_weight':mix,'plan_sha256':sha(OUT/'plan.json'),
                    'training_seconds':time.perf_counter()-started})
                write(record_path,record)
            summary['models'][method].append(record)
            print(f'{method} seed={seed} selected_step={record["selected_step"]} validation_BCE={record["validation_bce"]:.6f}',flush=True)
    write(OUT/'training.json',summary)
    write(OUT/'training_freeze.json',{'frozen_at_utc':datetime.now(timezone.utc).isoformat(),
        'plan_sha256':sha(OUT/'plan.json'),'calibration_used_for_checkpoint_selection':False,
        'old_evaluation_values_read':False,
        'weights':{p.name:sha(p) for p in sorted(OUT.glob('*.pt'))}})


def mean(rows,key):return float(np.mean([row[key] for row in rows.values()]))


def select(candidates,reference,budgets):
    def feasible(row):return all(row['by_scenario'][s]['false_per_valid_station_day']<=budgets[s]+1e-12
        and row['by_scenario'][s]['detection_recall']>=reference[s]['detection_recall']-.02-1e-12 for s in SCENARIOS)
    survivors=[row for row in candidates if feasible(row)]
    for row in candidates:row['feasible']=feasible(row)
    if not survivors:return None
    return min(survivors,key=lambda row:(-mean(row['by_scenario'],'warning_recall_at_least10'),
        -min(v['detection_recall'] for v in row['by_scenario'].values()),
        mean(row['by_scenario'],'false_per_valid_station_day'),row['method_index'],row['confirmation'],row['grid_index']))


def calibration(plan):
    assert (OUT/'training_freeze.json').exists()
    training_freeze=read(OUT/'training_freeze.json')
    for name,digest in training_freeze['weights'].items():assert sha(OUT/name)==digest
    old=read(CAL/'selection.json');budgets=old['budgets']
    reference=old['methods']['global_calibration']['fine']['selected']['by_scenario']
    all_candidates=[];by_method={};diagnostic={}
    for index,method in enumerate(('onset_mlp','persistent_mlp','state_logistic','onset_linear')):
        candidates=[]
        for row in old['methods'][method]['fine']['grid']:
            candidates.append({**row,'method':method,'method_index':index})
        chosen=select(candidates,reference,budgets)
        diagnostic[method]={'budget_feasible':sum(row['feasible'] for row in old['methods'][method]['fine']['grid']),
            'joint_constraint_feasible':sum(row['feasible'] for row in candidates),'selected':chosen}
        if chosen:all_candidates.append(chosen)
    write(OUT/'threshold_only_diagnostic.json',diagnostic)
    part=load(CAL/'calibration.npz');norm=load(RISK/'normalization.npz')
    scores=load(CAL/'scores_calibration.npz')
    grid=[round(value/1000,3) for value in range(10,901,5)]+[1.0001]
    for index,mix in enumerate(MIXES,4):
        method=f'mixed_state{int(mix*100)}'
        models=[load_risk(OUT/f'{method}_seed{seed}.pt') for seed in SEEDS]
        own={}
        for scenario in SCENARIOS:
            x=((part[f'{scenario}_state'].reshape(-1,51)-norm['mean'])/norm['std']).astype(np.float32)
            own[scenario]=np.mean([sigmoid(score(model,x)) for model in models],axis=0).reshape(part['truth'].shape)
        np.savez_compressed(OUT/f'{method}_calibration_scores.npz',**own)
        candidates=[]
        for gi,threshold in enumerate(grid):
            for confirmation in (1,2):
                rows={scenario:replay(part,alarm(own[scenario],threshold,confirmation,part),details=True)[0] for scenario in SCENARIOS}
                candidates.append({'method':method,'method_index':index,'grid_index':gi,'threshold':threshold,
                    'confirmation':confirmation,'by_scenario':rows})
        chosen=select(candidates,reference,budgets)
        by_method[method]={'feasible_settings':sum(row['feasible'] for row in candidates),'selected':chosen}
        write(OUT/(method+'_calibration_grid.json'),candidates)
        if chosen:all_candidates.append(chosen)
        print(f'{method}: detection/budget feasible settings={by_method[method]["feasible_settings"]}',flush=True)
    base=old['methods']['global_calibration']['fine']['selected']
    base_alarms={s:alarm(scores[f'global_calibration__{s}'],base['threshold'],base['confirmation'],part) for s in SCENARIOS}
    candidates=[]
    for gi,threshold in enumerate(plan['fallback_onset_thresholds']):
        for confirmation in plan['fallback_confirmations']:
            rows={s:replay(part,base_alarms[s]|alarm(scores[f'onset_mlp__{s}'],threshold,confirmation,part),details=True)[0] for s in SCENARIOS}
            candidates.append({'method':'global_plus_onset','method_index':6,'grid_index':gi,'threshold':threshold,
                'confirmation':confirmation,'global_threshold':base['threshold'],'global_confirmation':base['confirmation'],'by_scenario':rows})
    chosen=select(candidates,reference,budgets)
    by_method['global_plus_onset']={'feasible_settings':sum(row['feasible'] for row in candidates),'selected':chosen}
    write(OUT/'fallback_calibration_grid.json',candidates)
    if chosen:all_candidates.append(chosen)
    winner=select(all_candidates,reference,budgets)
    assert winner is not None,'Fallback-off should reproduce original global rule'
    # Off-fallback is an exact implementation check against the old saved replay.
    for s in SCENARIOS:
        for key in ('warning_recall_at_least10','warning_recall','detection_recall','false_per_valid_station_day'):
            assert candidates[-1]['by_scenario'][s][key]==reference[s][key],(s,key)
    baseline={method:old['methods'][method]['fine']['selected'] for method in ('global_calibration','group_calibration','onset_mlp','persistent_mlp')}
    result={'stage':'calibration_only_exploratory','plan_sha256':sha(OUT/'plan.json'),
        'old_evaluation_values_read':False,'raw_hdf5_read':False,'independent_test_executed':False,
        'calibration_events':int(reference['natural']['events']),'calibration_days':14,
        'budgets':budgets,'detection_floor':{s:reference[s]['detection_recall']-.02 for s in SCENARIOS},
        'baseline_original_settings':baseline,'threshold_only_diagnostic':diagnostic,'candidate_families':by_method,
        'selected':winner,'pilot_acceptance_passed':mean(winner['by_scenario'],'warning_recall_at_least10')>=mean(reference,'warning_recall_at_least10')+.02-1e-12,
        'calibration_only_means':{method:{key:mean(row['by_scenario'],key) for key in ('warning_recall_at_least10','warning_recall','detection_recall','false_per_valid_station_day')}
            for method,row in {**baseline,'selected_candidate':winner}.items()}}
    write(OUT/'results.json',result)
    write(OUT/'selection_freeze.json',{'frozen_at_utc':datetime.now(timezone.utc).isoformat(),
        'results_sha256':sha(OUT/'results.json'),'plan_sha256':sha(OUT/'plan.json'),
        'selected':{key:value for key,value in winner.items() if key!='by_scenario'},'old_evaluation_values_read':False})
    print(json.dumps({'winner':winner['method'],'pilot_acceptance_passed':result['pilot_acceptance_passed'],
        'calibration_only_means':result['calibration_only_means']},ensure_ascii=True),flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--stage',choices=('train','calibrate','all'),default='all');args=parser.parse_args()
    sys.addaudithook(audit)
    torch.set_num_threads(1);torch.use_deterministic_algorithms(True)
    plan=freeze_plan();verify_inputs(plan)
    if args.stage in ('train','all'):training(plan)
    if args.stage in ('calibrate','all'):calibration(plan)
    for name,digest in plan['input_and_source_sha256'].items():assert sha(ROOT/name)==digest,name
    write(OUT/'access_log.json',{'logical_input_reads':sorted(set(READS)),
        'evaluation_and_raw_hdf5_runtime_open_guard_enabled':True,'old_evaluation_values_read':False,
        'old_scientific_input_hashes_unchanged':True})


if __name__=='__main__':main()
