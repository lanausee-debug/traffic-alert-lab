"""Save a cumulative writing/slide checkpoint, preserving prior archives."""
from __future__ import annotations
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'outputs/undergraduate-slides'
CHECKPOINTS = ROOT.parent / 'checkpoints'
NAME = 'traffic-recovery-lab-2026-10-13-undergraduate-slides'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


def main():
    archive = CHECKPOINTS / (NAME + '.zip')
    receipt_path = CHECKPOINTS / (NAME + '-save-receipt.json')
    if archive.exists() or receipt_path.exists():
        raise FileExistsError('Preserve existing archives; choose a new name')
    prior_path = 'outputs/undergraduate-defense/writing_archive_manifest.json'
    previous = read(ROOT / prior_path)
    for p, item in previous['files'].items():
        if p not in {'README.md', 'CURRENT_STATE.zh-CN.md'}:
            assert sha(ROOT / p) == item['sha256'], p
    quality = read(OUT / 'quality_review.json')
    assert quality['visual_review_completed'] and quality['primary_metric_supported'] is False
    assert sha(ROOT / quality['final_path']) == quality['final_sha256']
    build = read(OUT / 'build/build_manifest-v2.json')
    for p, digest in build['sources'].items():
        assert sha(ROOT / p) == digest, p
    additions = {
        prior_path, quality['final_path'], 'build_undergraduate_slides.mjs', 'render_undergraduate_slides.ps1',
        'check_undergraduate_slides.py', 'save_undergraduate_slides_checkpoint.py',
        'docs/undergraduate_slides_handoff.zh-CN.md', 'outputs/undergraduate-slides/quality_review.json',
        *['outputs/undergraduate-slides/build/'+p for p in
          ('candidate-v2.pptx', 'slide_content.json', 'presentation.json', 'validation-v2.json', 'build_manifest-v2.json')],
        *[p.relative_to(ROOT).as_posix() for p in (OUT / 'powerpoint-v2').iterdir() if p.is_file()],
    }
    files = set(previous['files']) | additions
    base_receipt_path = CHECKPOINTS / 'traffic-recovery-lab-2026-10-11-event-timeline-save-receipt.json'
    base_receipt = read(base_receipt_path)
    base = Path(base_receipt['full_archive'])
    assert base.stat().st_size == base_receipt['full_archive_bytes']
    assert base_receipt['archive_crc_and_all_sha256_verified']
    with ZipFile(base) as z:
        available = {p.removeprefix('traffic-recovery-lab/') for p in z.namelist()} | files
        assert all(p in available for p in build['sources'])
        for p in files:
            if p.endswith('/documentation_manifest.json'):
                sources = read(ROOT / p).get('source_sha256', {})
                if isinstance(sources, dict):
                    assert all(s in available for s in sources), p
    manifest_path = OUT / 'writing_archive_manifest.json'
    dump(manifest_path, {
        'stage': 'cumulative_undergraduate_defense_slides', 'client_date': '2026-10-13',
        'archive_name': archive.name,
        'scope': 'Restore October 11 full base, then this cumulative writing/slide supplement.',
        'base_archive': {'name': base.name, 'sha256_from_prior_verified_receipt': base_receipt['full_archive_sha256'],
                         'prior_verified_at_utc': base_receipt['saved_at_utc'], 'full_crc_rechecked_this_turn': False},
        'files': {p: {'bytes': (ROOT / p).stat().st_size, 'sha256': sha(ROOT / p)} for p in sorted(files)},
        'two_archive_documentation_dependencies_present': True, 'slides': 13,
        'visual_review_completed': True, 'primary_metric_supported': False,
        'word_updated': False, 'research_training_performed': False, 'research_weights_changed': False,
        'traffic_speed_values_decoded': False, 'github_uploaded': False,
        'external_runtime_and_office_bundled': False,
    })
    files.add(manifest_path.relative_to(ROOT).as_posix())
    with ZipFile(archive, 'x', compression=ZIP_DEFLATED, compresslevel=6) as z:
        for p in sorted(files):
            z.write(ROOT / p, 'traffic-recovery-lab/' + p)
    with ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist()) == len(files)
        for p in files:
            data = z.read('traffic-recovery-lab/'+p)
            assert data == (ROOT / p).read_bytes(), p
            assert hashlib.sha256(data).hexdigest() == sha(ROOT / p), p
    receipt = {
        'saved_at_utc': datetime.now(timezone.utc).isoformat(), 'stage': 'cumulative_undergraduate_defense_slides',
        'archive': str(archive), 'archive_bytes': archive.stat().st_size, 'archive_sha256': sha(archive),
        'archived_files': len(files), 'archive_crc_and_all_file_bytes_and_sha256_verified': True,
        'full_base_prior_receipt': str(base_receipt_path), 'full_base_reverified_this_turn': False,
        'two_archive_documentation_dependencies_present': True, 'manifest': str(manifest_path),
        'delivered_deck_sha256': quality['final_sha256'], 'visual_review_completed': True,
        'primary_metric_supported': False, 'word_updated': False, 'github_uploaded': False,
    }
    dump(receipt_path, receipt)
    print(json.dumps(receipt, ensure_ascii=True))


if __name__ == '__main__':
    main()
