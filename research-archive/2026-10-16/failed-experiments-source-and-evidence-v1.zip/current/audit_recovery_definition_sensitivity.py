"""Independent maximal-low/high-run reconstruction of recovery definitions."""
from datetime import datetime,timezone
import sys
import numpy as np
import torch
import recovery_definition_sensitivity as pilot
import effective_alert_pilot as previous
import calibration_fragility as common
import alarm_start_separability as probe
import early_warning_protection as protection
from audit_early_warning_protection import independent_observed_low,interval_gate
from complete_bypass_diagnosis import json_native
from congestion_alert_pilot import SCENARIOS,runs
from pems_bay_alert_replay import alarm,replay,layout
from train_pems_bay_risk import load_risk


def independent_labels(part,support,low,k):
    """Enumerate maximal runs, rather than the pilot's samplewise state machine."""
    labels=np.zeros_like(support);records=[]
    for slo,shi in layout(part)[0]:
        for node in range(support.shape[1]):
            for a,b in runs(support[slo:shi,node]):
                lo,hi=int(slo+a),int(slo+b);first=int(part['origins'][lo]);last=int(part['origins'][hi-1])+3
                lows=low[first:last,node]
                triggers=[first+int(a) for a,b in runs(lows) if b-a>=3]
                recoveries=[first+int(a) for a,b in runs(~lows) if b-a>=k]
                covered_until=first
                for q in triggers:
                    if q<covered_until:continue
                    possible=[h for h in recoveries if h>=q+3]
                    confirmed=bool(possible);h=possible[0] if confirmed else last
                    end=h-2 if confirmed else int(part['origins'][hi-1])+1
                    left=q-first+lo;right=end-first+lo
                    labels[max(lo,left):min(hi,right),node]=True
                    records.append({'node':node,'eligible_start_row':lo,'eligible_end_row':hi,
                        'physical_start_origin':q,'first_recovery_high_origin':h if confirmed else None,
                        'recovery_confirmation_origin':h+k-1 if confirmed else None,
                        'proxy_start_row':left,'proxy_end_row':right,'proxy_start_origin':q,
                        'proxy_end_origin_exclusive':end,'end_confirmed':confirmed})
                    covered_until=h if confirmed else last
    return labels,records


def independent_runs(part,truth,support):
    result=[]
    for slo,shi in layout(part)[0]:
        for node in range(truth.shape[1]):
            for a,b in runs(support[slo:shi,node]):
                lo,hi=int(slo+a),int(slo+b)
                for a,b in runs(truth[lo:hi,node]):
                    s,e=int(lo+a),int(lo+b)
                    result.append({'node':node,'start_row':s,'end_row':e,
                        'event_start_origin':int(part['origins'][s]),'event_end_origin_exclusive':int(part['origins'][e-1])+1,
                        'complete':s-2>=lo and e<hi})
    return result


def main():
    sys.addaudithook(protection.guard);torch.set_num_threads(1)
    root=pilot.ROOT;out=pilot.OUT;r=common.read(out/'results.json');plan=common.read(out/'plan.json')
    done=common.read(out/'completion.json')
    for n,h in plan['source_and_input_sha256'].items():assert common.sha(root/n)==h,n
    for n,h in done['artifacts'].items():assert common.sha(out/n)==h,n
    assert done['plan_sha256']==common.sha(out/'plan.json')
    assert datetime.fromisoformat(plan['frozen_at_utc'])<datetime.fromisoformat(done['completed_at_utc'])
    seal=common.read(previous.OUT/'training_freeze.json');assert r['cutoff']==seal['cutoff']
    assert r['model_sha256']==seal['model_sha256']==common.sha(previous.OUT/'effective_model.npz')
    model=common.load(previous.OUT/'effective_model.npz');norm=common.load(common.RISK/'normalization.npz')
    anchor=load_risk(common.RISK/'global_calibration.pt')
    parts={'training28':common.load(common.RISK/'risk_train.npz'),
        'risk_validation7':common.load(common.RISK/'risk_validation.npz'),
        'calibration_full14':common.load(common.CAL/'calibration.npz')}
    parts.update({'calibration_week1_7':common.subset(parts['calibration_full14'],0,7),
        'calibration_week2_7':common.subset(parts['calibration_full14'],7,14)})
    old=common.read(previous.OUT/'results.json');old_active=common.load(previous.OUT/'activations.npz')
    previous_diag=common.read(root/'outputs/proxy-event-semantics-2026-10-16/results.json')
    stored=common.load(out/'shared_labels.npz');daily=common.load(out/'daily.npz')
    counts={'original_full_replays':0,'shared_definition_replays':0,'labels_reconstructed':0,
        'old_runs_mapped':0,'case_lineages_checked':0,'shared_support_points_including_halves':0}
    for block,part in parts.items():
        x=part['natural_state'];speed=np.full((len(part['timestamps']),x.shape[1]),np.nan);low=np.zeros_like(speed,bool)
        for i,t in enumerate(part['origins']):
            valid=(x[i,:,12]>0)&(np.abs(x[i,:,13])<1e-6)&(x[i,:,8]>0)
            speed[t-1,valid]=x[i,valid,8].astype(float)*70
            low[t-1,valid]=x[i,valid,8]<=np.float32(30/70)
        future=np.stack([speed[part['origins']+i] for i in range(3)],axis=1)
        available=np.isfinite(future).all(axis=1);ambiguous=(np.abs(future-30)<=1e-4).any(axis=1)
        support=part['eligible']&available&~ambiguous
        np.testing.assert_array_equal(support,stored[block+'__support'])
        info={'original_station_day_exposure':float(part['eligible'].sum()/288),'shared_station_day_exposure':float(support.sum()/288),
            'original_valid_points':int(part['eligible'].sum()),'shared_valid_points':int(support.sum()),
            'original_eligible_but_future_cache_unknown':int((part['eligible']&~available).sum()),
            'original_eligible_known_but_precision_band':int((part['eligible']&available&ambiguous).sum())}
        data=r['blocks'][block];assert info==data['shared_evidence']
        labels={}
        for name,k in [('one_high',1),('two_high',2)]:
            labels[name],physical=independent_labels(part,support,low,k)
            np.testing.assert_array_equal(labels[name],stored[block+'__'+name])
            assert physical==data['physical_records'][name]
            counts['labels_reconstructed']+=1
        np.testing.assert_array_equal(labels['one_high'][support],part['truth'][support])
        assert not (labels['one_high']&~labels['two_high']).any()
        oldruns=independent_runs(part,labels['one_high'],support);newruns=independent_runs(part,labels['two_high'],support)
        mapping=[]
        for e in oldruns:
            matches=[j for j,v in enumerate(newruns) if v['node']==e['node'] and v['start_row']<=e['start_row'] and e['end_row']<=v['end_row']]
            assert len(matches)==1;j=matches[0];mapping.append({'old':e,'new_run_index':j,'new':newruns[j]})
        link={'old_runs':oldruns,'new_runs':newruns,'old_to_new':mapping,
            'old_complete_events':sum(e['complete'] for e in oldruns),'new_complete_events':sum(e['complete'] for e in newruns),
            'new_runs_with_multiple_old_runs':sum(sum(m['new_run_index']==j for m in mapping)>1 for j in range(len(newruns))),
            'old_complete_mapped_to_new_censored':sum(e['old']['complete'] and not e['new']['complete'] for e in mapping),
            'old_complete_mapped_to_earlier_start':sum(e['old']['complete'] and e['new']['event_start_origin']<e['old']['event_start_origin'] for e in mapping)}
        assert link==data['lineage'];counts['old_runs_mapped']+=len(mapping)
        scores=common.global_scores(part,norm,anchor)
        for scenario in SCENARIOS:
            p=scores[scenario];cred=probe.predict(model,probe.start_features(part,scenario,p).reshape(-1,30)).reshape(part['truth'].shape)
            bits={'global_c1':alarm(p,.46,1,part),
                'effective_no_bypass':interval_gate(p,cred,np.zeros_like(p,bool),part,seal['cutoff']),
                previous.PRIMARY:interval_gate(p,cred,independent_observed_low(part,scenario),part,seal['cutoff'])}
            eventmaps={}
            for method,b in bits.items():
                row,_,_=replay(part,b,details=True)
                assert row==data['original_full'][scenario][method]==previous_diag['blocks'][block]['scenarios'][scenario][method]['operating']
                if block!='training28':
                    assert row==old['evaluation'][block][method][scenario]
                    np.testing.assert_array_equal(b,old_active[f'{block}__{method}__{scenario}'])
                counts['original_full_replays']+=1
            for definition,truth in labels.items():
                eventmaps[definition]={};local={**part,'eligible':support,'truth':truth}
                for method,b in bits.items():
                    expected=data['shared_evaluation'][definition][scenario][method]
                    row,days,events=replay(local,b,details=True)
                    assert row==expected['operating'] and events==expected['event_records']
                    np.testing.assert_array_equal(days,daily[f'{block}__{definition}__{scenario}__{method}'])
                    episodes=common.episodes(local,b);assert json_native(episodes)==expected['episode_records']
                    for kind,column in [('warned','warned'),('late','late'),('false','false'),('duplicate','duplicate'),('censored','censored_alerts'),('unknown','unknown_alerts')]:
                        assert sum(e['kind']==kind for e in episodes)==row[column]
                    assert np.isclose(row['exposure'],support.sum()/288)
                    assert row['events']==link['old_complete_events' if definition=='one_high' else 'new_complete_events']
                    eventmaps[definition][method]={(e['node'],e['event_start_origin']):e for e in events}
                    counts['shared_definition_replays']+=1
            for case in data['case_lineage'][scenario]:
                key=tuple(case['original_node_event_key'])
                matches=[m for m in mapping if (m['old']['node'],m['old']['event_start_origin'])==key]
                assert case['on_shared_support']==bool(matches)
                if not matches:continue
                m=matches[0];assert case['old_run']==m['old'] and case['new_run']==m['new']
                newkey=(key[0],m['new']['event_start_origin'])
                assert case['one_high_methods']=={method:eventmaps['one_high'][method].get(key) for method in pilot.METHODS}
                assert case['two_high_methods']=={method:eventmaps['two_high'][method].get(newkey) for method in pilot.METHODS}
                counts['case_lineages_checked']+=1
        counts['shared_support_points_including_halves']+=int(support.sum())
    assert r['new_models_fitted']==r['optimizer_updates']==0 and not r['online_policy_changed'] and not r['original_labels_changed']
    assert r['original_thesis_primary_test_still_failed'] and not r['previous_candidate_acceptance_passed']
    assert not r['definition_selected_on_results'] and not r['new_acceptance_test_performed']
    assert not r['new_station_cohort_consumed'] and not r['consumed_transfer_values_used']
    audit={'passed':True,'audited_at_utc':datetime.now(timezone.utc).isoformat(),**counts,
        'different_maximal_run_algorithm_matches_state_machine':True,'one_high_matches_old_truth_on_shared_support':True,
        'new_truth_superset_old_on_shared_support':True,'prior36_activations_reproduced':True,
        'results_sha256':common.sha(out/'results.json'),'scientific_source_and_input_hashes_preserved':True,
        'new_models_fitted':0,'online_policy_changed':False,'original_labels_changed':False,
        'original_thesis_primary_test_still_failed':True,'new_station_cohort_consumed':False,
        'runtime_output_paths':sorted(set(common.READS))}
    common.write(out/'audit.json',audit);print({k:v for k,v in audit.items() if k!='runtime_output_paths'})


if __name__=='__main__':main()
