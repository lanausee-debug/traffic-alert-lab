"""Save the verified reference-updated Word edition as a new cumulative archive."""
from __future__ import annotations
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
import re
import xml.etree.ElementTree as ET
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'outputs/thesis-word-references-2026-10-13'
CHECKPOINTS = ROOT.parent / 'checkpoints'
NAME = 'traffic-recovery-lab-2026-10-13-thesis-word-references'
NEW_WORD = 'docs/thesis_review.references-2026-10-13.zh-CN.docx'
NEW_MD = 'docs/thesis_manuscript.references-2026-10-13.zh-CN.md'
NS = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
      'm': 'http://schemas.openxmlformats.org/officeDocument/2006/math'}


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def record(path):
    return {'bytes': path.stat().st_size, 'sha256': sha(path)}


def xml(path):
    with ZipFile(path) as z:
        assert z.testzip() is None
        return ET.fromstring(z.read('word/document.xml'))


def clean(text):
    text = re.sub(r'\[([^\]]+)\]\([^)]+\)', r'\1', text)
    return re.sub(r'\s+', '', text.replace('\u200b', '').replace('［', '[').replace('］', ']'))


def main():
    import build_thesis_referenced_manuscript as manuscript
    for name, content in manuscript.build().items():
        assert (ROOT / name).read_bytes() == content, name
    archive = CHECKPOINTS / (NAME + '.zip')
    receipt_path = CHECKPOINTS / (NAME + '-save-receipt.json')
    if archive.exists() or receipt_path.exists():
        raise FileExistsError('Preserve existing checkpoints; use a new archive name.')
    qa, export, author = [read(OUT / p) for p in ('qa.json', 'word_export.json', 'authoring_manifest.json')]
    assert qa['pages'] == export['pages'] == 68
    assert qa['all_final_pages_visually_reviewed'] and qa['reviewed_pages'] == list(range(1, 69))
    assert qa['docx_sha256'] == export['docx_sha256'] == author['docx_sha256'] == sha(ROOT / NEW_WORD)
    assert qa['pdf_sha256'] == export['pdf_sha256'] == sha(OUT / 'word-preview.pdf')
    assert qa['source_sha256'] == author['source_sha256'] == sha(ROOT / NEW_MD)
    old_word = ROOT / 'docs/thesis_review.zh-CN.docx'
    assert sha(old_word) == read(ROOT / 'outputs/thesis-word/qa.json')['docx_sha256']
    old, new = xml(old_word), xml(ROOT / NEW_WORD)
    for selector in ('.//m:oMath', './/w:tbl'):
        assert [ET.tostring(e) for e in old.findall(selector, NS)] == [ET.tostring(e) for e in new.findall(selector, NS)]
    paragraphs = {clean(''.join(t.text or '' for t in p.findall('.//w:t', NS))) for p in new.findall('.//w:p', NS)}
    entries = read(ROOT / 'outputs/thesis-manuscript-references-2026-10-13/replacement_entries.json')
    assert all(clean(e) in paragraphs for e in entries.values())
    previous = read(ROOT / 'outputs/thesis-bibliography-review/writing_archive_manifest.json')
    changed_tools = {'README.md', 'CURRENT_STATE.zh-CN.md', 'build_thesis_word.py', 'render_thesis_word.ps1',
                     'render_thesis_pages.py', 'check_thesis_word.py'}
    for p, item in previous['files'].items():
        if p not in changed_tools:
            assert sha(ROOT / p) == item['sha256'], p
    sources = ['build_thesis_referenced_manuscript.py', 'build_thesis_word.py', 'render_thesis_word.ps1',
               'render_thesis_pages.py', 'check_thesis_word.py', Path(__file__).name,
               'docs/thesis_bibliography_amendments.json', NEW_MD,
               'outputs/thesis-manuscript-references-2026-10-13/documentation_manifest.json']
    artifacts = [NEW_WORD, 'docs/thesis_word_references_handoff.zh-CN.md',
                 *['outputs/thesis-word-references-2026-10-13/' + p for p in
                   ('authoring_manifest.json', 'word_export.json', 'qa.json', 'method_flow.png', 'word-preview.pdf')]]
    renderer = Path('${USER_HOME}/.codex/plugins/cache/openai-primary-runtime/documents/26.1011.11113/skills/documents/render_docx.py')
    dump(OUT / 'documentation_manifest.json', {
        'stage': 'reference_updated_word_after_final_68_page_visual_qa', 'client_date': '2026-10-13',
        'source_sha256': {p: sha(ROOT / p) for p in sources}, 'files': {p: record(ROOT / p) for p in artifacts},
        'page_images_sha256': {f'page-{i}.png': sha(OUT / f'pages/page-{i}.png') for i in range(1, 69)},
        'pages': 68, 'all_final_pages_visually_reviewed': True, 'reviewed_pages': list(range(1, 69)),
        'review_image_dpi': 120, 'page_pairs_resized': False,
        'old_word_sha256_preserved': sha(old_word), 'all_native_math_and_table_xml_identical_to_old_word': True,
        'amended_reference_docx_paragraphs_verified': 4,
        'pdf_engine': 'Microsoft Word', 'canonical_renderer_sha256': sha(renderer),
        'office_xslt_sha256': author['xslt_sha256'], 'external_runtime_office_and_skill_resources_included': False,
        'degree_level': 'undergraduate', 'primary_metric_supported': False, 'school_submission_format_complete': False,
    })
    additions = set(sources + artifacts) | {
        'outputs/thesis-bibliography-review/writing_archive_manifest.json',
        'docs/thesis_manuscript.references-2026-10-13_review.zh-CN.md',
        'outputs/thesis-word-references-2026-10-13/documentation_manifest.json',
        'outputs/thesis-manuscript-references-2026-10-13/structure.json',
        'outputs/thesis-manuscript-references-2026-10-13/replacement_entries.json',
    }
    files = set(previous['files']) | additions
    base_receipt_path = CHECKPOINTS / 'traffic-recovery-lab-2026-10-11-event-timeline-save-receipt.json'
    base_receipt = read(base_receipt_path)
    base = Path(base_receipt['full_archive'])
    assert base.stat().st_size == base_receipt['full_archive_bytes']
    assert base_receipt['archive_crc_and_all_sha256_verified']
    with ZipFile(base) as z:
        available = {p.removeprefix('traffic-recovery-lab/') for p in z.namelist()} | files
    missing = []
    for p in files:
        if p.endswith('/documentation_manifest.json'):
            inputs = read(ROOT / p).get('source_sha256', {})
            if isinstance(inputs, dict):
                missing += [(p, s) for s in inputs if s not in available]
    assert not missing, missing
    manifest = OUT / 'writing_archive_manifest.json'
    dump(manifest, {
        'stage': 'cumulative_reference_updated_word_checkpoint', 'client_date': '2026-10-13',
        'archive_name': archive.name, 'scope': 'Restore full October 11 base, then this cumulative writing supplement.',
        'base_archive': {'name': base.name, 'sha256_from_prior_verified_receipt': base_receipt['full_archive_sha256'],
                         'prior_verified_at_utc': base_receipt['saved_at_utc'], 'full_crc_rechecked_this_turn': False},
        'files': {p: record(ROOT / p) for p in sorted(files)}, 'changed_prior_tools': sorted(changed_tools),
        'old_stage_manifests_are_historical_snapshots': True, 'two_archive_documentation_dependencies_present': True,
        'word_updated': True, 'old_word_preserved': True, 'primary_metric_supported': False, 'github_uploaded': False,
    })
    files.add(manifest.relative_to(ROOT).as_posix())
    with ZipFile(archive, 'x', compression=ZIP_DEFLATED, compresslevel=6) as z:
        for p in sorted(files):
            z.write(ROOT / p, 'traffic-recovery-lab/' + p)
    with ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist()) == len(files)
        for p in files:
            assert z.read('traffic-recovery-lab/' + p) == (ROOT / p).read_bytes(), p
    receipt = {
        'saved_at_utc': datetime.now(timezone.utc).isoformat(), 'stage': 'cumulative_reference_updated_word_checkpoint',
        'archive': str(archive), 'archive_bytes': archive.stat().st_size, 'archive_sha256': sha(archive),
        'archived_files': len(files), 'archive_crc_and_all_file_bytes_verified': True,
        'two_archive_documentation_dependencies_present': True, 'full_base_reverified_this_turn': False,
        'full_base_prior_receipt': str(base_receipt_path), 'manifest': str(manifest),
        'all_final_68_pages_visually_reviewed': True, 'old_word_preserved': True,
        'new_word_sha256': qa['docx_sha256'], 'primary_metric_supported': False, 'github_uploaded': False,
    }
    dump(receipt_path, receipt)
    print(json.dumps(receipt, ensure_ascii=True))


if __name__ == '__main__':
    main()
