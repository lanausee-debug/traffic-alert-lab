"""Cumulative archive: consumed-cohort ranking signal and early-warning losses."""
from datetime import datetime,timezone
from pathlib import Path
import hashlib
from zipfile import ZipFile,ZIP_DEFLATED
from save_station_agnostic_checkpoint import read,write,sha

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs/frozen-probe-transfer-2026-10-15'
NAME='traffic-recovery-lab-2026-10-15-frozen-probe-transfer'


def main():
    archive=ROOT.parent/'checkpoints'/(NAME+'.zip');receipt=archive.with_name(NAME+'-save-receipt.json')
    if archive.exists() or receipt.exists():raise FileExistsError('Preserve existing archives')
    r=read(OUT/'results.json');audit=read(OUT/'audit.json');tests=read(OUT/'test_receipt.json')
    assert audit['passed'] and tests['passed'] and tests['tests_run']==7
    assert sha(ROOT/'tests/test_frozen_probe_transfer.py')==tests['test_source_sha256']
    assert r['natural_diagnostic_gate']['passed'] and not r['new_alarm_policy_accepted']
    assert r['cohort_already_consumed'] and not r['new_station_cohort_consumed']
    assert not r['probes_or_thresholds_refit'] and r['original_development_diagnostic_gate_still_failed']
    for name,digest in read(OUT/'completion.json')['artifacts'].items():assert sha(OUT/name)==digest
    prior_path='outputs/alarm-start-separability-2026-10-15/writing_archive_manifest.json';prior=read(ROOT/prior_path)
    for name,meta in prior['files'].items():assert sha(ROOT/name)==meta['sha256'],name
    summary=('3个判别器与分界线固定，在已消耗的另一24站83日缓存做探索。自然状态AUC=0.802、AP=0.761；'
        '三个子块AUC=0.793/0.819/0.798，排序诊断通过。固定分界线却只保留70.2%的R10预警：'
        '5/10/15分钟代理预警分别保留95.3%/79.5%/59.2%，不能直接过滤或宣传误报减半。')
    marker='# 最新检查点：固定判别器跨站探索（2026-10-15）'
    p=ROOT/'CURRENT_STATE.zh-CN.md';old=p.read_text(encoding='utf-8');assert marker not in old
    p.write_text(marker+'\n\n- '+summary+'\n'
        '- 该24站与原开发零重叠但此前已分析过，同路网同期、前端此前适配，本轮不重训、不重开HDF5。不是新的未见/外部独立确认。\n'
        '- 自然任务620获记预警/869误报；迟报和重复排除。固定分类分界线拒绝435误报同时拒绝83获记预警，其中64条原R10。分类拒绝率不是完整告警服务收益。\n'
        '- 上轮原开发AP联合诊断仍失败、原论文主检验仍失败；本轮排序通过不覆盖旧失败，也未接受新告警策略。\n'
        '- 7项测试最终通过，独立审计重建12样本集、60组指标及6000组情景/日期抽样，所有固定权重、分界线及旧科学文件哈希保持。\n'
        '- 报告outputs/frozen-probe-transfer-2026-10-15/report.zh-CN.md；接续docs/frozen_probe_transfer_handoff.zh-CN.md。下一轮应只在原开发段设计显式的早期预警保护，不能按本次站点调分界线。\n'
        '- 原Word/PPT与GitHub v7不变，真实缓存和输出仅本地；全新站点未选择/解码。最新累计包2026-10-15-frozen-probe-transfer，先10月11日基包再本累计包恢复。\n\n以下为之前阶段记录。\n\n'+old,encoding='utf-8')
    p=ROOT/'README.md';old=p.read_text(encoding='utf-8')
    p.write_text('# 最新研究：跨站排序信号保持，早期预警保护不足\n\n'
        '[完整报告](outputs/frozen-probe-transfer-2026-10-15/report.zh-CN.md) · [接续说明](docs/frozen_probe_transfer_handoff.zh-CN.md)\n\n'
        +summary+' 这是已分析站点的探索，非独立确认。原论文和线上版本保持。最新累计包为2026-10-15-frozen-probe-transfer。\n\n以下为之前阶段记录。\n\n'+old,encoding='utf-8')
    files=set(prior['files'])|{prior_path,'frozen_probe_transfer.py','audit_frozen_probe_transfer.py',
        'summarize_frozen_probe_transfer.py','save_frozen_probe_transfer_checkpoint.py',
        'tests/test_frozen_probe_transfer.py','docs/frozen_probe_transfer_handoff.zh-CN.md'}
    files|={p.relative_to(ROOT).as_posix() for p in OUT.rglob('*') if p.is_file() and p.name!='writing_archive_manifest.json'}
    base_path=ROOT.parent/'checkpoints/traffic-recovery-lab-2026-10-11-event-timeline-save-receipt.json';base=read(base_path)
    assert Path(base['full_archive']).stat().st_size==base['full_archive_bytes'] and base['archive_crc_and_all_sha256_verified']
    manifest=OUT/'writing_archive_manifest.json'
    write(manifest,{'client_date':'2026-10-15','stage':'cumulative_consumed_cohort_fixed_probe_transfer',
        'archive_name':archive.name,'restore':'October11 full base, then this supplement',
        'exploratory_transfer_diagnostic_gate_passed':True,'new_alarm_policy_accepted':False,
        'new_station_cohort_consumed':False,'cached_previously_consumed_cohort_only':True,
        'probes_or_thresholds_refit':False,'unit_tests_observed_passed':7,
        'all60_metric_pairs_independently_checked':True,'all6000_scenario_date_draws_expanded_checked':True,
        'prior_files_changed':['README.md','CURRENT_STATE.zh-CN.md'],
        'original_development_diagnostic_gate_still_failed':True,'original_thesis_primary_test_still_failed':True,
        'public_commit_unchanged':'ab8760a3e6ea1784fea3195a0e7aadbaff6fe80d',
        'base_crc_rechecked_this_turn':False,'base_sha256_from_prior_verified_receipt':base['full_archive_sha256'],
        'files':{n:{'bytes':(ROOT/n).stat().st_size,'sha256':sha(ROOT/n)} for n in sorted(files)}})
    files.add(manifest.relative_to(ROOT).as_posix())
    with ZipFile(archive,'x',compression=ZIP_DEFLATED) as z:
        for n in sorted(files):z.write(ROOT/n,'traffic-recovery-lab/'+n)
    with ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist())==len(files)
        for n in sorted(files):
            data=z.read('traffic-recovery-lab/'+n)
            assert data==(ROOT/n).read_bytes() and hashlib.sha256(data).hexdigest()==sha(ROOT/n)
    proof={'saved_at_utc':datetime.now(timezone.utc).isoformat(),'archive':str(archive),
        'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'files':len(files),
        'crc_and_all_file_bytes_and_sha256_verified':True,'exploratory_transfer_diagnostic_gate_passed':True,
        'new_alarm_policy_accepted':False,'new_station_cohort_consumed':False,
        'original_thesis_primary_test_still_failed':True,'public_version_unchanged':True,
        'base_prior_verified_receipt':str(base_path),'base_crc_rechecked_this_turn':False}
    write(receipt,proof);print(proof)


if __name__=='__main__':main()
