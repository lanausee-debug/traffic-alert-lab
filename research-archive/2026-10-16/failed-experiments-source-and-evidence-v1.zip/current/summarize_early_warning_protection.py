"""Report full replay: original early warnings retained, late detections lost."""
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
import early_warning_protection as pilot
import calibration_fragility as common
ROOT=pilot.ROOT;OUT=pilot.OUT
def pct(v):return '不可计算' if v is None else f'{100*v:.2f}%'


def main():
    r=common.read(OUT/'results.json');audit=common.read(OUT/'audit.json');assert audit['passed']
    assert not r['primary_acceptance_passed']
    diagnosis=common.read(OUT/'matched_event_diagnosis.json')
    common.write(OUT/'test_receipt.json',{'recorded_at_utc':datetime.now(timezone.utc).isoformat(),
        'command':'.venv/Scripts/python.exe -m unittest discover -s tests -p test_early_warning_protection.py -v',
        'tests_run':9,'observed_exit_code':0,'passed':True,
        'basis':'Successful tool output before full pilot; report generator does not rerun unchanged tests',
        'test_source_sha256':common.sha(ROOT/'tests/test_early_warning_protection.py')})
    full=r['means']['calibration_full14'];reference=full['global_c1'];primary=full[pilot.PRIMARY]
    reduction=1-primary['false_per_valid_station_day']/reference['false_per_valid_station_day']
    names={'global_c1':'原全局一次确认','old_gate':'旧分界线过滤',
        'early_cutoff_gate':'训练早预警保护分界线','old_gate_observed_low':'旧分界线+已观测低速豁免',pilot.PRIMARY:'主方案：保护分界线+低速豁免'}
    lines=['# 显式早期预警保护：开发完整回放未通过','',
        '日期：2026-10-15。**在本轮已使用过的原开发数据中，主方案保住全部原≥10分钟代理预警及其提前量；但减少了迟报检出，仍未通过验收。** 这是完整告警事件回放，不再把分类样本排除率当服务改善。','',
        '## 方案在做什么','',
        '车速前端、原全局风险头、30维告警起点判别器全部固定。原概率阈值0.46/c1不改；仅改变是否允许一次原告警开启。','',
        f"第一层，分界线只按原28日训练起点确定：取旧95%任意预警保留分界线{r['parameters']['old_cutoff']:.15f}与全部原训练≥10分钟预警最低判别概率的较小值，得到{r['parameters']['protected_cutoff']:.15f}。后者由84条训练情景记录确定，其中35条为15分钟代理提前量；三情景相关，不能当成独立事件数。没有读取后来开发块或已消耗站点来挑分界线。",'',
        '第二层，准备开启告警时，若最近三条新鲜可用的本站观测均≤30 mph，就允许原告警通过。三条观测为v(t−3),v(t−2),v(t−1)，要求origin/时钟相邻、观测年龄为0且可用。断点和分块前两行无此豁免。不用未来三读数有效性、真值或之后的事件类别。','',
        '对原风险连续阳性段，只在起点判断一次：满足分界线或已观测低速豁免则保留整个原阳性段，否则整个拒绝；不在中途重新进入，不等待未来观测。这与上一轮“多等一次确认”是不同决策。','',
        '主方案固定为两层同时启用。预定三项消融分别是旧分界线、仅保护分界线、旧分界线加低速豁免；消融不能替代失败的主方案。','',
        '## 预先固定的验收','',
        '- 14日校准平均误报至少下降10%，且各情景不超过原误报预算。','- 完整校准14日、风险验证7日、校准前7日、校准后7日，各块各情景误报不增、R10不降、检出下降不超过2个百分点。','- 逐个对齐原事件：每条原≥10分钟预警仍需获记，并保留其原提前量，不能用新增预警抵消另一条预警的丢失，也不能把原15分钟退成10分钟。','- 原训练没有早期预警则报告不可行，不补造阈值；任何开发检查失败就停止，不改分界线或豁免、不换消融、不进入站点测试。','',
        '这仍是自适应开发。此前已看过的跨站结果影响了问题选择，但本轮运行没有加载原评测、迁移缓存或原始HDF5。原风险验证和校准此前均被多次使用，不是独立测试。','',
        '## 完整校准14日：真实服务回放','',
        '69个完整低速代理事件，三情景共享真值。下表三情景等权平均。','',
        '| 方法 | R10 | 含迟报检出率 | 误报/有效站日 |',
        '| --- | ---: | ---: | ---: |']
    for method,label in names.items():
        row=full[method];lines.append(f"| {label} | {pct(row['warning_recall_at_least10'])} | {pct(row['detection_recall'])} | {row['false_per_valid_station_day']:.6f} |")
    lines+=['',
        f"主方案R10保持{pct(primary['warning_recall_at_least10'])}；检出从{pct(reference['detection_recall'])}降至{pct(primary['detection_recall'])}，下降{100*(reference['detection_recall']-primary['detection_recall']):.2f}个百分点，超过2个百分点上限。误报仅减少{100*reduction:.2f}%，未达10%。因此未通过，不能因早预警保护成功就单独宣传总体有效。",'',
        '仅保护分界线在该14日降低更多误报，但检出同样损失；加低速豁免在该段没有额外恢复检出，反而保留更多误报。在另7日验证块，豁免恢复一部分检出，仍达不到门槛。这说明豁免也须接受实测，不能因为物理直觉合理就默认有效。','',
        '## 时间块与逐事件早期保护','',
        '| 时间块 | 原R10事件数（单情景） | 原→主方案R10 | 原→主方案检出 | 原→主方案误报 | 原早期事件及提前量 |',
        '| --- | ---: | --- | --- | --- | --- |']
    for block,methods in r['means'].items():
        a=methods['global_c1'];b=methods[pilot.PRIMARY]
        n=r['original_early_event_checks'][block][pilot.PRIMARY]['natural']['baseline_original_R10_events']
        text='全部保留' if n else '本块无原早期事件'
        lines.append(f"| {block} | {n} | {pct(a['warning_recall_at_least10'])}→{pct(b['warning_recall_at_least10'])} | {pct(a['detection_recall'])}→{pct(b['detection_recall'])} | {a['false_per_valid_station_day']:.6f}→{b['false_per_valid_station_day']:.6f} | {text} |")
    lines+=['','完整14日包含其两个7日子块，不能重复计为更多独立样本。校准前7日无原R10事件，保护约束在该块没有可检验的正例，不能当成强安全证据。其余范围逐事件身份与原提前量均保持。','',
        '## 新增漏检来自哪里','',
        '审计对齐同站同起点事件，而非只看平均比率。主方案在本轮各块新增漏检全部来自原先能被检测到的迟报事件，没有原获记预警变漏报。','',
        '| 时间块 | 自然：原迟报→漏检 | 单站缺失 | 成组缺失 |',
        '| --- | ---: | ---: | ---: |']
    for block,scenes in diagnosis.items():
        values=[str(scenes[s]['newly_missed_by_original_status']['late']) for s in ('natural','single_outage','group_outage')]
        lines.append(f"| {block} | {' | '.join(values)} |")
    lines+=['',
        '原起点判别器的训练任务只区分“获记提前预警”和“误报”，当时把迟报排除。部署式完整过滤却会作用于迟报告警：它们虽不满足提前预警目标，仍然提供事件检出价值。本轮“新增漏检全是原迟报”揭示了这个任务覆盖缺口。它不能单独证明所有损失只由该因素造成，也不保证补入迟报训练后就一定有效。','',
        '原分界线在分类子任务中看似能大量排除误报，但真实服务回放检出下降明显，说明AUC和条件拒绝率不能替代事件约束回放。','',
        '## 日期配对的描述区间','',
        '14日2000次共同按日期抽样、种子20261015，三情景同日使用同一索引；条件于固定模型和已重复使用的开发数据，不构成新的主检验或部署保证。','',
        '| 主方案−原全局 | 点差 | 95%描述区间 |',
        '| --- | ---: | --- |']
    for metric,mult in [('R10',100),('detection',100),('false_rate',1)]:
        row=r['paired_calibration_comparisons'][pilot.PRIMARY][metric];ci=row['ci95']
        lines.append(f"| {metric}{'（百分点）' if mult==100 else ''} | {row['difference']*mult:+.4f} | [{ci[0]*mult:.4f}, {ci[1]*mult:.4f}] |")
    lines+=['','两项差的区间上界均到0；不把小样本点估计写成稳定总体改善。没有改变原联合主检验失败状态。','',
        '## 核查与后续','',
        '9项测试已通过：训练早预警约束、无早预警不可行、三条可用历史观测、缺失与断点、整段拒绝及无中途进入、未来前缀不变、零阈值退化、逐事件原提前量保护和禁止读取迁移/原评测。独立审计用连续段重建48组过滤激活、核对60组完整回放、重算配对统计与原科学文件哈希。','',
        '原深度前端、风险模型和31参数判别器均未重训。原论文、Word/PPT、GitHub v7不覆盖；所有失败及消融完整保留，真实缓存和输出只本地保存。','',
        '下一轮应先在原开发训练段补齐“有效告警”任务：明确把仍能贡献检出的迟报纳入保护/学习目标，并保留早预警约束。不能继续降低分界线来遮住这个标签范围缺口。任何新目标和有限方案另行冻结，仍先做完整事件回放；本轮尚未实施该训练或新目标。','']
    (OUT/'report.zh-CN.md').write_text('\n'.join(lines),encoding='utf-8')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    methods=['global_c1','old_gate','early_cutoff_gate',pilot.PRIMARY]
    fig,axes=plt.subplots(1,3,figsize=(13,4.7),facecolor='#f5f8fa')
    for ax,(metric,title,mult) in zip(axes,[('warning_recall_at_least10','Proxy warning >=10 min (%)',100),('detection_recall','Detection incl. late (%)',100),('false_per_valid_station_day','False alerts / valid station-day',1)]):
        values=[full[m][metric]*mult for m in methods]
        bars=ax.bar(range(4),values,width=.65,color=['#8297ab','#bda3ad','#b8a171','#137c83'])
        ax.set_xticks(range(4),['Original','Old gate','Early cutoff','Primary'],fontsize=8)
        ax.set_ylim(0,100 if metric=='detection_recall' else max(values)*1.35)
        ax.set_title(title,fontsize=10);ax.spines[['top','right']].set_visible(False)
        for bar,value in zip(bars,values):ax.text(bar.get_x()+bar.get_width()/2,bar.get_height(),f'{value:.2f}' if mult==100 else f'{value:.3f}',ha='center',va='bottom',fontsize=9)
    fig.suptitle('Early protection: original early events kept, late detections lost - screen FAILED',fontsize=12)
    fig.text(.5,.025,'Reused original development calibration / 69 shared proxy events. Full episode replay; no new station test.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.08,1,.91));fig.savefig(OUT/'comparison.png',dpi=150);plt.close(fig)
    print({'report':str(OUT/'report.zh-CN.md'),'tests_observed_passed':9,'primary_passed':False})


if __name__=='__main__':main()
