"""Rebuild risk probabilities, calibration choices, statistics and research report."""
from __future__ import annotations

import json
import argparse
import os
import numpy as np
import torch

from recovery_pilot import ROOT, write_json
from state_value_pilot import read_data
from fresh_holdout_pilot import MaskedGraphTCN
from multifault_pilot import sha256
from audit_congestion_pilot import compare
from congestion_alert_pilot import SCENARIOS, labels, outage_mask
from congestion_risk_pilot import (BASE, METHODS, BASELINES, RiskModel, prepare_partition, pool,
    full_scores, score, choose, summary_key, operating, aggregate_ci, hidden_features_check)

OUTPUT = ROOT/'outputs/congestion-risk-pilot'


def load_model(path):
    saved = torch.load(path, weights_only=True)
    model = RiskModel(saved['dimension'], saved['nonlinear'])
    model.load_state_dict(saved['state_dict']); model.eval()
    return model, saved


def check_validation(model, saved, x, y):
    logits = score(model, x)
    loss = float(np.mean(np.logaddexp(0, logits)-y*logits))
    assert np.isclose(loss, saved['validation_bce'], rtol=1e-6, atol=1e-7)
    selected = min(saved['logs'], key=lambda v: v['validation_bce'])
    if saved.get('solver') == 'LBFGS':
        assert saved['selected_alpha'] == selected['alpha']
    else:
        assert saved['selected_epoch'] == selected['epoch']


def number(v, percent=False):
    if v is None:
        return '无可评值'
    return f'{v*100:.2f}%' if percent else f'{v:.3f}'


def create_report(result):
    reference = result['reference']; selected = result['selection']; comparison = result['comparison']
    title = {'dense_speed': '密集速度阈值', 'global_calibration': '全局校准', 'group_calibration': '缺测分组校准',
             'state_logistic': '可见状态逻辑回归', 'risk_mlp': '条件风险MLP'}
    lines = ['# 拥堵告警：条件风险层探索结果', '',
             '日期：2026-10-10。全部日期此前已使用，本阶段为探索。未重训交通预测器，训练的是风险层。', '',
             '## 主要比较', '',
             f'校准段选定最强简单参考：**{title[reference]}**；预定候选：三种子32/16层MLP。',
             f"三情景平均预警召回差（MLP−参考）：**{comparison['mean_warning_recall_difference']*100:.2f}个百分点**；按日期联合重采样95%探索区间{[round(v*100, 3) for v in comparison['mean_warning_recall_difference_ci']]}个百分点。",
             f"平均每有效站日误报率差：**{comparison['mean_false_rate_difference']:.3f}**；区间{[round(v, 5) for v in comparison['mean_false_rate_difference_ci']]}。", '',
             '校准误报预算来自第一阶段固定规则；不是现场容忍度，也不保证评测仍满足。各方法的设置均在评测概率计算前保存。', '',
             '| 方法 | 自然预警召回 | 单站预警召回 | 三站预警召回 | 自然误报/有效站日 | 单站误报 | 三站误报 |',
             '| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
    ref_detection = np.mean([result['evaluation'][reference][s]['detection_recall'] for s in SCENARIOS])
    candidate_detection = np.mean([result['evaluation']['risk_mlp'][s]['detection_recall'] for s in SCENARIOS])
    lines.insert(9, f'代价：包含迟报的平均检测召回由{ref_detection*100:.2f}%降到{candidate_detection*100:.2f}%，下降{(ref_detection-candidate_detection)*100:.2f}个百分点。因此不能把误报减少解读为整体检测改善。')
    for method in METHODS:
        rows = result['evaluation'][method]
        values = [number(rows[s]['warning_recall'], True) for s in SCENARIOS]+[number(rows[s]['false_per_valid_station_day']) for s in SCENARIOS]
        lines.append('| '+title[method]+' | '+' | '.join(values)+' |')
    lines += ['', '## 校准选择与权重', '',
              '| 方法 | 告警阈值 | 连续确认次数 | 校准平均预警召回 |', '| --- | ---: | ---: | ---: |']
    for method in METHODS:
        op = selected['methods'][method]['selected']
        threshold = -op['threshold'] if method == 'dense_speed' else op['threshold']
        unit = ' mph' if method == 'dense_speed' else ' 概率'
        recall = np.mean([op['by_scenario'][s]['warning_recall'] for s in SCENARIOS])
        lines.append(f'| {title[method]} | {threshold:g}{unit} | {op["confirmation"]} | {recall*100:.2f}% |')
    lines += ['', '校准预算：'+', '.join(f'{s}={v:.3f}' for s, v in selected['budgets'].items())+'误报/有效站日。', '',
              '风险训练28日、模型验证7日、告警校准14日、探索评测28日。训练起点每15分钟抽样，评测每5分钟连续回放；均剔除跨分区的历史/未来窗口。51维可见特征包括预测/分歧、本站与去自环邻居历史、缺测覆盖与年龄、日历和站点one-hot。', '',
              '## 提前量、迟报、删失与故障站', '']
    for method in (reference, 'risk_mlp'):
        lines += [f'### {title[method]}', '']
        for s in SCENARIOS:
            row = result['evaluation'][method][s]
            lines.append(f"- {s}：预警{int(row['warned'])}/{int(row['events'])}，含迟报检测召回{row['detection_recall']*100:.2f}%，成功预警平均提前{number(row['warning_lead_mean_minutes'])}分钟；迟报{int(row['late'])}，漏检{row['missed_events']}，重复{int(row['duplicate'])}；事件删失{int(row['censored_events'])}，告警删失{int(row['censored_alerts'])}，未知告警{int(row['unknown_alerts'])}。")
            if s != 'natural':
                point = row['point_fault_nodes']
                lines.append(f"  同情景故障站逐点召回{number(point['recall'], True)}、精确率{number(point['precision'], True)}；这是辅助逐点指标，不等于事件预警召回。")
        lines.append('')
    lines += ['## 判断边界', '',
              '若简单分组或逻辑回归已解释收益，不能把MLP作为新算法贡献。正的召回差若伴随更多误报、较差提前量、更多边界删失，不能直接称为同等服务下的改善。全局单分数校准主要是分数变换，不能把更细阈值当深度学习贡献。', '',
              '低速事件来自30 mph规则，三步窗口结束不等于真实拥堵消散；人工故障不是现场故障，数据里没有核验事故标签。第一阶段已分析过评测日期，本轮不再称独立测试。下一步如继续，需要先确认方法差异和信息来源，再冻结方法并获取外部数据验证。', '',
              '## 可复现文件', '',
              '- config.json：协议/代码/数据/旧模型/缓存哈希。',
              '- normalization.npz、features.json：仅训练段拟合的标准化和输入定义。',
              '- model_selection.json、*.pt：全部验证轮次日志与选定权重。',
              '- selection.json：校准预算、所有阈值/确认设置及参考选择。',
              '- scores_*.npz、daily_metrics.npz：冻结概率和按日统计。',
              '- audit.json：审核结果；training/validation预测保存在本目录，校准/评测复用第一阶段缓存。', '',
              '审核脚本从保存权重、原始可见历史和训练标准化重建概率、选择与统计；不重新训练。']
    if result['config'].get('solver_audit_post_run'):
        lines[3:3] = ['本版为事后线性求解器补强：全局/分组/状态线性模型使用LBFGS及验证段正则化选择；MLP、标签、特征、数据和阈值规则不变。初版结果保留，不把本补强称为独立验证。', '']
    (OUTPUT/'report.zh-CN.md').write_text('\n'.join(lines)+'\n', encoding='utf-8')
    os.environ.setdefault('MPLCONFIGDIR', str(ROOT/'.mplconfig'))
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.7))
    colors = ['#737373', '#d9a441', '#8d6cab', '#2d8d78', '#2378bd']
    for index, method in enumerate(METHODS):
        x = np.arange(3)+(index-2)*.15
        for ax, metric in zip(axes, ('warning_recall', 'false_per_valid_station_day')):
            ax.bar(x, [result['evaluation'][method][s][metric] for s in SCENARIOS], width=.14, color=colors[index], label=method.replace('_', ' '))
    axes[0].set_ylabel('Event warning recall'); axes[0].set_ylim(0, 1)
    axes[1].set_ylabel('False episodes / valid station-day')
    for ax in axes:
        ax.set_xticks(np.arange(3), ['Natural', 'Single outage', 'Group outage'])
        ax.set_axisbelow(True); ax.grid(axis='y', alpha=.2)
    handles, legend_labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, legend_labels, loc='lower center', ncol=3, fontsize=8, frameon=False)
    fig.suptitle('Risk-layer pilot - frozen calibration settings, exploratory dates')
    fig.tight_layout(rect=(0, .12, 1, .95))
    fig.savefig(OUTPUT/'summary.png', dpi=170); fig.savefig(OUTPUT/'summary.svg')
    plt.close(fig)


def main():
    global OUTPUT
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=type(OUTPUT), default=OUTPUT)
    OUTPUT = parser.parse_args().output
    torch.set_num_threads(1)
    result = json.loads((OUTPUT/'results.json').read_text(encoding='utf-8'))
    config = result['config']; audit = json.loads((OUTPUT/'audit.json').read_text(encoding='utf-8'))
    assert all(sha256(ROOT/k) == v for k, v in config['sha256'].items())
    assert all(sha256(OUTPUT/k) == v for k, v in audit['artifact_sha256'].items())
    z, valid, scale, adjacency, ts, context, cuts = read_data()
    old = json.loads((ROOT/'outputs/recovery-pilot/config.json').read_text(encoding='utf-8'))
    mean = np.array(old['normalization_mean'], np.float32)
    import h5py
    with h5py.File(ROOT/'data/raw/metr-la.h5', 'r') as f:
        raw = f['df/block0_values'][:, old['raw_column_indices']].astype(np.float32)
    groups = json.loads((ROOT/'outputs/multifault-pilot/config.json').read_text(encoding='utf-8'))['groups']
    day = (ts.astype('datetime64[D]')-ts[0].astype('datetime64[D]')).astype(int)
    data = raw, z, valid, ts, context, mean, scale, adjacency, day, groups
    at = lambda d: int(np.searchsorted(day, d))
    parts = {}
    for partition, (a, b) in config['partition_days'].items():
        stride = 3 if partition == 'training' else 1
        parts[partition], names = prepare_partition(partition, at(a), at(b), stride, data, [], OUTPUT)
        hidden_features_check(parts[partition], data)
        p = parts[partition]['natural']; ids = p['origins']
        assert np.array_equal(ids, np.arange(at(a)+12, at(b)-2, stride))
        window = ids[:, None]+np.arange(-12, 3)[None]
        regular = (np.diff(ts[window], axis=1) == np.timedelta64(5, 'm')).all(axis=1)
        truth, eligible, _ = labels(raw, valid, ids, regular)
        assert np.array_equal(truth, p['truth']) and np.array_equal(eligible, p['eligible'])
    n = np.load(OUTPUT/'normalization.npz')
    norm = n['mean'], n['std'], n['single_mean'], n['single_std']
    x = pool(parts['training'], 'state'); single = pool(parts['training'], 'single')[:, None]
    std = x.std(axis=0); std[std < 1e-5] = 1
    sstd = single.std(axis=0); sstd[sstd < 1e-5] = 1
    assert np.array_equal(norm[0], x.mean(axis=0)) and np.array_equal(norm[1], std)
    assert np.array_equal(norm[2], single.mean(axis=0)) and np.array_equal(norm[3], sstd)
    assert names == json.loads((OUTPUT/'features.json').read_text(encoding='utf-8'))
    xv = ((pool(parts['validation'], 'state')-norm[0])/norm[1]).astype(np.float32)
    sv = ((pool(parts['validation'], 'single')[:, None]-norm[2])/norm[3]).astype(np.float32)
    yv = pool(parts['validation'], 'truth').astype(np.float32)
    gv = pool(parts['validation'], 'group')
    global_model, record = load_model(OUTPUT/'global.pt'); check_validation(global_model, record, sv, yv)
    group_models = {}
    for g in ('0', '1', '2'):
        if (OUTPUT/f'group{g}.pt').exists():
            model, record = load_model(OUTPUT/f'group{g}.pt')
            rows = gv == int(g); check_validation(model, record, sv[rows], yv[rows])
            group_models[g] = model
    logistic, record = load_model(OUTPUT/'logistic.pt'); check_validation(logistic, record, xv, yv)
    mlps = []
    for seed in (202, 203, 204):
        model, record = load_model(OUTPUT/f'mlp{seed}.pt'); check_validation(model, record, xv, yv); mlps.append(model)
    fitted = global_model, group_models, logistic, mlps
    all_daily, maximum_error = {}, 0.
    for partition in ('calibration', 'evaluation'):
        rebuilt = full_scores(parts[partition], fitted, norm)
        with np.load(OUTPUT/f'scores_{partition}.npz') as saved:
            for method in METHODS:
                for s in SCENARIOS:
                    delta = float(np.max(np.abs(rebuilt[method][s]-saved[f'{method}_{s}'])))
                    maximum_error = max(maximum_error, delta)
                    assert delta < 1e-6
        if partition == 'calibration':
            selections = {m: choose(m, rebuilt[m], parts[partition], result['selection']['budgets']) for m in METHODS}
            compare(selections, result['selection']['methods'])
            def rank(m):
                return (*summary_key(list(selections[m]['selected']['by_scenario'].values())), BASELINES.index(m))
            assert min(BASELINES, key=rank) == result['reference']
        else:
            for method in METHODS:
                op = result['selection']['methods'][method]['selected']
                for s in SCENARIOS:
                    stats, daily = operating(rebuilt[method][s], parts[partition][s], op['threshold'], op['confirmation'])
                    compare(stats, {k: v for k, v in result['evaluation'][method][s].items() if k not in ('bce', 'brier')})
                    all_daily[f'{method}_{s}'] = daily
                    if method != 'dense_speed':
                        p = rebuilt[method][s]; e = parts[partition][s]['eligible']; y = parts[partition][s]['truth'][e].astype(np.float64)
                        brier = float(np.mean((p[e]-y)**2))
                        compare(brier, result['evaluation'][method][s]['brier'])
    with np.load(OUTPUT/'daily_metrics.npz') as saved:
        assert all(np.array_equal(a, saved[k]) for k, a in all_daily.items())
    reference = result['reference']
    a = np.stack([all_daily[f'{reference}_{s}'] for s in SCENARIOS])
    b = np.stack([all_daily[f'risk_mlp_{s}'] for s in SCENARIOS])
    rebuilt_intervals = aggregate_ci(a, b)
    compare(rebuilt_intervals, {k: result['comparison'][k] for k in rebuilt_intervals})
    # Recompute sampled training and validation cached forecasts from frozen weights.
    max_forecast_error, requests = 0., 0
    for partition in ('training', 'validation'):
        with np.load(OUTPUT/f'predictions_{partition}.npz') as saved:
            indices = np.unique(np.linspace(0, len(saved['origins'])-1, 8, dtype=int))
            ids = saved['origins'][indices]; history = ids[:, None]+np.arange(-12, 0)[None]
            for s in SCENARIOS:
                mask, fault = outage_mask(valid, day, s, groups)
                assert np.array_equal(fault[saved['origins']-1], saved[f'fault_{s}'])
                for j, seed in enumerate((42, 43, 44)):
                    model = MaskedGraphTCN(12, 3, adjacency)
                    model.load_state_dict(torch.load(ROOT/'outputs/fresh-holdout-pilot'/f'model_tcn_seed{seed}.pt', weights_only=True)['state_dict']); model.eval()
                    with torch.no_grad():
                        forecast = model(torch.tensor(np.where(mask[history] > 0, z[history], 0)), torch.tensor(mask[history]), torch.tensor(context[ids])).numpy()*scale[None, None]+mean[None, None]
                    error = float(np.max(np.abs(forecast-saved[f'predictions_{s}'][j, indices])))
                    max_forecast_error = max(max_forecast_error, error); requests += len(indices)
                    assert error < 2e-4
    audit.update({'audit_status': 'passed', 'normalization_training_only_recomputed': True,
                  'validation_selected_weights_and_losses_recomputed': True,
                  'all_calibration_grids_and_reference_recomputed': True,
                  'all_risk_probabilities_rebuilt_from_weights': True,
                  'max_probability_rebuild_error': maximum_error,
                  'all_event_point_daily_statistics_and_intervals_recomputed': True,
                  'raw_target_and_partition_boundary_checks': True,
                  'sampled_new_forecast_requests': requests, 'max_cached_forecast_error_mph': max_forecast_error})
    write_json(OUTPUT/'audit.json', audit)
    create_report(result)
    print(json.dumps({'audit': audit['audit_status'], 'probability_error': maximum_error, 'forecast_requests': requests,
                      'forecast_error': max_forecast_error, 'reference': reference, 'comparison': result['comparison']}, indent=2))


if __name__ == '__main__':
    main()
