"""Save a new local demo + pipeline candidate, preserving both earlier packages."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT / 'publication/traffic-alert-lab-pipeline-v1'
TARGET = ROOT / 'publication/traffic-alert-lab-demo-v1'
NEW_FILES = (
    'build_event_timeline_demo.py', 'tests/test_event_timeline_demo.py',
    'demo/index.html', 'demo/data.json', 'demo/timeline.template.html', 'demo/demo_manifest.json',
    'docs/event_timeline_demo.zh-CN.md',
    'outputs/pems-bay-demo-verification/browser_checks.json',
    'outputs/pems-bay-demo-verification/entry_tests.json',
    'outputs/pems-bay-demo-verification/preview.jpg',
    'prepare_demo_publication.py',
)


def digest(blob):
    return hashlib.sha256(blob).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def main():
    original = read(PREVIOUS / 'publication_manifest.json')
    blobs = {}
    for name, meta in original['files'].items():
        blob = (PREVIOUS / name).read_bytes()
        if digest(blob) != meta['sha256'] or len(blob) != meta['bytes']:
            raise ValueError(f'Previous candidate changed: {name}')
        blobs[name] = blob
    demo = read(ROOT / 'demo/demo_manifest.json')
    if demo['fine_operating_points_verified'] != 21 or demo['cases'] != 18:
        raise ValueError('Demo replay consistency verification incomplete')
    for name, meta in demo['files'].items():
        blob = (ROOT / name).read_bytes()
        if digest(blob) != meta['sha256'] or len(blob) != meta['bytes']:
            raise ValueError(f'Demo changed: {name}')
    if demo['builder_sha256'] != digest((ROOT / 'build_event_timeline_demo.py').read_bytes()):
        raise ValueError('Demo builder changed after generation')
    if demo['template_sha256'] != digest((ROOT / 'demo/timeline.template.html').read_bytes()):
        raise ValueError('Demo template changed after generation')
    browser = read(ROOT / 'outputs/pems-bay-demo-verification/browser_checks.json')
    tests = read(ROOT / 'outputs/pems-bay-demo-verification/entry_tests.json')
    if not tests['passed'] or tests['tests'] != 7:
        raise ValueError('Boundary test evidence missing')
    if tests['source_sha256'] != digest((ROOT / 'tests/test_event_timeline_demo.py').read_bytes()):
        raise ValueError('Boundary tests differ from tested source')
    if not all(c['passed'] for c in browser['methodScenarioChecks']):
        raise ValueError('Browser interaction failed')
    if len(browser['allTeachingCaseChecks']) != 18 or any(c['error'] for c in browser['allTeachingCaseChecks']):
        raise ValueError('Teaching case did not load')
    if browser['consoleErrors']:
        raise ValueError('Browser reported runtime errors')
    for name in NEW_FILES:
        blobs[name] = (ROOT / name).read_bytes()
    blobs['verification/previous_pipeline_publication_manifest.json'] = (PREVIOUS / 'publication_manifest.json').read_bytes()
    previous_readme = blobs['README.md'].decode('utf-8')
    first_line, rest = previous_readme.split('\n', 1)
    addition = '\n\n## 先打开事件时间线\n\n'
    addition += '双击 [demo/index.html](demo/index.html)，离线查看18个真实教学窗口；切换七方法、三情景，检查五分钟游标、告警开启与误报/漏检。页面不用安装依赖。\n\n'
    addition += '![事件回放预览](outputs/pems-bay-demo-verification/preview.jpg)\n\n'
    addition += '[演示说明与生成命令](docs/event_timeline_demo.zh-CN.md)。页面保留完整83日取舍与主验收未通过，不用局部案例声称总体优势。派生窗口和项目源码许可尚未确认，本包仅为本地发布候选，未上传GitHub。\n\n'
    blobs['README.md'] = (first_line + addition + rest).encode('utf-8')
    if any(Path(name).suffix in {'.h5', '.pt', '.npz', '.zip'} or name.startswith('runs/') for name in blobs):
        raise ValueError('Data cache or weights leaked into candidate')
    manifest = {'stage': 'local_demo_pipeline_publication_candidate_not_uploaded',
                'fresh_independent_validation': False, 'full_training_pipeline_verification_preserved': True,
                'raw_hdf5_or_model_weights_included': False, 'derived_teaching_windows_included': True,
                'license_review_complete': False,
                'previous_candidate_manifest_sha256': digest((PREVIOUS / 'publication_manifest.json').read_bytes()),
                'files': {name: {'bytes': len(blob), 'sha256': digest(blob)} for name, blob in blobs.items()}}
    blobs['publication_manifest.json'] = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    if TARGET.exists():
        actual = {p.relative_to(TARGET).as_posix() for p in TARGET.rglob('*') if p.is_file()}
        if actual != set(blobs) or any((TARGET / name).read_bytes() != blob for name, blob in blobs.items()):
            raise ValueError('Existing candidate differs; preserve it and use a new version')
    else:
        for name, blob in blobs.items():
            path = TARGET / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(blob)
    archive = TARGET.parent / 'traffic-alert-lab-demo-v1-publication-candidate.zip'
    if not archive.exists():
        with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as packed:
            for name, blob in blobs.items():
                packed.writestr(TARGET.name + '/' + name, blob)
    with zipfile.ZipFile(archive) as packed:
        if packed.testzip() is not None or set(packed.namelist()) != {TARGET.name + '/' + name for name in blobs}:
            raise ValueError('Archive CRC or file list mismatch')
        for name, blob in blobs.items():
            if packed.read(TARGET.name + '/' + name) != blob:
                raise ValueError(f'Archive bytes differ: {name}')
    print(json.dumps({'candidate': str(TARGET), 'files': len(blobs), 'archive': str(archive),
                      'archive_bytes': archive.stat().st_size, 'crc_and_every_byte_verified': True,
                      'uploaded': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()
