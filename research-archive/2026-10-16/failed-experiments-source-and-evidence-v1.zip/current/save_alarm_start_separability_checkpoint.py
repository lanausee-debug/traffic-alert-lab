"""Cumulative archive: partial separability signal, failed joint diagnostic."""
from datetime import datetime,timezone
from pathlib import Path
import hashlib
from zipfile import ZipFile,ZIP_DEFLATED
from save_station_agnostic_checkpoint import read,write,sha

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs/alarm-start-separability-2026-10-15'
NAME='traffic-recovery-lab-2026-10-15-alarm-start-separability'


def main():
    archive=ROOT.parent/'checkpoints'/(NAME+'.zip');receipt=archive.with_name(NAME+'-save-receipt.json')
    if archive.exists() or receipt.exists():raise FileExistsError('Preserve existing archives')
    r=read(OUT/'results.json');audit=read(OUT/'audit.json');tests=read(OUT/'test_receipt.json')
    assert audit['passed'] and tests['passed'] and tests['tests_run']==9
    assert sha(ROOT/'tests/test_alarm_start_separability.py')==tests['test_source_sha256']
    assert not r['natural_diagnostic_gate']['passed'] and not r['new_alarm_policy_evaluated']
    assert not r['new_station_cohort_consumed']
    for name,digest in read(OUT/'completion.json')['artifacts'].items():assert sha(OUT/name)==digest
    prior_path='outputs/adaptive-confirmation-2026-10-15/writing_archive_manifest.json';prior=read(ROOT/prior_path)
    for name,meta in prior['files'].items():assert sha(ROOT/name)==meta['sha256'],name
    summary=('原28日告警起点拟合3个固定线性探针，30维完整状态在后续三个开发块自然情景AUC为0.818/0.715/0.822，'
        '均高于简单参照包络0.653/0.615/0.639；但一块AP为0.612低于参照0.623，联合诊断未通过。'
        '训练固定分界线还会损失1/5条验证块R10预警，不能直接当成安全过滤器。')
    marker='# 最新检查点：告警起点可分性探针（2026-10-15）'
    p=ROOT/'CURRENT_STATE.zh-CN.md';old=p.read_text(encoding='utf-8');assert marker not in old
    p.write_text(marker+'\n\n- '+summary+'\n'
        '- 训练池450行（147获记预警/303误报），只有167个不同node/origin键，三情景不独立。只分获记预警vs误报，迟报/重复/删失/未知排除；不是完整告警服务评测。\n'
        '- 3个探针各2/3/31参数，PyTorch float64 LBFGS、alpha0.1固定，训练专用标准化，无新网络训练或阈值调优。封存模型后才加载三个检查块；这些块此前都参与过开发，非新的独立测试。\n'
        '- 后续自然样本36/23/28条，负例排除约31%–41%仅子任务分类数，不能宣传为线上误报下降；未改原告警规则，也没有新站点测试。\n'
        '- 9项测试已在拟合前通过；审计重建样本/标签/训练梯度、45组AUC/AP及阈值。原科学文件、论文与GitHub v7保持，既有失败全部保留。\n'
        '- 报告outputs/alarm-start-separability-2026-10-15/report.zh-CN.md；接续docs/alarm_start_separability_handoff.zh-CN.md。下一步可冻结同一探针，做已看过站点缓存的探索性稳定性检查，绝非独立确认。\n'
        '- 最新累计包2026-10-15-alarm-start-separability；恢复先10月11日完整基包再本累计包。\n\n以下为之前阶段记录。\n\n'+old,encoding='utf-8')
    p=ROOT/'README.md';old=p.read_text(encoding='utf-8')
    p.write_text('# 最新研究：告警起点有部分区分信号，尚不能安全过滤\n\n'
        '[完整报告](outputs/alarm-start-separability-2026-10-15/report.zh-CN.md) · [接续说明](docs/alarm_start_separability_handoff.zh-CN.md)\n\n'
        +summary+' 仅此前使用过的开发分区诊断，未更新线上模型。最新累计包为2026-10-15-alarm-start-separability。\n\n以下为之前阶段记录。\n\n'+old,encoding='utf-8')
    files=set(prior['files'])|{prior_path,'alarm_start_separability.py','audit_alarm_start_separability.py',
        'summarize_alarm_start_separability.py','save_alarm_start_separability_checkpoint.py',
        'tests/test_alarm_start_separability.py','docs/alarm_start_separability_handoff.zh-CN.md'}
    files|={p.relative_to(ROOT).as_posix() for p in OUT.rglob('*') if p.is_file() and p.name!='writing_archive_manifest.json'}
    base_path=ROOT.parent/'checkpoints/traffic-recovery-lab-2026-10-11-event-timeline-save-receipt.json';base=read(base_path)
    assert Path(base['full_archive']).stat().st_size==base['full_archive_bytes'] and base['archive_crc_and_all_sha256_verified']
    manifest=OUT/'writing_archive_manifest.json'
    write(manifest,{'client_date':'2026-10-15','stage':'cumulative_start_separability_partial_signal_failed_joint_gate',
        'archive_name':archive.name,'restore':'October11 full base, then this supplement',
        'development_diagnostic_gate_passed':False,'new_alarm_policy_accepted':False,
        'new_station_cohort_consumed':False,'new_deep_frontend_training':False,'linear_probes_fitted':3,
        'unit_tests_observed_passed':9,'training_rows':450,'unique_node_origin_pairs':167,
        'all45_AUC_AP_metric_pairs_independently_checked':True,
        'prior_files_changed':['README.md','CURRENT_STATE.zh-CN.md'],
        'original_thesis_primary_test_still_failed':True,
        'public_commit_unchanged':'ab8760a3e6ea1784fea3195a0e7aadbaff6fe80d',
        'base_crc_rechecked_this_turn':False,'base_sha256_from_prior_verified_receipt':base['full_archive_sha256'],
        'files':{n:{'bytes':(ROOT/n).stat().st_size,'sha256':sha(ROOT/n)} for n in sorted(files)}})
    files.add(manifest.relative_to(ROOT).as_posix())
    with ZipFile(archive,'x',compression=ZIP_DEFLATED) as z:
        for n in sorted(files):z.write(ROOT/n,'traffic-recovery-lab/'+n)
    with ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist())==len(files)
        for n in sorted(files):
            data=z.read('traffic-recovery-lab/'+n)
            assert data==(ROOT/n).read_bytes() and hashlib.sha256(data).hexdigest()==sha(ROOT/n)
    proof={'saved_at_utc':datetime.now(timezone.utc).isoformat(),'archive':str(archive),
        'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'files':len(files),
        'crc_and_all_file_bytes_and_sha256_verified':True,'development_diagnostic_gate_passed':False,
        'new_alarm_policy_accepted':False,'new_station_cohort_consumed':False,
        'original_thesis_primary_test_still_failed':True,'public_version_unchanged':True,
        'base_prior_verified_receipt':str(base_path),'base_crc_rechecked_this_turn':False}
    write(receipt,proof);print(proof)


if __name__=='__main__':main()
