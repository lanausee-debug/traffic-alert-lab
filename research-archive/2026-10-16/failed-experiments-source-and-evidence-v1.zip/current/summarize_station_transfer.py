"""Report the fixed new-station check without mixing it with development results."""
from pathlib import Path
import json

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs/new-station-transfer-2026-10-15'


def percent(value):return '无分母' if value is None else f'{100*value:.2f}%'
def number(value):return '无分母' if value is None else f'{value:.6f}'


def main():
    result=json.loads((OUT/'results.json').read_text(encoding='utf-8'))
    plan=json.loads((OUT/'plan.json').read_text(encoding='utf-8'))
    assert not set(result['new_station_ids'])&set(result['development_station_ids'])
    assert not result['risk_heads_refit'] and not result['thresholds_refit'] and not result['external_independent_data']
    lines=['# 固定风险模型的新站点迁移检查','',
        '日期：2026-10-15。24个新站点与原开发24站零重叠。选择只根据站点ID哈希，未用速度或结果筛站；训练质量不通过则停止、不换站。计划、固定权重和阈值在新站点速度解码前保存。','',
        '**这是同一路网、同一日历时期的不同站点检查，不是独立外部数据集验证。** 原有记录表明本项目开发阶段速度读取只涉及原24列；这是基于保存记录的来源检查，不是完整操作系统访问历史证明。','',
        '## 哪些部分固定，哪些重新训练','',
        '原Graph TCN有站点专属嵌入，不能任意把旧站点位置映射到新站点。因此新站点前42日拟合均值、尺度、训练相关图；按原三种子42/43/44、25轮规则重新训练车速前端，接下来7日只用于选前端轮次。没有用新站点风险训练、风险验证或校准段拟合风险模型。','',
        '原全局/分组/起点MLP风险头、风险特征标准化、有界修正候选的三份权重及所有告警阈值保持原样。代码审查在评测前发现风险特征也有站点独热身份：已通过identity_amendment.json记录适配，将未见站点的node0..node23全部设为0表示未知，再用原标准化；没有让新站点冒充旧站点槽位。此适配对所有使用状态特征的风险头一致应用。候选阈值0.505、一次确认；没有为本次检查重新校准。它检验的是“新前端适配后固定风险头迁移”，不能称为整个系统零样本迁移。','',
        f"新站点评测区间：{result['evaluation_dates'][0]}至{result['evaluation_dates'][-1]}，{len(result['evaluation_dates'])}日、24站、{int(result['events'])}个完整低速代理事件。三种情景共享这些事件，不能乘三充当独立样本。",'',
        '## 三种观测情景等权平均','',
        '| 方法 | ≥10分钟代理预警召回 | 含迟报检出率 | 误报/有效站日 |','| --- | ---: | ---: | ---: |']
    names={'global_calibration':'固定全局校准','group_calibration':'固定分组校准','onset_mlp':'固定原起点MLP','anchored_candidate':'固定有界修正候选'}
    for method,label in names.items():
        row=result['means'][method]
        lines.append(f"| {label} | {percent(row['warning_recall_at_least10'])} | {percent(row['detection_recall'])} | {number(row['false_per_valid_station_day'])} |")
    lines+=['','## 候选减参考：按日期配对的条件区间','',
        '2000次按日期共同抽样，种子20261015。三种情景同一天使用同一抽样索引；区间条件于已拟合权重，不包含训练不确定性、跨站或跨路网不确定性。逐比较95%区间属于描述，不作为新的论文联合主检验。若抽样分母为零，则报告不可计算，不把它补成零。','',
        '| 参考 | R10差（百分点）与95%区间 | 检出差（百分点）与95%区间 | 误报率差与95%区间 |','| --- | --- | --- | --- |']
    for method,label in names.items():
        if method=='anchored_candidate':continue
        comparison=result['comparisons'][method];cells=[]
        for key,multiplier in (('R10',100),('detection',100),('false_rate',1)):
            row=comparison[key];delta=row['difference'];interval=row['conditional_ci95']
            cells.append('不可计算' if delta is None else f"{delta*multiplier:+.3f} / "+('不可计算' if interval is None else f"[{interval[0]*multiplier:.3f}, {interval[1]*multiplier:.3f}]"))
        lines.append('| '+label+' | '+' | '.join(cells)+' |')
    lines+=['','## 事先固定的点估计验收','',
        '相对固定全局校准，需同时满足：R10至少增加2个百分点、检出下降不超过2个百分点、误报不增加。该点估计门槛在数据解码前固定，不能把通过它写成置信区间证明或总体优越。', '',
        '**结果：'+('通过此点估计门槛。' if result['fixed_point_gate_vs_global_passed'] else '没有通过此点估计门槛。')+' 不根据本次结果重选权重、阈值、站点或验收条件。','',
        '候选对原起点MLP的检出改善仍伴随误报增加。判断附加MLP是否值得保留，需要与强全局校准比较；不能只挑原起点MLP这个弱参考宣传。对全局的R10和误报率差的95%条件区间均包含零，当前没有证明稳定增益。有界修正依托固定的强底座，现有迁移结果不足以证明附加MLP带来可靠的额外收益。','',
        '| 情景 | 候选R10 | 候选检出 | 候选误报 | 原校准预算 | 超预算 |','| --- | ---: | ---: | ---: | ---: | --- |']
    for scenario,row in result['evaluation']['anchored_candidate'].items():
        lines.append(f"| {scenario} | {percent(row['warning_recall_at_least10'])} | {percent(row['detection_recall'])} | {number(row['false_per_valid_station_day'])} | {plan['original_calibration_false_budgets'][scenario]:.6f} | {'无分母' if result['candidate_budget_exceedance'][scenario] is None else '是' if result['candidate_budget_exceedance'][scenario] else '否'} |")
    lines+=['','## 边界与后续','',
        '- 此前83日开发站点回放数字不与新站点混为一张成绩表。新站点前端经过适配训练，风险头和阈值固定。','- 若结果不佳，意味着当前固定迁移方案在这组站点没有满足要求；不能据此断言所有深度学习无效，也不能删掉失败记录。','- 原30 mph持续低速代理事件、L=5(s−a+1)和完整事件边界保持。尚无现场拥堵起点、管理决策收益或部署误报保证。','- 原论文主检验仍失败；本次检查不替换论文冻结结果，不更新既有在线演示为新的性能宣称。','- 本次评测结果已经分析后，这组站点不再是下一次方法改进的未见评测。继续改进必须保留此记录，并使用新的验证安排。','']
    (OUT/'report.zh-CN.md').write_text('\n'.join(lines),encoding='utf-8')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    methods=['global_calibration','onset_mlp','anchored_candidate']
    fig,axes=plt.subplots(1,3,figsize=(12,4.8),facecolor='#f5f8fa')
    for ax,(metric,title,multiplier) in zip(axes,[('warning_recall_at_least10','Proxy warning >=10 min (%)',100),('detection_recall','Detection incl. late (%)',100),('false_per_valid_station_day','False alerts / valid station-day',1)]):
        values=[result['means'][method][metric] for method in methods]
        if any(value is None for value in values):ax.text(.5,.5,'Undefined denominator',ha='center');continue
        values=[value*multiplier for value in values]
        bars=ax.bar(range(3),values,color=['#8297ab','#d29572','#137c83'],width=.65)
        ax.set_title(title,fontsize=11);ax.set_xticks(range(3),['Global','Onset MLP','Anchored'],fontsize=9)
        ax.spines[['top','right']].set_visible(False);ax.set_ylim(0,100 if metric=='detection_recall' else max(max(values)*1.3,.01))
        for bar,value in zip(bars,values):ax.text(bar.get_x()+bar.get_width()/2,bar.get_height(),f'{value:.2f}' if multiplier==100 else f'{value:.3f}',ha='center',va='bottom',fontsize=10)
    fig.suptitle('Disjoint stations: adapted forecasters, frozen risk heads and thresholds',fontsize=13)
    fig.text(.5,.025,f"24 new stations / {int(result['events'])} shared proxy events. Same network and dates; not an external-independent-data claim.",ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.08,1,.91));fig.savefig(OUT/'comparison.png',dpi=150);plt.close(fig)
    print(json.dumps({'report':str(OUT/'report.zh-CN.md'),'point_gate_passed':result['fixed_point_gate_vs_global_passed'],'external_independent_data':False}))


if __name__=='__main__':main()
