"""Save the October 13 cumulative writing checkpoint, preserving previous archives."""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'outputs/thesis-bibliography-review'
CHECKPOINTS = ROOT.parent / 'checkpoints'
NAME = 'traffic-recovery-lab-2026-10-13-thesis-bibliography'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def dump(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def main():
    import build_thesis_bibliography_review as review
    for path, content in review.build().items():
        assert path.read_bytes() == content, path
    archive = CHECKPOINTS / (NAME + '.zip')
    receipt_path = CHECKPOINTS / (NAME + '-save-receipt.json')
    if archive.exists() or receipt_path.exists():
        raise FileExistsError('Preserve existing checkpoint; choose a new name.')
    prior_manifest = read(ROOT / 'outputs/thesis-word/writing_archive_manifest.json')
    prior_receipt = read(CHECKPOINTS / 'traffic-recovery-lab-2026-10-12-thesis-word-save-receipt.json')
    assert sha(Path(prior_receipt['archive'])) == prior_receipt['archive_sha256']
    assert prior_receipt['archive_crc_and_all_file_bytes_verified']
    for p, item in prior_manifest['files'].items():
        if p not in {'README.md', 'CURRENT_STATE.zh-CN.md'}:
            assert sha(ROOT / p) == item['sha256'], p
    additions = {
        'docs/thesis_bibliography_amendments.json', 'docs/thesis_bibliography_review.zh-CN.md',
        'build_thesis_bibliography_review.py', 'save_thesis_bibliography_checkpoint.py',
        'outputs/thesis-bibliography-review/references.json',
        'outputs/thesis-bibliography-review/documentation_manifest.json',
        'outputs/thesis-word/writing_archive_manifest.json',
    }
    files = set(prior_manifest['files']) | additions
    base_receipt_path = CHECKPOINTS / 'traffic-recovery-lab-2026-10-11-event-timeline-save-receipt.json'
    base_receipt = read(base_receipt_path)
    base = Path(base_receipt['full_archive'])
    assert base.stat().st_size == base_receipt['full_archive_bytes']
    assert base_receipt['archive_crc_and_all_sha256_verified']
    with ZipFile(base) as z:
        available = {p.removeprefix('traffic-recovery-lab/') for p in z.namelist()} | files
    missing = []
    for p in files:
        if p.endswith('/documentation_manifest.json'):
            sources = read(ROOT / p).get('source_sha256', {})
            if isinstance(sources, dict):
                missing += [(p, s) for s in sources if s not in available]
    assert not missing, missing
    manifest_path = OUT / 'writing_archive_manifest.json'
    dump(manifest_path, {
        'stage': 'cumulative_thesis_bibliography_metadata_amendments', 'client_date': '2026-10-13',
        'archive_name': archive.name,
        'scope': 'Restore full October 11 event timeline base, then this cumulative writing supplement.',
        'base_archive': {'name': base.name, 'sha256_from_prior_verified_receipt': base_receipt['full_archive_sha256'],
                         'prior_verified_at_utc': base_receipt['saved_at_utc'], 'full_crc_rechecked_this_turn': False},
        'files': {p: {'bytes': (ROOT / p).stat().st_size, 'sha256': sha(ROOT / p)} for p in sorted(files)},
        'degree_level_confirmed_by_user': 'undergraduate', 'school_requirements_known': False,
        'word_updated': False, 'primary_metric_supported': False, 'github_uploaded': False,
        'two_archive_documentation_dependencies_present': True,
    })
    files.add(manifest_path.relative_to(ROOT).as_posix())
    with ZipFile(archive, 'x', compression=ZIP_DEFLATED, compresslevel=6) as z:
        for p in sorted(files):
            z.write(ROOT / p, 'traffic-recovery-lab/' + p)
    with ZipFile(archive) as z:
        assert z.testzip() is None
        assert len(z.namelist()) == len(files)
        for p in files:
            assert z.read('traffic-recovery-lab/' + p) == (ROOT / p).read_bytes(), p
    receipt = {
        'saved_at_utc': datetime.now(timezone.utc).isoformat(),
        'stage': 'cumulative_thesis_bibliography_metadata_amendments', 'archive': str(archive),
        'archive_bytes': archive.stat().st_size, 'archive_sha256': sha(archive), 'archived_files': len(files),
        'archive_crc_and_all_file_bytes_verified': True,
        'two_archive_documentation_dependencies_present': True,
        'full_base_reverified_this_turn': False, 'full_base_prior_receipt': str(base_receipt_path),
        'manifest': str(manifest_path), 'degree_level_confirmed_by_user': 'undergraduate',
        'word_updated': False, 'primary_metric_supported': False, 'github_uploaded': False,
    }
    dump(receipt_path, receipt)
    print(json.dumps(receipt, ensure_ascii=True))


if __name__ == '__main__':
    main()
