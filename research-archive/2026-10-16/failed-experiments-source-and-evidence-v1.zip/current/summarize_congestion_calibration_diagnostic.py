"""Independent frozen-model/calibration checks and a complete diagnostic report."""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import numpy as np
import torch
from recovery_pilot import ROOT,write_json
from multifault_pilot import sha256
from audit_congestion_pilot import compare
from congestion_alert_pilot import SCENARIOS,event_stats
from congestion_risk_pilot import RiskModel,score,online_alarm,choose
from congestion_ablation import OLD,SEEDS,load_data,load_model
from congestion_onset_pilot import supervised_data
from congestion_density_pilot import state_signature
from summarize_congestion_risk import check_validation
from summarize_congestion_onset import independent_targets
from summarize_congestion_objective import check_event_records
from congestion_calibration_diagnostic import (OUTPUT,ONSET,DENSITY,METHODS,BINS,QUANTILES,FIELDS,
    model_path,load_partitions,scores_from_weights,compute,grid_key,ranking)

NAMES={'onset_mlp':'旧起点MLP（逐轮打乱）','sparse_update_mlp':'15分钟等更新MLP','dense_update_mlp':'5分钟等更新MLP'}
METRICS={'warning_recall':'全部预警召回','warning10_recall':'≥10分钟预警召回',
         'detection_recall':'含迟报检测召回','false_per_valid_station_day':'误报/有效站日'}


def independent_ranking(p,y):
    values,inverse,counts=np.unique(p,return_inverse=True,return_counts=True)
    positive=np.bincount(inverse,weights=y,minlength=len(values)); negative=counts-positive
    below_negative=np.cumsum(negative)-negative
    auc=float(np.sum(positive*(below_negative+negative/2))/(y.sum()*(len(y)-y.sum())))
    tp=np.cumsum(positive[::-1]); total=np.cumsum(counts[::-1])
    ap=float(np.sum(positive[::-1]*tp/total)/y.sum())
    return {'average_precision':ap,'roc_auc':auc}


def check_probability(row,p,truth,mask):
    p=p[mask].astype(np.float64); y=truth[mask].astype(np.int64)
    assert row['valid_points']==len(p) and row['positive_points']==int(y.sum())
    compare(independent_ranking(p,y),{k:row[k] for k in ('average_precision','roc_auc')})
    assert np.isclose(row['brier'],np.mean((p-y)**2),rtol=1e-12)
    assert np.isclose(row['bce'],np.mean(-y*np.log(np.clip(p,1e-7,1-1e-7))-(1-y)*np.log(np.clip(1-p,1e-7,1))),rtol=1e-12)
    count=positive=0; expected_ece=predicted_sum=0.
    for i,r in enumerate(row['reliability']):
        chosen=(p>=BINS[i])&((p<BINS[i+1]) if i<len(BINS)-2 else (p<=BINS[i+1]))
        n=int(chosen.sum()); pos=int(y[chosen].sum()); assert n==r['count'] and pos==r['positive_count']
        count+=n; positive+=pos
        if n:
            assert np.isclose(p[chosen].mean(),r['mean_probability']) and np.isclose(pos/n,r['positive_fraction'])
            expected_ece+=n/len(p)*abs(p[chosen].mean()-pos/n); predicted_sum+=n*r['mean_probability']
        else: assert r['mean_probability'] is None and r['positive_fraction'] is None
    assert count==len(p) and positive==y.sum()
    assert np.isclose(expected_ece,row['ece_fixed_bins'],atol=1e-12)
    assert np.isclose(predicted_sum/len(p),row['mean_probability'],atol=1e-12)
    compare(np.quantile(p[y==1],QUANTILES).tolist(),row['positive_quantiles'])
    compare(np.quantile(p[y==0],QUANTILES).tolist(),row['negative_quantiles'])


def event_phase_diagnostic(records,scores,parts,targets,result):
    out={'phase_scores':{},'integer_budget_counts':{}}
    for m in METHODS:
        out['phase_scores'][m]={}; out['integer_budget_counts'][m]={}
        for s,p in parts['calibration'].items():
            events=records[m]['0.15_c1'][s]
            nodes=np.array([r['node'] for r in events]); indices=np.searchsorted(p['origins'],[r['event_start_origin'] for r in events])
            out['phase_scores'][m][s]={}
            for lead,offset in [(15,-2),(10,-1),(5,0)]:
                at=indices+offset; values=scores['calibration'][m][s][at,nodes]
                known=targets['calibration']['eligible'][at,nodes]
                positive=targets['calibration']['truth'][at,nodes]
                r={'complete_events':len(events),'common_target_known':int(known.sum()),'common_target_positive':int(positive.sum()),
                   'mean_probability':float(values.mean()),'quantiles':np.quantile(values,QUANTILES).tolist(),'threshold_counts':{}}
                for t in (.15,.2):
                    alarm=online_alarm(scores['calibration'][m][s],t,1)
                    current=alarm[at,nodes]; previous=alarm[at-1,nodes]
                    active=int(current.sum()); started=int((current&~previous).sum()); holding=int((current&previous).sum())
                    assert active==started+holding
                    r['threshold_counts'][str(t)]={'active':active,'new_start_at_position':started,'holding_from_previous_position':holding}
                out['phase_scores'][m][s][str(lead)]=r
            rows={}
            for t in (.15,.2):
                st=result['calibration_grid'][m][grid_key(t,1)]['by_scenario'][s]['stats']
                maximum=int(np.floor(result['budgets'][s]*st['exposure']+1e-9))
                rows[str(t)]={'false_alerts':int(st['false']),'maximum_false_alerts_at_existing_exposure':maximum,
                               'excess_false_alerts':int(st['false'])-maximum}
                assert (st['false']<=maximum)==(st['false_per_valid_station_day']<=result['budgets'][s]+1e-12)
            out['integer_budget_counts'][m][s]=rows
    return out


def report(result,validation_logs,phase,output):
    prob=result['probability']; grid=result['calibration_grid']; selection=result['selected_operating_points']
    lines=['# 校准分化诊断：相同阈值下的新模型并未普遍变差','',
           '2026-10-10。固定旧起点、新15分钟及新5分钟三种子集成；无训练，无评测段新增阈值回放。当前是事后校准/验证诊断，所有日期曾使用。','',
           '## 已保存的校准选择','',
           '| 模型 | 保存阈值/确认 | 校准预警召回 | 校准≥10分钟召回 | 校准检测召回 | 校准误报/有效站日 |',
           '| --- | --- | ---: | ---: | ---: | ---: |']
    for m in METHODS:
        op=selection[m]; row=grid[m][grid_key(op['threshold'],op['confirmation'])]['mean']
        lines.append(f'| {NAMES[m]} | {op["threshold"]:g}/{op["confirmation"]} | {row["warning_recall"]*100:.2f}% | {row["warning10_recall"]*100:.2f}% | {row["detection_recall"]*100:.2f}% | {row["false_per_valid_station_day"]:.3f} |')
    lines += ['', '原选择目标为误报预算内的全部预警召回，不是≥10分钟召回；本轮完整原网格和选择复算一致，历史设置保持。','',
              '## 起点概率与排序','',
              '| 分区 | 模型 | 阳性率 | 平均分数 | 集成BCE | Brier | AP | ROC-AUC | 固定箱ECE |',
              '| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
    for part in ('validation','calibration'):
        for m in METHODS:
            r=prob[part][m]['pooled']
            lines.append(f'| {part} | {NAMES[m]} | {r["positive_fraction"]*100:.3f}% | {r["mean_probability"]*100:.3f}% | {r["bce"]:.6f} | {r["brier"]:.6f} | {r["average_precision"]:.4f} | {r["roc_auc"]:.4f} | {r["ece_fixed_bins"]:.6f} |')
    lines += ['', '概率分数只在共同六读数有效点统计；三情景合并是共享真值下的点池，不是独立样本扩充。AP的随机排序参考为阳性率；ROC-AUC/AP不等于完整事件预警能力，ECE依赖分箱且在少数阳性场景受阴性主导。BCE/Brier下降也不保证固定预算下事件指标提高。','',
              '## 保存权重的逐种子验证损失','',
              '| 模型 | 种子 | 保存检查点 | 逐种子验证BCE |',
              '| --- | --- | --- | ---: |']
    for m in METHODS:
        for r in validation_logs[m]:
            label=f'epoch {r["selected_epoch"]}' if 'selected_epoch' in r else f'update {r["selected_step"]}'
            lines.append(f'| {NAMES[m]} | {r["seed"]} | {label} | {r["validation_bce"]:.6f} |')
    lines += ['', '集成BCE是平均概率后的损失，不是三份逐种子验证BCE的平均；各模型验证选择仍按原日志执行。','',
              '## 共同阈值回放及预算约束','',
              '| 模型 | 阈值/确认 | 全部预警% | ≥10分钟% | 检测% | 误报/站日 | 预算可行 | 自然/单站/三站预算超额 |',
              '| --- | --- | ---: | ---: | ---: | ---: | --- | --- |']
    for m in METHODS:
        for t in (.15,.2):
            r=grid[m][grid_key(t,1)]; v=r['mean']; excess='/'.join(f'{r["budget_excess_by_scenario"][s]:+.6f}' for s in SCENARIOS)
            lines.append(f'| {NAMES[m]} | {t:g}/1 | {v["warning_recall"]*100:.2f} | {v["warning10_recall"]*100:.2f} | {v["detection_recall"]*100:.2f} | {v["false_per_valid_station_day"]:.3f} | {"是" if r["feasible"] else "否"} | {excess} |')
    lines += ['', '负超额表示低于预算。可行性必须每个情景都满足，不能用平均误报代替。共同阈值.15/.20预先为本轮诊断固定；未作为新部署候选，也没有在评测段寻找最优阈值。','',
              '将预算换成当前曝光下的整数误报数：','',
              '| 模型（阈值.15） | 情景 | 实际误报 | 允许最大误报 | 超额 |',
              '| --- | --- | ---: | ---: | ---: |']
    for m in METHODS:
        for s in SCENARIOS:
            r=phase['integer_budget_counts'][m][s]['0.15']
            lines.append(f'| {NAMES[m]} | {s} | {r["false_alerts"]} | {r["maximum_false_alerts_at_existing_exposure"]} | {r["excess_false_alerts"]:+d} |')
    lines += ['',
              '## 2×2对称分解（校准段）','',
              '| 新模型−旧模型 | 指标 | 总差 | 模型分数组件 | 阈值组件 |',
              '| --- | --- | ---: | ---: | ---: |']
    for m,fields in result['decomposition'].items():
        for k,r in fields.items():
            factor=1 if k=='false_per_valid_station_day' else 100
            label=METRICS[k]+('' if factor==1 else '（百分点）')
            lines.append(f'| {NAMES[m]} | {label} | {r["total_difference"]*factor:+.3f} | {r["symmetric_model_component"]*factor:+.3f} | {r["symmetric_threshold_component"]*factor:+.3f} |')
    lines += ['', '以旧模型/.15与新模型/.20为端点，平均“先换模型再换阈值”与“先换阈值再换模型”两条路径。两个组件相加严格等于总差。它只是固定模型下的算术分解，不证明采样机制的因果效应；两条路径原始数字均保存。','',
              '## 固定阈值的告警开启诊断','',
              '| 模型 | 阈值 | 5/10/15分钟预警（合计） | 迟报 | 漏检 | 漏检但窗口有告警 | 漏检且入口前已开启保持 |',
              '| --- | ---: | --- | ---: | ---: | ---: | ---: |']
    for m in METHODS:
        for t in (.15,.2):
            rows=grid[m][grid_key(t,1)]['by_scenario']
            counts='/'.join(str(sum(rows[s]['diagnostic']['warning_by_lead'][str(v)] for s in SCENARIOS)) for v in (5,10,15))
            summed=lambda section,key: sum(rows[s][section][key] for s in SCENARIOS)
            lines.append(f'| {NAMES[m]} | {t:g} | {counts} | {summed("stats","late"):g} | {summed("stats","missed_events")} | {summed("diagnostic","missed_with_alarm_but_without_credited_start")} | {summed("diagnostic","missed_with_active_spanning_warning_window_entry")} |')
    lines += ['', '原代理事件每情景532个完整事件；合计1596情景-事件共享真值。长时间已开启告警不会被补记为新事件预警；删失、未知和重复严格沿用旧规则。','',
              '## 完整事件三个预警位置的风险分数','',
              '| 模型 | 计分提前档位 | 平均风险分数（三情景） | .15活跃/当点新开/已保持（合计） | .20活跃/当点新开/已保持（合计） | 六读数已知/起点阳性（合计） |',
              '| --- | ---: | ---: | --- | --- | --- |']
    for m in METHODS:
        for lead in (15,10,5):
            rows=[phase['phase_scores'][m][s][str(lead)] for s in SCENARIOS]
            counts=lambda t: '/'.join(str(sum(r['threshold_counts'][str(t)][k] for r in rows)) for k in ('active','new_start_at_position','holding_from_previous_position'))
            lines.append(f'| {NAMES[m]} | {lead} | {np.mean([r["mean_probability"] for r in rows]):.4f} | {counts(.15)} | {counts(.2)} | {sum(r["common_target_known"] for r in rows)}/{sum(r["common_target_positive"] for r in rows)} |')
    lines += ['', '该表在原完整事件集合上提取分数；六读数未知点仍保留在线分数，但不充当监督阴性。当点新开未必获得事件匹配分数，可能该事件已由更早开启匹配；表中保持也不补分。每情景和分位数见event_phase_probability.json。','',
              '## 全部原校准网格','',
              '| 模型 | 阈值/确认 | 全部预警% | ≥10分钟% | 检测% | 误报/站日 | 预算最大占比 | 可行 |',
              '| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |']
    for m in METHODS:
        for r in grid[m].values():
            v=r['mean']
            lines.append(f'| {NAMES[m]} | {r["threshold"]:g}/{r["confirmation"]} | {v["warning_recall"]*100:.2f} | {v["warning10_recall"]*100:.2f} | {v["detection_recall"]*100:.2f} | {v["false_per_valid_station_day"]:.3f} | {r["maximum_budget_fraction"]:.4f} | {"是" if r["feasible"] else "否"} |')
    lines += ['', '每情景概率箱、分位数、原事件统计和完整日级数组见results.json/daily_metrics.npz；两固定阈值逐事件记录单独保存。','',
              '## 研究判断','',
              '校准段共同阈值下新模型并未普遍变差；新运行点预警下降的算术差主要在阈值组件。新模型在.15时可能违反原经验预算，不能据此将阈值改回去或忽略约束。不能把“阈值组件”解释为校准规则有错，更不能由校准现象解释全部旧评测差。','',
              '下一步可以在冻结的校准概率上分析可行边界与0.15→0.20之间的网格跨度，再决定是否单独研究更连续的预算校准策略。若需要新方法收益，必须先冻结方法，再用未分析数据验证；当前仅明确了问题所在，没有新增方法或收益结论。']
    (output/'report.zh-CN.md').write_text('\n'.join(lines)+'\n',encoding='utf-8'); plot(result,output)


def plot(result,output):
    os.environ.setdefault('MPLBACKEND','Agg')
    import matplotlib.pyplot as plt
    names=['Old onset','15-min equal updates','5-min equal updates']; colors=['#748a99','#3f7eac','#be7e50']
    fig,axes=plt.subplots(2,2,figsize=(12.8,9))
    for ax,key,title in zip(axes[0],['warning_recall','warning10_recall'],['All warning vs budget','Warning >=10 min vs budget']):
        for m,name,color in zip(METHODS,names,colors):
            rs=[r for r in result['calibration_grid'][m].values() if r['confirmation']==1]
            ax.plot([r['maximum_budget_fraction'] for r in rs],[r['mean'][key]*100 for r in rs],'-o',ms=3,color=color,label=name)
            for t,marker in [(.15,'s'),(.2,'^')]:
                r=result['calibration_grid'][m][grid_key(t,1)]
                ax.scatter(r['maximum_budget_fraction'],r['mean'][key]*100,color=color,marker=marker,s=70)
        ax.axvline(1,color='#666',ls='--',lw=1); ax.set_xlabel('Maximum scenario false-alert / budget ratio')
        ax.set_ylabel('Recall (%)'); ax.set_title(title); ax.legend(fontsize=8); ax.grid(alpha=.15)
    ax=axes[1,0]
    for m,name,color in zip(METHODS,names,colors):
        bins=[r for r in result['probability']['calibration'][m]['pooled']['reliability'] if r['count']]
        ax.plot([r['mean_probability'] for r in bins],[r['positive_fraction'] for r in bins],'-o',ms=4,label=name,color=color)
    ax.plot([0,1],[0,1],'--',color='#888',lw=1); ax.set_xlim(0,.6); ax.set_ylim(0,.6)
    ax.set_xlabel('Mean onset probability'); ax.set_ylabel('Observed onset fraction'); ax.set_title('Calibration reliability: fixed bins'); ax.legend(fontsize=8); ax.grid(alpha=.15)
    ax=axes[1,1]; d=result['decomposition']; keys=list(d)
    model=[d[m]['warning10_recall']['symmetric_model_component']*100 for m in keys]
    threshold=[d[m]['warning10_recall']['symmetric_threshold_component']*100 for m in keys]
    y=np.arange(2); ax.barh(y-.16,model,height=.3,label='Model score component',color='#3f7eac')
    ax.barh(y+.16,threshold,height=.3,label='Threshold component',color='#be7e50')
    ax.set_yticks(y,names[1:]); ax.axvline(0,color='#666',lw=1); ax.set_title('>=10-min recall: symmetric 2x2 decomposition')
    ax.set_xlabel('Percentage points (calibration only)'); ax.legend(fontsize=8); ax.grid(axis='x',alpha=.15)
    fig.suptitle('Frozen models: calibration diagnosis, no new evaluation replay',fontsize=14)
    fig.text(.5,.012,'Original grid; c=1 curves; squares p=0.15, triangles p=0.20. Post-hoc arithmetic components, not causal effects.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.04,1,.96)); fig.savefig(output/'summary.png',dpi=170); fig.savefig(output/'summary.svg'); plt.close(fig)


def main():
    parser=argparse.ArgumentParser(description=__doc__); parser.add_argument('--output',type=Path,default=OUTPUT)
    output=parser.parse_args().output; torch.set_num_threads(1); torch.use_deterministic_algorithms(True)
    result=json.loads((output/'results.json').read_text(encoding='utf-8')); config=json.loads((output/'config.json').read_text(encoding='utf-8'))
    compare(config,result['config']); audit=json.loads((output/'audit.json').read_text(encoding='utf-8'))
    assert all(sha256(ROOT/k)==v for k,v in config['sha256'].items())
    assert all(sha256(output/k)==v for k,v in audit['artifact_sha256'].items())
    data=load_data(); parts,targets=load_partitions(data); day=data[8]
    for name,a,b in [('validation',70,77),('calibration',77,91)]:
        start,end=int(np.searchsorted(day,a)),int(np.searchsorted(day,b)); p=parts[name]['natural']
        assert np.array_equal(p['origins'],np.arange(start+12,end-2))
        truth,mask=independent_targets(data,p['origins'],start,end)
        assert np.array_equal(truth,targets[name]['truth']) and np.array_equal(mask,targets[name]['eligible'])
        for source in (ONSET,DENSITY):
            with np.load(source/f'targets_{name}.npz') as saved: assert all(np.array_equal(v,saved[k]) for k,v in targets[name].items())
    with np.load(OLD/'normalization.npz') as n: mu,std=n['mean'],n['std']
    x,y=supervised_data(parts['validation'],targets['validation'],mu,std); logs={}
    for m in METHODS:
        logs[m]=[]; source=ONSET if m=='onset_mlp' else DENSITY
        original_logs=json.loads((source/'model_selection.json').read_text(encoding='utf-8'))[m]
        for seed in SEEDS:
            model,saved=load_model(model_path(m,seed)); logs[m].append({k:v for k,v in saved.items() if k!='state_dict'})
            compare(logs[m][-1],next(r for r in original_logs if r['seed']==seed))
            assert saved['dimension']==51 and saved['seed']==seed and saved['nonlinear']
            if m=='onset_mlp': check_validation(model,saved,x,y['onset'])
            else:
                l=score(model,x); bce=float(np.mean(np.logaddexp(0,l)-y['onset']*l))
                assert np.isclose(bce,saved['validation_bce'],rtol=1e-6,atol=1e-7)
                assert min(saved['logs'],key=lambda r:r['validation_bce'])['step']==saved['selected_step']
                torch.manual_seed(seed); init=RiskModel(51,True); assert state_signature(init.state_dict())==saved['initial_parameters_sha256']
    rebuilt=scores_from_weights(parts,mu,std); maxerror=0.
    for part,by_m in rebuilt.items():
        with np.load(output/f'scores_{part}.npz') as cached:
            for m,by_s in by_m.items():
                for s,p in by_s.items():
                    error=float(np.max(np.abs(p-cached[f'{m}_{s}']))); maxerror=max(maxerror,error); assert error==0.
                    check_probability(result['probability'][part][m][s],p,targets[part]['truth'],targets[part]['eligible'])
                t=targets[part]
                check_probability(result['probability'][part][m]['pooled'],np.concatenate(list(by_s.values())),np.tile(t['truth'],(3,1)),np.tile(t['eligible'],(3,1)))
        if part=='calibration':
            for source,methods in [(ONSET,('onset_mlp',)),(DENSITY,METHODS)]:
                with np.load(source/'scores_calibration.npz') as old:
                    assert all(np.array_equal(rebuilt[part][m][s],old[f'{m}_{s}']) for m in methods for s in SCENARIOS)
    # Synthetic tie/reversed/perfect fixtures guard the independent rank implementations.
    for p,y_ in [(np.array([.1,.1,.6,.6]),np.array([0,1,0,1])),(np.array([.8,.9,.1,.2]),np.array([0,0,1,1])),(np.array([.1,.2,.8,.9]),np.array([0,0,1,1]))]:
        compare(ranking(p,y_),independent_ranking(p,y_))
    selection=json.loads((DENSITY/'selection.json').read_text(encoding='utf-8'))
    rebuilt_result,daily,records=compute(rebuilt,parts,targets,selection,data[3])
    compare(rebuilt_result,{k:result[k] for k in rebuilt_result})
    with np.load(output/'daily_metrics.npz') as cached: assert set(daily)==set(cached.files) and all(np.array_equal(v,cached[k]) for k,v in daily.items())
    compare(records,json.loads((output/'fixed_threshold_event_records.json').read_text(encoding='utf-8')))
    verified=0
    from congestion_objective_diagnostic import trace_events
    for m in METHODS:
        choice=choose(m,rebuilt['calibration'][m],parts['calibration'],result['budgets'])
        compare(choice,selection['methods'][m]); compare(result['selected_operating_points'][m],choice['selected'])
        for oldrow in choice['grid']:
            row=result['calibration_grid'][m][grid_key(oldrow['threshold'],oldrow['confirmation'])]
            assert row['feasible']==oldrow['feasible']
            for s,pr in parts['calibration'].items():
                st=row['by_scenario'][s]['stats']
                compare({k:st[k] for k in oldrow['by_scenario'][s]},oldrow['by_scenario'][s])
                alarm=online_alarm(rebuilt['calibration'][m][s],oldrow['threshold'],oldrow['confirmation'])
                original_stats,core=event_stats(pr['truth'],pr['eligible'],alarm,pr['day_ids'])[:2]
                compare(original_stats,{k:st[k] for k in original_stats})
                assert np.array_equal(core,daily[f'{m}_{grid_key(oldrow["threshold"],oldrow["confirmation"])}_{s}'])
                _,_,trace,diagnostic=trace_events(pr['truth'],pr['eligible'],alarm,pr['day_ids'],pr['origins'],data[3])
                check_event_records(trace,pr,alarm,data[3]); verified+=len(trace)
                compare(diagnostic,row['by_scenario'][s]['diagnostic'])
                counts={str(v):sum(r['lead_minutes']==v for r in trace) for v in (5,10,15)}
                compare(counts,diagnostic['warning_by_lead'])
        for f in FIELDS:
            if m!='onset_mlp':
                r=result['decomposition'][m][f]
                assert np.isclose(r['total_difference'],r['symmetric_model_component']+r['symmetric_threshold_component'],atol=1e-14)
                assert all(np.isclose(sum(r[path]),r['total_difference'],atol=1e-14) for path in ('model_first_path','threshold_first_path'))
    phase=event_phase_diagnostic(records,rebuilt,parts,targets,result)
    write_json(output/'event_phase_probability.json',phase)
    audit['artifact_sha256']['event_phase_probability.json']=sha256(output/'event_phase_probability.json')
    audit.update({'audit_status':'passed','audit_script_sha256':sha256(Path(__file__)),
                  'all_9_saved_weights_validation_choices_checked':True,'probability_rebuild_maximum_error':maxerror,
                  'calibration_probabilities_and_original_choices_unchanged':True,
                  'independent_onset_targets_and_masks_verified':True,'independent_AP_AUC_ties_and_bin_conservation_checked':True,
                  'all_102_operating_points_event_daily_and_lead_metrics_checked':True,
                  'independent_event_records_verified':verified,'both_2x2_decompositions_and_paths_conserve':True,
                  'event_phase_score_active_start_hold_conservation_checked':True,
                  'integer_budget_feasibility_equivalent_to_original_rates':True,
                  'no_evaluation_partition_prepared_or_new_evaluation_thresholds_run':True})
    write_json(output/'audit.json',audit); report(result,logs,phase,output)
    print(json.dumps({'audit':'passed','probability_error':maxerror,'event_records':verified,
        'pooled_probability':{p:{m:{k:v['pooled'][k] for k in ('bce','average_precision','roc_auc','ece_fixed_bins')} for m,v in rows.items()} for p,rows in result['probability'].items()},
        'fixed_thresholds':{m:{k:{'mean':v['mean'],'feasible':v['feasible'],'budget_excess':v['budget_excess_by_scenario']} for k,v in rows.items() if k in ('0.15_c1','0.2_c1')} for m,rows in result['calibration_grid'].items()},
        'report':str(output/'report.zh-CN.md')},indent=2))


if __name__=='__main__': main()
