"""Save the cumulative writing supplement without replacing earlier checkpoints."""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'outputs/thesis-word'
CHECKPOINTS = ROOT.parent / 'checkpoints'
NAME = 'traffic-recovery-lab-2026-10-12-thesis-word'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def record(path):
    return {'bytes': path.stat().st_size, 'sha256': sha(path)}


def main():
    archive = CHECKPOINTS / (NAME + '.zip')
    receipt_path = CHECKPOINTS / (NAME + '-save-receipt.json')
    if archive.exists() or receipt_path.exists():
        raise FileExistsError('Preserve existing checkpoint; use a new name for another save.')
    qa = read(OUT / 'qa.json')
    export = read(OUT / 'word_export.json')
    author = read(OUT / 'authoring_manifest.json')
    assert qa['all_final_pages_visually_reviewed']
    assert qa['pages'] == export['pages'] == 68
    assert qa['reviewed_pages'] == list(range(1, 69))
    assert qa['docx_sha256'] == author['docx_sha256'] == export['docx_sha256'] == sha(ROOT / 'docs/thesis_review.zh-CN.docx')
    assert qa['pdf_sha256'] == export['pdf_sha256'] == sha(OUT / 'word-preview.pdf')
    assert qa['source_sha256'] == author['source_sha256'] == sha(ROOT / 'docs/thesis_manuscript.zh-CN.md')
    assert qa['primary_metric_supported'] is False
    assert qa['school_submission_format_complete'] is False

    renderer = Path('${USER_HOME}/.codex/plugins/cache/openai-primary-runtime/documents/26.1011.11113/skills/documents/render_docx.py')
    # Skill versions may place the renderer under scripts rather than their root.
    if not renderer.is_file():
        renderer = renderer.parent / 'scripts/render_docx.py'
    assert renderer.is_file(), renderer
    doc_sources = [
        'docs/thesis_manuscript.zh-CN.md', 'outputs/thesis-manuscript/documentation_manifest.json',
        'build_thesis_manuscript.py', 'build_thesis_word.py', 'render_thesis_word.ps1',
        'render_thesis_pages.py', 'check_thesis_word.py', 'save_thesis_word_checkpoint.py',
    ]
    artifacts = [
        'docs/thesis_review.zh-CN.docx', 'docs/thesis_word_handoff.zh-CN.md',
        'outputs/thesis-word/authoring_manifest.json', 'outputs/thesis-word/word_export.json',
        'outputs/thesis-word/qa.json', 'outputs/thesis-word/word-preview.pdf',
        'outputs/thesis-word/method_flow.png',
    ]
    dump(OUT / 'documentation_manifest.json', {
        'stage': 'word_review_edition_after_final_68_page_visual_qa', 'client_date': '2026-10-12',
        'source_sha256': {p: sha(ROOT / p) for p in doc_sources},
        'files': {p: record(ROOT / p) for p in artifacts},
        'page_images_sha256': {f'page-{i}.png': sha(OUT / f'pages/page-{i}.png') for i in range(1, 69)},
        'pages': 68, 'all_final_pages_visually_reviewed': True, 'review_image_dpi': 120,
        'reviewed_pages': list(range(1, 69)), 'page_pairs_resized': False,
        'pdf_engine': 'Microsoft Word', 'canonical_page_renderer': str(renderer),
        'canonical_page_renderer_sha256': sha(renderer), 'office_math_xslt_sha256': author['xslt_sha256'],
        'external_runtime_office_and_skill_resources_included': False,
        'original_research_results_changed': False, 'primary_metric_supported': False,
        'school_submission_format_complete': False, 'github_uploaded': False,
    })
    old = read(ROOT / 'outputs/thesis-manuscript/writing_archive_manifest.json')
    files = set(old['files']) | set(doc_sources) | set(artifacts) | {'outputs/thesis-word/documentation_manifest.json'}
    assert all((ROOT / p).is_file() for p in files)
    base_receipt_path = CHECKPOINTS / 'traffic-recovery-lab-2026-10-11-event-timeline-save-receipt.json'
    base_receipt = read(base_receipt_path)
    base = Path(base_receipt['full_archive'])
    assert base.stat().st_size == base_receipt['full_archive_bytes']
    assert base_receipt['archive_crc_and_all_sha256_verified'] is True
    with ZipFile(base) as z:
        available = {n.removeprefix('traffic-recovery-lab/') for n in z.namelist()} | files
    # Check every recorded chapter/manuscript dependency is supplied by the two archives.
    manifests = sorted(p for p in files if p.endswith('/documentation_manifest.json'))
    missing = []
    for p in manifests:
        sources = read(ROOT / p).get('source_sha256', {})
        if isinstance(sources, dict):
            missing += [(p, s) for s in sources if s not in available]
    assert not missing, missing
    archive_manifest = OUT / 'writing_archive_manifest.json'
    dump(archive_manifest, {
        'stage': 'cumulative_thesis_writing_archive_after_word_review', 'client_date': '2026-10-12',
        'archive_name': archive.name,
        'scope': 'Restore full 2026-10-11 event-timeline base, then this cumulative writing supplement in a new directory.',
        'base_archive': {'name': base.name,
                         'sha256_from_prior_verified_receipt': base_receipt['full_archive_sha256'],
                         'prior_verified_at_utc': base_receipt['saved_at_utc'],
                         'full_crc_rechecked_this_turn': False},
        'files': {p: record(ROOT / p) for p in sorted(files)},
        'internal_pdf_included': True, 'page_pngs_included': False,
        'two_archive_documentation_dependencies_present': True,
        'external_runtime_office_and_skill_resources_included': False,
        'primary_metric_supported': False, 'github_uploaded': False,
    })
    files.add('outputs/thesis-word/writing_archive_manifest.json')
    CHECKPOINTS.mkdir(exist_ok=True)
    with ZipFile(archive, 'x', compression=ZIP_DEFLATED, compresslevel=6) as z:
        for p in sorted(files):
            z.write(ROOT / p, 'traffic-recovery-lab/' + p)
    with ZipFile(archive) as z:
        assert z.testzip() is None
        assert len(z.namelist()) == len(files)
        for p in files:
            assert z.read('traffic-recovery-lab/' + p) == (ROOT / p).read_bytes(), p
    receipt = {
        'saved_at_utc': datetime.now(timezone.utc).isoformat(),
        'stage': 'cumulative_thesis_writing_archive_after_word_review', 'archive': str(archive),
        'archive_bytes': archive.stat().st_size, 'archive_sha256': sha(archive),
        'archived_files': len(files), 'archive_crc_and_all_file_bytes_verified': True,
        'all_final_68_pages_visually_reviewed': True,
        'two_archive_documentation_dependencies_present': True,
        'full_base_reverified_this_turn': False, 'full_base_prior_receipt': str(base_receipt_path),
        'manifest': str(archive_manifest), 'docx_sha256': qa['docx_sha256'],
        'primary_metric_supported': False, 'github_uploaded': False,
    }
    dump(receipt_path, receipt)
    print(json.dumps(receipt, ensure_ascii=True))


if __name__ == '__main__':
    main()
