"""Cumulative snapshot of failed early-protected full episode replay."""
from datetime import datetime,timezone
from pathlib import Path
import hashlib
from zipfile import ZipFile,ZIP_DEFLATED
from save_station_agnostic_checkpoint import read,write,sha

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs/early-warning-protection-2026-10-15'
NAME='traffic-recovery-lab-2026-10-15-early-warning-protection'


def main():
    archive=ROOT.parent/'checkpoints'/(NAME+'.zip');receipt=archive.with_name(NAME+'-save-receipt.json')
    if archive.exists() or receipt.exists():raise FileExistsError('Preserve existing archives')
    r=read(OUT/'results.json');audit=read(OUT/'audit.json');tests=read(OUT/'test_receipt.json')
    assert audit['passed'] and tests['passed'] and tests['tests_run']==9
    assert sha(ROOT/'tests/test_early_warning_protection.py')==tests['test_source_sha256']
    assert not r['primary_acceptance_passed'] and not r['new_station_cohort_consumed']
    assert audit['all_original_development_R10_event_identities_and_leads_preserved_by_primary']
    assert not r['consumed_transfer_values_used_in_this_run'] and not read(OUT/'selection_freeze.json')['ablation_substitution']
    for name,digest in read(OUT/'completion.json')['artifacts'].items():assert sha(OUT/name)==digest
    prior_path='outputs/frozen-probe-transfer-2026-10-15/writing_archive_manifest.json';prior=read(ROOT/prior_path)
    for name,meta in prior['files'].items():assert sha(ROOT/name)==meta['sha256'],name
    summary=('固定原判别器，训练专用早预警保护分界线0.1641272233加三条已观测低速豁免，完整事件回放保住原R10身份与原提前量；'
        '但14日校准检出87.44%→81.64%，误报0.084619→0.078646（仅降7.06%），主方案未通过。'
        '新增漏检均来自原迟报，暴露原“预警vs误报”训练任务排除了迟报的覆盖缺口。')
    marker='# 最新检查点：早预警保护完整回放未通过（2026-10-15）'
    p=ROOT/'CURRENT_STATE.zh-CN.md';old=p.read_text(encoding='utf-8');assert marker not in old
    p.write_text(marker+'\n\n- '+summary+'\n'
        '- 分界线只用原训练450起点中的84条R10情景行确定，参数封存后才加载开发验证/校准；不重训模型。主方案固定，三消融也均未过，没有交换主方案或放宽条件。\n'
        '- 四范围各情景原R10身份与提前量均保留；前校准周无R10，空保护不构成强保证。校准每情景多漏4个迟报；验证自然/单站/成组多漏5/3/4迟报。\n'
        '- 9项测试、48过滤激活独立重建、60完整回放、逐事件转移与bootstrap核对通过；原科学文件保持。\n'
        '- 本轮没有加载原评测或已消耗迁移缓存/结果，也未开HDF5或新站点；既往跨站发现影响假设选择须披露。\n'
        '- 报告outputs/early-warning-protection-2026-10-15/report.zh-CN.md；接续docs/early_warning_protection_handoff.zh-CN.md。下一轮应原开发训练补齐迟报等有效告警目标，仍须保护提前量及做完整回放。\n'
        '- 原论文主检验/旧失败保留，Word/PPT与GitHub v7未改；最新累计包2026-10-15-early-warning-protection，恢复先10月11日完整基包再本累计包。\n\n以下为之前阶段记录。\n\n'+old,encoding='utf-8')
    p=ROOT/'README.md';old=p.read_text(encoding='utf-8')
    p.write_text('# 最新研究：早预警保住，但迟报检出损失\n\n'
        '[完整报告](outputs/early-warning-protection-2026-10-15/report.zh-CN.md) · [接续说明](docs/early_warning_protection_handoff.zh-CN.md)\n\n'
        +summary+' 仅重复使用的原开发数据检查，未更新线上规则。最新累计包为2026-10-15-early-warning-protection。\n\n以下为之前阶段记录。\n\n'+old,encoding='utf-8')
    files=set(prior['files'])|{prior_path,'early_warning_protection.py','audit_early_warning_protection.py',
        'summarize_early_warning_protection.py','save_early_warning_protection_checkpoint.py',
        'tests/test_early_warning_protection.py','docs/early_warning_protection_handoff.zh-CN.md'}
    files|={p.relative_to(ROOT).as_posix() for p in OUT.rglob('*') if p.is_file() and p.name!='writing_archive_manifest.json'}
    base_path=ROOT.parent/'checkpoints/traffic-recovery-lab-2026-10-11-event-timeline-save-receipt.json';base=read(base_path)
    assert Path(base['full_archive']).stat().st_size==base['full_archive_bytes'] and base['archive_crc_and_all_sha256_verified']
    manifest=OUT/'writing_archive_manifest.json'
    write(manifest,{'client_date':'2026-10-15','stage':'cumulative_failed_early_protected_full_replay',
        'archive_name':archive.name,'restore':'October11 full base, then this supplement',
        'primary_acceptance_passed':False,'all_original_development_R10_and_leads_retained':True,
        'new_station_cohort_consumed':False,'consumed_transfer_values_loaded':False,
        'models_refit':False,'unit_tests_observed_passed':9,
        'all48_gated_activations_reconstructed':True,'all60_operating_replays_checked':True,
        'prior_files_changed':['README.md','CURRENT_STATE.zh-CN.md'],
        'original_thesis_primary_test_still_failed':True,
        'public_commit_unchanged':'ab8760a3e6ea1784fea3195a0e7aadbaff6fe80d',
        'base_crc_rechecked_this_turn':False,'base_sha256_from_prior_verified_receipt':base['full_archive_sha256'],
        'files':{n:{'bytes':(ROOT/n).stat().st_size,'sha256':sha(ROOT/n)} for n in sorted(files)}})
    files.add(manifest.relative_to(ROOT).as_posix())
    with ZipFile(archive,'x',compression=ZIP_DEFLATED) as z:
        for n in sorted(files):z.write(ROOT/n,'traffic-recovery-lab/'+n)
    with ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist())==len(files)
        for n in sorted(files):
            data=z.read('traffic-recovery-lab/'+n)
            assert data==(ROOT/n).read_bytes() and hashlib.sha256(data).hexdigest()==sha(ROOT/n)
    proof={'saved_at_utc':datetime.now(timezone.utc).isoformat(),'archive':str(archive),
        'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'files':len(files),
        'crc_and_all_file_bytes_and_sha256_verified':True,'primary_acceptance_passed':False,
        'all_original_development_R10_and_leads_retained':True,'new_station_cohort_consumed':False,
        'original_thesis_primary_test_still_failed':True,'public_version_unchanged':True,
        'base_prior_verified_receipt':str(base_path),'base_crc_rechecked_this_turn':False}
    write(receipt,proof);print(proof)


if __name__=='__main__':main()
