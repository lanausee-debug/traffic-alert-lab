"""Recompute complete fine calibration grids and unchanged selected event scoring."""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import time
import numpy as np
import torch
from recovery_pilot import ROOT,write_json
from multifault_pilot import sha256
from audit_congestion_pilot import compare
from congestion_alert_pilot import SCENARIOS,event_stats
from congestion_risk_pilot import online_alarm,choose
from congestion_ablation import load_data
from congestion_density_pilot import METHODS,SIMPLE,OUTPUT as DENSITY,saved_targets,evaluate_with_leads
from summarize_congestion_density import NAMES
from summarize_congestion_onset import mean,independent_targets
from summarize_congestion_objective import check_event_records
from congestion_fine_grid_pilot import (OUTPUT,PROB_FINE,SPEED_FINE,thresholds,load_partition,frozen_scores,
    comparisons,nonmonotonic_example,nonmonotonic_counts)
from congestion_calibration_diagnostic import grid_key


def independent_rank(row,index):
    rows=list(row['by_scenario'].values())
    warning=np.array([r['warning_recall'] for r in rows])
    false=np.array([r['false_per_valid_station_day'] for r in rows])
    return (-float(warning.mean()),-float(warning.min()),float(false.mean()),row['confirmation'],index)


def report(result,output):
    fine=result['evaluation']; coarse=result['coarse_evaluation']; budgets=result['selection']['budgets']; ref=result['reference']
    lines=['# 细校准网格：冻结模型的运行点探索','',
           '2026-10-10。全部日期以前使用过；本轮探索。模型、预算、计分和选择目标保持，只细化校准阈值；先保存选择，再在原评测段回放已选设置。没有评测全阈值扫描。','',
           f'概率网格180个阈值（.010–.900步长.005及关闭值），速度网格92个阈值（15–60 mph步长.5及关闭值），均确认1/2次。全部13组方法同样细化，校准简单参考为**{NAMES[ref]}**。','',
           '## 两项固定主要比较','',
           '| 对照 | 指标 | 5分钟MLP细网格−对照 | 95%日期探索区间 | 97.5%日期探索区间 |',
           '| --- | --- | ---: | --- | --- |']
    for c in result['comparisons'].values():
        name=NAMES[c['baseline']]+('（粗网格）' if c['baseline_grid']=='coarse' else '（细网格）')
        for key,label,factor in [('warning10_recall','≥10分钟召回（百分点）',100),('warning_recall','全部预警（百分点）',100),
                                 ('detection_recall','含迟报检测（百分点）',100),('false_rate','误报/有效站日',1)]:
            interval=lambda k:'['+', '.join(f'{v*factor:.3f}' for v in c[k])+']'
            extra=interval(key+'_ci975') if key+'_ci975' in c else '—'
            lines.append(f'| {name} | {label} | {c[key+"_difference"]*factor:+.3f} | {interval(key+"_ci95")} | {extra} |')
    lines += ['', '2000次日期配对bootstrap，三情景共用同一日期索引。97.5%只用于主要指标两个比较，不控制辅助指标或历史反复探索，也不含训练方差；不是独立确认。','',
              '## 全部13组粗/细运行点','',
              '| 方法 | 网格 | 阈值/确认 | 校准预警% | 评测≥10分钟% | 评测全部预警% | 评测检测% | 误报/有效站日 | 成功子集平均提前分钟 |',
              '| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |']
    for m in METHODS:
        for label,selection,rows in [('粗',result['coarse_selection'],coarse),('细',result['selection'],fine)]:
            op=selection['methods'][m]['selected']; r=rows[m]
            threshold=-op['threshold'] if m=='dense_speed' else op['threshold']
            cal=np.mean([op['by_scenario'][s]['warning_recall'] for s in SCENARIOS])*100
            lines.append(f'| {NAMES[m]} | {label} | {threshold:g}/{op["confirmation"]} | {cal:.2f} | {mean(r,"warning_recall_at_least10")*100:.2f} | {mean(r,"warning_recall")*100:.2f} | {mean(r,"detection_recall")*100:.2f} | {mean(r,"false_per_valid_station_day"):.3f} | {mean(r,"warning_lead_mean_minutes"):.2f} |')
    lines += ['', '粗运行点均为原保存选择。细网格包含所有粗点，因此校准全部预警最优值不降低，这是搜索集合扩大的必然性质，不是泛化或创新证据。原选择目标仍是全部预警；≥10分钟是评测主指标，未据它重选阈值。','',
              f'校准简单参考按全部预警选为起点线性，并非评测≥10分钟最强简单方法。全局校准细网格≥10分钟{mean(fine["global_calibration"],"warning_recall_at_least10")*100:.2f}%、检测{mean(fine["global_calibration"],"detection_recall")*100:.2f}%、误报{mean(fine["global_calibration"],"false_per_valid_station_day"):.3f}；5分钟起点MLP对应{mean(fine["dense_update_mlp"],"warning_recall_at_least10")*100:.2f}%、{mean(fine["dense_update_mlp"],"detection_recall")*100:.2f}%、{mean(fine["dense_update_mlp"],"false_per_valid_station_day"):.3f}。起点MLP全部预警更多，但不能只凭超过起点线性就称优于所有简单方法。这里是全表描述，不新增方法选择或确认性比较。','',
              '## 每情景预算、提前档位及完整事件计数','',
              '| 方法 | 网格 | 情景 | ≥10分钟% | 全预警% | 检测% | 5/10/15分钟数 | 误报/站日 | 校准预算 | 评测超额 | 迟报 | 漏检 | 重复 | 未知 | 删失告警 |',
              '| --- | --- | --- | ---: | ---: | ---: | --- | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: |']
    for m in METHODS:
        for label,rows in [('粗',coarse),('细',fine)]:
            for s in SCENARIOS:
                r=rows[m][s]; counts='/'.join(str(r['warning_lead_counts'][str(v)]) for v in (5,10,15))
                lines.append(f'| {NAMES[m]} | {label} | {s} | {r["warning_recall_at_least10"]*100:.2f} | {r["warning_recall"]*100:.2f} | {r["detection_recall"]*100:.2f} | {counts} | {r["false_per_valid_station_day"]:.3f} | {budgets[s]:.3f} | {"是" if r["false_per_valid_station_day"]>budgets[s] else "否"} | {r["late"]:g} | {r["missed_events"]} | {r["duplicate"]:g} | {r["unknown_alerts"]:g} | {r["censored_alerts"]:g} |')
    lines += ['', '经验预算仅约束校准段，不保证评测或线上误报。评测仍每情景1089完整事件、73删失事件；三情景共享真值，合计3267情景-事件不是独立事件扩样。成功提前量是各自成功子集统计，不能直接相减作因果效果。','',
              '## 细网格选定点的校准完整指标','',
              '| 方法 | ≥10分钟% | 全部预警% | 检测% | 误报/站日 |',
              '| --- | ---: | ---: | ---: | ---: |']
    for m in METHODS:
        r=result['calibration_selected'][m]
        lines.append(f'| {NAMES[m]} | {mean(r,"warning_recall_at_least10")*100:.2f} | {mean(r,"warning_recall")*100:.2f} | {mean(r,"detection_recall")*100:.2f} | {mean(r,"false_per_valid_station_day"):.3f} |')
    lines += ['', '完整4504个校准运行点及13512个情景日级数组见selection.json/calibration_grid_daily.npz，没有隐藏更差点；辅助逐点、概率与故障站指标保存于results.json。','',
              '## 不采用二分搜索的原因','',
              '计数对象是告警段，不是超过阈值的点数。最小例子：一个段内分数[.30,.15,.30]，阈值.10形成1次误报，阈值.20将其切成2次误报。提高阈值可能增加误报次数，本輪完整枚举。每模型/确认/情景实际网格中“提高阈值而误报增加”的相邻次数另存结果。','',
              '## 审核与边界','',
              '冻结数据/模型/旧审核哈希；分数与既有缓存严格一致；原始标签有效性、网格范围/包含性、4504运行点全部事件/日级计数、预算、选择与简单参考重算。校准选择文件的SHA在评测准备前保存，评测后未改变。全部细选点及粗评测事件记录用独立可计分开启列表检查，原粗统计与分母一致；两项日期区间复算。','',
              '细网格只改运行点选择，属于常规校准工具。无论本轮结果是否变好，都不能据此宣称新深度学习算法、方法原创性或整体服务已提升。下一步需根据完整召回/误报/检测权衡决定是否冻结一套候选，再在未使用数据上检验；避免继续用当前评测寻找最好的网格。']
    (output/'report.zh-CN.md').write_text('\n'.join(lines)+'\n',encoding='utf-8'); plot(result,output)


def plot(result,output):
    os.environ.setdefault('MPLBACKEND','Agg')
    import matplotlib.pyplot as plt
    names=['Speed rule','Global cal.','Group cal.','State linear','Persistent MLP','Common BCE linear',
           'Common BCE MLP','Onset linear','Old onset MLP','15-min onset linear','15-min onset MLP','5-min onset linear','5-min onset MLP']
    fig,axes=plt.subplots(1,4,figsize=(17,8.2),sharey=True); y=np.arange(len(METHODS))
    for ax,key,title,factor in zip(axes,['warning_recall_at_least10','warning_recall','detection_recall','false_per_valid_station_day'],
        ['Warning >=10 min (%)','All warning (%)','Detection incl. late (%)','False / valid station-day'],[100,100,100,1]):
        a=[mean(result['coarse_evaluation'][m],key)*factor for m in METHODS]
        b=[mean(result['evaluation'][m],key)*factor for m in METHODS]
        ax.barh(y-.17,a,height=.32,color='#b8bec6',label='Original coarse grid')
        ax.barh(y+.17,b,height=.32,color='#3f7eac',label='Uniform finer grid')
        ax.set_title(title,fontsize=10); ax.set_xlim(0,max(a+b)*1.19); ax.grid(axis='x',alpha=.17); ax.set_axisbelow(True)
        for i,v in enumerate(b): ax.text(v+max(a+b)*.01,i+.17,f'{v:.2f}',va='center',fontsize=7)
    axes[0].set_yticks(y,names); axes[0].invert_yaxis()
    handles,labels_=axes[0].get_legend_handles_labels()
    fig.legend(handles,labels_,fontsize=9,loc='lower center',bbox_to_anchor=(.53,.027),ncol=2,frameon=False)
    fig.suptitle('Frozen models: calibration grid resolution, one selected evaluation replay',fontsize=13)
    fig.text(.53,.008,'Previously analyzed dates; original per-scenario budgets; calibrated settings; no new training.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.08,1,.95)); fig.savefig(output/'summary.png',dpi=170); fig.savefig(output/'summary.svg'); plt.close(fig)


def main():
    parser=argparse.ArgumentParser(description=__doc__); parser.add_argument('--output',type=Path,default=OUTPUT)
    output=parser.parse_args().output; torch.set_num_threads(1); begun=time.perf_counter()
    result=json.loads((output/'results.json').read_text(encoding='utf-8')); config=json.loads((output/'config.json').read_text(encoding='utf-8'))
    compare(config,result['config']); audit=json.loads((output/'audit.json').read_text(encoding='utf-8'))
    assert all(sha256(ROOT/k)==v for k,v in config['sha256'].items())
    assert all(sha256(output/k)==v for k,v in audit['artifact_sha256'].items())
    prior_audit=json.loads((DENSITY/'audit.json').read_text(encoding='utf-8')); assert prior_audit['audit_status']=='passed'
    assert all(sha256(DENSITY/k)==v for k,v in prior_audit['artifact_sha256'].items())
    assert PROB_FINE==[i/1000 for i in range(10,901,5)]+[1.0001]
    assert SPEED_FINE==[-i/2 for i in range(30,121)]+[1000.]
    assert len(PROB_FINE)==180 and len(SPEED_FINE)==92
    for m in METHODS: assert set(thresholds(m,False)).issubset(thresholds(m))
    frozen=json.loads((output/'calibration_frozen.json').read_text(encoding='utf-8'))
    compare(frozen['sha256'],result['calibration_artifacts_frozen_before_evaluation'])
    assert frozen['selected_before_evaluation_partition_prepared'] and all(sha256(output/k)==v for k,v in frozen['sha256'].items())
    selection=json.loads((output/'selection.json').read_text(encoding='utf-8')); compare(selection,result['selection'])
    coarse=json.loads((DENSITY/'results.json').read_text(encoding='utf-8')); compare(coarse['evaluation'],result['coarse_evaluation'])
    compare(coarse['selection'],result['coarse_selection']); compare(selection['budgets'],coarse['selection']['budgets'])
    data=load_data(); parts=load_partition(data,'calibration'); scores=frozen_scores('calibration'); all_days={}; verified_ops=0
    with np.load(output/'scores_calibration.npz') as saved: assert all(np.array_equal(p,saved[f'{m}_{s}']) for m,rows in scores.items() for s,p in rows.items())
    with np.load(output/'calibration_grid_daily.npz') as saved:
        for m in METHODS:
            rows=selection['methods'][m]['grid']; expected=[(t,c) for t in thresholds(m) for c in (1,2)]
            assert [(r['threshold'],r['confirmation']) for r in rows]==expected
            candidates=[]
            for idx,r in enumerate(rows):
                feasible=True
                for s in SCENARIOS:
                    p=parts[s]; alarm=online_alarm(scores[m][s],r['threshold'],r['confirmation'])
                    stats,days,_=event_stats(p['truth'],p['eligible'],alarm,p['day_ids'])
                    compare({k:stats[k] for k in r['by_scenario'][s]},r['by_scenario'][s])
                    feasible &= stats['false_per_valid_station_day']<=selection['budgets'][s]+1e-12
                    key=f'{m}_{grid_key(r["threshold"],r["confirmation"])}_{s}'
                    assert np.array_equal(days,saved[key]); all_days[key]=days
                assert feasible==r['feasible']
                if feasible: candidates.append((independent_rank(r,idx//2),r))
                verified_ops+=1
            compare(min(candidates,key=lambda p:p[0])[1],selection['methods'][m]['selected'])
            row_map={(r['threshold'],r['confirmation']):r for r in rows}
            for r in coarse['selection']['methods'][m]['grid']: compare(r,row_map[(r['threshold'],r['confirmation'])])
            new=selection['methods'][m]['selected']; old=coarse['selection']['methods'][m]['selected']
            assert np.mean([r['warning_recall'] for r in new['by_scenario'].values()])>=np.mean([r['warning_recall'] for r in old['by_scenario'].values()])-1e-12
            print(f'complete grid audited: {m}, elapsed={time.perf_counter()-begun:.1f}s',flush=True)
        assert set(all_days)==set(saved.files)
    def simple_rank(m):
        r=selection['methods'][m]['selected']; rows=list(r['by_scenario'].values())
        return (-np.mean([x['warning_recall'] for x in rows]),-min(x['warning_recall'] for x in rows),np.mean([x['false_per_valid_station_day'] for x in rows]),SIMPLE.index(m))
    assert min(SIMPLE,key=simple_rank)==result['reference']==selection['reference']
    compare(nonmonotonic_example(),result['nonmonotonicity_example'])
    compare(nonmonotonic_counts(all_days),result['higher_threshold_adjacent_false_count_increases'])
    raw,_,valid,ts,*_=data; records_saved=json.loads((output/'event_records.json').read_text(encoding='utf-8')); verified_events=0
    for partition in ('calibration','evaluation'):
        if partition=='evaluation': parts=load_partition(data,partition); scores=frozen_scores(partition)
        p=parts['natural']; origins=p['origins']; future=origins[:,None]+np.arange(3)[None]
        window=origins[:,None]+np.arange(-12,3)[None]; regular=(np.diff(ts[window],axis=1)==np.timedelta64(5,'m')).all(axis=1)
        assert np.array_equal((raw[future]<=30).all(axis=1),p['truth'])
        assert np.array_equal((valid[future]>0).all(axis=1)&regular[:,None],p['eligible'])
        a,b=(77,91) if partition=='calibration' else (91,119); day=data[8]; lo,hi=int(np.searchsorted(day,a)),int(np.searchsorted(day,b))
        target=saved_targets(partition); truth,mask=independent_targets(data,origins,lo,hi)
        assert np.array_equal(truth,target['truth']) and np.array_equal(mask,target['eligible'])
        with np.load(output/f'scores_{partition}.npz') as saved: assert all(np.array_equal(v,saved[f'{m}_{s}']) for m,rows in scores.items() for s,v in rows.items())
        rows,daily,records=evaluate_with_leads(scores,parts,target,selection['methods'],ts)
        compare(rows,result['calibration_selected' if partition=='calibration' else 'evaluation'])
        compare(records,records_saved[partition])
        daily_file='calibration_selected_daily.npz' if partition=='calibration' else 'daily_metrics.npz'
        with np.load(output/daily_file) as saved: assert set(saved.files)==set(daily) and all(np.array_equal(v,saved[k]) for k,v in daily.items())
        for m in METHODS:
            op=selection['methods'][m]['selected']
            for s in SCENARIOS:
                alarm=online_alarm(scores[m][s],op['threshold'],op['confirmation'])
                check_event_records(records[m][s],parts[s],alarm,ts); verified_events+=len(records[m][s])
        if partition=='evaluation':
            old_rows,old_daily,old_records=evaluate_with_leads(scores,parts,target,coarse['selection']['methods'],ts)
            compare(old_rows,coarse['evaluation'])
            with np.load(DENSITY/'daily_metrics.npz') as saved: assert all(np.array_equal(v,saved[k]) for k,v in old_daily.items())
            for m in METHODS:
                op=coarse['selection']['methods'][m]['selected']
                for s in SCENARIOS:
                    check_event_records(old_records[m][s],parts[s],online_alarm(scores[m][s],op['threshold'],op['confirmation']),ts)
                    verified_events+=len(old_records[m][s])
            compare(comparisons(daily,old_daily,result['reference']),result['comparisons'])
    assert verified_ops==4504
    audit.update({'audit_status':'passed','audit_script_sha256':sha256(Path(__file__)),
        'prior_passed_weight_probability_audit_and_all_source_hashes_unchanged':True,
        'all_score_copies_byte_equal_to_prior_arrays':True,'fixed_ranges_steps_and_coarse_grid_inclusion_checked':True,
        'verified_calibration_operating_points':verified_ops,'verified_scenario_calibration_daily_arrays':len(all_days),
        'independent_rank_budget_choices_and_simple_reference_checked':True,
        'selection_artifact_hashes_saved_before_evaluation_and_unchanged':True,
        'raw_event_targets_masks_coarse_results_and_all_selected_daily_metrics_checked':True,
        'independent_selected_and_coarse_event_records_verified':verified_events,
        'two_primary_date_bootstrap_comparisons_recomputed':True,'nonmonotonic_alert_count_example_checked':True})
    write_json(output/'audit.json',audit); report(result,output)
    print(json.dumps({'audit':'passed','operating_points':verified_ops,'event_records':verified_events,
                      'reference':result['reference'],'comparisons':result['comparisons'],'report':str(output/'report.zh-CN.md')},indent=2))


if __name__=='__main__': main()
