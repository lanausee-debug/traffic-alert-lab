"""Development pilot: gate new starts on an available past residual.

One declared primary rule (>5 mph), two sensitivity checks (>3, >7).
No model fitting, threshold search, test access, or switching primary on failure.
"""
from __future__ import annotations
from datetime import datetime,timezone
from pathlib import Path
import sys
import numpy as np
import torch
import calibration_fragility as common
from congestion_alert_pilot import SCENARIOS
from pems_bay_alert_replay import alarm,replay
from train_pems_bay_risk import load_risk

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs/adaptive-confirmation-2026-10-15'
PRIMARY='residual_gt5'
BOUNDS=(3.,5.,7.)
METRICS=('warning_recall_at_least10','detection_recall','false_per_valid_station_day')


def adaptive_alarm(scores,residual,origins,timestamps,threshold=.46,bound=5.):
    """Only start confirmation changes. Existing alarms follow raw score until off.

    inputs are available scores, past residuals and clock metadata, never targets.
    Missing residual => original one-reading rule. Clock gaps reset all state.
    """
    scores=np.asarray(scores);residual=np.asarray(residual)
    if scores.ndim!=2 or residual.shape!=scores.shape or len(origins)!=len(scores):raise ValueError('Invalid online shapes')
    if not np.isfinite(scores).all() or not np.isfinite(bound) or bound<0:raise ValueError('Invalid rule inputs')
    raw=scores>=threshold
    active=np.zeros_like(raw)
    previous=np.zeros(scores.shape[1],bool);ongoing=previous.copy()
    times=timestamps[origins]
    for at in range(len(scores)):
        if at==0 or origins[at]-origins[at-1]!=1 or times[at]-times[at-1]!=np.timedelta64(5,'m'):
            previous[:]=False;ongoing[:]=False
        needs=np.isfinite(residual[at])&(residual[at]>bound)
        ongoing=raw[at]&(ongoing|~needs|previous)
        active[at]=ongoing
        previous=raw[at].copy()
    return active


def block_gate(candidate,reference):
    defined=all(candidate[s][k] is not None and reference[s][k] is not None for s in SCENARIOS for k in METRICS)
    if not defined:return {'passed':False,'defined':False,'by_scenario':None}
    by_s={s:{'false_not_increased':candidate[s]['false_per_valid_station_day']<=reference[s]['false_per_valid_station_day']+1e-12,
        'R10_not_decreased':candidate[s]['warning_recall_at_least10']>=reference[s]['warning_recall_at_least10']-1e-12,
        'detection_within_2pp':candidate[s]['detection_recall']>=reference[s]['detection_recall']-.02-1e-12} for s in SCENARIOS}
    return {'passed':all(all(v.values()) for v in by_s.values()),'defined':True,'by_scenario':by_s}


def freeze_plan():
    OUT.mkdir(exist_ok=True)
    names=['adaptive_confirmation.py','calibration_fragility.py','pems_bay_alert_replay.py',
        'congestion_alert_pilot.py','congestion_risk_pilot.py','train_pems_bay_risk.py',
        'outputs/pems-bay-risk/risk_validation.npz','outputs/pems-bay-risk/normalization.npz',
        'outputs/pems-bay-risk/global_calibration.pt','outputs/pems-bay-calibration/calibration.npz',
        'outputs/pems-bay-calibration/selection.json','outputs/calibration-fragility-2026-10-15/results.json']
    plan={'stage':'adaptive_development_residual_conditioned_start_confirmation',
        'hypothesis_from_previous_development_diagnosis':True,'independent_confirmation':False,
        'primary_rule':PRIMARY,'positive_past_residual_cutoff_mph':5.,
        'sensitivity_only_cutoffs_mph':[3.,7.],'primary_cannot_be_replaced_by_sensitivity_winner':True,
        'model_and_threshold':'original frozen global calibration risk, threshold0.46',
        'rule':'if score is positive and not already active, require previous raw score positive only when finite causal residual>cutoff; otherwise start immediately; once active, remain until raw score off; clock/origin gap resets',
        'residual':'f(t-1|history<=t-2)-observed_v(t-1); fresh own observation only, gap safe',
        'unavailable_residual':'original c1 behavior; no forced drop or invented zero residual',
        'baselines':['global_c1','global_c2'],
        'allowed_data':'original24 risk_validation7days and calibration14days; both previously reused',
        'blocks':['risk_validation7','calibration_week1_7','calibration_week2_7'],
        'primary_acceptance':'all4 full/block comparisons each scenario false<=c1, R10>=c1, detection>=c1-0.02; full calibration mean false<=0.9*c1 and each scene<=original calibration budget',
        'objective_changed_explicitly':'false reduction with protected R10/detection; does not satisfy or replace earlier +2pp R10 hypothesis',
        'undefined':'infeasible; no zero substitution',
        'on_failure':'keep all outcomes; do not change cutoff/score threshold/gate; no fresh station test',
        'on_pass':'freeze primary for possible later validation; no new station values in this pilot',
        'uncertainty':'2000 paired date draws seed20261015 on full14-day calibration; descriptive conditional intervals on reused data, not confirmatory',
        'optimizer_updates':0,'new_station_values_used':False,
        'source_and_input_sha256':{name:common.sha(ROOT/name) for name in names}}
    path=OUT/'plan.json'
    if path.exists():assert {k:v for k,v in common.read(path).items() if k!='frozen_at_utc'}==plan
    else:common.write(path,{**plan,'frozen_at_utc':datetime.now(timezone.utc).isoformat()})
    return plan


def paired_counts(candidate,reference,draws):
    result={}
    for key,cols,den in [('R10',[11,12],1),('detection',[3],1),('false_rate',[4],0)]:
        a=candidate.sum(axis=1);b=reference.sum(axis=1)
        ac=candidate[:,draws,:].sum(axis=2);bc=reference[:,draws,:].sum(axis=2)
        defined=bool(np.all(a[:,den]>0)&np.all(b[:,den]>0))
        invalid=np.any((ac[:,:,den]<=0)|(bc[:,:,den]<=0),axis=0)
        point=float(np.mean(a[:,cols].sum(axis=-1)/a[:,den]-b[:,cols].sum(axis=-1)/b[:,den])) if defined else None
        if defined and not invalid.any():
            v=(ac[:,:,cols].sum(axis=-1)/ac[:,:,den]-bc[:,:,cols].sum(axis=-1)/bc[:,:,den]).mean(axis=0)
            ci=np.quantile(v,[.025,.975]).tolist()
        else:ci=None
        result[key]={'difference':point,'ci95':ci,'undefined_draws':int(invalid.sum())}
    return result


def main():
    sys.addaudithook(common.guard)
    torch.set_num_threads(1);plan=freeze_plan()
    if (OUT/'completion.json').exists():
        for name,digest in common.read(OUT/'completion.json')['artifacts'].items():assert common.sha(OUT/name)==digest
        print('Completed pilot verified; no rerun');return
    norm=common.load(common.RISK/'normalization.npz');model=load_risk(common.RISK/'global_calibration.pt')
    cal=common.load(common.CAL/'calibration.npz');validation=common.load(common.RISK/'risk_validation.npz')
    blocks={'calibration_full14':cal,'risk_validation7':validation,
        'calibration_week1_7':common.subset(cal,0,7),'calibration_week2_7':common.subset(cal,7,14)}
    settings=common.read(common.CAL/'selection.json')
    original=settings['methods']['global_calibration']['fine']['selected']
    assert original['threshold']==.46 and original['confirmation']==1
    rows={};daily={};details={};activations={}
    for block,part in blocks.items():
        scores=common.global_scores(part,norm,model);rows[block]={};details[block]={}
        for method in ['global_c1','global_c2']+[f'residual_gt{int(v)}' for v in BOUNDS]:
            rows[block][method]={};details[block][method]={}
            for s in SCENARIOS:
                residual=common.causal_residual(part,s)
                raw=alarm(scores[s],.46,1,part)
                if method.startswith('global_'):active=alarm(scores[s],.46,int(method[-1]),part)
                else:active=adaptive_alarm(scores[s],residual,part['origins'],part['timestamps'],.46,float(method.rsplit('gt',1)[1]))
                row,days,_=replay(part,active,details=True)
                key=f'{block}__{method}__{s}'
                daily[key]=days;activations[key]=active
                records=common.episodes(part,active)
                assert sum(r['kind']=='false' for r in records)==row['false']
                rows[block][method][s]=row
                details[block][method][s]={'raw_positive_points_suppressed':int((raw&~active).sum()),
                    'false_episode_starts':int(row['false']),
                    'false_early_spanning_complete_window':sum(r['early_spanning_complete_window'] for r in records)}
        print(block+': '+str({m:common.mean_metrics(v) for m,v in rows[block].items()}),flush=True)
    means={b:{m:common.mean_metrics(v) for m,v in methods.items()} for b,methods in rows.items()}
    gates={}
    for method in [f'residual_gt{int(v)}' for v in BOUNDS]:
        checks={b:block_gate(methods[method],methods['global_c1']) for b,methods in rows.items()}
        ref=means['calibration_full14']['global_c1'];candidate=means['calibration_full14'][method]
        ten_percent=(candidate['false_per_valid_station_day'] is not None and ref['false_per_valid_station_day'] is not None
            and ref['false_per_valid_station_day']>0 and candidate['false_per_valid_station_day']<=.9*ref['false_per_valid_station_day']+1e-12)
        budget={s:rows['calibration_full14'][method][s]['false_per_valid_station_day']<=settings['budgets'][s]+1e-12 for s in SCENARIOS}
        gates[method]={'block_checks':checks,'full_calibration_false_reduction_at_least10pct':bool(ten_percent),
            'full_calibration_original_budget_met':budget,
            'all_conditions_passed':all(c['passed'] for c in checks.values()) and bool(ten_percent) and all(budget.values()),
            'sensitivity_only':method!=PRIMARY}
    dates=common.layout(cal)[2]
    draws=np.random.default_rng(20261015).integers(0,len(dates),(2000,len(dates)))
    ref=np.stack([daily[f'calibration_full14__global_c1__{s}'] for s in SCENARIOS])
    comparisons={m:paired_counts(np.stack([daily[f'calibration_full14__{m}__{s}'] for s in SCENARIOS]),ref,draws)
        for m in ['global_c2']+[f'residual_gt{int(v)}' for v in BOUNDS]}
    result={'stage':'adaptive_confirmation_development_pilot','primary_rule':PRIMARY,'evaluation':rows,'means':means,
        'gates':gates,'primary_acceptance_passed':gates[PRIMARY]['all_conditions_passed'],
        'comparisons_calibration_vs_global_c1':comparisons,'activation_diagnostics':details,
        'optimizer_updates':0,'new_station_cohort_consumed':False,'independent_confirmation':False,
        'previous_plus2pp_R10_hypothesis_passed_by_this_pilot':False,
        'original_thesis_primary_test_still_failed':True,
        'limitation':'All blocks previously reused; adaptively proposed rule. No independent improvement or field performance established.'}
    common.write(OUT/'results.json',result)
    common.write(OUT/'selection_freeze.json',{'frozen_at_utc':datetime.now(timezone.utc).isoformat(),
        'plan_sha256':common.sha(OUT/'plan.json'),'results_sha256':common.sha(OUT/'results.json'),
        'declared_primary':PRIMARY,'accepted_for_later_validation':bool(result['primary_acceptance_passed']),
        'sensitivity_winner_substitution':False,'new_station_values_read':False})
    np.savez_compressed(OUT/'daily.npz',**daily);np.savez_compressed(OUT/'activations.npz',**activations)
    np.savez_compressed(OUT/'bootstrap_draws.npz',draws=draws,dates=dates)
    common.write(OUT/'access_log.json',{'runtime_open_paths':sorted(set(common.READS)),
        'evaluation_and_raw_hdf5_guard_enabled':True,'evaluation_or_raw_hdf5_values_read':False})
    for name,digest in plan['source_and_input_sha256'].items():assert common.sha(ROOT/name)==digest,name
    names=['results.json','selection_freeze.json','daily.npz','activations.npz','bootstrap_draws.npz','access_log.json']
    common.write(OUT/'completion.json',{'completed_at_utc':datetime.now(timezone.utc).isoformat(),
        'plan_sha256':common.sha(OUT/'plan.json'),'artifacts':{name:common.sha(OUT/name) for name in names}})
    print({'primary':PRIMARY,'acceptance_passed':result['primary_acceptance_passed'],'gates':gates[PRIMARY]},flush=True)


if __name__=='__main__':main()
