"""Development-only full replay of an early-protected frozen-probe episode gate.

Primary: training-early-minimum cutoff plus observed-past-low bypass.
Three declared ablations; no swapping primary, no consumed transfer cache access.
"""
from __future__ import annotations
from datetime import datetime,timezone
from pathlib import Path
import sys
from unittest.mock import patch
import numpy as np
import torch
import alarm_start_separability as probe
import calibration_fragility as common
from congestion_alert_pilot import SCENARIOS
from pems_bay_alert_replay import alarm,replay,layout
from train_pems_bay_risk import load_risk
from adaptive_confirmation import block_gate,paired_counts

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs/early-warning-protection-2026-10-15'
PRIMARY='protected_gate'


def guard(event,args):
    common.guard(event,args)
    if event=='open' and isinstance(args[0],(str,bytes)):
        name=str(args[0]).replace('\\','/').lower()
        if '/outputs/frozen-probe-transfer-' in name:
            raise PermissionError('Early protection calibration cannot read consumed transfer outcomes')


def protected_cutoff(training,model,original_cutoff):
    p=probe.predict(model,training['x'])
    early=(training['y']==1)&(training['lead_minutes']>=10)
    if not early.any():raise ValueError('No original training early warning; plan infeasible, do not replace cutoff')
    cutoff=min(float(original_cutoff),float(p[early].min()))
    assert np.all(p[early]>=cutoff)
    return cutoff,{'training_rows':len(p),'training_original_R10_rows':int(early.sum()),
        'training_original_R15_rows':int(((training['y']==1)&(training['lead_minutes']==15)).sum()),
        'old_cutoff':float(original_cutoff),'minimum_training_R10_probability':float(p[early].min()),
        'protected_cutoff':cutoff,'all_original_training_R10_retained':True,
        'later_development_block_values_used':False}


def observed_past_low(part,scenario):
    """Three fresh available observations v(t-3),v(t-2),v(t-1), no targets."""
    x=part[scenario+'_state'];n=len(x)
    fresh=(x[:,:,12]>0)&(np.abs(x[:,:,13])<1e-6)
    low=fresh&(x[:,:,8]>0)&(x[:,:,8]<=np.float32(30/70))
    result=np.zeros(low.shape,bool)
    times=part['timestamps'][part['origins']]
    consecutive=(np.diff(part['origins'])==1)&(np.diff(times)==np.timedelta64(5,'m'))
    if n>=3:result[2:]=low[:-2]&low[1:-1]&low[2:]&consecutive[:-1,None]&consecutive[1:,None]
    return result


def episode_gate(scores,credibility,origins,timestamps,cutoff,bypass=None):
    """Decide once at each raw positive run; rejected runs never enter midway."""
    if scores.ndim!=2 or credibility.shape!=scores.shape or len(origins)!=len(scores):raise ValueError('Invalid shapes')
    if not np.isfinite(scores).all() or not np.isfinite(credibility).all() or not np.isfinite(cutoff):raise ValueError('Invalid values')
    if bypass is None:bypass=np.zeros_like(scores,bool)
    if bypass.shape!=scores.shape:raise ValueError('Invalid bypass shape')
    raw=scores>=.46;out=np.zeros_like(raw);previous=np.zeros(raw.shape[1],bool);allowed=previous.copy()
    times=timestamps[origins]
    for at in range(len(raw)):
        if at==0 or origins[at]-origins[at-1]!=1 or times[at]-times[at-1]!=np.timedelta64(5,'m'):
            previous[:]=False;allowed[:]=False
        start=raw[at]&~previous
        allowed=np.where(start,(credibility[at]>=cutoff)|bypass[at],allowed)
        allowed&=raw[at];out[at]=allowed;previous=raw[at].copy()
    return out


def protect_original_events(part,baseline,candidate):
    _,_,a=replay(part,baseline,details=True);_,_,b=replay(part,candidate,details=True)
    key=lambda r:(r['node'],r['event_start_origin'])
    first={key(r):r for r in a};second={key(r):r for r in b}
    assert first.keys()==second.keys()
    protected=[r for r in a if r['status']=='warned' and r['lead_minutes']>=10]
    lost=[]
    for before in protected:
        after=second[key(before)]
        if after['status']!='warned' or after['lead_minutes']<before['lead_minutes']:
            lost.append({'node':int(before['node']),'event_start_origin':int(before['event_start_origin']),
                'timestamp':before['timestamp'],'old_lead_minutes':before['lead_minutes'],
                'new_status':after['status'],'new_lead_minutes':after['lead_minutes']})
    return {'baseline_original_R10_events':len(protected),
        'baseline_original_R15_events':sum(r['lead_minutes']==15 for r in protected),
        'protected_events_lost_or_delayed':lost,'all_original_R10_events_and_leads_preserved':not lost}


def freeze_plan():
    OUT.mkdir(exist_ok=True)
    names=['early_warning_protection.py','alarm_start_separability.py','calibration_fragility.py',
        'adaptive_confirmation.py','pems_bay_alert_replay.py','congestion_alert_pilot.py',
        'congestion_risk_pilot.py','train_pems_bay_risk.py',
        'outputs/alarm-start-separability-2026-10-15/training_pooled_samples.npz',
        'outputs/alarm-start-separability-2026-10-15/state_logistic.npz',
        'outputs/alarm-start-separability-2026-10-15/training_freeze.json',
        'outputs/alarm-start-separability-2026-10-15/completion.json',
        'outputs/pems-bay-risk/global_calibration.pt','outputs/pems-bay-risk/normalization.npz',
        'outputs/pems-bay-risk/risk_validation.npz','outputs/pems-bay-calibration/calibration.npz',
        'outputs/pems-bay-calibration/selection.json']
    plan={'stage':'adaptive_original_development_full_episode_replay_with_early_protection',
        'prior_development_and_consumed_transfer_findings_informed_hypothesis':True,
        'independent_confirmation':False,'primary':PRIMARY,
        'fixed_predictors':'original global risk0.46/c1 and original30feature state_logistic; no refit',
        'cutoff_rule':'min(original training95%-any-warning cutoff, minimum frozen-model probability of every training credited R10 warning); training only, no grid',
        'bypass_rule':'at raw positive-run start allow if last3 cached fresh own observations<=30mph, each available/age0/positive, adjacent origins/clock; scale compare float32(30/70); first2 rows never bypass',
        'episode_rule':'at each original raw positive-run start retain whole run iff probe>=cutoff or bypass; otherwise reject whole run; never reconsider mid-run; gaps reset; no target eligibility in online input',
        'ablations':{'old_gate':'old cutoff/no bypass','early_cutoff_gate':'protected cutoff/no bypass','old_gate_observed_low':'old cutoff/observed-low bypass'},
        'primary_cannot_be_replaced_by_ablation':True,
        'allowed_data':'original training start samples to set cutoff; previously reused original risk_validation7 andcalibration14 for replay',
        'forbidden':'raw HDF5, original evaluation, consumed station/transfer caches/results, new cohort',
        'blocks':['calibration_full14','risk_validation7','calibration_week1_7','calibration_week2_7'],
        'full_replay':'all alert types incl late/duplicate/unknown/censored; no conditional-classification rejection as performance',
        'primary_gate':'each block each scenario false<=original_c1, R10>=original_c1, detection>=original_c1-0.02 AND each original R10 event retains its original proxy lead; full14 mean false reduction>=10% AND original per-scene calibration budgets',
        'new_objective_not_old_hypothesis':'false reduction with explicit original early-event preservation; does not pass original thesis primary or previous+2pp R10 question',
        'undefined':'report infeasible, no zero substitution; no training early examples =>stop',
        'on_failure':'no threshold/feature/bypass changes, no ablation substitution or consumed/fresh station replay',
        'on_pass':'freeze primary only as exploratory development candidate; no deployment or new station test this round',
        'uncertainty':'full14 2000 paired-calendar-date count bootstrap seed20261015 versus originalc1; reused-data conditional description only',
        'optimizer_updates':0,
        'source_and_input_sha256':{n:common.sha(ROOT/n) for n in names}}
    path=OUT/'plan.json'
    if path.exists():assert {k:v for k,v in common.read(path).items() if k!='frozen_at_utc'}==plan
    else:common.write(path,{**plan,'frozen_at_utc':datetime.now(timezone.utc).isoformat()})
    return plan


def main():
    sys.addaudithook(guard);torch.set_num_threads(1);plan=freeze_plan()
    if (OUT/'completion.json').exists():
        for n,h in common.read(OUT/'completion.json')['artifacts'].items():assert common.sha(OUT/n)==h
        print('Completed protected replay verified; no rerun');return
    previous=common.read(probe.OUT/'training_freeze.json');prior_done=common.read(probe.OUT/'completion.json')
    for name in ('state_logistic.npz','training_pooled_samples.npz'):
        assert common.sha(probe.OUT/name)==prior_done['artifacts'][name]
    model=common.load(probe.OUT/'state_logistic.npz');training=common.load(probe.OUT/'training_pooled_samples.npz')
    old=float(previous['cutoffs']['state_logistic'])
    cutoff,record=protected_cutoff(training,model,old)
    common.write(OUT/'parameter_freeze.json',{'frozen_at_utc':datetime.now(timezone.utc).isoformat(),
        'plan_sha256':common.sha(OUT/'plan.json'),'model_sha256':common.sha(probe.OUT/'state_logistic.npz'),
        'parameters':record,'later_block_values_loaded':False})
    print({'parameters_frozen':record},flush=True)
    norm=common.load(common.RISK/'normalization.npz');anchor=load_risk(common.RISK/'global_calibration.pt')
    val=common.load(common.RISK/'risk_validation.npz');cal=common.load(common.CAL/'calibration.npz')
    blocks={'calibration_full14':cal,'risk_validation7':val,
        'calibration_week1_7':common.subset(cal,0,7),'calibration_week2_7':common.subset(cal,7,14)}
    definitions={'old_gate':(old,False),'early_cutoff_gate':(cutoff,False),
        'old_gate_observed_low':(old,True),PRIMARY:(cutoff,True)}
    rows={};daily={};activations={};protection={};diagnostics={}
    with patch.object(probe,'fit_probe',side_effect=PermissionError('No model refit in protected replay')):
        for block,part in blocks.items():
            probabilities=common.global_scores(part,norm,anchor)
            rows[block]={m:{} for m in ['global_c1']+list(definitions)}
            protection[block]={m:{} for m in definitions};diagnostics[block]={}
            for s in SCENARIOS:
                credibility=probe.predict(model,probe.start_features(part,s,probabilities[s]).reshape(-1,30)).reshape(part['truth'].shape)
                observed=observed_past_low(part,s)
                baseline=alarm(probabilities[s],.46,1,part)
                choices={'global_c1':baseline,**{m:episode_gate(probabilities[s],credibility,part['origins'],part['timestamps'],t,observed if bypass else None) for m,(t,bypass) in definitions.items()}}
                for method,active in choices.items():
                    key=f'{block}__{method}__{s}'
                    rows[block][method][s],daily[key],_=replay(part,active,details=True)
                    activations[key]=active
                    if method!='global_c1':protection[block][method][s]=protect_original_events(part,baseline,active)
                diagnostics[block][s]={'observed_low_bypass_points':int(observed.sum()),
                    'baseline_positive_points':int(baseline.sum()),
                    'primary_positive_points':int(choices[PRIMARY].sum())}
            print(block+': '+str({m:common.mean_metrics(v) for m,v in rows[block].items()}),flush=True)
    original=common.read(common.CAL/'selection.json')
    means={b:{m:common.mean_metrics(v) for m,v in methods.items()} for b,methods in rows.items()}
    gates={}
    for method in definitions:
        checks={b:block_gate(methods[method],methods['global_c1']) for b,methods in rows.items()}
        early={b:all(r['all_original_R10_events_and_leads_preserved'] for r in v[method].values()) for b,v in protection.items()}
        a=means['calibration_full14'][method]['false_per_valid_station_day'];b=means['calibration_full14']['global_c1']['false_per_valid_station_day']
        ten=bool(a is not None and b is not None and b>0 and a<=.9*b+1e-12)
        budgets={s:rows['calibration_full14'][method][s]['false_per_valid_station_day']<=original['budgets'][s]+1e-12 for s in SCENARIOS}
        gates[method]={'service_block_checks':checks,'original_early_event_identity_and_lead_preserved':early,
            'full14_false_reduction_at_least10pct':ten,'full14_original_budget_met':budgets,
            'passed':all(v['passed'] for v in checks.values()) and all(early.values()) and ten and all(budgets.values()),
            'ablation_only':method!=PRIMARY}
    dates=layout(cal)[2];draws=np.random.default_rng(20261015).integers(0,len(dates),(2000,len(dates)))
    baseline=np.stack([daily[f'calibration_full14__global_c1__{s}'] for s in SCENARIOS])
    comparisons={m:paired_counts(np.stack([daily[f'calibration_full14__{m}__{s}'] for s in SCENARIOS]),baseline,draws) for m in definitions}
    result={'stage':'early_protected_episode_gate_original_development_full_replay','primary':PRIMARY,
        'parameters':record,'evaluation':rows,'means':means,'gates':gates,
        'original_early_event_checks':protection,'activation_diagnostics':diagnostics,
        'paired_calibration_comparisons':comparisons,'primary_acceptance_passed':gates[PRIMARY]['passed'],
        'candidate_only_not_deployment':True,'independent_confirmation':False,'optimizer_updates':0,
        'original_thesis_primary_test_still_failed':True,'new_station_cohort_consumed':False,
        'consumed_transfer_values_used_in_this_run':False,
        'limitation':'Adaptive candidate motivated partly by previously seen transfer failure; setting uses training only, replay uses previously reused original development. No unseen validation or field guarantee.'}
    common.write(OUT/'results.json',result)
    np.savez_compressed(OUT/'daily.npz',**daily);np.savez_compressed(OUT/'activations.npz',**activations)
    np.savez_compressed(OUT/'bootstrap_draws.npz',draws=draws,dates=dates)
    common.write(OUT/'selection_freeze.json',{'frozen_at_utc':datetime.now(timezone.utc).isoformat(),
        'plan_sha256':common.sha(OUT/'plan.json'),'parameter_freeze_sha256':common.sha(OUT/'parameter_freeze.json'),
        'results_sha256':common.sha(OUT/'results.json'),'declared_primary':PRIMARY,
        'accepted_for_future_validation':bool(result['primary_acceptance_passed']),
        'ablation_substitution':False,'new_or_consumed_station_values_read':False})
    for n,h in plan['source_and_input_sha256'].items():assert common.sha(ROOT/n)==h,n
    common.write(OUT/'access_log.json',{'runtime_open_paths':sorted(set(common.READS)),
        'raw_and_evaluation_and_consumed_transfer_guard_enabled':True,
        'raw_or_original_evaluation_or_transfer_values_used':False})
    names=['parameter_freeze.json','results.json','daily.npz','activations.npz','bootstrap_draws.npz','selection_freeze.json','access_log.json']
    common.write(OUT/'completion.json',{'completed_at_utc':datetime.now(timezone.utc).isoformat(),
        'plan_sha256':common.sha(OUT/'plan.json'),'artifacts':{n:common.sha(OUT/n) for n in names}})
    print({'primary_acceptance_passed':result['primary_acceptance_passed'],'primary_gate':gates[PRIMARY]},flush=True)


if __name__=='__main__':main()
