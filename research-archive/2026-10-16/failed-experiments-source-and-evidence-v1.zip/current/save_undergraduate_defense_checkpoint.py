"""Save cumulative writing and teaching materials without replacing old archives."""
from __future__ import annotations
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
import build_undergraduate_defense as builder

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'outputs/undergraduate-defense'
CHECKPOINTS = ROOT.parent / 'checkpoints'
NAME = 'traffic-recovery-lab-2026-10-13-undergraduate-defense'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def main():
    for name, content in builder.build().items():
        assert (ROOT / name).read_bytes() == content, name
    archive = CHECKPOINTS / (NAME + '.zip')
    receipt_path = CHECKPOINTS / (NAME + '-save-receipt.json')
    if archive.exists() or receipt_path.exists():
        raise FileExistsError('Keep old archives; choose a new name.')
    prior_path = 'outputs/thesis-word-references-2026-10-13/writing_archive_manifest.json'
    previous = read(ROOT / prior_path)
    for p, item in previous['files'].items():
        if p not in {'README.md', 'CURRENT_STATE.zh-CN.md'}:
            assert sha(ROOT / p) == item['sha256'], p
    additions = {
        prior_path, 'undergraduate_torch_demo.py', 'build_undergraduate_defense.py',
        'save_undergraduate_defense_checkpoint.py', 'docs/undergraduate_defense_handoff.zh-CN.md',
        'docs/undergraduate_defense_notes.template.zh-CN.md', 'docs/undergraduate_defense_notes.zh-CN.md',
        'docs/undergraduate_pytorch_learning.template.zh-CN.md', 'docs/undergraduate_pytorch_learning.zh-CN.md',
        'docs/undergraduate_pytorch_sources.json',
        *['outputs/undergraduate-defense/' + p for p in
          ('torch_demo.json', 'key_facts.json', 'code_anchors.json', 'documentation_manifest.json')],
    }
    files = set(previous['files']) | additions
    base_receipt_path = CHECKPOINTS / 'traffic-recovery-lab-2026-10-11-event-timeline-save-receipt.json'
    base_receipt = read(base_receipt_path)
    base = Path(base_receipt['full_archive'])
    assert base.stat().st_size == base_receipt['full_archive_bytes']
    assert base_receipt['archive_crc_and_all_sha256_verified']
    with ZipFile(base) as z:
        available = {p.removeprefix('traffic-recovery-lab/') for p in z.namelist()} | files
        for p in files:
            if p.endswith('/documentation_manifest.json'):
                sources = read(ROOT / p).get('source_sha256', {})
                if isinstance(sources, dict):
                    assert all(s in available for s in sources), p
        # The new lesson's small research source records and code come from the full base.
        small_base_sources = []
        for p, digest in read(OUT / 'documentation_manifest.json')['source_sha256'].items():
            if p not in files:
                assert hashlib.sha256(z.read('traffic-recovery-lab/' + p)).hexdigest() == digest, p
                small_base_sources.append(p)
    manifest_path = OUT / 'writing_archive_manifest.json'
    dump(manifest_path, {
        'stage': 'cumulative_undergraduate_defense_and_pytorch_materials', 'client_date': '2026-10-13',
        'archive_name': archive.name, 'scope': 'Restore October 11 full base, then this cumulative writing supplement.',
        'base_archive': {'name': base.name, 'sha256_from_prior_verified_receipt': base_receipt['full_archive_sha256'],
                         'prior_verified_at_utc': base_receipt['saved_at_utc'], 'full_crc_rechecked_this_turn': False},
        'files': {p: {'bytes': (ROOT / p).stat().st_size, 'sha256': sha(ROOT / p)} for p in sorted(files)},
        'lesson_small_base_sources_sha256_rechecked': sorted(small_base_sources),
        'two_archive_documentation_dependencies_present': True, 'word_updated': False,
        'traffic_speed_values_decoded': False, 'research_weights_changed': False,
        'synthetic_optimizer_updates': 0, 'primary_metric_supported': False, 'github_uploaded': False,
    })
    files.add(manifest_path.relative_to(ROOT).as_posix())
    with ZipFile(archive, 'x', compression=ZIP_DEFLATED, compresslevel=6) as z:
        for p in sorted(files):
            z.write(ROOT / p, 'traffic-recovery-lab/' + p)
    with ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist()) == len(files)
        for p in files:
            assert z.read('traffic-recovery-lab/' + p) == (ROOT / p).read_bytes(), p
    receipt = {
        'saved_at_utc': datetime.now(timezone.utc).isoformat(),
        'stage': 'cumulative_undergraduate_defense_and_pytorch_materials',
        'archive': str(archive), 'archive_bytes': archive.stat().st_size, 'archive_sha256': sha(archive),
        'archived_files': len(files), 'archive_crc_and_all_file_bytes_verified': True,
        'two_archive_documentation_dependencies_present': True, 'full_base_reverified_this_turn': False,
        'full_base_prior_receipt': str(base_receipt_path), 'manifest': str(manifest_path),
        'word_updated': False, 'synthetic_optimizer_updates': 0, 'primary_metric_supported': False,
        'github_uploaded': False,
    }
    dump(receipt_path, receipt)
    print(json.dumps(receipt, ensure_ascii=True))


if __name__ == '__main__':
    main()
