"""Cumulative archive of the effective-alert label expansion pilot."""
from datetime import datetime,timezone
from pathlib import Path
import hashlib
from zipfile import ZipFile,ZIP_DEFLATED
from save_station_agnostic_checkpoint import read,write,sha

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs/effective-alert-pilot-2026-10-16'
NAME='traffic-recovery-lab-2026-10-16-effective-alert-pilot'


def main():
    archive=ROOT.parent/'checkpoints'/(NAME+'.zip');receipt=archive.with_name(NAME+'-save-receipt.json')
    if archive.exists() or receipt.exists():raise FileExistsError('Preserve existing archives')
    r=read(OUT/'results.json');audit=read(OUT/'audit.json');tests=read(OUT/'test_receipt.json')
    assert audit['passed'] and tests['passed'] and tests['tests_run']==7
    assert sha(ROOT/'tests/test_effective_alert_pilot.py')==tests['test_source_sha256']
    assert not r['primary_acceptance_passed'] and not r['new_station_cohort_consumed']
    assert not r['consumed_transfer_values_used_in_this_run'] and not r['deep_predictors_refit']
    assert r['new_linear_models_fitted']==1 and not read(OUT/'selection_freeze.json')['comparator_substitution']
    for name,digest in read(OUT/'completion.json')['artifacts'].items():assert sha(OUT/name)==digest
    prior_path='outputs/early-warning-protection-2026-10-15/writing_archive_manifest.json';prior=read(ROOT/prior_path)
    for name,meta in prior['files'].items():assert sha(ROOT/name)==meta['sha256'],name
    summary=('原训练28日纳入迟報正例，800条情景记录拟合一个31参数有效告警模型，原归一化/深度前端固定。'
        '14日校准检出由上轮81.64%恢复至85.99%（原全局87.44%），原R10身份与提前量保持；'
        '误報0.084619→0.079642，仅降5.88%，短块仍超检出保护线，主方案未通过。')
    marker='# 最新检查点：补齐迟報训练后仍未过门槛（2026-10-16）'
    p=ROOT/'CURRENT_STATE.zh-CN.md';old=p.read_text(encoding='utf-8');assert marker not in old
    p.write_text(marker+'\n\n- '+summary+'\n'
        '- 新训练800行=147预警+350迟報+303误報，497有效正例、298不同node/origin键，三情景不独立。L2=0.1固定，原训练均值尺度不改，无验证选模型。\n'
        '- 模型与训练专用分界线0.4388462326封存后才加载后续开发块。主方案保留原低速豁免；无豁免对照虽校准误報降11.76%，验证各情景丢1条原R10，未替换主方案。\n'
        '- 校准原迟報新增漏检由每情景4减至1；前校准周每情景少1/37=2.70pp，验证自然少2/55=3.64pp，均超2pp。所有本轮原获记预警/R10身份与提前量保持，但这些块已反复用于开发。\n'
        '- 7项测试、800训练记录/梯度/阈值核查、36过滤激活独立重建、48完整回放/逐事件保护及配对统计通过。\n'
        '- 没有使用原评测、迁移缓存、HDF5或新站点；原论文主检验与历史失败保留，Word/PPT与GitHub v7未改。真实模型和明细仅本地。\n'
        '- 报告outputs/effective-alert-pilot-2026-10-16/report.zh-CN.md；接续docs/effective_alert_pilot_handoff.zh-CN.md。下一轮先固定本模型/阈值，诊断低速豁免保护的真预警和保留的误報。\n'
        '- 最新累计包2026-10-16-effective-alert-pilot，恢复先10月11日完整基包再本累计包。\n\n以下为之前阶段记录。\n\n'+old,encoding='utf-8')
    p=ROOT/'README.md';old=p.read_text(encoding='utf-8')
    p.write_text('# 最新研究：有效告警目标部分恢复检出，联合门槛仍未过\n\n'
        '[完整报告](outputs/effective-alert-pilot-2026-10-16/report.zh-CN.md) · [接续说明](docs/effective_alert_pilot_handoff.zh-CN.md)\n\n'
        +summary+' 仅重复使用的原开发检查，未更新线上规则。最新累计包为2026-10-16-effective-alert-pilot。\n\n以下为之前阶段记录。\n\n'+old,encoding='utf-8')
    files=set(prior['files'])|{prior_path,'effective_alert_pilot.py','audit_effective_alert_pilot.py',
        'summarize_effective_alert_pilot.py','save_effective_alert_pilot_checkpoint.py',
        'tests/test_effective_alert_pilot.py','docs/effective_alert_pilot_handoff.zh-CN.md'}
    files|={p.relative_to(ROOT).as_posix() for p in OUT.rglob('*') if p.is_file() and p.name!='writing_archive_manifest.json'}
    base_path=ROOT.parent/'checkpoints/traffic-recovery-lab-2026-10-11-event-timeline-save-receipt.json';base=read(base_path)
    assert Path(base['full_archive']).stat().st_size==base['full_archive_bytes'] and base['archive_crc_and_all_sha256_verified']
    manifest=OUT/'writing_archive_manifest.json'
    write(manifest,{'client_date':'2026-10-16','stage':'cumulative_effective_alert_label_expansion_failed_gate',
        'archive_name':archive.name,'restore':'October11 full base, then this supplement',
        'primary_acceptance_passed':False,'new_station_cohort_consumed':False,'consumed_transfer_values_loaded':False,
        'new_linear_models_fitted':1,'parameters':31,'old_normalization_reused':True,'deep_predictors_refit':False,
        'unit_tests_observed_passed':7,'training_rows':800,'training_effective_positives':497,'unique_node_origin_pairs':298,
        'all36_gated_activations_reconstructed':True,'all48_operating_replays_checked':True,
        'prior_files_changed':['README.md','CURRENT_STATE.zh-CN.md'],
        'original_thesis_primary_test_still_failed':True,
        'public_commit_unchanged':'ab8760a3e6ea1784fea3195a0e7aadbaff6fe80d',
        'base_crc_rechecked_this_turn':False,'base_sha256_from_prior_verified_receipt':base['full_archive_sha256'],
        'files':{n:{'bytes':(ROOT/n).stat().st_size,'sha256':sha(ROOT/n)} for n in sorted(files)}})
    files.add(manifest.relative_to(ROOT).as_posix())
    with ZipFile(archive,'x',compression=ZIP_DEFLATED) as z:
        for n in sorted(files):z.write(ROOT/n,'traffic-recovery-lab/'+n)
    with ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist())==len(files)
        for n in sorted(files):
            data=z.read('traffic-recovery-lab/'+n)
            assert data==(ROOT/n).read_bytes() and hashlib.sha256(data).hexdigest()==sha(ROOT/n)
    proof={'saved_at_utc':datetime.now(timezone.utc).isoformat(),'client_date':'2026-10-16',
        'archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'files':len(files),
        'crc_and_all_file_bytes_and_sha256_verified':True,'primary_acceptance_passed':False,
        'new_station_cohort_consumed':False,'new_linear_models_fitted':1,
        'original_thesis_primary_test_still_failed':True,'public_version_unchanged':True,
        'base_prior_verified_receipt':str(base_path),'base_crc_rechecked_this_turn':False}
    write(receipt,proof);print(proof)


if __name__=='__main__':main()
