"""Post-run diagnostic of detection loss alongside warning/false-alert gains."""
import json
import numpy as np
from recovery_pilot import ROOT, write_json
from congestion_alert_pilot import SCENARIOS

out = ROOT/'outputs/congestion-risk-solver-audit'
result = json.loads((out/'results.json').read_text(encoding='utf-8'))
rng = np.random.default_rng(6110)
with np.load(out/'daily_metrics.npz') as saved:
    reference = result['reference']
    a = np.stack([saved[f'{reference}_{s}'] for s in SCENARIOS])
    b = np.stack([saved[f'risk_mlp_{s}'] for s in SCENARIOS])
    draws = rng.integers(0, a.shape[1], size=(2000, a.shape[1]))
    ar, br = a[:, draws].sum(axis=2), b[:, draws].sum(axis=2)
    detection_delta = (br[:, :, 3]/np.maximum(br[:, :, 1], 1)-ar[:, :, 3]/np.maximum(ar[:, :, 1], 1)).mean(axis=0)
    old_false = (ar[:, :, 4]/ar[:, :, 0]).mean(axis=0)
    new_false = (br[:, :, 4]/br[:, :, 0]).mean(axis=0)
    relative_false = 1-new_false/old_false

def mean_metric(method, key):
    return float(np.mean([result['evaluation'][method][s][key] for s in SCENARIOS]))

diagnostic = {'post_run_descriptive': True, 'reference': reference, 'candidate': 'risk_mlp',
    'mean_reference_warning_recall': mean_metric(reference, 'warning_recall'),
    'mean_candidate_warning_recall': mean_metric('risk_mlp', 'warning_recall'),
    'mean_reference_detection_recall': mean_metric(reference, 'detection_recall'),
    'mean_candidate_detection_recall': mean_metric('risk_mlp', 'detection_recall'),
    'mean_detection_recall_difference': mean_metric('risk_mlp', 'detection_recall')-mean_metric(reference, 'detection_recall'),
    'mean_detection_recall_difference_ci': np.quantile(detection_delta, [.025, .975]).tolist(),
    'mean_reference_false_per_valid_station_day': mean_metric(reference, 'false_per_valid_station_day'),
    'mean_candidate_false_per_valid_station_day': mean_metric('risk_mlp', 'false_per_valid_station_day'),
    'relative_mean_false_reduction': 1-mean_metric('risk_mlp', 'false_per_valid_station_day')/mean_metric(reference, 'false_per_valid_station_day'),
    'relative_mean_false_reduction_ci': np.quantile(relative_false, [.025, .975]).tolist(),
    'additional_missed_events_by_scenario': {s: result['evaluation']['risk_mlp'][s]['missed_events']-result['evaluation'][reference][s]['missed_events'] for s in SCENARIOS},
    'mean_successful_warning_lead_reference': mean_metric(reference, 'warning_lead_mean_minutes'),
    'mean_successful_warning_lead_candidate': mean_metric('risk_mlp', 'warning_lead_mean_minutes'),
    'note': 'Warning lead averages condition on different detected subsets; no causal lead-time estimate. Same analysed dates; no external validation.'}
write_json(out/'tradeoff_diagnostic.json', diagnostic)
print(json.dumps(diagnostic, indent=2))
