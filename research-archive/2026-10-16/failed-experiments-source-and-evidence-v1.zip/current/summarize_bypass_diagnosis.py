"""Report the frozen bypass diagnosis, with corrected context units."""
from datetime import datetime,timezone
import numpy as np
import bypass_diagnosis as pilot
import calibration_fragility as common
from congestion_alert_pilot import SCENARIOS


def main():
    out=pilot.OUT;root=pilot.ROOT;r=common.read(out/'audited_results.json');audit=common.read(out/'audit.json')
    assert audit['passed'] and audit['audited_results_sha256']==common.sha(out/'audited_results.json')
    common.write(out/'test_receipt.json',{'recorded_at_utc':datetime.now(timezone.utc).isoformat(),
        'tests_run':8,'passed':True,'observed_exit_code':0,
        'basis':'Observed successful 8-test tool execution after JSON/unit fixes; report does not rerun tests',
        'command':'.venv/Scripts/python.exe -m unittest discover -s tests -p test_bypass_diagnosis.py -v',
        'test_source_sha256':common.sha(root/'tests/test_bypass_diagnosis.py')})
    labels={'training28':'训练28日（已参与拟合）','risk_validation7':'验证7日（已复用开发）',
        'calibration_full14':'校准14日（已复用开发）','calibration_week1_7':'校准前7日','calibration_week2_7':'校准后7日'}
    scenes={'natural':'自然','single_outage':'单站缺失','group_outage':'成组缺失'}
    lines=['# 低速豁免诊断：保护一个早预警，也留下额外误报','',
        '日期：2026-10-16。**豁免不能直接删除，也未证明怎样收紧才安全。验证7日各情景恢复同一个原15分钟代理预警，同时分别多留3、4、3次误报；校准14日分别多留2、2、1次误报，没有增加检出。**','',
        '## 本轮固定了什么','',
        f"沿用上一轮有效告警模型（31参数）及训练专用分界线{r['fixed_cutoff']:.15f}；原PyTorch深度预测前端、全局风险头、归一化均不重训。本轮零优化更新，零新模型，零新候选策略。",'',
        '原全局风险≥0.46的连续阳性段起点只判断一次。若有效告警得分足够，或最近三条新鲜车速观测均≤30 mph，则放行整个原阳性段；拒绝后不中途恢复。本轮只比较启用/禁用原低速豁免，保持所有其他部分一致。','',
        '诊断计划在解码缓存前封存：过去一步预测残差分为缺失、<-5、[-5,0)、[0,5]、>5 mph；三个未来预测是否都≤30 mph；距离固定有效分界线是否≤0.05。区间只作预定描述，没有依据结果搜索新阈值、拟合分类器或选择最好的分组。','',
        '在线可用信息取实际原风险段起点：三条已有观测、历史统计、模型预测、邻站/网络可用率、过去一步可观测残差和两个模型分数。未来真值、获记类型、真实/代理提前量、告警随后持续时间仅作离线评价，不进入任何决策。','',
        '## 豁免单独放行了什么','',
        '下表是启用豁免相对禁用豁免的额外记录。新增原风险段与评分器的有效片段分开记录，避免把缺测边界后的片段当作当时重新作出的决策。预警、迟报、误报、重复、删失、不可判断类型全部保留。','',
        '| 范围 | 情景 | 额外原风险段 | 预警 | 迟报 | 误报 | 重复 | 恢复原R10身份及原提前量 | 新增检出事件 |',
        '| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
    for block,ss in r['blocks'].items():
        for s,d in ss.items():
            v=d['summary'];k=v['added_scored_fragment_types']
            lines.append(f"| {labels[block]} | {scenes[s]} | {v['added_raw_runs']} | {k['warned']} | {k['late']} | {k['false']} | {k['duplicate']} | {v['restored_original_R10']} | {v['recovered_detections']} |")
    lines+=['',
        '本次额外段没有删失/不可判断片段。训练段额外检出的是各情景3个迟报；没有豁免独有的提前预警。这里不能说训练数据没有预警：模型训练本来含147条预警情景记录，只是固定分界线已保留训练早期记录。','',
        '验证三种情景救回的是同一个(node=12, event_start_origin=508)事件：原告警起点origin=506，2017-03-20 18:10，评分器记为15分钟代理预警。自然情景从漏检恢复；另两情景还出现其他匹配字段变化，全部逐事件存档，不能把发生字段变化都说成额外检出。','',
        '三种情景共用事件和时段；14日与其两个7日子块重叠。不能把三条预警情景记录或子块计数加成更多独立事件。重复告警不计误报，但仍是额外告警负担；豁免在验证共放行25条、校准共放行27条重复情景记录。','',
        '## 误报代价与保护收益','',
        '| 范围 | 豁免带来的三情景平均检出变化 | 平均R10变化 | 误报/有效站日：无→有豁免 |',
        '| --- | ---: | ---: | ---: |']
    for block in ('risk_validation7','calibration_full14'):
        ds=r['blocks'][block];summ=[d['summary'] for d in ds.values()]
        no=np.mean([d['operating']['effective_no_bypass']['false_per_valid_station_day'] for d in ds.values()])
        yes=np.mean([d['operating']['effective_protected_gate']['false_per_valid_station_day'] for d in ds.values()])
        lines.append(f"| {labels[block]} | {100*np.mean([s['detection_increase'] for s in summ]):+.2f}个百分点 | {100*np.mean([s['R10_increase'] for s in summ]):+.2f}个百分点 | {no:.6f}→{yes:.6f} |")
    lines+=['',
        '因此上一轮无豁免对照在校准14日误报减少11.76%，但原豁免主方案只有5.88%；无豁免在验证丢失原早预警。不能只挑校准段删除豁免，也不能为保护一个事件而声称豁免没有代价。上一轮主方案的联合验收仍失败，本轮没有重新验收或改变失败结论。','',
        '## 起点信息是否容易区分','',
        '为避免用相关三情景重复加强证据，下表仅列自然情景的获记预警/误报。节点只是本地数组编号，无地理含义。标准差已按原特征源码的/20尺度恢复；车速水平按/70恢复。','',
        '| 时段/类型 | 节点 | 最近三观测 mph | 有效告警得分 | 过去残差 mph | 15分钟预测 mph | 邻站末值 mph |',
        '| --- | ---: | --- | ---: | ---: | ---: | ---: |']
    cases=[]
    for block in ('risk_validation7','calibration_full14'):
        for e in r['blocks'][block]['natural']['added_runs']:
            kinds=[f['kind'] for f in e['scored_fragments']]
            if not any(k in ('warned','false') for k in kinds):continue
            c=e['context'];kind='代理预警' if 'warned' in kinds else '误报';cases.append((block,e,kind))
            lines.append(f"| {e['timestamp'][:16].replace('T',' ')} / {kind} | {e['node']} | {' / '.join(f'{v:.1f}' for v in c['observed_last3_mph'])} | {c['effective_probability']:.4f} | {c['past_residual_mph']:.2f} | {c['forecast15_mph']:.2f} | {c['neighbor_last_mph']:.2f} |")
    lines+=['',
        '三个预定简单方向没有给出干净的分离：','',
        '- 所有验证/完整校准额外段的三个预测都≤30 mph，单凭“预测持续低速”无法区分这些预警、误报或重复。',
        '- 自然验证保护的预警过去残差2.06 mph，误报中也有2.73、3.27 mph；校准误报为1.81、2.64 mph，落在同一预定[0,5]区间。>5区间只有验证的一条额外误报，不能据此解释其余误报或宣布新规则成功。',
        '- 保护的自然预警得分仅0.2383，低于自然验证三个误报（0.2890、0.3966、0.4370）和校准两个误报（0.2607、0.3779）。若只给豁免加一个“得分必须更高”的下限，要保留这条预警，就会保留这里全部五条误报。这是这些固定样本内的排序事实，不是证明所有多特征方法都做不到。','',
        '邻站末值在自然情景两个校准误报中约62.5 mph，保护预警约31.9 mph；但验证另有误报约33.0 mph，接近该预警。样本极少且这些数据反复用于开发，不能据此拼一个阈值宣称泛化。趋势、邻站和不确定性明细已保存，未搜索组合。','',
        '## 提前量的实际含义','',
        '被保护预警作出时，最近三条真实已有观测已是26.8、27.2、26.5 mph，均属低速。因此“15分钟代理预警”指针对未来三次低速标签组成的代理事件的记分提前量，并不证明早于现实拥堵首次发生15分钟。论文和展示需要保留这个定义，不能把该例包装成真正未拥堵时提前预知。','',
        '## 核查、保存与下一轮边界','',
        '8项针对性测试通过，覆盖真假告警/原提前量恢复、时钟断点、禁止段内重启、有效片段与决策起点区分、未来真值/身份不入上下文、分箱边界、数字序列化和标准差单位。另一实现独立核对15个情景块、45次完整回放、196次额外段决策和1173条事件记录；其中14条匹配记录变化。累计数含相关情景、重叠子块及训练段，不作为独立样本量。四个后续开发块的36组原激活逐位复现。','',
        '透明记录两次工程修正：首次结果写出因NumPy整数的JSON转换失败；用单独包装器转换数字，原冻结源码/计划不改。核查发现上下文明细的两项标准差错误乘了70；另存按原源码应乘20的audited_results与修正记录，原results不覆盖。两项修正未改变模型输入、得分、策略、分箱、计数或结论；本报告使用核查后的单位。','',
        '主实验的plan、模型、参数、原论文失败记录与历史资料不覆盖。当前仅开发诊断，未使用原评测、已消耗跨站缓存、新站或原HDF5；线上GitHub v7、Word/PPT不变。','',
        '下一轮优先核对代理事件为何在已经低速后仍出现“新事件/早预警”，检视这种标签分段及重复告警对结论的影响。若再设计状态条件豁免，应另外预先冻结单一方案及完整回放要求，不能从本轮样本直接挑阈值；独立确认仍需另行安排。本轮这两项均尚未执行。','']
    (out/'report.zh-CN.md').write_text('\n'.join(lines),encoding='utf-8')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(1,2,figsize=(12.6,5.1),facecolor='#f5f8fa')
    categories=[('risk_validation7',s) for s in SCENARIOS]+[('calibration_full14',s) for s in SCENARIOS]
    bottom=np.zeros(6)
    for kind,color,label in [('warned','#167c80','Credited warning'),('false','#ba5353','False'),('duplicate','#98a7b6','Duplicate')]:
        values=np.array([r['blocks'][b][s]['summary']['added_scored_fragment_types'][kind] for b,s in categories])
        axes[0].bar(np.arange(6),values,bottom=bottom,label=label,color=color)
        bottom+=values
    axes[0].set_xticks(range(6),['Val / natural','Val / single','Val / group','Cal / natural','Cal / single','Cal / group'],rotation=25,ha='right',fontsize=8)
    axes[0].set_ylabel('Additional scored episodes');axes[0].set_title('Fixed bypass: benefits and additional burden',fontsize=11)
    axes[0].legend(fontsize=8)
    for block,e,kind in cases:
        c=e['context'];warn=kind=='代理预警'
        axes[1].scatter(c['effective_probability'],c['past_residual_mph'],s=95 if warn else 60,
            marker='*' if warn else 'o',color='#167c80' if warn else '#ba5353',edgecolors='white',zorder=3)
        if warn:axes[1].annotate('Recovered proxy R15\nONE shared event',xy=(c['effective_probability'],c['past_residual_mph']),
            xytext=(.23,4.4),fontsize=9,arrowprops={'arrowstyle':'->','color':'#167c80'})
    axes[1].axvline(r['fixed_cutoff'],ls='--',color='#677889',label='Fixed cutoff',lw=1)
    axes[1].set_xlabel('Frozen effective-alert probability');axes[1].set_ylabel('Past observed forecast residual (mph)')
    axes[1].set_title('Natural scenarios: 1 warning and 5 false starts',fontsize=11)
    axes[1].set_xlim(.21,.47);axes[1].set_ylim(0,8);axes[1].legend(fontsize=8,loc='upper left')
    for ax in axes:ax.spines[['top','right']].set_visible(False)
    fig.suptitle('Observed-low bypass diagnosis / fixed model and cutoff / development data only',fontsize=12)
    fig.text(.5,.02,'Related scenarios are not independent. Proxy lead does not establish real congestion onset. No policy changed.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.06,1,.92));fig.savefig(out/'comparison.png',dpi=150);plt.close(fig)
    (root/'docs/bypass_diagnosis_handoff.zh-CN.md').write_text('''# 接续：固定低速豁免诊断（2026-10-16）

用户要求“下一轮”；本轮固定上一轮有效告警模型和分界线，诊断低速豁免，已完成并保存。没有新模型、策略、阈值或站点验证。主论文本科，题目《面向观测缺失的交通拥堵告警风险校准与事件级决策方法研究》，原主检验仍失败。

验证7日每情景救回同一个原15分钟代理预警（node12, event_origin508, alarm_origin506），各多3/4/3误报及9/9/7重复；校准14日各多2/2/1误报和10/9/8重复，检出与R10未增加。三情景不能当三个独立事件，两个7日校准半块不能和14日加总。

报告outputs/bypass-diagnosis-2026-10-16/report.zh-CN.md，正式核查后明细audited_results.json。源results保留两个上下文标准差单位错误（应/20恢复，原错误用70），context_unit_corrections.json透明列出，两字段不进入策略或分箱，其他结果相同。初次JSON写出失败、包装器修复也已记录。原冻结bypass_diagnosis.py与plan未覆盖。8测试和15情景块45回放独立核查通过；196段与1173事件记录含训练及重叠/相关情景，不作独立样本。

预定简单分箱未分离：额外后续段三个预测均≤30；残差多在[0,5]。自然保护预警分0.2383，低于五条后续误报的分数，简单高分下限不能同时保它并删除这五条误报。多特征是否有效未检验，没有新方法通过验收。

关键语义：该预警当时已有26.8/27.2/26.5mph三条低速观测；“15分钟”是未来三低速标签事件的代理提前量，不等于实际拥堵开始前15分钟。

下一轮建议：先固定模型/规则，核查代理标签怎样产生分段、新事件和重复，尤其已经低速后的代理预警，完整记录各种边界/匹配语义；不能直接试阈值拼出新豁免。任何新候选另冻结且完整回放。仍只能读原开发缓存，不读原评测、已消耗跨站/迁移、新站或HDF5。下一步标签语义诊断尚未做。

GitHub v7、Word/PPT不变；真实缓存/权重/明细仅本地。模型outputs/effective-alert-pilot-2026-10-16/effective_model.npz SHA1bea8ed689c6ac23dbcdec44212aed4bb3402ebb26a5f73f95aca7b92f9e6f21；固定分界线0.4388462325645476。

恢复：先10月11日完整基包，再traffic-recovery-lab-2026-10-16-bypass-diagnosis累计包。旧包与失败记录保留；基包完整CRC没有本轮重查，依赖既有已验证回执。
''',encoding='utf-8')
    print({'report':str(out/'report.zh-CN.md'),'test_count':8,'new_models':0,'policy_modified':False})


if __name__=='__main__':main()
