"""Recompute frozen alert choices/statistics and check sampled cached forecasts."""
from __future__ import annotations

import json
import h5py
import numpy as np
import torch

from recovery_pilot import ROOT, write_json
from state_value_pilot import read_data
from fresh_holdout_pilot import MaskedGraphTCN
from multifault_pilot import sha256
from congestion_alert_pilot import (evaluate, select, outage_mask, labels, semantic_checks,
                                    point_stats, paired_ci, REFERENCE, SCENARIOS)


def compare(a, b):
    if isinstance(a, dict):
        assert a.keys() == b.keys()
        for k in a:
            compare(a[k], b[k])
    elif isinstance(a, (list, tuple)):
        assert len(a) == len(b)
        for x, y in zip(a, b):
            compare(x, y)
    elif isinstance(a, (int, float)):
        assert np.isclose(a, b, rtol=1e-11, atol=1e-11), (a, b)
    else:
        assert a == b, (a, b)


def main():
    torch.set_num_threads(1)
    output = ROOT/'outputs/congestion-alert-pilot-v2'
    config = json.loads((output/'config.json').read_text(encoding='utf-8'))
    result = json.loads((output/'results.json').read_text(encoding='utf-8'))
    audit = json.loads((output/'audit.json').read_text(encoding='utf-8'))
    assert all(sha256(ROOT/k) == v for k, v in config['sha256'].items())
    assert all(sha256(output/k) == v for k, v in audit['prediction_cache_sha256'].items())
    z, valid, scale, adjacency, ts, context, cuts = read_data()
    original = json.loads((ROOT/'outputs/recovery-pilot/config.json').read_text(encoding='utf-8'))
    groups = json.loads((ROOT/'outputs/multifault-pilot/config.json').read_text(encoding='utf-8'))['groups']
    mean = np.array(original['normalization_mean'], np.float32)
    with h5py.File(ROOT/'data/raw/metr-la.h5', 'r') as h5:
        raw = h5['df/block0_values'][:, original['raw_column_indices']].astype(np.float32)
    day = (ts.astype('datetime64[D]')-ts[0].astype('datetime64[D]')).astype(int)
    models = []
    for seed in (42, 43, 44):
        model = MaskedGraphTCN(12, 3, adjacency)
        model.load_state_dict(torch.load(ROOT/'outputs/fresh-holdout-pilot'/f'model_tcn_seed{seed}.pt', weights_only=True)['state_dict'])
        model.eval(); models.append(model)
    matched, intervals, maximum_error, checked = {}, {}, 0., 0
    for partition in ('calibration', 'evaluation'):
        with np.load(output/f'predictions_{partition}.npz') as cache:
            saved = {k: cache[k] for k in cache.files}
        all_origins = saved['origins']
        target_raw = np.stack([raw[all_origins+k] for k in range(3)], axis=1)
        independently_valid = (np.isfinite(target_raw) & (target_raw > 0)).all(axis=1)
        window = all_origins[:, None]+np.arange(-12, 3)[None]
        independently_valid &= (np.diff(ts[window], axis=1) == np.timedelta64(5, 'm')).all(axis=1)[:, None]
        assert np.array_equal(independently_valid, saved['eligible'])
        assert np.array_equal((target_raw <= 30).all(axis=1), saved['truth'])
        recomputed, daily, columns = evaluate(saved)
        compare(recomputed, result[partition])
        if partition == 'calibration':
            selection = select(recomputed)
            compare(selection, result['selection'])
        selected = result['selection']['selected']
        if partition == 'evaluation':
            for scenario in SCENARIOS:
                compare(paired_ci(daily[scenario][REFERENCE], daily[scenario][selected]), result['paired_intervals'][scenario])
                fault = saved[f'fault_{scenario}']
                pred = saved['predictions_natural'].mean(axis=0)
                normal_alarm = pred.max(axis=1) <= 30
                matched[scenario] = {
                    'normal_input_on_same_fault_node_times': point_stats(saved['truth'], saved['eligible'] & fault, normal_alarm),
                    'outage_input_on_same_fault_node_times': recomputed[scenario][REFERENCE]['point_fault_nodes']}
                intervals[scenario] = paired_ci(daily['natural'][REFERENCE], daily[scenario][REFERENCE])
        indices = np.unique(np.r_[0, len(saved['origins'])-1, np.linspace(0, len(saved['origins'])-1, 14, dtype=int)])
        origins = saved['origins'][indices]
        # Include midnight cases so a new day's outage does not erase previous-day history.
        midnight = np.flatnonzero(np.diff(day[saved['origins']]) != 0)+1
        indices = np.unique(np.r_[indices, midnight[:3]])
        origins = saved['origins'][indices]
        history = origins[:, None]+np.arange(-12, 0)[None]
        assert np.all(history[:, -1] == origins-1)
        for scenario in SCENARIOS:
            mask, fault = outage_mask(valid, day, scenario, groups)
            assert np.array_equal(fault[saved['origins']-1], saved[f'fault_{scenario}'])
            for j, model in enumerate(models):
                with torch.no_grad():
                    x = torch.tensor(np.where(mask[history] > 0, z[history], 0))
                    m = torch.tensor(mask[history])
                    c = torch.tensor(context[origins])
                    prediction = model(x, m, c).numpy()*scale[None, None]+mean[None, None]
                error = float(np.max(np.abs(prediction-saved[f'predictions_{scenario}'][j, indices])))
                maximum_error = max(maximum_error, error)
                assert error < 2e-4, error
                checked += len(indices)
    audit.update(semantic_checks())
    audit.update({'grid_metrics_and_calibration_selection_recomputed': True,
                  'daily_paired_intervals_recomputed': True,
                  'sampled_cached_forecast_requests_checked': checked,
                  'sampled_forecast_max_abs_mph_error': maximum_error,
                  'raw_labels_and_common_target_coverage_checked': True,
                  'midnight_history_mask_checked': True})
    write_json(output/'audit.json', audit)
    diagnostic = {'post_run_descriptive': True, 'matched_fault_node_point_comparison': matched,
                  'outage_minus_natural_daily_intervals': intervals,
                  'note': 'Point recall on matched affected node-times; not event warning recall or an independent method trial.'}
    write_json(output/'fault_diagnostic.json', diagnostic)
    print(json.dumps({'checks': audit, 'descriptive': diagnostic}, indent=2))


if __name__ == '__main__':
    main()
