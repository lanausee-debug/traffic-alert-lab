"""Recover a development-only run whose episode JSON had NumPy integer fields.

Frozen scientific source and successfully written results remain unchanged.
Only NumPy scalar serialization is adapted. Existing equal artifacts are preserved.
"""
from datetime import datetime,timezone
import json
from pathlib import Path
from unittest.mock import patch
import numpy as np
import calibration_fragility as diagnostic


def scalar(value):
    if isinstance(value,np.generic):return value.item()
    raise TypeError('Unsupported JSON value: '+type(value).__name__)


def compatible_write(path,value):
    content=json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False,default=scalar)+'\n'
    if path.exists():
        old=json.loads(path.read_text(encoding='utf-8'));new=json.loads(content)
        if isinstance(old,dict) and isinstance(new,dict):
            a={k:v for k,v in old.items() if k!='frozen_at_utc'}
            b={k:v for k,v in new.items() if k!='frozen_at_utc'}
            if a==b:return
        if old==new:return
        raise ValueError('Keep differing partial artifact: '+str(path))
    path.write_text(content,encoding='utf-8')


def main():
    out=diagnostic.OUT
    amendment_path=out/'serialization_recovery.json'
    if not amendment_path.exists():
        assert not (out/'completion.json').exists()
        preserved={p.name:diagnostic.sha(p) for p in out.iterdir() if p.is_file()}
        diagnostic.write(amendment_path,{'frozen_at_utc':datetime.now(timezone.utc).isoformat(),
            'reason':'Episode row/node fields contain np.int64; JSON serializer rejected them after main results were written.',
            'scope':'np.generic.item serialization only; same source/inputs/offsets/grids/rules/results',
            'partial_artifacts_preserved_sha256':preserved,
            'source_sha256':diagnostic.sha(Path(__file__)),
            'development_recompute_only':True,'test_or_raw_data_access':False})
    amendment=diagnostic.read(amendment_path)
    assert amendment['source_sha256']==diagnostic.sha(Path(__file__))
    for name,digest in amendment['partial_artifacts_preserved_sha256'].items():assert diagnostic.sha(out/name)==digest
    with patch.object(diagnostic,'write',compatible_write):diagnostic.main()
    for name,digest in amendment['partial_artifacts_preserved_sha256'].items():assert diagnostic.sha(out/name)==digest
    compatible_write(out/'serialization_recovery_audit.json',{'passed':True,
        'amendment_sha256':diagnostic.sha(amendment_path),
        'all_prior_partial_artifacts_byte_unchanged':True,
        'completed_results_equal_pre_recovery_results':True})


if __name__=='__main__':main()
