"""Independent cached-transfer audit, including explicitly expanded date draws."""
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
import torch
import frozen_probe_transfer as transfer
import alarm_start_separability as probe
import calibration_fragility as common
from congestion_alert_pilot import SCENARIOS
from train_pems_bay_risk import load_risk

ROOT=transfer.ROOT;OUT=transfer.OUT


def curve_metrics(y,p):
    """Unweighted ROC area and PR step area, independent of weighted implementation."""
    y=np.asarray(y,bool);p=np.asarray(p,float);pos=int(y.sum());neg=len(y)-pos
    if not pos or not neg:return {'roc_auc':None,'average_precision':None}
    order=np.argsort(-p,kind='stable');value=p[order];truth=y[order]
    end=np.r_[np.flatnonzero(np.diff(value)!=0),len(value)-1]
    tp=np.cumsum(truth)[end];fp=(end+1)-tp
    tpr=np.r_[0,tp/pos];fpr=np.r_[0,fp/neg]
    return {'roc_auc':float(np.trapezoid(tpr,fpr)),
        'average_precision':float(np.sum(np.diff(tpr)*(tp/(tp+fp))))}


def lead_retention(samples,p,cutoff):
    result={};keep=p>=cutoff
    for minutes in (5,10,15):
        mask=(samples['y']==1)&(samples['lead_minutes']==minutes)
        count=int(mask.sum());retained=int((mask&keep).sum())
        result[str(minutes)]={'original_credited_warnings':count,'retained':retained,
            'rejected':count-retained,'fraction_retained':retained/count if count else None}
    assert sum(v['original_credited_warnings'] for v in result.values())==int(samples['y'].sum())
    return result


def main():
    torch.set_num_threads(1)
    plan=common.read(OUT/'plan.json');result=common.read(OUT/'results.json')
    completed=common.read(OUT/'completion.json');sealed=common.read(OUT/'result_freeze.json')
    for mapping in ('input_sha256','source_sha256'):
        for name,digest in plan[mapping].items():assert common.sha(ROOT/name)==digest,name
    for name,digest in completed['artifacts'].items():assert common.sha(OUT/name)==digest,name
    assert completed['plan_sha256']==sealed['plan_sha256']==common.sha(OUT/'plan.json')
    assert sealed['results_sha256']==common.sha(OUT/'results.json')
    assert datetime.fromisoformat(plan['frozen_at_utc'])<datetime.fromisoformat(sealed['frozen_at_utc'])
    original=common.read(transfer.PROBES/'training_freeze.json')
    assert sealed['originating_training_freeze_sha256']==common.sha(transfer.PROBES/'training_freeze.json')
    assert sealed['unchanged_probe_cutoffs']==original['cutoffs']
    assert result['cohort_already_consumed'] and not result['external_independent_confirmation']
    assert not result['probes_or_thresholds_refit'] and not result['new_alarm_policy_accepted']
    assert result['original_development_diagnostic_gate_still_failed'] and result['original_thesis_primary_test_still_failed']
    assert not set(plan['new_station_ids'])&set(plan['development_station_ids'])
    access=common.read(OUT/'access_log.json')
    assert access['named_cached_input_allowlist_enforced'] and not access['raw_hdf5_opened']
    assert all(path in transfer.ALLOWED for path in access['declared_input_open_paths'])
    models={name:common.load(transfer.PROBES/(name+'.npz')) for name in probe.METHODS}
    for name,digest in original['weights'].items():assert common.sha(transfer.PROBES/name)==digest
    training=common.read(transfer.PROBES/'training.json')['training_class_counts']
    prior=sum(v['credited_warnings'] for v in training.values())/sum(v['rows'] for v in training.values())
    norm=common.load(common.RISK/'normalization.npz');anchor=load_risk(common.RISK/'global_calibration.pt')
    part=common.load(transfer.CACHE/'evaluation_features.npz')
    scores=common.global_scores(part,norm,anchor)
    with np.load(transfer.CACHE/'fixed_scores.npz') as f:
        for s in SCENARIOS:np.testing.assert_array_equal(scores[s],f['global_calibration__'+s])
    predicted=common.load(OUT/'predictions.npz');lead_slices={};metrics_checked=0
    full_samples={}
    for block,(lo,hi) in plan['blocks_days_half_open'].items():
        local=part if block=='full83' else common.subset(part,lo,hi)
        p=scores if block=='full83' else common.global_scores(local,norm,anchor)
        samples,excluded=probe.build_samples(local,p)
        assert excluded==result['excluded_episode_counts'][block]
        lead_slices[block]={}
        for s,rows in samples.items():
            stored=common.load(OUT/(block+'__'+s+'_samples.npz'))
            for key,value in rows.items():np.testing.assert_array_equal(value,stored[key])
            if block=='full83':full_samples[s]=rows
            values={'constant_prior':np.full(len(rows['y']),prior),'fixed_risk':rows['global_probability'],
                **{name:probe.predict(model,rows['x']) for name,model in models.items()}}
            for name,value in values.items():
                np.testing.assert_array_equal(value,predicted[f'{block}__{s}__{name}'])
                actual=curve_metrics(rows['y'],value);expected=result['metrics'][block][s][name]
                for metric in ('roc_auc','average_precision'):assert np.isclose(actual[metric],expected[metric],atol=1e-12)
                metrics_checked+=1
                if name in models:assert probe.retention_metrics(rows,value,original['cutoffs'][name])==result['retention'][block][s][name]
            lead_slices[block][s]=lead_retention(rows,values['state_logistic'],original['cutoffs']['state_logistic'])
    assert probe.separation_gate({block:rows['natural'] for block,rows in result['metrics'].items()})==result['natural_diagnostic_gate']
    bootstrap=common.load(OUT/'bootstrap_draws.npz');dates=common.layout(part)[2]
    np.testing.assert_array_equal(dates,bootstrap['dates'])
    draws=bootstrap['draws'];np.testing.assert_array_equal(draws,np.random.default_rng(20261015).integers(0,len(dates),(2000,len(dates))))
    for s,rows in full_samples.items():
        indices=[np.flatnonzero(rows['date']==str(date)) for date in dates]
        candidate=predicted[f'full83__{s}__state_logistic'];reference=predicted[f'full83__{s}__score_logistic']
        samples={'roc_auc':[],'average_precision':[]};undefined=0
        for draw in draws:
            ids=np.concatenate([indices[int(day)] for day in draw])
            a=curve_metrics(rows['y'][ids],candidate[ids]);b=curve_metrics(rows['y'][ids],reference[ids])
            if any(v is None for v in (*a.values(),*b.values())):undefined+=1;continue
            for metric in samples:samples[metric].append(a[metric]-b[metric])
        for metric,values in samples.items():
            expected=result['full83_state_minus_score_logistic_date_bootstrap'][s][metric]
            assert expected['undefined_draws']==undefined
            if undefined:assert expected['conditional_ci95'] is None
            else:np.testing.assert_allclose(np.quantile(values,[.025,.975]),expected['conditional_ci95'],atol=1e-12)
    prior=common.read(ROOT/'outputs/alarm-start-separability-2026-10-15/writing_archive_manifest.json')
    for name,meta in prior['files'].items():
        if name in ('README.md','CURRENT_STATE.zh-CN.md') and (OUT/'writing_archive_manifest.json').exists():
            assert common.sha(ROOT/name)==common.read(OUT/'writing_archive_manifest.json')['files'][name]['sha256']
        else:assert common.sha(ROOT/name)==meta['sha256'],name
    common.write(OUT/'posthoc_proxy_lead_retention.json',{'posthoc_descriptive_only':True,
        'not_used_to_change_probe_cutoffs_or_gate':True,'by_block_and_scenario':lead_slices})
    proof={'passed':True,'checked_at_utc':datetime.now(timezone.utc).isoformat(),
        'all60_metric_pairs_independently_checked':metrics_checked==60,
        'all6000_scenario_date_draws_explicitly_expanded_and_checked':True,
        'all12_sample_sets_and_labels_rebuilt':True,'frozen_model_and_cutoff_hashes_unchanged':True,
        'cached_global_scores_exactly_reproduced':True,'cached_cohort_overlap_with_original_development':0,
        'prior_scientific_files_unchanged':True,'raw_hdf5_reopened':False,'new_station_cohort_consumed':False,
        'new_alarm_policy_accepted':False,'transfer_diagnostic_gate_passed':result['natural_diagnostic_gate']['passed'],
        'original_thesis_primary_test_still_failed':True,'source_sha256':common.sha(Path(__file__))}
    common.write(OUT/'audit.json',proof);print(proof)
    print({'natural_proxy_lead_retention':lead_slices['full83']['natural']})


if __name__=='__main__':main()
