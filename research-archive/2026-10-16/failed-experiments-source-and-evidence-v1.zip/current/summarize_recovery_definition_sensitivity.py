"""Report prespecified recovery semantics and fixed-policy comparisons."""
from datetime import datetime,timezone
import numpy as np
import recovery_definition_sensitivity as pilot
import calibration_fragility as common
from congestion_alert_pilot import SCENARIOS


def means(rows,method):return common.mean_metrics({s:rows[s][method]['operating'] for s in SCENARIOS})
def pct(value):return '未定义' if value is None else f'{100*value:.2f}%'


def main():
    root=pilot.ROOT;out=pilot.OUT;r=common.read(out/'results.json');audit=common.read(out/'audit.json')
    assert audit['passed'] and audit['results_sha256']==common.sha(out/'results.json')
    common.write(out/'test_receipt.json',{'recorded_at_utc':datetime.now(timezone.utc).isoformat(),
        'tests_run':9,'passed':True,'observed_exit_code':0,
        'basis':'Observed successful 9-test execution before real sensitivity replay; report does not rerun tests',
        'command':'.venv/Scripts/python.exe -m unittest discover -s tests -p test_recovery_definition_sensitivity.py -v',
        'test_source_sha256':common.sha(root/'tests/test_recovery_definition_sensitivity.py')})
    labels={'training28':'训练28日','risk_validation7':'验证7日','calibration_full14':'校准14日',
        'calibration_week1_7':'校准前7日','calibration_week2_7':'校准后7日'}
    methods={'global_c1':'原全局规则','effective_no_bypass':'固定有效告警模型：无豁免','effective_protected_gate':'固定有效告警模型：有豁免'}
    cases=r['blocks']['risk_validation7']['case_lineage']
    case=cases['natural'][0];assert case['new_run']['event_start_origin']==484
    assert all(e['status']=='late' and e['alarm_start_origin']==485 for e in case['two_high_methods'].values())
    lines=['# 连续两次回升的事件定义敏感性：独立预警保护收益消失','',
        '日期：2026-10-16。**固定模型与告警后，要求连续两条>30mph观测才结束事件，原被豁免救回的18:20新事件并入了16:20开始的低速过程。三种方法都已在16:25检出该过程，18:10告警转为重复。验证段豁免的新增检出/R10收益消失，但仍有额外误报。**','',
        '这是事先固定的开发语义敏感性分析，不是新的确认性实验，也不是模型变强。不能用新定义成绩覆盖原定义或让旧验收从失败改为通过。','',
        '## 只改变离线事件结束条件','',
        '两种定义都在连续三次车速≤30mph时开始一个低速过程，并把开始时刻回溯到第一条低速观测。对照在一次>30mph时结束；敏感性定义要求两次相邻、连续的>30mph读数，结束回溯到第一条高车速读数。两次高值之间如出现低速，不满足连续恢复，原过程继续。','',
        '为保持原三次读数代理窗口对齐，已确认物理低速区间[q,h)转换为代理标签区间[q,h−2)。即开始仍为第一条低速样本，结束沿用原窗口末端约定。这是离线定义，是否现实拥堵以及事件具体起止仍需外部标注。本轮不声称该恢复定义符合某个行业标准或最优定义。','',
        '边界上还没有确认恢复的事件保持右删失；不足前两条有效标签的事件保持左删失。时钟断点、缺测或共同可判断范围的中断强制分开，不能跨过未知观测合并。','',
        '原模型、权重、训练分界线0.4388462325645476、全局规则、有豁免与无豁免激活全部固定。没有搜索恢复次数、车速门槛、模型或新策略，零训练更新；新标签只在本次离线评价副本使用，原缓存不覆盖，未来恢复观测不进入在线告警。','',
        '## 共同观测范围：先分清样本排除与定义变化','',
        '两种定义、三个方法和三种情景共享同一可判断范围：原有效标签点，且未来三条自然缓存车速都可回推，且没有任何读数落在30±0.0001mph的反标准化精度带。缓存尾部/断点/未知保持未知；不是用预测补真值。','',
        '原完整范围的评价先逐项复现；再在共同范围重放一次原定义，最后对比两次恢复。两次恢复定义产生的分母变化与可判断范围缩小带来的变化分别记录。','',
        '| 范围 | 原有效站日 | 共同有效站日 | 原完整事件 | 原定义共同事件 | 两次恢复共同事件 |',
        '| --- | ---: | ---: | ---: | ---: | ---: |']
    for block,d in r['blocks'].items():
        e=d['shared_evidence'];link=d['lineage'];old=d['original_full']['natural']['global_c1']['events']
        lines.append(f"| {labels[block]} | {e['original_station_day_exposure']:.6f} | {e['shared_station_day_exposure']:.6f} | {int(old)} | {link['old_complete_events']} | {link['new_complete_events']} |")
    lines+=['',
        '例如验证事件55→52是共同观测范围变化；52→46才是在同一观测范围改变恢复定义的变化。校准69→66与66→62也应分开。不能把它们一起算成模型减少了漏检或更准确。校准14日和两个7日子块重叠，不能加总为更多独立事件。','',
        '## 原案例还存在吗','',
        '原验证node12事件origin508（18:20）在共同范围内完整保留。单次越线定义下，global和有豁免方法用origin506（18:10）获记15分钟代理预警，无豁免漏检。连续两条回升定义下，它映射到起点origin484（16:20）、结束代理索引512的同一较长过程。','',
        '| 固定方法 | 单次越线：原18:20事件 | 两次回升：合并16:20过程 | 18:10额外告警的作用 |',
        '| --- | --- | --- | --- |']
    for method,label in methods.items():
        a=case['one_high_methods'][method];b=case['two_high_methods'][method]
        before='漏检' if a['status']=='missed' else f"代理预警，L={a['lead_minutes']}分钟"
        after=f"迟报检出，起点origin{b['alarm_start_origin']}（16:25）"
        effect='没有此激活' if method=='effective_no_bypass' else '该后续起点记为重复'
        lines.append(f'| {label} | {before} | {after} | {effect} |')
    for s in SCENARIOS:
        extra=r['blocks']['risk_validation7']['shared_evaluation']['two_high'][s]['effective_protected_gate']['episode_records']
        assert any(e['node']==12 and e['kind']=='duplicate' and e['row']==494 for e in extra)
    lines+=['',
        '三种情景的映射和状态一致，它们共享同一个真实车速序列，不是三份独立证据。迟报0分钟沿用原最后历史观测的时间参考（s=484，a=485，5(a−s−1)=0），不表示系统实际发布没有延迟。该低速过程在本定义下已经被无豁免方法检出，不能继续把18:10额外告警宣传为保护首次起点的唯一有效预警。','',
        '## 同一范围内的固定方法指标','',
        '每个时间范围下，事件分母由定义决定，三个方法在同一定义使用相同事件和站日。下表为三情景等权均值。不同定义的百分比不能当作同一任务的模型提升；须同时看事件数量与原完整结果。','',
        '| 范围 | 定义 | 方法 | R10代理事件召回 | 含迟报检出 | 误报/有效站日 |',
        '| --- | --- | --- | ---: | ---: | ---: |']
    for block in ('risk_validation7','calibration_full14'):
        for definition,ds in r['blocks'][block]['shared_evaluation'].items():
            for method,label in methods.items():
                m=means(ds,method)
                lines.append(f"| {labels[block]} | {'一次越线' if definition=='one_high' else '两次连续回升'} | {label} | {pct(m['warning_recall_at_least10'])} | {pct(m['detection_recall'])} | {m['false_per_valid_station_day']:.6f} |")
    lines+=['',
        '验证共同范围中，有豁免相对无豁免在旧定义下各情景多检出1个事件、多保住1个R10；新定义下检出/R10数完全相同。新定义的平均检出都是78.26%，R10都是8.70%。误报仍分别多3、4、3次；平均误报/站日0.074051→0.094065。','',
        '校准共同范围中，两定义下有豁免与无豁免的检出/R10数都相同；新定义平均检出88.71%、R10为6.45%，误报仍各多1次，平均0.071740→0.074729。这个“一次”不同于原完整范围的2/2/1，因为此处已使用共同范围；原完整计数仍在results中保留。','',
        '两次恢复要求使事件更长，部分事件合并或变删失，检出分母/匹配机会改变。例如校准检出率上升时，原全局规则同样从87.88%升至90.32%；不能把这当训练模型改善。训练段仍有部分豁免检出收益，本轮没有证明豁免在所有数据、所有任务中都无效。','',
        '## 事件谱系与边界','',
        '| 范围 | 新事件包含多个旧阳性段的组数 | 旧完整事件映射到更早起点 | 旧完整事件映射到新删失段 |',
        '| --- | ---: | ---: | ---: |']
    for block,d in r['blocks'].items():
        v=d['lineage'];lines.append(f"| {labels[block]} | {v['new_runs_with_multiple_old_runs']} | {v['old_complete_mapped_to_earlier_start']} | {v['old_complete_mapped_to_new_censored']} |")
    lines+=['',
        '这些计数有不同单位且可能重叠：合并组含原删失段，多个旧事件可以映射到同一新段，不能简单相加作为事件减少量。所有旧阳性段（含删失）均逐条映射到新段，保留原身份和时间。新标签在共同范围为旧阳性标签的超集，但完整可评价事件数不一定有相同关系；更长的未结束段可能右删失而退出完整事件分母。','',
        '## 工程核查与结论边界','',
        '9项针对性测试通过，覆盖原定义等价、一次越线合并、两次高值不合并、交替高低不算连续恢复、共同范围断点不跨越、未确认右删失、精度带/尾部未知、与预测告警无关和禁止未计划的恢复次数。','',
        '独立核查使用最大低速/高速连续段枚举，区别于主程序逐样本状态机；10组标签逐位一致，一次恢复在共同范围完全重建旧真值。核对45次原完整回放+90次共同定义回放、388条原阳性段谱系（含重叠子块/删失）、3条同事件情景谱系和共同有效432,963个点（含重叠半块），36组原开发激活逐位复现。','',
        '原论文主检验失败、有效告警候选联合验收失败、所有原标签和门槛保持。本轮没有重新进行候选验收，没有根据有利结果挑事件定义，没有使用评测/迁移/新站值或HDF5。两次恢复定义不是现场确认的拥堵定义，后续若要成为正式目标，需要独立交通语义支持和重新冻结验证协议。','',
        '## 下一步','',
        '建议将“首次代理事件预警”和“已有低速中的后续告警/重复管理”分开报告。先固定这两种已声明定义，按首次起点与重入/重复做事件谱系分组，找出方法收益来自哪类场景；不要再用同一数据搜索恢复次数或豁免阈值。本轮该分组评价、论文正文修订与新策略都尚未执行。','',
        '本轮结果和图表全部本地保存，Word/PPT及线上GitHub v7未更新。','']
    (out/'report.zh-CN.md').write_text('\n'.join(lines),encoding='utf-8')
    (root/'docs/recovery_definition_sensitivity_handoff.zh-CN.md').write_text('''# 接续：两次连续回升定义敏感性（2026-10-16）

用户“下一步”已执行：固定原模型/规则，预先冻结仅1 vs2条连续>30mph结束条件。共同观测范围为原eligible AND可回推未来3自然速度且不在30±0.0001mph精度带。未知/时钟/范围断点不能跨；原一次结束在共同范围逐位复现旧truth。开始3连续low回溯第一low，结束确认回溯第一high，物理[q,h)转原窗口代理[q,h−2)，未结束右删失。线上无future输入，新标签仅本轮副本，原标签/模型未改。

案例验证node12,event508(18:20),alarm506(18:10)合并到event484(16:20)，三个方法都在alarm485(16:25)迟报检出；有豁免18:10变成重复。三情景同一事件。两次结束下验证有/无豁免检出、R10相同，各额外3/4/3误报；校准额外1/1/1（共同范围，与完整旧2/2/1不可混用）。证明该独立预警保护收益对事件定义敏感，不证明所有豁免无用；训练仍有些收益。

原完整训练/验证/校准198/55/69事件，旧定义共同183/52/66，新定义共同167/46/62；先区分范围排除与定义变化，不能拿比例变好当模型提高。谱系保留所有旧含删失段；某些新长段变删失，不省略。

报告outputs/recovery-definition-sensitivity-2026-10-16/report.zh-CN.md，results.json/shared_labels.npz/daily.npz/plan/audit/completion/test_receipt/comparison.png。源码recovery_definition_sensitivity.py/audit_recovery_definition_sensitivity.py/summarize_recovery_definition_sensitivity.py/save_recovery_definition_sensitivity_checkpoint.py，tests/test_recovery_definition_sensitivity.py。9测试，独立最大连续段枚举vs主状态机10标签一致；45原+90共同完整回放，388旧段谱系（含重叠半块/删失）及3相关情景案例核对，36旧开发激活复现。零训练更新/新模型。

原论文主检验/候选联合验收失败保持。用户本科论文题目《面向观测缺失的交通拥堵告警风险校准与事件级决策方法研究》。Word/PPT和GitHubv7不变，模型SHA1bea8ed689c6ac23dbcdec44212aed4bb3402ebb26a5f73f95aca7b92f9e6f21，固定分界线0.4388462325645476。禁读原评测/迁移/新站/HDF5，只有原复用开发缓存。

下一轮可固定本轮两定义，按首次起点/短暂重入/后续重复分别做谱系分组评价，明确真实价值来源；本轮分组、新策略、论文正文同步尚未做。不要通过新定义把旧失败变通过，不搜索恢复次数或拼阈值。新定义若正式采用需独立交通语义和另封存确认方案。

最新累计包traffic-recovery-lab-2026-10-16-recovery-definition-sensitivity.zip，先10月11日完整基包，再本包。旧文件与ZIP保留，只根README/CURRENT_STATE加说明；基包CRC本轮未重查，依赖既有验证回执。
''',encoding='utf-8')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(1,3,figsize=(13.7,4.9),facecolor='#f5f8fa')
    colors=['#8fa2b6','#c5a678','#237e86'];methodnames=['Global','No bypass','With bypass']
    for ax,metric,title,mult in zip(axes,['warning_recall_at_least10','detection_recall','false_per_valid_station_day'],
            ['Proxy R10 recall (%)','Detection incl. late (%)','False alerts / valid station-day'],[100,100,1]):
        for i,m in enumerate(pilot.METHODS):
            values=[means(r['blocks']['risk_validation7']['shared_evaluation'][d],m)[metric]*mult for d in ['one_high','two_high']]
            bars=ax.bar(np.arange(2)+(i-1)*.24,values,width=.23,color=colors[i],label=methodnames[i])
            for bar,v in zip(bars,values):ax.text(bar.get_x()+bar.get_width()/2,bar.get_height(),f'{v:.2f}' if mult==100 else f'{v:.3f}',ha='center',va='bottom',fontsize=8)
        ax.set_xticks([0,1],['1 high ends event\n52 shared events','2 highs end event\n46 shared events'],fontsize=9)
        ax.set_title(title,fontsize=10);ax.spines[['top','right']].set_visible(False)
        ax.set_ylim(0,100 if metric=='detection_recall' else .145 if mult==1 else 13)
    axes[0].legend(fontsize=8,loc='upper right')
    fig.suptitle('Fixed policies / validation7 / event-end sensitivity on exactly shared evidence support',fontsize=12)
    fig.text(.5,.025,'Recovered restart becomes a duplicate of an earlier detected event. Changed denominators are NOT model improvement.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.07,1,.92));fig.savefig(out/'comparison.png',dpi=150);plt.close(fig)
    print({'report':str(out/'report.zh-CN.md'),'tests':9,'online_policy_changed':False})


if __name__=='__main__':main()
