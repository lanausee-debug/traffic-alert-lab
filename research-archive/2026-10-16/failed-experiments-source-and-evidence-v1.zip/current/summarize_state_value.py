"""Reproduce saved policy choices and write fourth-round research artifacts."""
import json
import h5py
import csv
import numpy as np
import torch
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from recovery_pilot import ROOT, write_json
from multifault_pilot import day_macro, sha256
from state_value_pilot import (ValueMLP, VALUE_SEEDS, BASELINES, features, read_data,
                               ridge_predict, gain_choices, summarize)
from repair_policy import select_repair_order


def main():
    torch.set_num_threads(1)
    output = ROOT/'outputs/state-value-pilot'
    config = json.loads((output/'config.json').read_text(encoding='utf-8'))
    results = json.loads((output/'results.json').read_text(encoding='utf-8'))
    for name, expected in config['hashes'].items():
        if sha256(ROOT/name) != expected: raise AssertionError(f'Frozen source changed: {name}')
    z, valid, scale, adjacency, timestamps, context, cuts = read_data()
    events, groups = config['events'], config['groups']
    audit = {'source_hashes_verified': True, 'saved_choices_recomputed': {}, 'summary_recomputed': {},
             'feature_normalization_training_only': True, 'oracle_lower_bound': True}
    with np.load(output/'features.npz') as stored_features:
        for part in events:
            raw = features(events[part], groups, z, valid, context, adjacency)
            for i, kind in enumerate(('calendar', 'state')):
                expected = (raw[i]-stored_features[kind+'_mean'])/stored_features[kind+'_std']
                if not np.array_equal(expected, stored_features[part+'_'+kind]): raise AssertionError('Features changed')
                if part == 'training':
                    std = raw[i].std(axis=0); std = np.where(std > 1e-5, std, 1)
                    if not np.array_equal(raw[i].mean(axis=0), stored_features[kind+'_mean']) or not np.array_equal(std, stored_features[kind+'_std']):
                        raise AssertionError('Normalization not fitted to training only')
        for variant in results['models']:
            selection = json.loads((output/f'selection_{variant}.json').read_text(encoding='utf-8'))
            if selection['reference'] != min(BASELINES, key=lambda k: selection['validation_costs'][k]): raise AssertionError('Reference not selected on validation')
            saved = np.load(output/f'choices_{variant}.npz')
            if sha256(output/f'choices_{variant}.npz') != results['models'][variant]['choices_sha256_before_test_labels']:
                raise AssertionError('Choice hash differs')
            coefs = np.load(output/f'ridge_{variant}.npz')
            for part in ('validation', 'test'):
                for name, kind in (('calendar_ridge', 'calendar'), ('state_ridge', 'state'), ('state_gain_time', 'state')):
                    pred = ridge_predict(stored_features[part+'_'+kind], coefs[name])
                    choice = gain_choices(pred, events[part], groups) if name == 'state_gain_time' else pred.argmin(axis=1)
                    if not np.array_equal(choice, saved[part+'_'+name]): raise AssertionError('Ridge choice mismatch')
                for name, key in (('shortest_time', 'shortest_time'), ('fixed_joint', 'joint'), ('fixed_gain_time', 'gain_per_time')):
                    choice = [selection['fixed'][f"{e['group']}:{e['hour']}"][key] for e in events[part]]
                    if not np.array_equal(choice, saved[part+'_'+name]): raise AssertionError('Fixed choice mismatch')
                predictions = []
                for seed in VALUE_SEEDS:
                    ck = torch.load(output/f'value_{variant}_seed{seed}.pt', weights_only=True)
                    if ck['epoch'] != selection['value_mlp']['selected_epoch']: raise AssertionError('Epoch mismatch')
                    model = ValueMLP(ck['dimension']); model.load_state_dict(ck['state_dict']); model.eval()
                    with torch.no_grad(): pred = model(torch.tensor(stored_features[part+'_state'])).numpy()
                    predictions.append(pred)
                    if not np.array_equal(pred.argmin(axis=1), saved[f'{part}_state_mlp_seed{seed}']): raise AssertionError('Seed choice mismatch')
                if not np.array_equal(np.mean(predictions, axis=0).argmin(axis=1), saved[part+'_state_mlp']): raise AssertionError('MLP choice mismatch')
            with np.load(output/f'labels_{variant}_test.npz') as labels:
                choices = {k.removeprefix('test_'): saved[k] for k in saved.files if k.startswith('test_')}
                report = summarize(events['test'], labels, choices, selection['reference'])
                for key, value in report.items():
                    if value != results['models'][variant][key]: raise AssertionError(f'Summary changed: {key}')
                if np.any(labels['actual'][np.arange(len(events['test'])), choices['state_mlp']] < labels['actual'].min(axis=1)-1e-8):
                    raise AssertionError('Policy beat exhaustive oracle')
                with (output/f'episodes_{variant}.csv').open('w', encoding='utf-8-sig', newline='') as handle:
                    writer = csv.writer(handle)
                    writer.writerow(['day', 'hour', 'group', 'category', 'usable_steps', 'reference', 'reference_order',
                                     'candidate_order', 'reference_cost', 'candidate_cost', 'healthy_cost', 'offline_oracle_cost'])
                    for i, e in enumerate(events['test']):
                        ref_order = choices[selection['reference']][i]; candidate_order = choices['state_mlp'][i]
                        writer.writerow([e['day'], e['hour'], e['group'], e['category'], len(e['usable_steps']), selection['reference'],
                                         ref_order, candidate_order, labels['actual'][i, ref_order], labels['actual'][i, candidate_order],
                                         labels['healthy'][i], labels['actual'][i].min()])
            audit['saved_choices_recomputed'][variant] = True
            audit['summary_recomputed'][variant] = True
    original = json.loads((ROOT/'outputs/recovery-pilot/config.json').read_text(encoding='utf-8'))
    interface_cases = 0
    with h5py.File(ROOT/'data/raw/metr-la.h5', 'r') as h5:
        for variant in results['models']:
            with np.load(output/f'choices_{variant}.npz') as saved:
                samples = sorted(set(range(12)) | set(range(0, len(events['test']), max(1, len(events['test'])//12))))
                for i in samples:
                    event = events['test'][i]; origin = event['origin']; gid = event['group']
                    past = h5['df/block0_values'][origin-12:origin, original['raw_column_indices']]
                    before = past.copy()
                    for method in ('state_mlp', 'state_ridge', 'calendar_ridge', 'state_gain_time', 'reference'):
                        answer = select_repair_order(past, str(timestamps[origin]), gid, method, variant)
                        if answer['order_index'] != saved['test_'+answer['method']][i]: raise AssertionError('Independent policy interface disagrees')
                    changed = past.copy(); changed[:, groups[gid]['nodes']] = 1234
                    invariant = select_repair_order(changed, str(timestamps[origin]), gid, 'state_mlp', variant)
                    if invariant['order_index'] != saved['test_state_mlp'][i]: raise AssertionError('Hidden fault data changed interface choice')
                    if not np.array_equal(past, before, equal_nan=True): raise AssertionError('Caller history mutated')
                    interface_cases += 1
    audit['independent_raw_speed_interface_cases'] = interface_cases
    audit['interface_hidden_fault_invariant'] = True
    audit['feature_dimensions'] = {'calendar': int(raw[0].shape[1]), 'state': int(raw[1].shape[1])}
    write_json(output/'audit.json', audit)
    lines = ['# 第四轮：当前可见状态价值策略', '',
             '本轮在维修开始时，仅用其他站过去60分钟的可见速度、日历、故障位置和已知工时选择完整维修顺序。已实际训练PyTorch价值网络，并在此前未分析的最后四周测试。不是完工后滚动重规划。', '',
             '## 时间与方法', '',
             '- 价值策略训练：2012-04-12至05-17，1248个情景；原第三轮测试段在本轮明确转为训练。',
             '- 策略验证：05-17至05-31，504个情景；只在该段选择岭回归正则化、价值网络轮数和参考策略。',
             f"- 最终测试：05-31至06-28，{len(events['test'])}个情景，{len(set(e['day'] for e in events['test']))}个可评日期；此前未做误差分析。",
             '- 固定24站、12组三站故障、10/20/30分钟维修、单班组和120分钟累计全网预测MAE。相同六顺序、相同自然目标mask。',
             '- 故障组类别沿用原一跳统计图定义；disjoint_outputs不代表TCN两跳图下严格独立，也不是道路地理邻接。',
             '- 冻结预测器三个种子的平均损失作为标签；价值MLP另训练202/203/204三种子，平均预测选择。三种子不当作独立样本。',
             f"- 可见状态特征{audit['feature_dimensions']['state']}维；日历对照{audit['feature_dimensions']['calendar']}维。标准化只拟合训练段。MLP隐藏层64/32、ReLU、MSE回归六顺序中心化成本；已有组件组合。", '',
             '## 最终测试', '',
             '正改善表示比验证段选定参考更好；负数表示更差。累计成本单位为速度原始单位×分钟，不能解释为车辆延误或费用。', '']
    labels_cn = {'shortest_time': '最短工时', 'fixed_joint': '固定联合顺序', 'fixed_gain_time': '固定收益/工时',
                 'calendar_ridge': '日历六顺序回归', 'state_ridge': '状态六顺序岭回归', 'state_gain_time': '状态收益/工时',
                 'state_mlp': '状态价值MLP', 'offline_oracle': '未来已知离线最优'}
    for variant, title in (('graph_tcn_candidate', '冻结图TCN预测器（主实验）'), ('mlp_baseline', '冻结图MLP预测器（复核）')):
        s = results['models'][variant]
        lines += [f'### {title}', '', f"参考策略由验证段选为**{labels_cn[s['reference']]}**；价值网络选择第{s['selection']['selected_epoch']}轮。",
                  f"无人工故障对照成本{s['healthy_cost']:.4f}；参考故障增量{s['reference_fault_added_loss']:.4f}，按日95%区间[{s['reference_fault_added_ci'][0]:.4f}, {s['reference_fault_added_ci'][1]:.4f}]。", '',
                  '| 方法 | 累计成本 | 故障增量改善 | 改善95%区间 | 总损失改善 |', '|---|---:|---:|---:|---:|']
        for name in (*BASELINES, 'state_mlp', 'offline_oracle'):
            p = s['policies'][name]; ci = p['fault_added_gain_ci']
            pct = f"{100*p['fault_added_gain_fraction']:.2f}%" if p['fault_added_gain_fraction'] is not None else '分母不稳定'
            ci_str = f'[{100*ci[0]:.2f}%, {100*ci[1]:.2f}%]' if ci is not None else '分母不稳定'
            lines.append(f"| {labels_cn[name]} | {p['cost']:.4f} | {pct} | {ci_str} | {100*p['total_loss_gain_fraction']:.3f}% |")
        p = s['policies']['state_mlp']
        lines += ['', f"价值MLP绝对改善{p['absolute_gain']:.4f}，区间[{p['absolute_gain_ci'][0]:.4f}, {p['absolute_gain_ci'][1]:.4f}]；捕获离线空间{100*p['oracle_space_captured']:.2f}%。相对参考有{100*s['candidate_change_vs_reference_fraction']:.2f}%情景选择不同，改变顺序本身不等于改善。", '',
                  '| 价值MLP相对哪种基线 | 绝对改善 | 95%区间 |', '|---|---:|---:|']
        for name, pair in s['candidate_vs_each_baseline'].items():
            lines.append(f"| {labels_cn[name]} | {pair['absolute_gain']:.4f} | [{pair['ci'][0]:.4f}, {pair['ci'][1]:.4f}] |")
        lines += ['', '| 价值网络种子 | 相对参考的故障增量改善 |', '|---|---:|']
        for seed in VALUE_SEEDS:
            v = s['policies'][f'state_mlp_seed{seed}']['fault_added_gain_fraction']
            lines.append(f'| {seed} | {100*v:.2f}% |' if v is not None else f'| {seed} | 分母不稳定 |')
        lines += ['', '| 起点时段 | 价值MLP绝对改善 | 95%区间 |', '|---|---:|---:|']
        for hour, pair in s['by_hour'].items():
            lines.append(f"| {hour}:00 | {pair['absolute_gain']:.4f} | [{pair['ci'][0]:.4f}, {pair['ci'][1]:.4f}] |")
        lines += ['', '| 故障组类型 | 价值MLP绝对改善 | 95%区间 |', '|---|---:|---:|']
        for category, pair in s['by_category'].items():
            lines.append(f"| {category} | {pair['absolute_gain']:.4f} | [{pair['ci'][0]:.4f}, {pair['ci'][1]:.4f}] |")
        lines.append('')
    lines += ['## 研发判据与解释', '',
              f"预定条件：主实验至少降低5%故障增量损失、95%区间下界大于0、原MLP预测器复核绝对改善为正。本轮**{'通过' if results['screen_passed'] else '未通过'}**。5%只是事前研发投入标准，没有运营经济依据。第三轮未通过原5%预测能力及3%总损失判据的结论保持不变。", '',
              '未来已知离线最优只表示剩余空间，使用真实未来误差，不能部署。状态岭回归是必要的强简单基线；如果价值MLP不能超过它，不能把深度学习复杂性当作贡献。日历对照用于辨别可见速度是否增加决策价值。', '',
              '这是单数据集、固定24站与模拟工时的探索结果。没有真实维修工单、故障机理、路程、班组多资源或现场交通控制验证。按日bootstrap没有完整处理跨日序列相关及多方法选择不确定性。没有用测试成绩调整超参数、筛故障组或重选参考。', '',
              '## 共同评测覆盖', '', '| 日期 | 情景数 | 可评起点数 | 平均可评5分钟步数（满24） |', '|---|---:|---:|---:|']
    for day in sorted({e['day'] for e in events['test']}):
        es = [e for e in events['test'] if e['day'] == day]
        lines.append(f"| {day} | {len(es)} | {len(set(e['origin'] for e in es))} | {np.mean([len(e['usable_steps']) for e in es]):.2f} |")
    missing = sorted(set(str(d) for d in np.arange(np.datetime64('2012-05-31'), np.datetime64('2012-06-28')))-set(e['day'] for e in events['test']))
    lines += ['', f"完全不可评日期：{', '.join(missing) if missing else '无'}。被排除起点来自自然数据有效性/连续性规则，不由策略得分决定。", '',
              '## 保存与检查', '',
              '源码/协议/数据/旧标签/冻结模型哈希核对；旧训练情景顺序复建；训练段特征标准化复算；隐藏故障历史与未来值扰动不改变特征；固定/线性/三种子价值网络及平均选择全部从权重复算；测试选择文件在测试标签计算前保存且哈希不变；完工前历史禁止打开和预测器mask不变性沿用执行；穷举最优下界检查通过。', '',
              '保存config.json、features.npz、selection_*.json、ridge_*.npz、value_*.pt、choices_*.npz、labels_*.npz、results.json、audit.json与图表。协议见docs/state_value_protocol.zh-CN.md，教学说明见docs/pytorch_value_guide.zh-CN.md。', '']
    (output/'report.zh-CN.md').write_text('\n'.join(lines), encoding='utf-8')
    names = [*BASELINES, 'state_mlp', 'offline_oracle']
    fig, axes = plt.subplots(1, 2, figsize=(12, 5.5), sharey=True)
    display = ['Shortest time', 'Fixed joint', 'Fixed gain/time', 'Calendar ridge', 'State ridge', 'State gain/time', 'State value MLP', 'Future-known oracle']
    for ax, (variant, title) in zip(axes, (('graph_tcn_candidate', 'Frozen graph TCN'), ('mlp_baseline', 'Frozen graph MLP'))):
        policies = results['models'][variant]['policies']
        vals = np.array([100*policies[k]['fault_added_gain_fraction'] for k in names])
        cis = np.array([np.array(policies[k]['fault_added_gain_ci'])*100 for k in names])
        err = np.stack([np.maximum(vals-cis[:, 0], 0), np.maximum(cis[:, 1]-vals, 0)])
        ax.barh(np.arange(len(names)), vals, color=['#74869a']*6+['#137c90', '#d9a441'])
        ax.errorbar(vals, np.arange(len(names)), xerr=err, fmt='none', ecolor='#333', capsize=3)
        ax.axvline(0, color='#555', lw=.8); ax.set_title(title); ax.set_xlabel('Fault-added loss improvement vs validation-selected reference (%)')
        ax.set_yticks(np.arange(len(names)), display); ax.grid(axis='x', alpha=.2)
    axes[0].invert_yaxis(); fig.suptitle('Start-time policies: unseen final four-week test (day bootstrap intervals)')
    fig.tight_layout(); fig.savefig(output/'state_value_summary.png', dpi=180); fig.savefig(output/'state_value_summary.svg'); plt.close(fig)
    fig, axes = plt.subplots(1, 2, figsize=(10, 4))
    for ax, (variant, title) in zip(axes, (('graph_tcn_candidate', 'Frozen graph TCN'), ('mlp_baseline', 'Frozen graph MLP'))):
        selection = json.loads((output/f'selection_{variant}.json').read_text(encoding='utf-8'))
        logs = selection['value_mlp']['epochs']
        ax.plot([e['epoch'] for e in logs], [e['validation_cost'] for e in logs], 'o-', color='#137c90', ms=3)
        ax.axhline(selection['validation_costs'][selection['reference']], ls='--', color='#74869a', label='Selected baseline')
        ax.axvline(selection['value_mlp']['selected_epoch'], ls=':', color='#d9a441', label='Selected epoch')
        ax.set_title(title); ax.set_xlabel('Value MLP training epoch'); ax.set_ylabel('Validation decision cost'); ax.legend(fontsize=8)
    fig.tight_layout(); fig.savefig(output/'value_validation_curve.png', dpi=180); plt.close(fig)
    print(json.dumps({'audit': audit, 'screen_passed': results['screen_passed'], 'report': str(output/'report.zh-CN.md')}, ensure_ascii=False))


if __name__ == '__main__': main()
