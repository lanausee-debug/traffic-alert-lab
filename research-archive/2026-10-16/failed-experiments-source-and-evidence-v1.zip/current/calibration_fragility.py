"""Development-only diagnosis, not a new fitted method or independent test."""
from __future__ import annotations
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
import torch
from congestion_alert_pilot import SCENARIOS,runs
from congestion_risk_pilot import score,sigmoid
from train_pems_bay_risk import load_risk
from pems_bay_alert_replay import alarm,replay,layout
from improve_alert_recall import select

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs/calibration-fragility-2026-10-15'
RISK=ROOT/'outputs/pems-bay-risk'
CAL=ROOT/'outputs/pems-bay-calibration'
OFFSETS=(-5.,-2.,0.,2.,5.)
READS=[]
def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def read(path):return json.loads(path.read_text(encoding='utf-8'))
def load(path):
    with np.load(path) as f:return {k:f[k] for k in f.files}


def guard(event,args):
    if event!='open' or not isinstance(args[0],(str,bytes)):return
    name=str(args[0]).replace('\\','/').lower()
    if (name.endswith(('.h5','.hdf5')) or '/data/raw/' in name or
        any(token in name for token in ('/pems-bay-evaluation/','/new-station-transfer-',
            '/station-agnostic-transfer-','/historical-replay/'))):
        raise PermissionError('Development-only calibration diagnosis cannot open test/raw data')
    if '/outputs/' in name and name.endswith(('.npz','.pt','.json')):READS.append(name)


def subset(part,first_day,last_day):
    """Select origin rows; preserve native origin/timestamp mapping and censor edges."""
    days=part['timestamps'][part['origins']].astype('datetime64[D]')
    d0=part['timestamps'][0].astype('datetime64[D]')
    keep=(days>=d0+np.timedelta64(first_day,'D'))&(days<d0+np.timedelta64(last_day,'D'))
    if not keep.any():raise ValueError('Empty calendar block')
    # Explicit time-axis rules: never guess from coincidental equal dimensions.
    result={}
    for key,value in part.items():
        if key=='timestamps':result[key]=value
        elif key.endswith('_predictions'):result[key]=value[:,keep]
        else:
            if value.shape[0]!=len(keep):raise ValueError('Unexpected cache axis: '+key)
            result[key]=value[keep]
    return result


def causal_residual(part,scenario):
    """At t: forecast(t-1|history <=t-2) minus observed speed(t-1).

    Current forecast, future labels, hidden/old observations and clock gaps are excluded.
    This measures one-step residual where observed, not whole-horizon forecast MAE.
    """
    x=part[scenario+'_state'];residual=np.full(x.shape[:2],np.nan,dtype=np.float64)
    times=part['timestamps'][part['origins']]
    regular=(np.diff(part['origins'])==1)&(np.diff(times)==np.timedelta64(5,'m'))
    observed=(x[1:,:,12]>0)&(np.abs(x[1:,:,13])<1e-6)&regular[:,None]
    values=(x[:-1,:,0]-x[1:,:,8])*70.
    residual[1:]=np.where(observed,values,np.nan)
    return residual


def episodes(part,active):
    """Independently label all alarm episodes using the frozen matching rules."""
    records=[]
    for seg_lo,seg_hi in layout(part)[0]:
        for node in range(part['truth'].shape[1]):
            for a0,b0 in runs(part['eligible'][seg_lo:seg_hi,node]):
                lo,hi=seg_lo+int(a0),seg_lo+int(b0)
                complete=[];censored=[]
                for s0,e0 in runs(part['truth'][lo:hi,node]):
                    s,e=lo+int(s0),lo+int(e0)
                    (censored if s-2<lo or e==hi else complete).append((s,e))
                used=set()
                for a0,b0 in runs(active[lo:hi,node]):
                    a,b=lo+int(a0),lo+int(b0)
                    if a==lo or b==hi:kind='censored'
                    elif any(s-2<=a<e for s,e in censored):kind='unknown'
                    else:
                        matches=[i for i,(s,e) in enumerate(complete) if s-2<=a<e]
                        unmatched=[i for i in matches if i not in used]
                        if unmatched:
                            j=unmatched[0];used.add(j)
                            kind='warned' if a<=complete[j][0] else 'late'
                        elif matches:kind='duplicate'
                        else:kind='false'
                    records.append({'row':a,'node':node,'kind':kind,'length_steps':b-a,
                        'early_spanning_complete_window':bool(kind=='false' and any(a<s-2<b for s,e in complete))})
    return records


def grouped_exposure(part,groups,records,labels):
    valid=part['eligible'];result={}
    for index,label in enumerate(labels):
        mask=groups==index
        exposure=float((mask&valid).sum()/288.)
        count=sum(r['kind']=='false' and mask[r['row'],r['node']] for r in records)
        result[label]={'exposure_station_days':exposure,'false_episode_starts':int(count),
            'false_per_valid_station_day':count/exposure if exposure else None}
    assert sum(r['false_episode_starts'] for r in result.values())==sum(r['kind']=='false' for r in records)
    assert np.isclose(sum(r['exposure_station_days'] for r in result.values()),valid.sum()/288.)
    return result


def probability_summary(part,p):
    mask=part['eligible'];y=part['truth'][mask].astype(float);v=p[mask].astype(float)
    bins=[]
    indices=np.minimum((v*10).astype(int),9)
    for i in range(10):
        a=indices==i;n=int(a.sum())
        bins.append({'lower':i/10,'upper':(i+1)/10,'rows':n,
            'mean_probability':float(v[a].mean()) if n else None,
            'persistent_positive_rate':float(y[a].mean()) if n else None})
    return {'eligible_points':len(v),'persistent_positive_rate':float(y.mean()),
        'mean_probability':float(v.mean()),'brier':float(np.mean((v-y)**2)),
        'ece_10_equal_width_bins':float(sum(b['rows']*abs(b['mean_probability']-b['persistent_positive_rate']) for b in bins if b['rows'])/len(v)),
        'bins':bins,'event_false_budget_guarantee':False}


def mean_metrics(rows):
    keys=('warning_recall_at_least10','detection_recall','false_per_valid_station_day')
    return {k:float(np.mean([r[k] for r in rows.values()])) if all(r[k] is not None for r in rows.values()) else None for k in keys}


def global_scores(part,norm,model,offset=0.):
    return {s:sigmoid(score(model,((part[s+'_single'].reshape(-1,1)-offset/70.-norm['single_mean'])/norm['single_std']).astype(np.float32))).reshape(part['truth'].shape) for s in SCENARIOS}


def operating(part,scores,setting):
    rows={};daily={};active={}
    for s in SCENARIOS:
        active[s]=alarm(scores[s],setting['threshold'],setting['confirmation'],part)
        rows[s],daily[s],_=replay(part,active[s],details=True)
    return rows,daily,active


def freeze_plan():
    OUT.mkdir(exist_ok=True)
    names=['calibration_fragility.py','pems_bay_alert_replay.py','congestion_alert_pilot.py',
        'congestion_risk_pilot.py','improve_alert_recall.py','train_pems_bay_risk.py',
        'outputs/pems-bay-risk/risk_validation.npz','outputs/pems-bay-risk/global_calibration.pt',
        'outputs/pems-bay-risk/normalization.npz','outputs/pems-bay-calibration/calibration.npz',
        'outputs/pems-bay-calibration/selection.json','outputs/pems-bay-calibration/scores_calibration.npz']
    plan={'stage':'adaptive_development_calibration_fragility_diagnosis',
        'prior_failures_informed_question':True,'new_method_or_independent_confirmation':False,
        'allowed_caches':['original24 risk_validation7days','original24 calibration14days'],
        'forbidden':'raw HDF5, original/consumed cohort evaluation caches, next cohort',
        'fixed_head':'original global_calibration, original fine threshold and confirmation',
        'forecast_residual':'causal one-step past forecast minus freshly available own_last; only adjacent clock/origin and own_age0/coverage>0',
        'residual_bins_mph':['missing','<-5','[-5,0)','[0,5]','>5'],
        'episode_diagnostics':'fixed start-only event matcher; independently reconstructed false/censored/unknown/duplicate/warned/late; early spanning is descriptive',
        'probability_diagnostics':'persistent proxy target on eligible points; Brier and 10-bin ECE are not event false-rate guarantees',
        'synthetic_uniform_forecast_offsets_mph':list(OFFSETS),
        'stress_semantics':'offset all horizon predictions; fixed labels/head/threshold; synthetic sensitivity, not measured real forecast bias or correction',
        'week_split':'calendar first7/last7 calibration days; independent replay boundaries; reciprocal stress description, both blocks already reused for development',
        'weekly_selection':'same0.01..0.90 step0.005 plus1.0001, c1/2; each-scene own-week dense30 false budget and fixed-global detection floor minus0.02; max mean R10 then worst detection then min false then c/grid',
        'weekly_transfer':'apply each frozen weekly setting to other week with no retune; report own-other-week budgets and detection floors; no candidate acceptance or new station test in this round',
        'undefined':'report None/infeasible; never substitute zero denominators',
        'optimizer_updates':0,'public_performance_claim_changed':False,
        'source_and_input_sha256':{n:sha(ROOT/n) for n in names}}
    path=OUT/'plan.json'
    if path.exists():assert {k:v for k,v in read(path).items() if k!='frozen_at_utc'}==plan
    else:write(path,{**plan,'frozen_at_utc':datetime.now(timezone.utc).isoformat()})
    return plan


def main():
    sys.addaudithook(guard)
    torch.set_num_threads(1);plan=freeze_plan()
    if (OUT/'completion.json').exists():
        for n,h in read(OUT/'completion.json')['artifacts'].items():assert sha(OUT/n)==h
        print('Completed diagnosis verified; no rerun');return
    norm=load(RISK/'normalization.npz');model=load_risk(RISK/'global_calibration.pt')
    old=read(CAL/'selection.json');setting={k:old['methods']['global_calibration']['fine']['selected'][k] for k in ('threshold','confirmation')}
    linear=model.layers
    w=float(linear.weight.detach()[0,0]);b=float(linear.bias.detach()[0])
    assert w>0,'Expected higher risk for more negative speed feature'
    logit=np.log(setting['threshold']/(1-setting['threshold']))
    equivalent=-70.*(float(norm['single_mean'][0])+float(norm['single_std'][0])*(logit-b)/w)
    equivalence={'threshold':setting,'w_standardized_negative_speed':w,'bias':b,
        'equivalent_max_three_horizon_ensemble_speed_cutoff_mph':equivalent,
        'linear_monotone_only_no_additional_information':True}
    summaries={};all_daily={};all_records={};stress={};cal=None
    for name,path in [('risk_validation',RISK/'risk_validation.npz'),('calibration',CAL/'calibration.npz')]:
        part=load(path);scores=global_scores(part,norm,model)
        rows,daily,active=operating(part,scores,setting)
        dates=layout(part)[2].astype(str).tolist()
        by_s={}
        for s in SCENARIOS:
            records=episodes(part,active[s]);all_records[name+'__'+s]=records
            counts={kind:sum(r['kind']==kind for r in records) for kind in ('false','censored','unknown','duplicate','warned','late')}
            for kind,key in [('false','false'),('censored','censored_alerts'),('unknown','unknown_alerts'),('duplicate','duplicate'),('warned','warned'),('late','late')]:assert counts[kind]==rows[s][key]
            residual=causal_residual(part,s);finite=np.isfinite(residual)
            x=part[s+'_state'];coverage=x[:,:,12]
            groups=np.where(coverage==0,0,np.where(coverage<1.,1,2))
            rg=np.zeros(residual.shape,int)
            rg[finite&(residual< -5)]=1;rg[finite&(residual>=-5)&(residual<0)]=2
            rg[finite&(residual>=0)&(residual<=5)]=3;rg[finite&(residual>5)]=4
            valid=part['eligible'];values=residual[finite&valid]
            direct=x[:,:,6]*70<=equivalent
            if setting['confirmation']==1:assert np.array_equal(direct,active[s])
            if name=='calibration':
                cached=load(CAL/'scores_calibration.npz')[f'global_calibration__{s}']
                np.testing.assert_array_equal(scores[s],cached)
            by_s[s]={'operating':rows[s],'episode_counts':counts,
                'false_early_spanning_complete_window':sum(r['early_spanning_complete_window'] for r in records),
                'point_probability':probability_summary(part,scores[s]),
                'available_causal_residual':{'rows':int(len(values)),
                    'coverage_of_eligible':float(len(values)/valid.sum()),
                    'mean_predicted_minus_observed_mph':float(values.mean()) if len(values) else None,
                    'mean_absolute_mph':float(np.mean(np.abs(values))) if len(values) else None,
                    'quantiles_10_50_90':np.quantile(values,[.1,.5,.9]).tolist() if len(values) else None},
                'by_own_history_availability':grouped_exposure(part,groups,records,['unavailable','partial','complete']),
                'by_available_past_residual':grouped_exposure(part,rg,records,['missing','below_minus5','minus5_to0','0_to5','above5'])}
            all_daily[name+'__'+s]=daily[s]
        summaries[name]={'dates':dates,'events':rows['natural']['events'],'means':mean_metrics(rows),'by_scenario':by_s,
            'risk_validation_previously_used_for_head_selection':name=='risk_validation','independent_holdout':False}
        stress[name]={}
        for offset in OFFSETS:
            shifted=global_scores(part,norm,model,offset)
            sr,_,_=operating(part,shifted,setting)
            stress[name][str(offset)]={'synthetic_speed_offset_mph':offset,'means':mean_metrics(sr),'by_scenario':sr,
                'exceeds_original_calibration_budget':{s:sr[s]['false_per_valid_station_day']>old['budgets'][s]+1e-12 for s in SCENARIOS}}
        if name=='calibration':cal=part
        print(f'{name}: events={rows["natural"]["events"]} fixed_global={mean_metrics(rows)}',flush=True)
    weeks={name:subset(cal,lo,hi) for name,lo,hi in [('week1',0,7),('week2',7,14)]}
    weekly={};week_scores={};chosen={};grid_artifacts=[]
    for name,part in weeks.items():
        scores=global_scores(part,norm,model);week_scores[name]=scores
        reference,_,_=operating(part,scores,setting)
        dense={s:replay(part,alarm(part[s+'_single']*70,-30.,1,part),details=True)[0] for s in SCENARIOS}
        budgets={s:dense[s]['false_per_valid_station_day'] for s in SCENARIOS}
        feasible_inputs=all(reference[s]['events'] and budgets[s] is not None for s in SCENARIOS)
        rows=[]
        if feasible_inputs:
            for gi,t in enumerate([round(v/1000,3) for v in range(10,901,5)]+[1.0001]):
                for c in (1,2):
                    by_s,_,_=operating(part,scores,{'threshold':t,'confirmation':c})
                    rows.append({'method':'global_weekly','method_index':0,'grid_index':gi,'threshold':t,'confirmation':c,'by_scenario':by_s})
            chosen[name]=select(rows,reference,budgets)
        else:chosen[name]=None
        grid_name=name+'_grid.json';write(OUT/grid_name,rows);grid_artifacts.append(grid_name)
        own_dates=part['timestamps'][part['origins'][[0,-1]]].astype('datetime64[D]').astype(str).tolist()
        weekly[name]={'own_dates':own_dates,
            'events':reference['natural']['events'],'dense30_budgets':budgets,
            'fixed_global':reference,'fixed_global_means':mean_metrics(reference),
            'feasible_grid_settings':sum(r['feasible'] for r in rows),'selected':chosen[name],
            'not_a_holdout_or_new_method':True}
        print(f'{name}: events={reference["natural"]["events"]}, feasible={weekly[name]["feasible_grid_settings"]}',flush=True)
    # Choices are persisted before opposite-week application, but both weeks were used
    # earlier in this development project; this ordering cannot restore independence.
    write(OUT/'weekly_choice_freeze.json',{'frozen_at_utc':datetime.now(timezone.utc).isoformat(),
        'plan_sha256':sha(OUT/'plan.json'),'selected':chosen,'both_weeks_previously_seen':True})
    for name,selection in chosen.items():
        other='week2' if name=='week1' else 'week1'
        if selection is None:weekly[name]['opposite_week_application']=None;continue
        rows,_,_=operating(weeks[other],week_scores[other],selection)
        weekly[name]['opposite_week_application']={'target_week':other,'by_scenario':rows,'means':mean_metrics(rows),
            'false_budget_met':{s:rows[s]['false_per_valid_station_day']<=weekly[other]['dense30_budgets'][s]+1e-12 for s in SCENARIOS},
            'detection_floor_met':{s:rows[s]['detection_recall']>=weekly[other]['fixed_global'][s]['detection_recall']-.02-1e-12 for s in SCENARIOS},
            'refit':False,'independent_confirmation':False}
    result={'stage':'development_calibration_fragility_diagnosis','equivalence':equivalence,
        'partitions':summaries,'synthetic_shift_stress':stress,'reciprocal_week_stress':weekly,
        'optimizer_updates':0,'new_station_cohort_consumed':False,'external_independent_data':False,
        'new_method_accepted':False,'actual_cross_station_failure_cause_established':False,
        'original_thesis_primary_test_still_failed':True,
        'limitation':'Adaptive diagnostics on previously reused development partitions only. Synthetic speed shifts are not measured new-station bias. Point calibration cannot guarantee event-budget calibration.'}
    write(OUT/'results.json',result);write(OUT/'episode_records.json',all_records)
    np.savez_compressed(OUT/'fixed_daily.npz',**all_daily)
    for n,h in plan['source_and_input_sha256'].items():assert sha(ROOT/n)==h,n
    write(OUT/'access_log.json',{'runtime_open_paths':sorted(set(READS)),
        'evaluation_and_hdf5_runtime_guard_enabled':True,'evaluation_or_raw_hdf5_values_read':False})
    artifacts=['results.json','episode_records.json','fixed_daily.npz','access_log.json','weekly_choice_freeze.json']+grid_artifacts
    write(OUT/'completion.json',{'completed_at_utc':datetime.now(timezone.utc).isoformat(),
        'plan_sha256':sha(OUT/'plan.json'),'artifacts':{n:sha(OUT/n) for n in artifacts}})
    print(json.dumps({'equivalence':equivalence,'new_method_accepted':False}))


if __name__=='__main__':main()
