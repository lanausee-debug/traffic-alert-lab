"""Independently classify raw event phases and audit frozen objective diagnosis."""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import numpy as np
import torch

from recovery_pilot import ROOT,write_json
from multifault_pilot import sha256
from audit_congestion_pilot import compare
from congestion_alert_pilot import SCENARIOS,runs,event_stats,labels
from congestion_risk_pilot import sigmoid,online_alarm,pool
from congestion_ablation import OLD,SEEDS,load_data,load_parts,load_model
from summarize_congestion_risk import check_validation
from congestion_objective_diagnostic import (OUTPUT,PHASES,PARTITIONS,METHODS,build_maps,
                                              rebuild_logits,trace_events)


def independent_phase(truth,eligible):
    """A raw point scan, using adjacency validity instead of eligible-run nesting."""
    cat=np.full(truth.shape,-1,np.int8); cat[eligible]=0; cat[eligible & truth]=5
    records=[]
    for node in range(truth.shape[1]):
        positive=truth[:,node] & eligible[:,node]; i=0
        while i<len(positive):
            if not positive[i]:
                i+=1; continue
            s=i
            while i<len(positive) and positive[i]: i+=1
            e=i
            if s>=2 and eligible[s-2:s,node].all() and e<len(positive) and eligible[e,node]:
                assert not truth[s-2:s,node].any()
                cat[s-2:s,node]=(1,2); cat[s,node]=3; cat[s+1:e,node]=4
                records.append((node,s,e))
    return cat,records


def independent_losses(logits,truth,phase):
    if logits.ndim==2: logits=logits[None]
    y=truth.astype(np.float32); masks=[phase==i for i in range(6)]
    losses=[]; grads=[]
    for l in logits:
        bce=np.logaddexp(0,l)-l*y
        grad=np.abs(sigmoid(l)-y)
        losses.append([float(bce[m].sum(dtype=np.float64)) for m in masks])
        grads.append([float(grad[m].sum(dtype=np.float64)) for m in masks])
    loss=np.mean(losses,axis=0); grad=np.mean(grads,axis=0)
    counts=np.array([m.sum() for m in masks],dtype=int)
    total=int(counts.sum()); pos=int(counts[3:].sum())
    ls=float(loss.sum()); gs=float(grad.sum()); pls=float(loss[3:].sum()); pgs=float(grad[3:].sum())
    rows={}
    for i,label in enumerate(PHASES):
        n=int(counts[i]); l=float(loss[i]); g=float(grad[i])
        rows[label]={'count':n,'sample_share_all':n/total,'loss_sum':l,'mean_bce':l/n if n else None,
                     'loss_share_all':l/ls,'local_gradient_sum':g,'mean_abs_logit_gradient':g/n if n else None,
                     'local_gradient_share_all':g/gs,'positive_sample_share':n/pos if i>=3 else None,
                     'positive_loss_share':l/pls if i>=3 else None,'positive_local_gradient_share':g/pgs if i>=3 else None}
    return {'valid_points':total,'positive_points':pos,'mean_bce':ls/total,'loss_sum':ls,
            'positive_loss_sum':pls,'positive_loss_share_all':pls/ls,'local_gradient_sum':gs,
            'positive_local_gradient_sum':pgs,'phases':rows}


def check_event_records(records,p,alarm,ts):
    """Check each event against accepted starts, independently of online matching."""
    ids=p['origins']; truth=p['truth']; eligible=p['eligible']
    accepted={}; complete=[]
    for node in range(truth.shape[1]):
        starts=[]
        for lo,hi in runs(eligible[:,node]):
            targets=[(int(lo+a),int(lo+b)) for a,b in runs(truth[lo:hi,node])]
            censored=[(s,e) for s,e in targets if s-2<lo or e==hi]
            complete.extend((node,s,e,lo,hi) for s,e in targets if (s,e) not in censored)
            for a,b in runs(alarm[lo:hi,node]):
                a,b=int(lo+a),int(lo+b)
                if a==lo or b==hi or any(s-2<=a<e for s,e in censored): continue
                starts.append(a)
        accepted[node]=starts
    assert len(complete)==len(records)
    for r,(node,s,e,lo,hi) in zip(records,complete):
        assert r['node']==node and r['event_start_origin']==int(ids[s])
        assert r['event_end_origin_exclusive']==int(ids[e-1]+1)
        assert r['timestamp']==str(ts[ids[s]]) and r['proxy_positive_steps']==e-s
        possible=[a for a in accepted[node] if s-2<=a<e]
        a=min(possible) if possible else None
        expected='missed' if a is None else ('warned' if a<=s else 'late')
        assert r['status']==expected
        assert r['alarm_start_origin']==(None if a is None else int(ids[a]))
        assert r['alarm_start_point_label']==(None if a is None else bool(truth[a,node]))
        assert r['lead_minutes']==(5*(s-a+1) if expected=='warned' else None)
        assert r['late_minutes']==(5*(a-s-1) if expected=='late' else None)
        assert r['any_alarm_match_window']==bool(alarm[s-2:e,node].any())
        assert r['any_alarm_warning_window']==bool(alarm[s-2:s+1,node].any())
        assert r['active_spanning_warning_window_entry']==bool(s-3>=lo and alarm[s-3,node] and alarm[s-2,node])


def pooled_event(result,method,partition='evaluation'):
    rows=result['event_diagnostic'][partition][method]
    fields=['events','warned','late','missed_events']
    out={f:sum(rows[s]['stats'][f] for s in SCENARIOS) for f in fields}
    out['negative_warning_starts']=sum(rows[s]['diagnostic']['warning_starts_label_negative'] for s in SCENARIOS)
    out['missed_without_alarm']=sum(rows[s]['diagnostic']['missed_without_any_alarm_in_match_window'] for s in SCENARIOS)
    out['missed_with_alarm']=sum(rows[s]['diagnostic']['missed_with_alarm_but_without_credited_start'] for s in SCENARIOS)
    out['missed_spanning_entry']=sum(rows[s]['diagnostic']['missed_with_active_spanning_warning_window_entry'] for s in SCENARIOS)
    out['warning_by_lead']={str(k):sum(rows[s]['diagnostic']['warning_by_lead'][str(k)] for s in SCENARIOS) for k in (5,10,15)}
    return out


def report(result,output):
    t=result['targets']['training']; loss=result['loss_diagnostic']['training']['risk_mlp']
    interior=loss['phases']['interior_positive']; onset=loss['phases']['onset_positive']
    mlp=pooled_event(result,'risk_mlp')
    labels_zh={'other_negative':'其他阴性','pre15_negative':'提前15分钟/阴性','pre10_negative':'提前10分钟/阴性',
               'onset_positive':'完整事件首阳性','interior_positive':'完整事件后续阳性','censored_positive':'删失事件阳性'}
    lines=['# 逐点BCE与事件提前预警：目标诊断', '',
           '日期：2026-10-10。冻结模型与运行点，无新训练；所有日期已经分析，当前是探索性诊断。', '',
           '## 三个需要区分的发现', '',
           f'1. 完整事件后续低速点占训练阳性样本{interior["positive_sample_share"]*100:.2f}%，占阳性BCE {interior["positive_loss_share"]*100:.2f}%、阳性局部logit梯度绝对值{interior["positive_local_gradient_share"]*100:.2f}%。这是最终冻结权重上的分解，不是训练全过程更新归因。',
           f'2. MLP成功预警{int(mlp["warned"])}个情景-事件，开启点有{mlp["negative_warning_starts"]}个被逐点标签标为阴性，占{mlp["negative_warning_starts"]/mlp["warned"]*100:.2f}%。计分提前10/15分钟的开启点均属这一组。',
           f'3. MLP漏检{int(mlp["missed_events"])}个情景-事件，其中{mlp["missed_with_alarm"]}个窗口实际有告警，却没有计分有效的开启；其中{mlp["missed_spanning_entry"]}个告警在预警窗口入口之前已开启并跨入窗口。', '',
           '三情景共享同一目标，情景-事件数不是独立事件数。评测唯一完整事件仍1089个。以上说明任务和计分存在结构差异，尚未证明修改损失、重发报警或修改计分能提升现场服务。', '',
           '## 标签与局部梯度方向', '',
           '以完整代理事件首阳性s为界，当前标签y表示从该预测起点开始的三步速度全部≤30 mph；事件预警可在s−2、s−1、s开启，对应计分15、10、5分钟。前两处的y都是0。', '',
           'BCE对logit的导数是p−y：y=0时，增大该点风险分数会增加损失；y=1时方向相反。因此提前10/15分钟报警和当前逐点真值存在明确任务差异。风险仍可通过共享特征得到提前信号，这个差异并不证明BCE一定不可用。', '',
           '提前量是已有代理事件计分公式5×(s−a+1)，不能直接当已核验的物理拥堵起点时间；事件结束也是三步低速阳性段的结束。', '',
           '## 训练分解：实际15分钟抽样', '',
           '| 相位 | 唯一时间-站点数 | 三情景样本数 | MLP平均BCE | 全部BCE份额 | 阳性样本份额 | 阳性BCE份额 | 阳性局部梯度份额 |',
           '| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
    for label,r in loss['phases'].items():
        fmt=lambda key: '—' if r[key] is None else f'{r[key]*100:.2f}%'
        lines.append(f'| {labels_zh[label]} | {t["sampled_unique_phase_counts"][label]} | {r["count"]} | {r["mean_bce"]:.5f} | {fmt("loss_share_all")} | {fmt("positive_sample_share")} | {fmt("positive_loss_share")} | {fmt("positive_local_gradient_share")} |')
    lines += ['',
              f'全部有效训练样本{loss["valid_points"]}，唯一61500个时间-站点；阳性样本{loss["positive_points"]}，唯一2703个。这里的MLP损失是先对各种子计算、再平均，不是对平均概率计算BCE；各种子与线性对照完整分解见results.json。', '',
              f'首阳性只占阳性样本{onset["positive_sample_share"]*100:.2f}%，却占阳性BCE {onset["positive_loss_share"]*100:.2f}%，平均损失{onset["mean_bce"]:.3f}，后续阳性为{interior["mean_bce"]:.3f}。因此“长期低速样本多”成立，但“起点完全没有训练信号”不成立。后续阳性也没有占全部BCE的多数。', '',
              '绝对局部logit梯度是|p−y|，没有乘网络输入或计算参数梯度，不能据其份额断言某组支配参数更新。还未验证事件加权、重采样、起点标签或结构损失的实际效果。', '',
              '## 抽样保留了哪些事件', '',
              f'同一训练分区5分钟连续目标中有{t["complete_events_dense"]}个完整事件。原15分钟抽样保留了其中{t["events_with_sampled_positive"]}个的任一阳性（{t["events_with_sampled_positive"]/t["complete_events_dense"]*100:.2f}%）、{t["events_with_sampled_onset"]}个的首阳性（{t["events_with_sampled_onset"]/t["complete_events_dense"]*100:.2f}%）。{t["complete_events_dense"]-t["events_with_sampled_positive"]}个事件没有抽到任何阳性。', '',
              f'每个事件的三个计分预警位置恰有一个落在15分钟抽样网格上；其中{t["events_with_sampled_pre15_or_pre10"]}个抽到前两处阴性，{t["events_with_sampled_onset"]}个抽到首阳性。这个抽样结构可以放大任务差异，但没有对不同抽样间隔的模型进行重训比较，不能确认其收益代价。', '',
              '## 三种方法的固定运行点追踪', '',
              '| 方法 | 提前5/10/15分钟预警数 | 预警开启为阴性 | 阴性开启占成功预警 | 迟报数 | 漏检数 | 漏检但窗口有告警 | 其中入口前已开启 |',
              '| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |']
    for method in METHODS:
        v=pooled_event(result,method); d=v['warning_by_lead']
        lines.append(f'| {method} | {d["5"]}/{d["10"]}/{d["15"]} | {v["negative_warning_starts"]} | {v["negative_warning_starts"]/v["warned"]*100:.2f}% | {int(v["late"])} | {int(v["missed_events"])} | {v["missed_with_alarm"]} | {v["missed_spanning_entry"]} |')
    lines += ['',
              '“有告警但未计分”可能包括长时间开启、边界删失和未知窗口等情形。入口前已开启只是该集合的子集，不等于这些告警可用于有效预警：过早或长时间报警也可能无用。没有修改原匹配规则或给任何模型补分。', '',
              '## 分情景与成功子集长度', '',
              '| 方法 | 情景 | 预警 | 迟报 | 漏检 | 无告警的漏检 | 有告警未计分 | 入口前已开启 | 预警/迟报/漏检事件阳性步数中位数 |',
              '| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |']
    for method,rows in result['event_diagnostic']['evaluation'].items():
        for s,row in rows.items():
            a=row['stats']; b=row['diagnostic']; dur=b['duration_by_status']
            med='/'.join(str(dur[k]['positive_steps_median']) for k in ('warned','late','missed'))
            lines.append(f'| {method} | {s} | {a["warned"]:g} | {a["late"]:g} | {a["missed_events"]} | {b["missed_without_any_alarm_in_match_window"]} | {b["missed_with_alarm_but_without_credited_start"]} | {b["missed_with_active_spanning_warning_window_entry"]} | {med} |')
    lines += ['',
              '每步5分钟，但这里是代理阳性段长度，并非实际拥堵持续时间。成功子集的长度不同，不能将两模型成功预警平均提前量差解释成同事件因果差。', '',
              '## 审核与结论边界', '',
              '独立逐点扫描核对六组相位、原始目标和抽样守恒；从保存权重重建全部训练/验证/校准/评测logit；核对模型验证选权重、训练标准化、损失与局部梯度分解；原校准和评测概率严格一致。逐事件用独立可计分开启列表核对预警/迟报/漏检与原因，全部统计和日级数组与原event_stats一致。', '',
              '四段所有概率、损失分解、校准/评测逐事件记录CSV/JSON、日级数组和审核均保存。未更改任何旧模型或运行点，本轮没有新的方法收益。', '',
              '下一步应先明确服务要求：新事件提前发现、持续状态提示，以及过早开启且保持的报警应如何评价。随后冻结一个事件起点目标/告警开启方法的小实验；保留原BCE和简单速度参考，比较完整误报、检测和提前量。当前不据此修改已用评测计分或宣称创新。']
    (output/'report.zh-CN.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    plot(result,output)


def plot(result,output):
    os.environ.setdefault('MPLBACKEND','Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(2,2,figsize=(12,8))
    phase=result['loss_diagnostic']['training']['risk_mlp']['phases']
    categories=['onset_positive','interior_positive','censored_positive']
    colors=['#3a7796','#db8b46','#b9bcc1']
    names=['Event onset','Later positive','Censored positive']
    ax=axes[0,0]; ypos=np.arange(3); left=np.zeros(3)
    for c,color,name in zip(categories,colors,names):
        values=np.array([phase[c][f] for f in ('positive_sample_share','positive_loss_share','positive_local_gradient_share')])*100
        ax.barh(ypos,values,left=left,color=color,label=name)
        for i,v in enumerate(values):
            if v>7: ax.text(left[i]+v/2,i,f'{v:.1f}%',ha='center',va='center',fontsize=9,color='white')
        left+=values
    ax.set_yticks(ypos,['Positive samples','Positive BCE','Abs logit gradient']); ax.set_xlim(0,100)
    ax.set_title('Frozen MLP: different denominators'); ax.set_xlabel('Share of positive total (%)')
    ax.legend(loc='upper center',bbox_to_anchor=(.5,-.19),ncol=3,fontsize=8,frameon=False)
    t=result['targets']['training']; ax=axes[0,1]
    values=[t['events_with_sampled_positive'],t['events_with_sampled_onset'],t['events_with_sampled_pre15_or_pre10']]
    percentages=np.array(values)/t['complete_events_dense']*100
    ax.barh(np.arange(3),percentages,color=['#8098a4','#3a7796','#db8b46'])
    for i,(p,n) in enumerate(zip(percentages,values)): ax.text(p+1,i,f'{n}/963 ({p:.1f}%)',va='center',fontsize=9)
    ax.set_yticks(np.arange(3),['Any positive sampled','Onset sampled','Pre-10/15 sampled']); ax.set_xlim(0,105)
    ax.set_title('15-minute training sampling'); ax.set_xlabel('Share of complete training events (%)')
    for ax,mode in zip(axes[1],('outcome','misses')):
        y=np.arange(3); left=np.zeros(3)
        if mode=='outcome':
            fields=['warned','late','missed_events']; labels_=['Warning','Late','Missed']; cs=['#3a7796','#db8b46','#b9bcc1']; denom='events'
            ax.set_title('Fixed evaluation event outcomes')
        else:
            fields=['missed_without_alarm','missed_with_alarm']; labels_=['No alarm in window','Alarm present, no credited start']; cs=['#b9bcc1','#a15a68']; denom='missed_events'
            ax.set_title('Misses under existing start-matching rule')
        for field,label,color in zip(fields,labels_,cs):
            v=np.array([pooled_event(result,m)[field]/pooled_event(result,m)[denom]*100 for m in METHODS])
            ax.barh(y,v,left=left,color=color,label=label)
            for i,n in enumerate(v): ax.text(left[i]+n/2,i,f'{n:.1f}%',ha='center',va='center',fontsize=9)
            left+=v
        ax.set_yticks(y,['Speed rule','State linear','Risk MLP']); ax.set_xlim(0,100)
        ax.set_xlabel('Share (%) - 3 scenarios sharing the same targets')
        ax.legend(loc='upper center',bbox_to_anchor=(.5,-.19),ncol=len(fields),fontsize=8,frameon=False)
    for ax in axes.flat: ax.set_axisbelow(True); ax.grid(axis='x',alpha=.15)
    fig.suptitle('Objective diagnosis: frozen models, previously analyzed dates',fontsize=14)
    fig.tight_layout(rect=(0,.035,1,.96),h_pad=3,w_pad=3)
    fig.savefig(output/'summary.png',dpi=170); fig.savefig(output/'summary.svg'); plt.close(fig)


def main():
    parser=argparse.ArgumentParser(description=__doc__); parser.add_argument('--output',type=Path,default=OUTPUT)
    output=parser.parse_args().output; torch.set_num_threads(1); torch.use_deterministic_algorithms(True)
    result=json.loads((output/'results.json').read_text(encoding='utf-8'))
    config=json.loads((output/'config.json').read_text(encoding='utf-8'))
    compare(config,result['config']); audit=json.loads((output/'audit.json').read_text(encoding='utf-8'))
    assert all(sha256(ROOT/k)==v for k,v in config['sha256'].items())
    assert all(sha256(output/k)==v for k,v in audit['artifact_sha256'].items())
    data=load_data(); parts,_=load_parts(data); maps,targets=build_maps(parts,data)
    compare(targets,result['targets'])
    with np.load(output/'phase_maps.npz') as cache:
        for partition,a,b,stride in PARTITIONS:
            q=maps[partition]; cat,events=independent_phase(q['truth'],q['eligible'])
            assert np.array_equal(cat,q['phase']) and np.array_equal(cat,cache[f'{partition}_phase'])
            assert [(r['node'],r['s'],r['e']) for r in q['events']]==events
            assert np.array_equal(q['selected'],cache[f'{partition}_selected'])
            assert np.array_equal(q['origins'],cache[f'{partition}_origins'])
            assert int((cat>=0).sum())==sum(targets[partition]['dense_unique_phase_counts'].values())
            assert np.array_equal(cat>=0,q['eligible'])
            assert np.array_equal(cat>=3,q['truth'] & q['eligible'])
            assert len(events)==targets[partition]['complete_events_dense']
            if stride==3:
                assert targets[partition]['events_with_sampled_onset']+targets[partition]['events_with_sampled_pre15_or_pre10']==len(events)
            else:
                assert targets[partition]['events_with_sampled_onset']==len(events)
                assert targets[partition]['events_with_sampled_pre15_or_pre10']==len(events)
    with np.load(OLD/'normalization.npz') as n: mean,std=n['mean'],n['std']
    train=pool(parts['training'],'state'); checkstd=train.std(axis=0); checkstd[checkstd<1e-5]=1
    assert np.array_equal(train.mean(axis=0),mean) and np.array_equal(checkstd,std)
    xv=((pool(parts['validation'],'state')-mean)/std).astype(np.float32)
    yv=pool(parts['validation'],'truth').astype(np.float32)
    for filename in ['logistic.pt']+[f'mlp{s}.pt' for s in SEEDS]:
        model,record=load_model(OLD/filename); check_validation(model,record,xv,yv)
    rebuilt=rebuild_logits(parts,mean,std); maxerror=0.
    for partition,bykey in rebuilt.items():
        phase=maps[partition]['phase'][maps[partition]['selected']]
        with np.load(output/f'logits_{partition}.npz') as cached:
            for key,l in bykey.items():
                error=float(np.max(np.abs(l-cached[key]))); maxerror=max(maxerror,error); assert error==0.
        for method in ('state_logistic','risk_mlp'):
            stacks=[bykey[f'{method}_{s}'][None] if method=='state_logistic' else bykey[f'{method}_{s}'] for s in SCENARIOS]
            logits=np.concatenate(stacks,axis=1)
            truth=np.concatenate([parts[partition][s]['truth'] for s in SCENARIOS],axis=0)
            cat=np.concatenate([phase]*len(SCENARIOS),axis=0)
            independent=independent_losses(logits,truth,cat)
            saved=result['loss_diagnostic'][partition][method]
            compare(independent,{k:v for k,v in saved.items() if k not in ('by_scenario','per_seed')})
            for s in SCENARIOS: compare(independent_losses(bykey[f'{method}_{s}'],parts[partition][s]['truth'],phase),saved['by_scenario'][s])
            if method=='risk_mlp':
                for i,seed in enumerate(SEEDS): compare(independent_losses(logits[i],truth,cat),saved['per_seed'][str(seed)])
    old=json.loads((OLD/'results.json').read_text(encoding='utf-8'))
    compare(result['frozen_operating_points'],{m:old['selection']['methods'][m]['selected'] for m in METHODS})
    all_records=json.loads((output/'event_records.json').read_text(encoding='utf-8'))
    verified=0
    with np.load(output/'event_daily_metrics.npz') as daily_cache:
        for partition in ('calibration','evaluation'):
            with np.load(OLD/f'scores_{partition}.npz') as old_scores:
                for method in METHODS:
                    op=result['frozen_operating_points'][method]
                    for s in SCENARIOS:
                        p=parts[partition][s]
                        if method=='dense_speed': scores=p['single']*70
                        else:
                            logits=rebuilt[partition][f'{method}_{s}']; scores=sigmoid(logits)
                            if method=='risk_mlp': scores=scores.mean(axis=0)
                        assert np.array_equal(scores,old_scores[f'{method}_{s}'])
                        alarm=online_alarm(scores,op['threshold'],op['confirmation'])
                        stats,daily=event_stats(p['truth'],p['eligible'],alarm,p['day_ids'])[:2]
                        row=result['event_diagnostic'][partition][method][s]
                        compare(stats,row['stats']); assert np.array_equal(daily,daily_cache[f'{partition}_{method}_{s}'])
                        records=[{k:v for k,v in r.items() if k not in ('partition','method','scenario')} for r in all_records if r['partition']==partition and r['method']==method and r['scenario']==s]
                        check_event_records(records,p,alarm,data[3]); verified+=len(records)
                        stats2,daily2,trace,detail=trace_events(p['truth'],p['eligible'],alarm,p['day_ids'],p['origins'],data[3])
                        compare(trace,records); compare(detail,row['diagnostic'])
                        if partition=='evaluation': compare(stats,{k:old['evaluation'][method][s][k] for k in stats})
    assert verified==len(all_records)
    audit.update({'audit_status':'passed','audit_script_sha256':sha256(Path(__file__)),
                  'raw_phase_classification_independent_point_scan':True,
                  'phase_counts_and_subsampling_conservation_checked':True,
                  'training_normalization_and_validation_selection_checked':True,
                  'all_frozen_logits_rebuilt_from_weights':True,'maximum_logit_rebuild_error':maxerror,
                  'per_seed_and_scenario_loss_gradient_decomposition_independently_recomputed':True,
                  'all_event_records_checked_against_independent_accepted_start_lists':True,
                  'verified_event_records':verified,'old_scores_operating_points_event_stats_daily_metrics_unchanged':True})
    write_json(output/'audit.json',audit); report(result,output)
    print(json.dumps({'audit':'passed','logit_error':maxerror,'event_records':verified,
                      'mlp_pooled_evaluation':pooled_event(result,'risk_mlp'),'report':str(output/'report.zh-CN.md')},indent=2))


if __name__=='__main__': main()
