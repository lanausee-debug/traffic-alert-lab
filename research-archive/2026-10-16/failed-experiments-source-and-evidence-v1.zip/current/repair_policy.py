"""Load saved start-time policies. No future traffic is required for selection."""
from __future__ import annotations
import argparse
import json
import h5py
import numpy as np
import torch
from recovery_pilot import ROOT
from state_value_pilot import ValueMLP, VALUE_SEEDS, observable_features, ridge_predict, gain_choices
from multifault_pilot import ORDERS


def select_repair_order(history_speed, timestamp, group_id, method='reference', forecaster='graph_tcn_candidate'):
    """Use exactly 12 past samples x 24 archived nodes, in raw speed units.

    Only the twelve archived fault groups and their known processing times are
    supported. This is an experimental start-time selector, not a field dispatch
    service or a policy generalized to arbitrary sensor groups.
    """
    output = ROOT/'outputs/state-value-pilot'
    config = json.loads((output/'config.json').read_text(encoding='utf-8'))
    original = json.loads((ROOT/'outputs/recovery-pilot/config.json').read_text(encoding='utf-8'))
    if forecaster not in ('graph_tcn_candidate', 'mlp_baseline'): raise ValueError('Unknown frozen forecaster')
    if group_id not in range(len(config['groups'])): raise ValueError('Group must be one of the archived 0..11 groups')
    history_speed = np.asarray(history_speed, dtype=np.float32)
    if history_speed.shape != (12, 24): raise ValueError('Expected 12 chronological past samples x 24 archived sensor columns')
    valid = (np.isfinite(history_speed) & (history_speed > 0)).astype(np.float32)
    mean = np.array(original['normalization_mean'], np.float32)
    scale = np.array(original['normalization_std'], np.float32)
    z = np.where(valid > 0, (history_speed-mean)/scale, 0).astype(np.float32)
    stamp = np.datetime64(timestamp, 'ns'); day = stamp.astype('datetime64[D]')
    minute = float((stamp-day).astype('timedelta64[m]').astype(np.int64))
    weekday = (int(day.astype(np.int64))+3) % 7
    context = np.zeros((13, 4), np.float32)
    minute_array = np.array([minute], np.float32)
    weekday_array = np.array([weekday], np.int64)
    context[12] = [np.sin(2*np.pi*minute_array/1440)[0], np.cos(2*np.pi*minute_array/1440)[0],
                   np.sin(2*np.pi*weekday_array/7)[0], np.cos(2*np.pi*weekday_array/7)[0]]
    group = config['groups'][group_id]
    adjacency = torch.load(ROOT/'outputs/recovery-pilot/model_seed42.pt', weights_only=True)['state_dict']['adjacency'].numpy()
    calendar, state = observable_features(z, valid, context, 12, group, adjacency)
    selection = json.loads((output/f'selection_{forecaster}.json').read_text(encoding='utf-8'))
    if method == 'reference': method = selection['reference']
    predicted = None
    if method in ('state_mlp', 'state_ridge', 'calendar_ridge', 'state_gain_time'):
        kind = 'calendar' if method == 'calendar_ridge' else 'state'
        raw_features = calendar if kind == 'calendar' else state
        with np.load(output/'features.npz') as norms:
            x = ((raw_features-norms[kind+'_mean'])/norms[kind+'_std'])[None]
        if method == 'state_mlp':
            outputs = []
            with torch.no_grad():
                for seed in VALUE_SEEDS:
                    saved = torch.load(output/f'value_{forecaster}_seed{seed}.pt', weights_only=True)
                    model = ValueMLP(saved['dimension']); model.load_state_dict(saved['state_dict']); model.eval()
                    outputs.append(model(torch.tensor(x)).numpy()*saved['target_scale'])
            predicted = np.mean(outputs, axis=0)[0]; choice = int(predicted.argmin())
        else:
            with np.load(output/f'ridge_{forecaster}.npz') as coefs:
                pred = ridge_predict(x, coefs[method])
            if method == 'state_gain_time':
                choice = int(gain_choices(pred, [{'group': group_id}], config['groups'])[0])
            else:
                predicted = pred[0]; choice = int(predicted.argmin())
    elif method in ('shortest_time', 'fixed_joint', 'fixed_gain_time'):
        hour = int(minute//60)
        key = f'{group_id}:{hour}'
        if key not in selection['fixed']: raise ValueError('Fixed tables support dataset hours 6/12/18 only')
        mapping = {'shortest_time': 'shortest_time', 'fixed_joint': 'joint', 'fixed_gain_time': 'gain_per_time'}
        choice = selection['fixed'][key][mapping[method]]
    else:
        raise ValueError('Unknown saved policy method')
    order = ORDERS[choice]
    return {'method': method, 'forecaster': forecaster, 'timestamp': str(stamp), 'group': group_id,
            'order_index': choice, 'sensor_order': [group['sensor_ids'][i] for i in order],
            'duration_minutes': [5*group['durations_steps'][i] for i in order],
            'predicted_centered_costs': predicted.tolist() if predicted is not None else None}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--timestamp', default='2012-05-31T06:00')
    parser.add_argument('--group', type=int, default=0)
    parser.add_argument('--method', default='reference')
    parser.add_argument('--forecaster', default='graph_tcn_candidate')
    args = parser.parse_args()
    original = json.loads((ROOT/'outputs/recovery-pilot/config.json').read_text(encoding='utf-8'))
    with h5py.File(ROOT/'data/raw/metr-la.h5', 'r') as h5:
        ts = h5['df/axis1'][:].astype('datetime64[ns]')
        stamp = np.datetime64(args.timestamp, 'ns'); origin = int(np.searchsorted(ts, stamp))
        if origin >= len(ts) or origin < 12 or ts[origin] != stamp: raise ValueError('Timestamp not in data')
        if not np.all(np.diff(ts[origin-12:origin+1]) == np.timedelta64(5, 'm')): raise ValueError('Noncontinuous history')
        # Read speed only before the requested origin; selection does not read future targets.
        history = h5['df/block0_values'][origin-12:origin, original['raw_column_indices']]
    result = select_repair_order(history, args.timestamp, args.group, args.method, args.forecaster)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__': main()
