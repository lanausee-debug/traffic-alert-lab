"""Fixed-policy proxy-label/lead/episode semantics, original development only.

Offline speed reconstruction uses natural cached fresh own_last shifted by -1.
It does not invent missing tail/clock-gap speeds or change any policy/labels.
"""
from datetime import datetime,timezone
from pathlib import Path
import sys
import numpy as np
import torch
import calibration_fragility as common
import early_warning_protection as protection
import effective_alert_pilot as previous
import alarm_start_separability as probe
from complete_bypass_diagnosis import json_native
from congestion_alert_pilot import SCENARIOS,runs
from pems_bay_alert_replay import alarm,replay,layout
from train_pems_bay_risk import load_risk

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs/proxy-event-semantics-2026-10-16'
PRECISION_BAND_MPH=1e-4
METHODS=('global_c1','effective_no_bypass',previous.PRIMARY)


def cached_speed(part):
    """Offline evidence only. At cached origin t, own_last is v(t-1).

    Missing/current-age>0 is unknown, not a known negative or an imputed speed.
    Low classification stays in original float32 feature units to avoid 30mph
    rounding; raw64 truth reconciliation excludes an explicit precision band.
    """
    x=part['natural_state'];speed=np.full((len(part['timestamps']),x.shape[1]),np.nan)
    known=(x[:,:,12]>0)&(np.abs(x[:,:,13])<1e-6)&(x[:,:,8]>0)
    values=x[:,:,8].astype(float)*70
    speed[part['origins']-1]=np.where(known,values,np.nan)
    low=np.zeros_like(speed,bool)
    low[part['origins']-1]=known&(x[:,:,8]<=np.float32(30/70))
    return speed,np.isfinite(speed),low


def reconcile_labels(part,speed,known,low):
    origin=part['origins'];ids=origin[:,None]+np.arange(3)
    future_known=known[ids].all(axis=1)
    ambiguous=(np.abs(speed[ids]-30)<=PRECISION_BAND_MPH).any(axis=1)
    checked=future_known&~ambiguous&part['eligible']
    reconstructed=low[ids].all(axis=1)
    mismatch=np.argwhere(checked&(reconstructed!=part['truth']))
    return {'cached_origin_node_points':int(part['truth'].size),
        'eligible_points':int(part['eligible'].sum()),'three_future_cached_speeds_known':int(future_known.sum()),
        'eligible_precision_band_excluded':int((part['eligible']&future_known&ambiguous).sum()),
        'eligible_unrecoverable_points':int((part['eligible']&~future_known).sum()),
        'nonambiguous_eligible_points_checked':int(checked.sum()),
        'label_mismatches':int(len(mismatch)),
        'mismatch_row_node_keys':mismatch.tolist(),
        'known_future_but_original_ineligible_points':int((future_known&~part['eligible']).sum())}


def history_category(part,scenario,row,node):
    """Causal, cached own availability and last3 only; no future labels read."""
    x=part[scenario+'_state'];fresh=lambda i:bool(x[i,node,12]>0 and abs(x[i,node,13])<1e-6 and x[i,node,8]>0)
    last='unknown' if not fresh(row) else 'low' if x[row,node,8]<=np.float32(30/70) else 'high'
    if row<2:return last,'unknown'
    ids=part['origins'][row-2:row+1];times=part['timestamps'][ids]
    regular=np.all(np.diff(ids)==1) and np.all(np.diff(times)==np.timedelta64(5,'m'))
    if not regular or not all(fresh(i) for i in range(row-2,row+1)):return last,'unknown'
    sustained=all(x[i,node,8]<=np.float32(30/70) for i in range(row-2,row+1))
    return last,'last3_low' if sustained else 'last3_not_all_low'


def event_structure(part,speed,known,low):
    """Proxy event structure shared by scenarios; no merging or relabeling."""
    records=[]
    for seglo,seghi in layout(part)[0]:
        for node in range(part['truth'].shape[1]):
            for alo,ahi in runs(part['eligible'][seglo:seghi,node]):
                lo,hi=int(seglo+alo),int(seglo+ahi);prior=None
                for a,b in runs(part['truth'][lo:hi,node]):
                    s,e=int(lo+a),int(lo+b);complete=s-2>=lo and e<hi
                    gap=s-prior[1] if prior else None
                    # Last prior proxy positive ends at e-1 and covers speeds
                    # through e+1, so intervening high-speed samples start e+2.
                    bridge=np.arange(int(part['origins'][prior[1]-1])+3,int(part['origins'][s])) if prior else np.empty(0,int)
                    bridge_known=bool(len(bridge) and known[bridge,node].all())
                    highs=int((~low[bridge,node]).sum()) if bridge_known else None
                    records.append({'node':node,'start_row':s,'end_row':e,'event_start_origin':int(part['origins'][s]),
                        'proxy_positive_steps':e-s,'complete':bool(complete),
                        'preceding_proxy_event_gap_steps':gap,'bridge_speed_origin_indices':bridge.tolist(),
                        'bridge_cached_speeds_mph':speed[bridge,node].tolist() if bridge_known else None,
                        'bridge_all_known':bridge_known,'bridge_high_speed_samples':highs})
                    prior=(s,e)
    complete=[v for v in records if v['complete']]
    bins={'no_prior_proxy_run':0,'gap3':0,'gap4to6':0,'gap7to12':0,'gap_gt12':0,'other_gap':0}
    for e in complete:
        gap=e['preceding_proxy_event_gap_steps']
        label='no_prior_proxy_run' if gap is None else 'gap3' if gap==3 else 'gap4to6' if 4<=gap<=6 else 'gap7to12' if 7<=gap<=12 else 'gap_gt12' if gap>12 else 'other_gap'
        bins[label]+=1
    return {'complete_events':len(complete),'all_proxy_runs_including_censored':len(records),
        'preceding_gap_bins':bins,'gap3_with_known_single_high_speed':sum(e['preceding_proxy_event_gap_steps']==3 and e['bridge_high_speed_samples']==1 for e in complete),
        'records':records}


def warning_records(part,scenario,events):
    lookup={int(v):i for i,v in enumerate(part['origins'])};records=[]
    for event in events:
        if event['status']!='warned':continue
        a,s=lookup[event['alarm_start_origin']],lookup[event['event_start_origin']];node=event['node']
        natural=history_category(part,'natural',a,node);observed=history_category(part,scenario,a,node)
        history_time=part['timestamps'][part['origins'][a]-1]
        onset_time=part['timestamps'][part['origins'][s]];origin_time=part['timestamps'][part['origins'][a]]
        lastobslead=int((onset_time-history_time)/np.timedelta64(1,'m'))
        originlead=int((onset_time-origin_time)/np.timedelta64(1,'m'))
        assert event['lead_minutes']==lastobslead==5*(s-a+1)
        records.append({'node':int(node),'event_start_origin':int(event['event_start_origin']),
            'alarm_start_origin':int(event['alarm_start_origin']),'alarm_row':a,'event_row':s,
            'reported_proxy_lead_minutes':int(event['lead_minutes']),
            'proxy_start_minus_origin_clock_minutes':originlead,
            'proxy_start_minus_last_history_timestamp_minutes':lastobslead,
            'natural_last_observation':natural[0],'natural_last3_history':natural[1],
            'scenario_last_observation':observed[0],'scenario_last3_history':observed[1]})
    return records


def warning_summary(records):
    result={}
    for group,chosen in [('all_warned',records),('R10',[v for v in records if v['reported_proxy_lead_minutes']>=10]),
                         ('R15',[v for v in records if v['reported_proxy_lead_minutes']==15])]:
        result[group]={'records':len(chosen),'unique_events':len({(v['node'],v['event_start_origin']) for v in chosen}),
            **{f'{which}_{k}':sum(v[f'{which}_last_observation']==k for v in chosen) for which in ('natural','scenario') for k in ('low','high','unknown')},
            **{f'{which}_{k}':sum(v[f'{which}_last3_history']==k for v in chosen) for which in ('natural','scenario') for k in ('last3_low','last3_not_all_low','unknown')}}
    return result


def case_timeline(part,scores,choices,case):
    """Offline saved case: +/-6 origins around alarm start, never model input."""
    origin=case['with']['alarm_start_origin'];node=case['node'];speed,known,low=cached_speed(part)
    lookup={int(v):i for i,v in enumerate(part['origins'])};rows=[]
    for sample in range(max(0,origin-6),min(len(part['timestamps']),origin+7)):
        i=lookup.get(sample)
        rows.append({'speed_origin':sample,'timestamp':str(part['timestamps'][sample]),
            'cached_actual_speed_mph':float(speed[sample,node]) if known[sample,node] else None,
            'speed_known':bool(known[sample,node]),'actual_speed_low':bool(low[sample,node]) if known[sample,node] else None,
            'proxy_label':bool(part['truth'][i,node]) if i is not None else None,
            'proxy_eligible':bool(part['eligible'][i,node]) if i is not None else None,
            'global_probability':float(scores[i,node]) if i is not None else None,
            'activations':{m:bool(bits[i,node]) if i is not None else None for m,bits in choices.items()}})
    return {'node':node,'alarm_start_origin':origin,'proxy_event_start_origin':case['event_start_origin'],
        'reported_proxy_lead_minutes':case['with']['lead_minutes'],'rows':rows,
        'cached_precision_band_mph':PRECISION_BAND_MPH,'future_values_for_offline_diagnosis_only':True}


def freeze_plan():
    OUT.mkdir(exist_ok=True)
    names=['proxy_event_semantics.py','congestion_alert_pilot.py','congestion_objective_diagnostic.py',
        'congestion_onset_pilot.py','congestion_risk_pilot.py','pems_bay_alert_replay.py',
        'train_pems_bay_risk.py','calibration_fragility.py','early_warning_protection.py',
        'alarm_start_separability.py','complete_bypass_diagnosis.py',
        'outputs/pems-bay-risk/risk_train.npz','outputs/pems-bay-risk/risk_validation.npz',
        'outputs/pems-bay-risk/global_calibration.pt','outputs/pems-bay-risk/normalization.npz',
        'outputs/pems-bay-calibration/calibration.npz',
        'outputs/effective-alert-pilot-2026-10-16/effective_model.npz',
        'outputs/effective-alert-pilot-2026-10-16/training_freeze.json',
        'outputs/effective-alert-pilot-2026-10-16/activations.npz',
        'outputs/effective-alert-pilot-2026-10-16/results.json',
        'outputs/bypass-diagnosis-2026-10-16/audited_results.json']
    plan={'stage':'fixed_proxy_event_semantics_diagnosis','client_date':'2026-10-16',
        'frozen_at_utc':datetime.now(timezone.utc).isoformat(),
        'allowed':'original train28, validation7, calibration14 and independently replayed halves; reused development only',
        'forbidden':'original evaluation, rawHDF5, all consumed/new station transfer values',
        'fixed_methods':list(METHODS),'new_models':0,'optimizer_updates':0,'policy_or_label_changes':False,
        'lead_references':['last historical observation timestamp (existing definition)','origin timestamp (descriptive comparison)'],
        'offline_speed_source':'natural cached fresh own_last(t) equals original observed v(t-1); retain unknown gaps/tails',
        'reconstruction_precision_band_mph':PRECISION_BAND_MPH,
        'label_checks':'all3 known future cached speeds, eligible, outside precision band vs frozen truth; no imputation',
        'historical_classification':'natural and each scenario fresh last observation plus last3 low/high/unknown at credited warning start',
        'proxy_event_gap_bins':['no prior run','3','4..6','7..12','>12','other'],
        'episode_checks':'all credited/warned/late/false/duplicate/censored/unknown counts, false spans complete matching window',
        'selected_case':'all original-R10 cases restored by bypass identified in previous diagnosis; timeline alarm origin +/-6',
        'no_case_selection_by_this_round_outcome':True,
        'new_policy_or_acceptance_test':False,'independent_confirmation':False,
        'on_mismatch':'record mismatch, preserve outputs and investigate; do not overwrite old labels/scorer',
        'source_and_input_sha256':{n:common.sha(ROOT/n) for n in names}}
    if (OUT/'plan.json').exists():raise FileExistsError('Preserve prior semantics plan')
    common.write(OUT/'plan.json',plan);return plan


def main():
    sys.addaudithook(protection.guard);torch.set_num_threads(1)
    plan=freeze_plan();seal=common.read(previous.OUT/'training_freeze.json')
    assert common.sha(previous.OUT/'effective_model.npz')==seal['model_sha256']
    model=common.load(previous.OUT/'effective_model.npz');norm=common.load(common.RISK/'normalization.npz')
    anchor=load_risk(common.RISK/'global_calibration.pt')
    parts={'training28':common.load(common.RISK/'risk_train.npz'),
        'risk_validation7':common.load(common.RISK/'risk_validation.npz'),
        'calibration_full14':common.load(common.CAL/'calibration.npz')}
    parts.update({'calibration_week1_7':common.subset(parts['calibration_full14'],0,7),
        'calibration_week2_7':common.subset(parts['calibration_full14'],7,14)})
    old=common.read(previous.OUT/'results.json');active=common.load(previous.OUT/'activations.npz')
    bypass=common.read(ROOT/'outputs/bypass-diagnosis-2026-10-16/audited_results.json')
    blocks={};timelines={}
    for block,part in parts.items():
        speed,known,low=cached_speed(part);scores=common.global_scores(part,norm,anchor)
        blocks[block]={'label_reconstruction':reconcile_labels(part,speed,known,low),
            'shared_event_structure':event_structure(part,speed,known,low),'scenarios':{}}
        timelines[block]={}
        for scenario in SCENARIOS:
            p=scores[scenario]
            cred=probe.predict(model,probe.start_features(part,scenario,p).reshape(-1,30)).reshape(part['truth'].shape)
            choices={'global_c1':alarm(p,.46,1,part),
                'effective_no_bypass':protection.episode_gate(p,cred,part['origins'],part['timestamps'],seal['cutoff']),
                previous.PRIMARY:protection.episode_gate(p,cred,part['origins'],part['timestamps'],seal['cutoff'],protection.observed_past_low(part,scenario))}
            blocks[block]['scenarios'][scenario]={}
            for method,bits in choices.items():
                row,_,events=replay(part,bits,details=True);episodes=common.episodes(part,bits)
                warnings=warning_records(part,scenario,events)
                counts={k:sum(v['kind']==k for v in episodes) for k in ('warned','late','false','duplicate','censored','unknown')}
                if block!='training28':
                    np.testing.assert_array_equal(bits,active[f'{block}__{method}__{scenario}'])
                    assert row==old['evaluation'][block][method][scenario]
                blocks[block]['scenarios'][scenario][method]={'operating':row,'warning_history_summary':warning_summary(warnings),
                    'warning_records':warnings,'episode_type_counts':counts,
                    'false_start_spanning_later_complete_window':sum(e['early_spanning_complete_window'] for e in episodes),
                    'duplicate_episode_records':[e for e in episodes if e['kind']=='duplicate']}
            restored=[c for c in bypass['blocks'][block][scenario]['changed_events'] if c['restored_original_R10_identity_and_lead']]
            timelines[block][scenario]=[case_timeline(part,p,choices,c) for c in restored]
        print(block+': '+str({'labels':blocks[block]['label_reconstruction'],
            'proxy_gaps':blocks[block]['shared_event_structure']['preceding_gap_bins'],
            'natural_original_warnings':blocks[block]['scenarios']['natural']['global_c1']['warning_history_summary']}),flush=True)
    result={'blocks':blocks,'case_timelines':timelines,'model_sha256':seal['model_sha256'],'cutoff':seal['cutoff'],
        'new_models_fitted':0,'optimizer_updates':0,'policy_modified':False,'proxy_labels_changed':False,
        'original_thesis_primary_test_still_failed':True,'previous_candidate_acceptance_passed':old['primary_acceptance_passed'],
        'new_station_cohort_consumed':False,'consumed_transfer_values_used':False,'independent_confirmation':False,
        'offline_speed_reconstruction_not_online_input':True}
    common.write(OUT/'results.json',json_native(result))
    for n,h in plan['source_and_input_sha256'].items():assert common.sha(ROOT/n)==h,n
    common.write(OUT/'access_log.json',{'runtime_output_paths':sorted(set(common.READS)),
        'forbidden_values_used':False,'runtime_guard_enabled':True})
    common.write(OUT/'completion.json',{'completed_at_utc':datetime.now(timezone.utc).isoformat(),
        'plan_sha256':common.sha(OUT/'plan.json'),'artifacts':{n:common.sha(OUT/n) for n in ['results.json','access_log.json']}})


if __name__=='__main__':main()
