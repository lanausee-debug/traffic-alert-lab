"""Verify summary arithmetic and write an honest Chinese exploratory report."""
from pathlib import Path
import json
import platform
import numpy as np
import torch
import h5py
import matplotlib

ROOT=Path(__file__).resolve().parent
base=ROOT/"outputs/recovery-pilot"
main=json.loads((base/"results.json").read_text(encoding="utf-8"))
other=json.loads((ROOT/"outputs/recovery-pilot-no-residual/results.json").read_text(encoding="utf-8"))
provenance=json.loads((ROOT/"data/provenance.json").read_text(encoding="utf-8"))
for result in (main,other):
    curves=result["curves"]
    for row in curves:
        if not np.isclose(row["ongoing_outage_mae"]-row["failed_station_mae"],row["gain_vs_outage"],atol=2e-5):
            raise AssertionError("MAE and paired gains must use the same aggregation")
    if not np.isclose(curves[-1]["failed_station_mae"],curves[-1]["ideal_history_mae"],atol=1e-6):
        raise AssertionError("Full recovered window must match ideal-history diagnostic")
    if not np.isclose(curves[0]["gain_vs_outage"],0,atol=1e-6):
        raise AssertionError("No restored readings means no recovery gain")
if main["config"]["selected_sensor_ids"] != other["config"]["selected_sensor_ids"]:
    raise AssertionError("Ablation sensors differ")
if main["per_event"][0]["origin"] != other["per_event"][0]["origin"] or len(main["per_event"]) != len(other["per_event"]):
    raise AssertionError("Ablation events differ")
environment={"python":platform.python_version(),"torch":torch.__version__,"numpy":np.__version__,"h5py":h5py.__version__,"matplotlib":matplotlib.__version__,"device":"cpu"}
(base/"environment.json").write_text(json.dumps(environment,indent=2),encoding="utf-8")

rows="\n".join(f"| {r['recovered_minutes']} | {r['usable_new_slots']} | {r['failed_station_mae']:.3f} | {r['gain_vs_outage']:.3f} |" for r in main["curves"] if r["recovered_minutes"] in (0,5,10,20,30,45,60))
comparison="\n".join(f"| {name} | {r['curves'][0]['failed_station_mae']:.3f} | {r['curves'][-1]['failed_station_mae']:.3f} | {r['full_gain_fraction_available_at_10min']:.1%} | {r['remaining_gain_after_10min']:.3f} [{r['remaining_gain_after_10min_ci'][0]:.3f}, {r['remaining_gain_after_10min_ci'][1]:.3f}] |"
                      for name,r in (("含持久性残差（主实验）",main),("去掉持久性残差（探索性对照）",other)))
seed_rows="\n".join(f"| {r['seed']} | {r['outage_mae']:.3f} | {r['ideal_mae']:.3f} | {r['gain']:.3f} |" for r in main["per_seed_full_gain"])
gain_fraction=main["full_gain_fraction_available_at_10min"]
interpretation=("主实验中，前10分钟已经获得了至少90%的完整窗口收益；不能把‘必须等待一小时补满历史’作为已得到支持的核心机制。"
                if gain_fraction>=.9 else "主实验中，10分钟后的额外历史仍有可测的平均收益；其能否改变维修顺序还未检验。")
toy=main["scheduling_sanity"]
report=f"""# METR-LA 检测器观测恢复：小实验报告

**状态：已实际运行；真实交通速度＋人工单站缺测；探索性结果。没有训练或验证维修调度策略。**

## 主要结果

{interpretation}

完整60分钟窗口相对持续故障的平均MAE下降为 **{main['full_window_gain']:.3f}**（速度原始单位），探索性95%按日期重采样区间 **[{main['full_window_gain_ci'][0]:.3f}, {main['full_window_gain_ci'][1]:.3f}]**。{len(main['per_event'])}个案例中的正收益案例数实际为 **{main['events_with_positive_full_gain']}/{len(main['per_event'])}**，不保证每个站点、每个时刻都改善。

主实验累计平均曲线有 **{main['aggregate_error_increasing_steps']}** 个新增历史反而增加误差的步长，不支持收益必然单调回升。完整历史是诊断对照，并非最优预测的理论上界。

## 实验怎么做

- 24个检测器、42个日历日（2012年数据）；原始时间连续分为28天训练、7天验证、7天测试。
- 只在训练段选择可用率>=90%的传感器，再用固定随机种子抽取24个；原95%阈值在训练段无合格传感器，于模型训练前降低，未依据测试表现选点。
- 归一化、相关性邻接图只用训练段拟合。图为统计相关性图，并非地理路网。
- 固定图聚合＋时间MLP，CPU训练20轮，训练种子42/43/44。每个模型由验证集选择权重。
- 每次只有一个人工故障站，其他站保留原始观测与原始缺失。预测过去60分钟后的未来15分钟。
- 在同一预测时刻，依次恢复该站最近0、1、2……12个历史采样槽，未来目标和其他站输入不变。因此横轴代表假设该站提前多久完工，**不是不同预测时刻拼接成的真实恢复轨迹**。
- 原始零值/非有限值作为缺测；预测目标缺测时不计误差。预定测试7天中，实际能产生所选评测案例的日期为 **{len(main['test_days'])}天**，共 **{len(main['per_event'])}个案例**。模型种子先平均，再对每个可评日期等权聚合；区间按日期重采样，避免把重叠窗口当成独立样本。

## 主实验曲线

MAE越低越好；“收益”是相对同一时刻持续故障的MAE减少。数据原始速度单位未作换算。新增采样槽可能仍包含原始缺失。

| 已恢复分钟 | 可获得的新采样槽 | 故障站MAE | 相对持续故障的MAE收益 |
|---:|---:|---:|---:|
{rows}

![恢复曲线](recovery_curve.png)

## 模型结构对照

主模型含最近有效读数的持久性残差，因此恢复后快速获益可能与模型结构有关。看到主实验后增加了去掉残差的探索性对照；数据、归一化、图、故障案例、种子及训练轮数相同。不能将此补充分析描述为预注册验证。

| 模型 | 持续故障MAE | 完整窗口MAE | 10分钟获得的完整窗口收益比例 | 10到60分钟额外收益及95%区间 |
|---|---:|---:|---:|---:|
{comparison}

收益比例以各模型自己的完整窗口收益为分母。区间是探索性的，不能把本次小切片推广到所有预测器。

## 主实验随机种子

| 训练种子 | 持续故障MAE | 完整历史MAE | 完整历史收益 |
|---:|---:|---:|---:|
{seed_rows}

## 调度程序逻辑检查（与真实数据实验分开）

两站假设案例中，A维修2小时且每小时价值10；B维修1小时且价值起初为1、下一小时起为20；评价期4小时。

- 价值恒定时：A→B收益{toy['constant_values']['A_then_B']}，B→A收益{toy['constant_values']['B_then_A']}。
- B价值随时间变化时：A→B收益{toy['changing_B_value']['A_then_B']}，B→A收益{toy['changing_B_value']['B_then_A']}。

这只是人为构造的排序翻转与代码逻辑检查，**不是METR-LA上的维修策略实验，不是论文实证改善比例**。

## 对论文方向的含义

本次支持“恢复新读数能够改变该预测器的误差”；还没有证明观测积累能改变最佳维修顺序。根据收益集中程度，应谨慎把长时间渐进恢复作为主要创新。

下一步只有在需要继续验证题目时才扩展：相同滚动调度器下比较即时可分价值与恢复历史共同价值，并加入收益/工时、普通滚动调度强基线；检验多站联合故障的信息替代/互补。当前不能声称实际维修预算节省、拥堵管理改善或新的调度算法。

## 复现与来源

运行命令见项目README。主脚本为`recovery_pilot.py`，报告脚本为`summarize_pilot.py`。完整配置在`config.json`，逐案例结果在`episode_results.csv`，训练与指标在`results.json`，环境在`environment.json`。

原始项目：[DCRNN](https://github.com/liyaguang/DCRNN)。本次公开镜像：{provenance['mirror_url']}。

SHA-256：`{provenance['sha256']}`。

本报告没有预设效果大小验收阈值；结果用于决定研究方向，不作为确认性创新证据。
"""
(base/"report.zh-CN.md").write_text(report,encoding="utf-8")
print(f"Saved {base/'report.zh-CN.md'}")
print(json.dumps({"primary_10min_gain_fraction":gain_fraction,"ablation_10min_gain_fraction":other['full_gain_fraction_available_at_10min'],"actual_days":len(main['test_days']),"events":len(main['per_event'])},indent=2))
