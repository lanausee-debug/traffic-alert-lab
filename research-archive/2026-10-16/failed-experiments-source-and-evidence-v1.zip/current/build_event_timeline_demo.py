"""Build an offline teaching demo from already analyzed, sealed replay caches.

No HDF5 reads, model fitting, threshold search, or modification of v1 artifacts.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
METHODS = {
    'dense_speed': '预测速度', 'global_calibration': '全局校准',
    'group_calibration': '分组校准', 'state_logistic': '状态线性',
    'persistent_mlp': '持续 MLP', 'onset_linear': '起点线性', 'onset_mlp': '起点 MLP',
}
SCENARIOS = {'natural': '自然缺测', 'single_outage': '单站人工缺测', 'group_outage': '固定三站人工缺测'}
TEMPLATE = ROOT / 'demo/timeline.template.html'


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def runs(bits):
    edges = np.diff(np.r_[False, bits, False].astype(np.int8))
    return list(zip(np.flatnonzero(edges == 1), np.flatnonzero(edges == -1)))


def segments(origins, timestamps):
    breaks = np.flatnonzero((np.diff(origins) != 1) |
                           (np.diff(timestamps[origins]) != np.timedelta64(5, 'm'))) + 1
    return list(zip(np.r_[0, breaks], np.r_[breaks, len(origins)]))


def confirmed(scores, threshold, confirmation, origins, timestamps):
    above = scores >= threshold
    if confirmation == 1:
        return above
    if confirmation != 2:
        raise ValueError('Only frozen confirmation 1 or 2 is supported')
    bits = np.zeros_like(above)
    bits[1:] = above[1:] & above[:-1]
    for lo, _ in segments(origins, timestamps):
        bits[lo] = False
    return bits


def classify(truth, eligible, bits, origins, timestamps):
    """Classify on the FULL series, then crop; never rematch inside a demo window.

    Mirror the documented one-to-one convention, including boundary and
    ineligible intervals. Results must agree with sealed v1 event records.
    """
    events, alerts = [], []
    for seg_lo, seg_hi in segments(origins, timestamps):
        for node in range(truth.shape[1]):
            for left, right in runs(eligible[seg_lo:seg_hi, node]):
                lo, hi = int(seg_lo + left), int(seg_lo + right)
                complete, censored = [], []
                for left, right in runs(truth[lo:hi, node]):
                    s, e = int(lo + left), int(lo + right)
                    if s - 2 < lo or e == hi:
                        censored.append((s, e))
                    else:
                        rec = {'node': node, 'event_start_origin': int(origins[s]),
                               'event_end_origin_exclusive': int(origins[e - 1] + 1),
                               'status': 'missed', 'alarm_start_origin': None,
                               'lead_minutes': None, 'late_minutes': None}
                        complete.append((s, e, rec))
                        events.append(rec)
                used = set()
                for left, right in runs(bits[lo:hi, node]):
                    a, b = int(lo + left), int(lo + right)
                    rec = {'node': node, 'origin': int(origins[a]),
                           'end_origin_exclusive': int(origins[b - 1] + 1),
                           'event_start_origin': None}
                    alerts.append(rec)
                    if a == lo or b == hi:
                        rec['status'] = 'censored'
                        continue
                    if any(s - 2 <= a < e for s, e in censored):
                        rec['status'] = 'unknown'
                        continue
                    matches = [j for j, (s, e, _) in enumerate(complete) if s - 2 <= a < e]
                    unmatched = [j for j in matches if j not in used]
                    if unmatched:
                        j = unmatched[0]
                        used.add(j)
                        s, _, event = complete[j]
                        event['alarm_start_origin'] = int(origins[a])
                        rec['event_start_origin'] = int(origins[s])
                        if a <= s:
                            event['status'] = rec['status'] = 'warned'
                            event['lead_minutes'] = 5 * (s - a + 1)
                        else:
                            event['status'] = rec['status'] = 'late'
                            event['late_minutes'] = 5 * (a - s - 1)
                    elif matches:
                        rec['status'] = 'duplicate'
                    else:
                        rec['status'] = 'false'
    return events, alerts


def event_key(rec):
    return rec['node'], rec['event_start_origin'], rec['event_end_origin_exclusive']


def assert_records_match(generated, frozen):
    actual = {event_key(r): r for r in generated}
    expected = {event_key(r): r for r in frozen}
    if len(actual) != len(generated) or actual.keys() != expected.keys():
        raise ValueError('Event catalog differs from sealed records')
    for key, rec in actual.items():
        for field in rec:
            if rec[field] != expected[key][field]:
                raise ValueError(f'Event classification differs: {key}, {field}')


def plain(values, decimals=5):
    return np.round(np.asarray(values, dtype=np.float64), decimals).tolist()


def make_cases(records, catalogs):
    """Predefined coverage examples; earliest (origin, node), not best-looking.

    These are teaching examples selected AFTER evaluation, never an estimate
    or independent evidence. The full 83-day metrics remain in the demo.
    """
    cases = []
    tests = [
        ('warning10', '≥10 分钟预警', lambda r: r['status'] == 'warned' and r['lead_minutes'] >= 10),
        ('warning5', '5 分钟预警', lambda r: r['status'] == 'warned' and r['lead_minutes'] == 5),
        ('late', '迟报', lambda r: r['status'] == 'late'),
        ('missed', '没有告警的漏检', lambda r: r['status'] == 'missed' and not r['any_alarm_match_window']),
        ('spanning', '已开启却未匹配的漏检', lambda r: r['status'] == 'missed' and r['active_spanning_warning_window_entry']),
    ]
    for scenario in SCENARIOS:
        key = f'onset_mlp__fine__{scenario}'
        rows = sorted(records[key], key=lambda r: (r['event_start_origin'], r['node']))
        for category, title, predicate in tests:
            event = next((r for r in rows if predicate(r)), None)
            if event:
                cases.append({'id': f'{scenario}-{category}', 'title': title,
                              'selection_scenario': scenario, 'selection_method': 'onset_mlp',
                              'selection_category': category, 'anchor_kind': 'event',
                              'node': event['node'], 'anchor_origin': event['event_start_origin'],
                              'anchor_end': event['event_end_origin_exclusive']})
        first_false = min((r for r in catalogs[key] if r['status'] == 'false'),
                          key=lambda r: (r['origin'], r['node']), default=None)
        if first_false:
            cases.append({'id': f'{scenario}-false', 'title': '误报新开启',
                          'selection_scenario': scenario, 'selection_method': 'onset_mlp',
                          'selection_category': 'false', 'anchor_kind': 'alert',
                          'node': first_false['node'], 'anchor_origin': first_false['origin'],
                          'anchor_end': first_false['end_origin_exclusive']})
    return cases


def build(source):
    evaluation = source / 'outputs/pems-bay-evaluation'
    seal = read(evaluation / 'evaluation_results_freeze.json')
    result_path = evaluation / 'results.json'
    relative = 'outputs/pems-bay-evaluation/results.json'
    if sha(result_path) != seal['source_sha256'][relative]:
        raise ValueError('Evaluation result is no longer sealed')
    result = read(result_path)
    source_hashes = {relative: sha(result_path)}
    inputs = ('evaluation.npz', 'scores_evaluation.npz', 'event_records.json', 'selected_settings.json')
    for name in inputs:
        path = evaluation / name
        if sha(path) != result['artifact_sha256'][name]:
            raise ValueError(f'Evaluation artifact changed: {name}')
        source_hashes['outputs/pems-bay-evaluation/' + name] = sha(path)
    metadata_path = source / 'outputs/pems-bay-binding/metadata.json'
    binding = read(source / 'outputs/pems-bay-binding/binding.json')
    if sha(metadata_path) != binding['artifact_sha256']['metadata.json']:
        raise ValueError('Station metadata changed')
    metadata = read(metadata_path)
    source_hashes['outputs/pems-bay-binding/metadata.json'] = sha(metadata_path)
    source_hashes['outputs/pems-bay-evaluation/evaluation_results_freeze.json'] = sha(evaluation / 'evaluation_results_freeze.json')
    settings = read(evaluation / 'selected_settings.json')['settings']
    records = read(evaluation / 'event_records.json')
    with np.load(evaluation / 'evaluation.npz', allow_pickle=False) as cache:
        origins, timestamps, truth, eligible = [cache[k] for k in ('origins', 'timestamps', 'truth', 'eligible')]
        # Cached features, not raw speed: own_last /70, history coverage, age /12.
        histories = {s: cache[f'{s}_state'][:, :, [8, 12, 13]] for s in SCENARIOS}
        forecasts = {s: cache[f'{s}_predictions'].mean(axis=0) for s in SCENARIOS}
        faults = {s: cache[f'{s}_fault'] for s in SCENARIOS}
    with np.load(evaluation / 'scores_evaluation.npz', allow_pickle=False) as cache:
        scores = {k: cache[k] for k in cache.files}
    bits, catalogs, checks = {}, {}, []
    for method in METHODS:
        setting = settings[method]['fine']
        for scenario in SCENARIOS:
            key = f'{method}__fine__{scenario}'
            active = confirmed(scores[f'{method}__{scenario}'], setting['threshold'],
                               setting['confirmation'], origins, timestamps)
            events, alerts = classify(truth, eligible, active, origins, timestamps)
            assert_records_match(events, records[key])
            counted = Counter(r['status'] for r in alerts)
            metrics = result['evaluation'][method]['fine'][scenario]
            for status, metric in [('false', 'false'), ('duplicate', 'duplicate'),
                                   ('censored', 'censored_alerts'), ('unknown', 'unknown_alerts')]:
                if counted[status] != metrics[metric]:
                    raise ValueError(f'Full-series alert classification mismatch: {key}, {status}')
            bits[key], catalogs[key] = active, alerts
            checks.append({'key': key, 'complete_events_verified': len(events),
                           'alert_categories_verified': dict(counted)})
    cases = make_cases(records, catalogs)
    record_maps = {key: {(r['node'], r['event_start_origin']): r for r in rows} for key, rows in records.items()}
    for case in cases:
        node, anchor, end = case['node'], case['anchor_origin'], case['anchor_end']
        # Include the full anchor event/run plus 60 min before and 40 min after.
        rows = np.flatnonzero((origins >= anchor - 12) & (origins < end + 8))
        if not len(rows):
            raise ValueError('Empty teaching window')
        lo, hi = int(rows[0]), int(rows[-1]) + 1
        window = slice(lo, hi)
        case.update({'station_id': metadata['selected_ids'][node],
                     'origins': origins[window].tolist(),
                     'times': timestamps[origins[window]].astype('datetime64[m]').astype(str).tolist(),
                     'truth': truth[window, node].astype(int).tolist(),
                     'eligible': eligible[window, node].astype(int).tolist(),
                     'scenarios': {}})
        for scenario in SCENARIOS:
            history = histories[scenario][window, node]
            case_data = {'last_visible_speed': [round(float(v * 70), 4) if coverage > 0 else None
                                               for v, coverage, _ in history],
                         'coverage': plain(history[:, 1] * 100, 3),
                         'age_minutes': [round(float(age * 60), 3) if coverage > 0 else None
                                         for _, coverage, age in history],
                         'forecast': plain(forecasts[scenario][window, :, node], 4),
                         'fault': faults[scenario][window, node].astype(int).tolist(), 'methods': {}}
            for method in METHODS:
                key = f'{method}__fine__{scenario}'
                anchor_rec = record_maps[key].get((node, anchor)) if case['anchor_kind'] == 'event' else None
                case_data['methods'][method] = {
                    'scores': plain(scores[f'{method}__{scenario}'][window, node], 8),
                    # Decisions are EXACT saved-float comparisons; JS does not rethreshold rounded scores.
                    'alarm': bits[key][window, node].astype(int).tolist(),
                    'previous_alarm': bool(lo > 0 and bits[key][lo - 1, node]),
                    'alerts': [r for r in catalogs[key] if r['node'] == node and origins[lo] <= r['origin'] <= origins[hi - 1]],
                    'event_result': anchor_rec,
                }
            case['scenarios'][scenario] = case_data
    payload = {
        'version': 1, 'methods': METHODS, 'scenarios': SCENARIOS,
        'settings': {m: {k: settings[m]['fine'][k] for k in ('threshold', 'confirmation')} for m in METHODS},
        'cases': cases, 'metrics': {m: result['evaluation'][m]['fine'] for m in METHODS},
        'primary_comparisons': {k: v for k, v in result['comparisons'].items() if v['primary']},
        'verdict': result['verdict'], 'source_hashes': source_hashes,
        'provenance': {'dataset': 'PEMS-BAY', 'speed_unit': 'mph', 'evaluation_start': result['evaluation_dates'][0],
                       'evaluation_end': result['evaluation_dates'][-1], 'complete_events': 673,
                       'selection': 'First (origin,node) for each predefined onset-MLP fine/scenario outcome category; post-evaluation teaching examples.',
                       'fresh_independent_validation': False, 'raw_hdf5_decoded': False,
                       'models_trained': False, 'thresholds_scanned': False,
                       'raw_observation_series_included': False,
                       'speed_line': 'Most recent visible historical input from cached own_last/own_coverage/own_age features, not current raw truth.',
                       'artificial_group_is_geographic': False},
    }
    return payload, checks


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-root', type=Path, default=ROOT,
                        help='Project or completed pipeline workspace containing sealed outputs/')
    parser.add_argument('--check', action='store_true', help='Rebuild in memory and compare; do not overwrite')
    args = parser.parse_args()
    payload, checks = build(args.run_root.resolve())
    data = (json.dumps(payload, ensure_ascii=False, separators=(',', ':'), allow_nan=False) + '\n').encode('utf-8')
    template = TEMPLATE.read_text(encoding='utf-8')
    if template.count('__TIMELINE_DATA__') != 1:
        raise ValueError('Template needs exactly one data placeholder')
    # JSON script element cannot be terminated by text content.
    html = template.replace('__TIMELINE_DATA__', data.decode().replace('<', '\\u003c')).encode('utf-8')
    blobs = {'demo/data.json': data, 'demo/index.html': html}
    manifest = {'stage': 'offline_event_timeline_teaching_demo', 'fresh_independent_validation': False,
                'source_hashes': payload['source_hashes'],
                'builder_sha256': sha(Path(__file__)), 'template_sha256': sha(TEMPLATE),
                'case_selection': payload['provenance']['selection'], 'cases': len(payload['cases']),
                'fine_operating_points_verified': len(checks), 'full_series_checks': checks,
                'files': {name: {'bytes': len(blob), 'sha256': hashlib.sha256(blob).hexdigest()} for name, blob in blobs.items()}}
    blobs['demo/demo_manifest.json'] = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    for name, blob in blobs.items():
        path = ROOT / name
        if args.check:
            if not path.exists() or path.read_bytes() != blob:
                raise ValueError(f'Demo differs: {name}')
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(blob)
    print(json.dumps({'demo': str(ROOT / 'demo/index.html'), 'cases': len(payload['cases']),
                      'full_series_operating_points_checked': len(checks), 'html_bytes': len(html),
                      'mode': 'checked' if args.check else 'built', 'fresh_validation': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()
