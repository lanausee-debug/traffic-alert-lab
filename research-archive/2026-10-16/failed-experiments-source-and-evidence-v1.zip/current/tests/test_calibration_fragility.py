"""Causality, boundaries and false-episode attribution for development diagnosis."""
import copy
from pathlib import Path
import sys
import unittest
import json
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from calibration_fragility import causal_residual,episodes,subset,guard,grouped_exposure,probability_summary
from pems_bay_alert_replay import replay,alarm
from complete_calibration_fragility import scalar


def fixture(n=24):
    ts=np.datetime64('2017-01-01')+np.arange(n)*np.timedelta64(5,'m')
    p={'timestamps':ts,'origins':np.arange(n),'truth':np.zeros((n,1),bool),'eligible':np.ones((n,1),bool)}
    x=np.zeros((n,1,51),np.float32);x[:,:,0]=40/70;x[:,:,8]=35/70;x[:,:,12]=1
    p['natural_state']=x
    return p


class CalibrationFragilityTest(unittest.TestCase):
    def test_residual_uses_prior_forecast_and_current_available_history(self):
        p=fixture();r=causal_residual(p,'natural')
        self.assertTrue(np.isnan(r[0,0]))
        np.testing.assert_allclose(r[1:],5,atol=1e-5)
        q=copy.deepcopy(p);q['truth'][:]=True
        q['natural_state'][7:,:,0]=1e5
        before=causal_residual(p,'natural');after=causal_residual(q,'natural')
        np.testing.assert_array_equal(before[:8],after[:8])
        self.assertGreater(after[8,0],1e5)

    def test_hidden_old_observation_and_clock_gap_never_form_residual(self):
        p=fixture();p['natural_state'][3,0,12]=0
        p['natural_state'][5,0,13]=1/12
        p['timestamps'][8:]+=np.timedelta64(5,'m')
        r=causal_residual(p,'natural')
        for index in (0,3,5,8):self.assertTrue(np.isnan(r[index,0]))
        self.assertTrue(np.isfinite(r[9,0]))

    def test_episode_start_rule_false_early_span_duplicate_and_censoring(self):
        p=fixture();p['truth'][8:13]=True
        active=np.zeros_like(p['truth']);active[1:7]=True;active[9:10]=True;active[11:12]=True;active[18:19]=True
        records=episodes(p,active);row,_,_=replay(p,active,details=True)
        self.assertEqual(sum(r['kind']=='false' for r in records),row['false'])
        self.assertEqual(sum(r['kind']=='duplicate' for r in records),row['duplicate'])
        self.assertEqual(sum(r['early_spanning_complete_window'] for r in records),1)
        self.assertEqual(row['false'],2)
        active[0:7]=True
        self.assertEqual(episodes(p,active)[0]['kind'],'censored')

    def test_episode_scorer_count_parity_with_gaps_and_invalid_targets(self):
        p=fixture(60);p['truth'][8:15]=True;p['truth'][25:34]=True;p['truth'][43:48]=True
        p['eligible'][28:31]=False;p['timestamps'][40:]+=np.timedelta64(10,'m')
        rng=np.random.default_rng(17)
        for _ in range(20):
            active=rng.random(p['truth'].shape)<.35
            row,_,_=replay(p,active,details=True)
            records=episodes(p,active)
            for kind,key in [('false','false'),('duplicate','duplicate'),('unknown','unknown_alerts'),('censored','censored_alerts'),('warned','warned'),('late','late')]:
                self.assertEqual(sum(r['kind']==kind for r in records),row[key])

    def test_week_subset_preserves_mapping_and_resets_confirmation(self):
        p=fixture(600);p['natural_predictions']=np.zeros((3,600,3,1))
        q=subset(p,1,2)
        self.assertEqual(q['origins'][0],288);self.assertEqual(q['origins'][-1],575)
        self.assertEqual(q['natural_predictions'].shape,(3,288,3,1))
        self.assertTrue(np.isnan(causal_residual(q,'natural')[0,0]))
        active=alarm(np.ones(q['truth'].shape),.5,2,q)
        self.assertFalse(active[0,0]);self.assertTrue(active[1,0])

    def test_group_exposure_empty_groups_and_total_conservation(self):
        p=fixture();active=np.zeros_like(p['truth']);active[3:4]=True
        rows=grouped_exposure(p,np.zeros_like(active,int),episodes(p,active),['all','empty'])
        self.assertEqual(rows['all']['false_episode_starts'],1)
        self.assertIsNone(rows['empty']['false_per_valid_station_day'])
        self.assertAlmostEqual(rows['all']['exposure_station_days'],24/288)

    def test_probability_bin_edges_and_target_validity(self):
        p=fixture(4);p['truth'][2:]=True;p['eligible'][0]=False
        v=np.array([[.0],[.1],[.9],[1.]])
        r=probability_summary(p,v)
        self.assertEqual(sum(b['rows'] for b in r['bins']),3)
        self.assertEqual(r['bins'][9]['rows'],2)
        self.assertAlmostEqual(r['brier'],(.1**2+.1**2)/3)
        self.assertFalse(r['event_false_budget_guarantee'])

    def test_forbidden_reads(self):
        for path in ('C:/p/data/raw/pems-bay.h5','C:/p/outputs/pems-bay-evaluation/evaluation.npz',
            'C:/p/outputs/new-station-transfer-2026-10-15/evaluation_features.npz'):
            with self.assertRaises(PermissionError):guard('open',(path,'rb',0))
        guard('open',('C:/p/outputs/pems-bay-risk/risk_validation.npz','rb',0))

    def test_recovery_serializer_preserves_numpy_scalar_types(self):
        value={'row':np.int64(3),'flag':np.bool_(True),'value':np.float32(2.5)}
        self.assertEqual(json.loads(json.dumps(value,default=scalar)),{'row':3,'flag':True,'value':2.5})
        with self.assertRaises(TypeError):scalar(object())


if __name__=='__main__':unittest.main()
