"""Checks for identity-free feature selection and safe model development."""
import copy
from pathlib import Path
import sys
import unittest
import numpy as np
import torch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from station_agnostic_risk import KEEP, StationAgnosticRisk, inputs, guard
from congestion_risk_pilot import RiskModel
from congestion_alert_pilot import SCENARIOS


class AgnosticRiskTest(unittest.TestCase):
    def setUp(self):
        rng=np.random.default_rng(20)
        self.part={s+'_state':rng.normal(size=(5,3,51)).astype(np.float32) for s in SCENARIOS}
        self.part.update({s+'_single':rng.normal(size=(5,3)).astype(np.float32) for s in SCENARIOS})
        self.part['common']=rng.random((5,3))>.3
        self.norm={'mean':np.arange(51)*.1,'std':np.arange(51)*.02+1.,
            'single_mean':np.array([.1]),'single_std':np.array([2.])}
        self.anchor=RiskModel(1,False)

    def test_identity_changed_to_arbitrary_values_is_ignored(self):
        before=inputs(self.part,self.norm,self.anchor)
        for s in SCENARIOS:self.part[s+'_state'][:,:,24:48]=1e6
        after=inputs(self.part,self.norm,self.anchor)
        for s in SCENARIOS:np.testing.assert_array_equal(before[s],after[s])

    def test_station_permutation_equivariance_of_risk_inputs_and_outputs(self):
        before=inputs(self.part,self.norm,self.anchor)
        perm=[2,0,1]
        for s in SCENARIOS:
            for suffix in ('_state','_single'):self.part[s+suffix]=self.part[s+suffix][:,perm]
        after=inputs(self.part,self.norm,self.anchor)
        model=StationAgnosticRisk(1.)
        with torch.no_grad():model.residual.layers[-1].weight.fill_(.2)
        for s in SCENARIOS:
            np.testing.assert_array_equal(after[s].reshape(5,3,28),before[s].reshape(5,3,28)[:,perm])
            a=model(torch.tensor(after[s])).detach().numpy().reshape(5,3)
            b=model(torch.tensor(before[s])).detach().numpy().reshape(5,3)[:,perm]
            np.testing.assert_allclose(a,b,atol=1e-6)

    def test_feature_indices_and_original_train_scaling(self):
        self.assertEqual(KEEP.tolist(),list(range(24))+[48,49,50])
        actual=inputs(self.part,self.norm,self.anchor)['natural'][:,:27]
        expected=((self.part['natural_state'].reshape(-1,51)[:,KEEP]-self.norm['mean'][KEEP])/self.norm['std'][KEEP]).astype(np.float32)
        np.testing.assert_array_equal(actual,expected)
        pooled=inputs(self.part,self.norm,self.anchor,True)
        self.assertEqual(pooled.shape,(3*int(self.part['common'].sum()),28))

    def test_future_labels_and_common_mask_not_used_at_inference(self):
        before=inputs(self.part,self.norm,self.anchor)
        self.part['truth']=np.ones((5,3),bool)
        self.part['onset']=np.ones((5,3),bool)
        self.part['common'][:]=False
        after=inputs(self.part,self.norm,self.anchor)
        for s in SCENARIOS:np.testing.assert_array_equal(before[s],after[s])

    def test_exact_initial_anchor_bound_and_parameters(self):
        x=torch.randn(40,28);model=StationAgnosticRisk(.5)
        self.assertEqual(sum(p.numel() for p in model.parameters()),1441)
        self.assertTrue(torch.equal(model(x),x[:,-1]))
        with torch.no_grad():model.residual.layers[-1].bias.fill_(1e6)
        self.assertLessEqual(float((model(x)-x[:,-1]).abs().max().detach()),.500001)
        with self.assertRaises(ValueError):model(torch.randn(4,52))

    def test_loss_reaches_residual_parameters(self):
        model=StationAgnosticRisk(1.);x=torch.randn(40,28)
        optimizer=torch.optim.Adam(model.parameters(),lr=.001)
        before=copy.deepcopy(model.state_dict())
        optimizer.zero_grad()
        torch.nn.functional.binary_cross_entropy_with_logits(model(x),torch.ones(40)).backward()
        optimizer.step()
        self.assertFalse(torch.equal(before['residual.layers.4.bias'],model.state_dict()['residual.layers.4.bias']))

    def test_forbidden_partition_guard(self):
        for path in ('C:/x/data/raw/pems-bay.h5','C:/x/outputs/pems-bay-evaluation/evaluation.npz',
                     'C:/x/outputs/new-station-transfer-2026-10-15/results.json',
                     'C:/x/outputs/anchored-risk-2026-10-15/historical-replay/daily.npz',
                     'C:/x/outputs/station-agnostic-transfer-2026-10-15/evaluation_features.npz'):
            with self.assertRaises(PermissionError):guard('open',(path,'rb',0))
        guard('open',('C:/x/outputs/pems-bay-calibration/calibration.npz','rb',0))


if __name__=='__main__':unittest.main()
