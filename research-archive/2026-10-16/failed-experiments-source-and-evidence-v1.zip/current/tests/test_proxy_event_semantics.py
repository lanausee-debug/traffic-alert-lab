"""Proxy label, clock convention, reconstruction and interruption examples."""
from pathlib import Path
import sys
import unittest
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import proxy_event_semantics as pilot
from congestion_alert_pilot import labels,SCENARIOS
from calibration_fragility import episodes
from pems_bay_alert_replay import replay


def fixture(raw=None):
    raw=np.full((65,1),60.,float) if raw is None else np.asarray(raw,float).reshape(-1,1)
    valid=np.isfinite(raw)&(raw>0);origins=np.arange(12,len(raw)-2)
    truth,eligible,_=labels(raw,valid,origins,np.ones(len(origins),bool))
    p={'origins':origins,'timestamps':np.datetime64('2017-01-01')+np.arange(len(raw))*np.timedelta64(5,'m'),
        'truth':truth,'eligible':eligible}
    for s in SCENARIOS:
        x=np.zeros((len(origins),1,51),np.float32)
        x[:,:,8]=np.where(valid[origins-1],raw[origins-1]/70,0)
        x[:,:,12]=valid[origins-1];x[:,:,13]=(~valid[origins-1]).astype(float)
        p[s+'_state']=x
    return p


class ProxySemanticsTest(unittest.TestCase):
    def test_one_high_observation_makes_three_negative_proxy_labels(self):
        raw=np.full(65,25.);raw[27]=40.;p=fixture(raw)
        lookup={int(t):i for i,t in enumerate(p['origins'])}
        self.assertTrue(p['truth'][lookup[24],0]);self.assertTrue(p['truth'][lookup[28],0])
        self.assertFalse(p['truth'][lookup[25]:lookup[28],0].any())

    def test_prior_low_then_one_high_can_still_receive_R15_for_restart(self):
        raw=np.full(65,60.);raw[20:27]=25.;raw[28:35]=25.;p=fixture(raw)
        bits=np.zeros_like(p['truth']);bits[p['origins']==26]=True
        _,_,events=replay(p,bits,details=True)
        records=pilot.warning_records(p,'natural',events)
        self.assertEqual(len(records),1);r=records[0]
        self.assertEqual(r['event_start_origin'],28);self.assertEqual(r['reported_proxy_lead_minutes'],15)
        self.assertEqual(r['natural_last3_history'],'last3_low')
        self.assertEqual(r['proxy_start_minus_origin_clock_minutes'],10)
        self.assertEqual(r['proxy_start_minus_last_history_timestamp_minutes'],15)

    def test_cached_speed_shift_tail_and_label_reconciliation(self):
        raw=np.arange(65)+10.;p=fixture(raw);v,k,low=pilot.cached_speed(p)
        np.testing.assert_allclose(v[11:62,0],raw[11:62],atol=1e-5)
        self.assertFalse(k[:11].any());self.assertFalse(k[62:].any())
        self.assertEqual(pilot.reconcile_labels(p,v,k,low)['label_mismatches'],0)

    def test_precision_band_is_explicit_and_does_not_relabel(self):
        raw=np.full(65,30.);p=fixture(raw);before=p['truth'].copy()
        v,k,low=pilot.cached_speed(p);r=pilot.reconcile_labels(p,v,k,low)
        self.assertGreater(r['eligible_precision_band_excluded'],0)
        self.assertEqual(r['nonambiguous_eligible_points_checked'],0)
        np.testing.assert_array_equal(p['truth'],before)

    def test_unknown_observation_not_filled_or_labeled_negative(self):
        raw=np.full(65,25.);raw[24]=np.nan;p=fixture(raw);v,k,low=pilot.cached_speed(p)
        self.assertFalse(k[24,0]);self.assertTrue(np.isnan(v[24,0]))
        row=int(np.flatnonzero(p['origins']==25)[0])
        self.assertEqual(pilot.history_category(p,'natural',row,0),('unknown','unknown'))

    def test_single_high_speed_bridge_and_censored_event_separation(self):
        raw=np.full(65,60.);raw[20:27]=25.;raw[28:35]=25.;p=fixture(raw)
        summary=pilot.event_structure(p,*pilot.cached_speed(p))
        self.assertEqual(summary['complete_events'],2)
        self.assertEqual(summary['preceding_gap_bins']['gap3'],1)
        self.assertEqual(summary['gap3_with_known_single_high_speed'],1)
        second=summary['records'][1]
        self.assertEqual(second['bridge_speed_origin_indices'],[27])
        self.assertAlmostEqual(second['bridge_cached_speeds_mph'][0],60.,places=4)

    def test_clock_gap_prevents_historical_three_consecutive_claim(self):
        raw=np.full(65,25.);p=fixture(raw);p['timestamps'][27:]+=np.timedelta64(5,'m')
        row=int(np.flatnonzero(p['origins']==27)[0])
        self.assertEqual(pilot.history_category(p,'natural',row,0),('low','unknown'))

    def test_history_summary_does_not_read_future_or_labels(self):
        raw=np.full(65,25.);p=fixture(raw);row=12
        before=pilot.history_category(p,'natural',row,0)
        p['truth'][:]=False;p['eligible'][:]=False;p['natural_state'][row+1:]=999
        self.assertEqual(pilot.history_category(p,'natural',row,0),before)

    def test_too_early_alarm_spanning_warning_window_still_counts_false(self):
        raw=np.full(65,60.);raw[30:40]=25.;p=fixture(raw)
        bits=((p['origins']>=26)&(p['origins']<34))[:,None]
        row,_,events=replay(p,bits,details=True)
        self.assertEqual(row['false'],1);self.assertEqual(events[0]['status'],'missed')
        self.assertTrue(events[0]['any_alarm_match_window'])
        self.assertTrue(episodes(p,bits)[0]['early_spanning_complete_window'])

    def test_two_alarm_starts_for_one_proxy_event_make_one_duplicate(self):
        raw=np.full(65,60.);raw[30:40]=25.;p=fixture(raw)
        bits=((p['origins']==29)|(p['origins']==34))[:,None]
        row,_,events=replay(p,bits,details=True)
        self.assertEqual(row['warned'],1);self.assertEqual(row['duplicate'],1)
        self.assertEqual(events[0]['lead_minutes'],10)

    def test_boundary_proxy_run_remains_censored(self):
        raw=np.full(65,60.);raw[12:20]=25.;p=fixture(raw)
        bits=(p['origins']==15)[:,None]
        row,_,events=replay(p,bits,details=True)
        self.assertEqual(row['events'],0);self.assertEqual(row['censored_events'],1)
        self.assertEqual(row['unknown_alerts'],1);self.assertEqual(events,[])


if __name__=='__main__':unittest.main()
