"""Lineage taxonomy, identity protection and episode accounting edge cases."""
from pathlib import Path
import sys
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import event_lineage_attribution as pilot


def run(node,s,e,complete=True):
    return {'node':node,'start_row':s,'end_row':e,'event_start_origin':s+12,
        'event_end_origin_exclusive':e+12,'complete':complete}


def link():
    old=[run(0,10,15),run(0,18,24),run(1,5,12),run(2,25,29)]
    new=[run(0,10,24),run(1,0,12,False),run(2,25,29)]
    indices=[0,0,1,2]
    return {'old_to_new':[{'old':a,'new':new[j],'new_run_index':j} for a,j in zip(old,indices)],
        'new_runs':new,'old_runs':old}


def event(node,origin,status,lead=None):
    return {'node':node,'event_start_origin':origin,'status':status,'lead_minutes':lead}


def episode(row,kind,node=0,group=None):
    return {'node':node,'row':row,'length_steps':1,'kind':kind,'event_group':group,'early_spanning_complete_window':False}


class LineageAttributionTest(unittest.TestCase):
    def test_first_reentry_and_censored_parent_are_distinct(self):
        groups=pilot.group_events(link())
        self.assertEqual([v['group'] for v in groups['one_high'].values()],
            ['first_segment','reentry_segment','parent_censored','first_segment'])
        self.assertEqual([v['group'] for v in groups['two_high'].values()],
            ['multi_segment_process','single_segment_process'])

    def test_empty_group_rates_remain_undefined(self):
        m=pilot.metrics([])
        self.assertEqual(m['events'],0);self.assertIsNone(m['R10_recall']);self.assertIsNone(m['detection_recall'])

    def test_identity_lead_delay_is_not_hidden_by_same_R10(self):
        catalog=pilot.group_events(link())['one_high']
        before=[event(0,22,'late'),event(0,30,'missed'),event(1,17,'warned',15),event(2,37,'warned',10)]
        after=[event(0,22,'missed'),event(0,30,'warned',15),event(1,17,'warned',10),event(2,37,'warned',10)]
        d=pilot.event_comparison(before,after,catalog,pilot.GROUPS['one_high'])
        self.assertEqual(d['groups']['first_segment']['lost_detection'],1)
        self.assertEqual(d['groups']['reentry_segment']['recovered_detection'],1)
        self.assertEqual(d['groups']['parent_censored']['R10_lost'],0)
        self.assertEqual(d['groups']['parent_censored']['original_R10_lost_or_delayed'],1)

    def test_duplicates_get_event_group_false_does_not_get_false_denominator(self):
        catalog=pilot.group_events(link())['one_high']
        tagged=pilot.tag_episodes([episode(20,'duplicate'),episode(36,'false')],catalog)
        self.assertEqual(tagged[0]['event_group'],'reentry_segment')
        self.assertIsNone(tagged[1]['event_group']);self.assertIsNone(tagged[1]['matched_window_event_key'])

    def test_shared_episode_reclassification_is_not_added_alarm(self):
        a=[episode(8,'late','0')];b=[episode(8,'duplicate','0'),episode(20,'warned','0')]
        d=pilot.episode_comparison(a,b)
        self.assertEqual(d['net_episode_count_change'],1)
        self.assertEqual(d['added_episode_types']['warned'],1)
        self.assertEqual(d['added_episode_types']['duplicate'],0)
        self.assertEqual(d['net_type_changes']['duplicate'],1)
        self.assertEqual(d['net_type_changes']['late'],-1)

    def test_same_activations_can_have_fewer_false_and_more_duplicates(self):
        a=[episode(8,'false'),episode(20,'warned')]
        b=[episode(8,'late'),episode(20,'duplicate')]
        d=pilot.definition_episode_transition(a,b)
        self.assertEqual(d['episode_count_unchanged'],2)
        self.assertEqual(d['kind_transition_matrix']['false']['late'],1)
        self.assertEqual(d['kind_transition_matrix']['warned']['duplicate'],1)

    def test_distinct_event_sets_are_not_silently_compared(self):
        catalog=pilot.group_events(link())['one_high']
        with self.assertRaises(AssertionError):pilot.event_comparison([],[],catalog,pilot.GROUPS['one_high'])


if __name__=='__main__':unittest.main()
