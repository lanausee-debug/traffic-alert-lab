"""Checks for cohort selection, sealed partitions and paired-count arithmetic."""
from pathlib import Path
import sys
import types
import unittest

import h5py
import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from new_station_transfer import choose_ids,validate_request,speed_guard,differences,DATA
from evaluate_station_transfer import unknown_identity


class NewStationTransferTest(unittest.TestCase):
    def test_unseen_identity_never_reuses_a_development_station_slot(self):
        rng=np.random.default_rng(3)
        part={scenario+'_state':rng.normal(size=(5,24,51)).astype(np.float32)
              for scenario in ('natural','single_outage','group_outage')}
        before={key:value.copy() for key,value in part.items()}
        names=['feature'+str(i) for i in range(24)]+['node'+str(i) for i in range(24)]+['a','b','c']
        unknown_identity(part,names)
        for key in part:
            self.assertTrue(np.array_equal(part[key][...,:24],before[key][...,:24]))
            self.assertTrue(np.array_equal(part[key][...,48:],before[key][...,48:]))
            self.assertTrue(np.all(part[key][...,24:48]==0))
        with self.assertRaises(ValueError):unknown_identity(part,['wrong']*51)

    def test_cohort_selection_is_value_free_disjoint_and_order_invariant(self):
        ids=[str(400000+i) for i in range(60)];excluded=ids[::3]
        first=choose_ids(ids,excluded)
        self.assertEqual(first,choose_ids(list(reversed(ids)),list(reversed(excluded))))
        self.assertEqual(len(first),24)
        self.assertFalse(set(first)&set(excluded))
        with self.assertRaises(ValueError):choose_ids(ids,ids[:-20])

    def test_partition_seal_rejects_other_splits_and_partial_slices(self):
        bounds={'forecast_train':(0,10),'forecast_validation':(10,14),'risk_train':(14,18),'evaluation':(20,30)}
        validate_request('train','forecast_train',0,10,bounds,False)
        validate_request('evaluate','evaluation',20,30,bounds,False)
        for stage,partition,lo,hi,consumed in (
            ('train','evaluation',20,30,False),('evaluate','forecast_train',0,10,False),
            ('train','risk_train',14,18,False),('evaluate','evaluation',20,29,False),
            ('evaluate','evaluation',20,30,True),('plan','forecast_train',0,10,False)):
            with self.assertRaises(PermissionError):validate_request(stage,partition,lo,hi,bounds,consumed)

    def test_runtime_guard_rejects_development_columns_and_unbounded_reads(self):
        reader=types.SimpleNamespace(stage='train',bounds={'forecast_train':(0,10),'forecast_validation':(10,14)},columns=np.array([2,7]))
        dataset=types.SimpleNamespace(name='/speed/block0_values',file=types.SimpleNamespace(filename=str(DATA)))
        trace=[]
        with speed_guard(reader,trace):
            for key in ((slice(None),np.array([2,7])),(slice(0,10),np.array([0,2])),
                        (slice(0,11),np.array([2,7])),slice(None)):
                with self.assertRaises(PermissionError):h5py.Dataset.__getitem__(dataset,key)
        self.assertEqual(trace,[])

    def test_paired_bootstrap_uses_counts_and_same_dates_for_all_scenarios(self):
        reference=np.zeros((3,12,13),np.float64);candidate=reference.copy()
        reference[:,:,0]=candidate[:,:,0]=24
        reference[:,:,1]=candidate[:,:,1]=2
        reference[:,:,11]=1;candidate[:,:,11]=2
        reference[:,:,3]=1;candidate[:,:,3]=2
        reference[:,:,4]=2;candidate[:,:,4]=1
        draws=np.random.default_rng(1).integers(0,12,(2000,12))
        out=differences(candidate,reference,draws)
        self.assertAlmostEqual(out['R10']['difference'],.5)
        self.assertAlmostEqual(out['detection']['difference'],.5)
        self.assertAlmostEqual(out['false_rate']['difference'],-1/24)
        for key in out:
            self.assertEqual(out[key]['undefined_draws'],0)
            self.assertAlmostEqual(out[key]['conditional_ci95'][0],out[key]['difference'])
            self.assertAlmostEqual(out[key]['conditional_ci95'][1],out[key]['difference'])

    def test_undefined_denominators_do_not_become_fabricated_zero_rates(self):
        rows=np.zeros((3,12,13),np.float64)
        draws=np.zeros((2000,12),np.int64)
        out=differences(rows,rows,draws)
        for key in out:
            self.assertIsNone(out[key]['difference'])
            self.assertIsNone(out[key]['conditional_ci95'])
            self.assertEqual(out[key]['undefined_draws'],2000)


if __name__=='__main__':unittest.main()
