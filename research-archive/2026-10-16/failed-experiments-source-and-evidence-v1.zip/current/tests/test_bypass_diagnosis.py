"""Targeted checks for the diagnostic's timing, event recovery and raw intervals."""
from pathlib import Path
import sys
import unittest
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from tests.test_effective_alert_pilot import fixture
from bypass_diagnosis import diagnose,causal_context,context_bins
from complete_bypass_diagnosis import json_native
from audit_bypass_diagnosis import correct_context_units


class BypassDiagnosisTest(unittest.TestCase):
    def inputs(self):
        p=fixture();p['natural_state'][:,:,8]=np.float32(25/70)
        score=np.zeros((40,1));cred=np.full((40,1),.2)
        return p,score,cred

    def test_bypass_recovers_original_early_event_and_retains_false(self):
        p,s,c=self.inputs();s[7:10]=.8;s[20:21]=.8
        d,no,yes=diagnose(p,'natural',s,c,.4)
        self.assertEqual(d['summary']['added_raw_runs'],2)
        self.assertEqual(d['summary']['restored_original_R10'],1)
        self.assertEqual(d['summary']['recovered_detections'],1)
        self.assertEqual(d['summary']['added_scored_fragment_types']['false'],1)
        self.assertEqual(d['changed_events'][0]['bypass_raw_run_indices'],[0])
        self.assertFalse(no.any());self.assertTrue(yes[7,0])

    def test_gap_prevents_using_three_discontinuous_observations(self):
        p,s,c=self.inputs();p['timestamps'][7:]+=np.timedelta64(5,'m');s[7:9]=.8
        d,_,yes=diagnose(p,'natural',s,c,.4)
        self.assertEqual(d['summary']['added_raw_runs'],0);self.assertFalse(yes.any())

    def test_no_midrun_rescue(self):
        p,s,c=self.inputs();p['natural_state'][5:7,:,8]=.6;s[7:13]=.8
        d,_,yes=diagnose(p,'natural',s,c,.4)
        self.assertEqual(d['summary']['added_raw_runs'],0);self.assertFalse(yes.any())

    def test_raw_decision_is_separate_from_eligible_fragment(self):
        p,s,c=self.inputs();p['eligible'][7:9]=False;s[7:11]=.8
        d,_,_=diagnose(p,'natural',s,c,.4)
        self.assertEqual(d['added_runs'][0]['row'],7)
        self.assertEqual(d['added_runs'][0]['scored_fragments'][0]['row'],9)
        self.assertEqual(d['added_runs'][0]['scored_fragments'][0]['kind'],'censored')

    def test_context_excludes_future_values_labels_and_eligibility(self):
        p,s,c=self.inputs();a=causal_context(p,'natural',s,c,7,0,.4)
        p['truth'][:]=~p['truth'];p['eligible'][:]=False
        p['natural_state'][8:]=999;s[8:]=.9;c[8:]=.9
        p['natural_state'][:,:,24:48]=10000
        self.assertEqual(a,causal_context(p,'natural',s,c,7,0,.4))

    def test_fixed_strata_boundaries(self):
        context={'past_residual_mph':5,'forecast5_mph':30,'forecast10_mph':29,'forecast15_mph':30,'score_deficit':.05}
        self.assertEqual(context_bins(context),{'residual':'[0,5]','forecast_all_low':'all<=30','score_deficit':'<=0.05'})
        context['past_residual_mph']=None;context['forecast15_mph']=30.01
        self.assertEqual(context_bins(context)['residual'],'missing')
        self.assertEqual(context_bins(context)['forecast_all_low'],'some>30')

    def test_offline_numpy_records_are_json_serializable(self):
        import json
        value={'records':[{'origin':np.int64(7),'lead':np.float64(10),'recovered':np.bool_(True)}]}
        self.assertEqual(json.loads(json.dumps(json_native(value),allow_nan=False)),
            {'records':[{'origin':7,'lead':10,'recovered':True}]})

    def test_std_units_follow_source_schema_and_preserve_original(self):
        original={'blocks':{'a':{'s':{'added_runs':[{'context':{'own_std_mph':17.5,'forecast_seed_std5_mph':3.5}}]}}}}
        fixed=correct_context_units(original)
        self.assertEqual(fixed['blocks']['a']['s']['added_runs'][0]['context'],{'own_std_mph':5.,'forecast_seed_std5_mph':1.})
        self.assertEqual(original['blocks']['a']['s']['added_runs'][0]['context']['own_std_mph'],17.5)


if __name__=='__main__':unittest.main()
