"""Recovery semantics, label alignment, shared evidence and lineage checks."""
from pathlib import Path
import sys
import unittest
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from tests.test_proxy_event_semantics import fixture
import recovery_definition_sensitivity as pilot


class RecoveryDefinitionTest(unittest.TestCase):
    def build(self,raw):
        p=fixture(raw);speed,low,support,info=pilot.evidence_support(p)
        a,ra=pilot.recovery_truth(p,support,low,1);b,rb=pilot.recovery_truth(p,support,low,2)
        return p,support,a,b,ra,rb

    def test_one_high_reproduces_original_three_reading_target(self):
        rng=np.random.default_rng(5);raw=rng.choice([25.,35.,60.],size=65)
        p,s,a,b,_,_=self.build(raw)
        np.testing.assert_array_equal(a[s],p['truth'][s]);self.assertFalse((a&~b).any())

    def test_one_high_bridge_merges_two_original_proxy_events(self):
        raw=np.full(65,60.);raw[20:27]=25.;raw[28:35]=25.
        p,s,a,b,_,_=self.build(raw);d=pilot.lineage(p,a,b,s)
        self.assertEqual(d['old_complete_events'],2);self.assertEqual(d['new_complete_events'],1)
        self.assertEqual(d['new_runs_with_multiple_old_runs'],1)
        self.assertEqual(d['new_runs'][0]['event_start_origin'],20)
        self.assertEqual(d['new_runs'][0]['event_end_origin_exclusive'],33)

    def test_two_consecutive_highs_keep_events_separate(self):
        raw=np.full(65,60.);raw[20:27]=25.;raw[29:36]=25.
        p,s,a,b,_,_=self.build(raw);d=pilot.lineage(p,a,b,s)
        self.assertEqual(d['old_complete_events'],2);self.assertEqual(d['new_complete_events'],2)
        self.assertEqual(d['new_runs_with_multiple_old_runs'],0)

    def test_alternating_recovery_is_not_mistaken_for_consecutive_highs(self):
        raw=np.full(65,60.);raw[20:27]=25.;raw[28]=25.;raw[30:37]=25.
        p,s,a,b,_,_=self.build(raw);d=pilot.lineage(p,a,b,s)
        self.assertEqual(d['old_complete_events'],2);self.assertEqual(d['new_complete_events'],1)

    def test_support_gap_cannot_be_bridged(self):
        raw=np.full(65,60.);raw[20:27]=25.;raw[28:35]=25.
        p,s,a,b,_,_=self.build(raw);s[p['origins']==26]=False
        b,_=pilot.recovery_truth(p,s,pilot.evidence_support(p)[1],2)
        runs=pilot.proxy_runs(p,b,s)
        self.assertEqual(len(runs),2);self.assertFalse(b[p['origins']==26].any())

    def test_pending_recovery_is_right_censored(self):
        raw=np.full(65,60.);raw[20:]=25.
        p,s,a,b,_,rb=self.build(raw)
        self.assertFalse(rb[-1]['end_confirmed'])
        self.assertFalse(pilot.proxy_runs(p,b,s)[-1]['complete'])

    def test_precision_band_and_cache_tail_are_shared_unknowns(self):
        raw=np.full(65,25.);raw[27]=30.;p=fixture(raw)
        speed,low,s,info=pilot.evidence_support(p)
        self.assertEqual(info['original_eligible_known_but_precision_band'],3)
        self.assertFalse(s[np.isin(p['origins'],[25,26,27])].any())
        self.assertFalse(s[-3:].any())

    def test_event_definition_has_no_prediction_or_alarm_input(self):
        raw=np.full(65,25.);p,s,a,b,_,_=self.build(raw)
        low=pilot.evidence_support(p)[1]
        p['natural_state'][:]=999;p['truth'][:]=False;p['scores']=np.ones_like(s)*1e8
        np.testing.assert_array_equal(b,pilot.recovery_truth(p,s,low,2)[0])

    def test_no_unplanned_recovery_count(self):
        p=fixture();speed,low,s,_=pilot.evidence_support(p)
        with self.assertRaises(ValueError):pilot.recovery_truth(p,s,low,3)


if __name__=='__main__':unittest.main()
