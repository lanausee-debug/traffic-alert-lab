"""Available inputs, chronological probes, tie-correct metrics and task labels."""
from pathlib import Path
import sys
import unittest
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from alarm_start_separability import (start_features,build_samples,binary_metrics,
    fit_probe,predict,retention_threshold,retention_metrics,separation_gate)
from calibration_fragility import guard
from congestion_alert_pilot import SCENARIOS


def fixture(n=40):
    part={'origins':np.arange(n),'timestamps':np.datetime64('2017-01-01')+np.arange(n)*np.timedelta64(5,'m'),
        'truth':np.zeros((n,1),bool),'eligible':np.ones((n,1),bool)}
    rng=np.random.default_rng(31)
    for s in SCENARIOS:
        x=rng.normal(size=(n,1,51)).astype(np.float32);x[:,:,12]=1;x[:,:,13]=0
        part[s+'_state']=x
    return part


class SeparabilityTest(unittest.TestCase):
    def test_features_ignore_truth_validity_identity_and_future_values(self):
        p=fixture();prob=np.full((40,1),.7)
        first=start_features(p,'natural',prob)
        p['truth'][:]=True;p['eligible'][:]=False;p['natural_state'][:,:,24:48]=1e5
        np.testing.assert_array_equal(first,start_features(p,'natural',prob))
        p['natural_state'][25:]=1e6;prob[25:]=.999
        np.testing.assert_array_equal(first[:25],start_features(p,'natural',prob)[:25])

    def test_residual_missing_and_clipping_are_explicit(self):
        p=fixture();p['natural_state'][:,:,0]=1e5;p['natural_state'][:,:,8]=0
        p['natural_state'][4,0,12]=0
        x=start_features(p,'natural',np.full((40,1),.6))
        self.assertEqual(x.shape,(40,1,30))
        self.assertEqual(x[0,0,27],0);self.assertEqual(x[0,0,28],1)
        self.assertEqual(x[1,0,27],20);self.assertEqual(x[1,0,28],0)
        self.assertEqual(x[4,0,28],1)

    def test_offline_task_excludes_late_duplicate_and_censored_starts(self):
        p=fixture();p['truth'][8:13]=True;p['truth'][28:34]=True
        probs={s:np.zeros((40,1)) for s in SCENARIOS}
        for value in probs.values():
            value[0:1]=.8;value[7:10]=.8;value[11:12]=.8;value[20:21]=.8;value[30:31]=.8
        data,counts=build_samples(p,probs)
        for s in SCENARIOS:
            self.assertEqual(data[s]['row'].tolist(),[7,20])
            self.assertEqual(data[s]['y'].tolist(),[1,0])
            self.assertEqual(data[s]['lead_minutes'].tolist(),[10,-1])
            self.assertEqual(counts[s]['duplicate'],1);self.assertEqual(counts[s]['late'],1)
            self.assertEqual(counts[s]['censored'],1)

    def test_metrics_handle_ties_without_artificial_constant_score_AP(self):
        y=np.array([1,0,1,0]);p=np.array([.9,.9,.2,.1])
        m=binary_metrics(y,p)
        self.assertAlmostEqual(m['roc_auc'],.625)
        self.assertAlmostEqual(m['average_precision'],7/12)
        m=binary_metrics(y,np.full(4,.5))
        self.assertEqual(m['roc_auc'],.5);self.assertEqual(m['average_precision'],.5)

    def test_one_class_and_empty_metrics_are_not_filled_as_success(self):
        self.assertIsNone(binary_metrics(np.zeros(3),np.ones(3))['roc_auc'])
        self.assertIsNone(binary_metrics(np.zeros(3),np.ones(3))['average_precision'])
        self.assertIsNone(binary_metrics(np.array([]),np.array([]))['bce'])

    def test_retention_cutoff_is_training_only_tie_safe(self):
        y=np.ones(20,int);p=np.arange(20)/20
        threshold=retention_threshold(y,p)
        self.assertEqual(threshold,.05)
        self.assertGreaterEqual(np.mean(p>=threshold),.95)
        self.assertEqual(retention_threshold(y,np.full(20,.2)),.2)
        rows={'y':np.array([1,1,0]),'lead_minutes':np.array([10,5,-1])}
        retained=retention_metrics(rows,np.array([.01,.9,.01]),threshold)
        self.assertEqual(retained['R10_credited_starts_retained'],0)
        self.assertFalse(retained['alarm_service_effect_measured'])

    def test_probe_converges_and_prediction_never_refits_normalization(self):
        rng=np.random.default_rng(3);x=rng.normal(size=(80,30));y=(x[:,0]+rng.normal(size=80)*.4>0).astype(float)
        model,record=fit_probe(x,y,[0,1])
        np.testing.assert_allclose(model['mean'],x[:,:2].mean(axis=0))
        self.assertLessEqual(record['max_abs_gradient'],1e-6)
        before=model['mean'].copy();predict(model,x*1e6)
        np.testing.assert_array_equal(before,model['mean'])

    def test_all_time_blocks_and_strongest_baseline_gate_are_required(self):
        def metric(auc,ap):return {'roc_auc':auc,'average_precision':ap,'credited_warnings':20,'false_starts':20}
        blocks={name:{'state_logistic':metric(.8,.8),'fixed_risk':metric(.6,.6),
            'score_logistic':metric(.6,.6),'residual_logistic':metric(.7,.7)} for name in ('a','b','c')}
        self.assertTrue(separation_gate(blocks)['passed'])
        blocks['c']['residual_logistic']['average_precision']=.9
        self.assertFalse(separation_gate(blocks)['passed'])
        blocks['c']['residual_logistic']['average_precision']=.7
        blocks['b']['state_logistic']['credited_warnings']=3
        self.assertFalse(separation_gate(blocks)['passed'])

    def test_forbidden_test_and_raw_sources_remain_closed(self):
        for path in ('C:/p/data/raw/pems-bay.h5','C:/p/outputs/pems-bay-evaluation/evaluation.npz',
                     'C:/p/outputs/new-station-transfer-2026-10-15/evaluation_features.npz'):
            with self.assertRaises(PermissionError):guard('open',(path,'rb',0))


if __name__=='__main__':unittest.main()
