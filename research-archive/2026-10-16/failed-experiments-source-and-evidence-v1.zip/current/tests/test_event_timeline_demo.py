"""Check the edge cases that would make a cropped teaching replay misleading."""
from pathlib import Path
import sys
import unittest

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from build_event_timeline_demo import classify, confirmed


class EventTimelineTests(unittest.TestCase):
    def arrays(self, count=22):
        origins = np.arange(count)
        times = np.datetime64('2017-04-09T23:10') + origins * np.timedelta64(5, 'm')
        truth = np.zeros((count, 1), bool)
        truth[8:12] = True
        return origins, times, truth, np.ones_like(truth), np.zeros_like(truth)

    def test_proxy_lead_and_zero_minute_late_are_distinct(self):
        for start, status, lead, delay in [(6, 'warned', 15, None), (7, 'warned', 10, None),
                                          (8, 'warned', 5, None), (9, 'late', None, 0)]:
            origins, times, truth, eligible, alarm = self.arrays()
            alarm[start:start + 1] = True
            events, alerts = classify(truth, eligible, alarm, origins, times)
            self.assertEqual((events[0]['status'], events[0]['lead_minutes'], events[0]['late_minutes']),
                             (status, lead, delay))
            self.assertEqual(alerts[0]['status'], status)

    def test_spanning_alarm_stays_missed_and_early_open_is_false(self):
        origins, times, truth, eligible, alarm = self.arrays()
        alarm[3:12] = True
        events, alerts = classify(truth, eligible, alarm, origins, times)
        self.assertEqual(events[0]['status'], 'missed')
        self.assertEqual(alerts[0]['status'], 'false')
        self.assertTrue(alarm[6:12].all())

    def test_second_opening_is_duplicate_not_false(self):
        origins, times, truth, eligible, alarm = self.arrays()
        alarm[6:8] = True
        alarm[10:11] = True
        events, alerts = classify(truth, eligible, alarm, origins, times)
        self.assertEqual(events[0]['alarm_start_origin'], 6)
        self.assertEqual([r['status'] for r in alerts], ['warned', 'duplicate'])

    def test_boundary_and_unknown_alerts_are_not_false(self):
        origins, times, truth, eligible, alarm = self.arrays()
        truth[:] = False
        truth[:4] = True  # Censored truth interval at the eligibility boundary.
        alarm[1:2] = True
        alarm[-2:] = True  # Alarm runs into the right boundary.
        events, alerts = classify(truth, eligible, alarm, origins, times)
        self.assertEqual(events, [])
        self.assertEqual([r['status'] for r in alerts], ['unknown', 'censored'])

    def test_confirmation_resets_at_clock_gap_but_not_midnight(self):
        origins, times, truth, _, _ = self.arrays()
        scores = np.ones_like(truth, float)
        continuous = confirmed(scores, .5, 2, origins, times)
        self.assertFalse(continuous[0, 0])
        self.assertTrue(continuous[10, 0])  # Midnight itself is not a reset.
        times[10:] += np.timedelta64(30, 'm')
        interrupted = confirmed(scores, .5, 2, origins, times)
        self.assertFalse(interrupted[10, 0])
        self.assertTrue(interrupted[11, 0])

    def test_natural_invalid_region_is_not_an_online_filter(self):
        origins, times, truth, eligible, alarm = self.arrays()
        alarm[4:5] = True
        eligible[4:5] = False
        events, alerts = classify(truth, eligible, alarm, origins, times)
        self.assertTrue(alarm[4, 0])  # Online activation preserved.
        self.assertEqual(alerts, [])  # Not a scored false alarm.
        self.assertEqual(events[0]['status'], 'missed')

    def test_raw_precision_controls_activation_not_display_rounding(self):
        origins, times, truth, _, _ = self.arrays()
        scores = np.full_like(truth, .165 - 1e-10, dtype=np.float64)
        self.assertEqual(round(float(scores[0, 0]), 8), .165)
        self.assertFalse(confirmed(scores, .165, 1, origins, times).any())


if __name__ == '__main__':
    unittest.main()
