"""Cache allowlist, frozen fitting, and date-weighted discrimination statistics."""
from pathlib import Path
import sys
import unittest
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from frozen_probe_transfer import (weighted_discrimination,date_paired_bootstrap,guard,
    prohibit_refit,ROOT,INPUT_NAMES,OUT)
from alarm_start_separability import binary_metrics


class FrozenTransferTest(unittest.TestCase):
    def test_weighted_metrics_equal_explicit_date_sample_replication(self):
        y=np.array([1,0,1,0,1]);p=np.array([.8,.8,.4,.1,.4]);weights=np.array([2,3,0,1,2])
        actual=weighted_discrimination(y,p,weights)
        expected=binary_metrics(np.repeat(y,weights),np.repeat(p,weights))
        self.assertAlmostEqual(actual['roc_auc'],expected['roc_auc'])
        self.assertAlmostEqual(actual['average_precision'],expected['average_precision'])

    def test_ties_and_zero_weight_thresholds_are_handled(self):
        y=np.array([1,0,1,0]);p=np.array([.9,.8,.2,.1])
        row=weighted_discrimination(y,p,np.array([0,0,2,3]))
        self.assertEqual(row['roc_auc'],1.);self.assertEqual(row['average_precision'],1.)
        row=weighted_discrimination(y,np.full(4,.5),np.array([1,2,1,2]))
        self.assertEqual(row['roc_auc'],.5);self.assertAlmostEqual(row['average_precision'],1/3)

    def test_one_class_and_invalid_weights_do_not_create_success(self):
        row=weighted_discrimination([1,0],[.5,.4],[1,0])
        self.assertIsNone(row['roc_auc']);self.assertIsNone(row['average_precision'])
        with self.assertRaises(ValueError):weighted_discrimination([1,0],[.5,.4],[1,-1])
        with self.assertRaises(ValueError):weighted_discrimination([1,0],[.5,.4],[1,np.nan])

    def test_paired_date_draws_preserve_same_day_observations(self):
        rows={'y':np.array([1,0,1,0]),'date':np.array(['d0','d0','d1','d1'])}
        p=np.array([.9,.2,.8,.1]);q=np.array([.1,.8,.2,.9])
        draws=np.array([[0,0],[1,1],[0,1]])
        result=date_paired_bootstrap(rows,p,q,['d0','d1'],draws)
        self.assertEqual(result['roc_auc']['difference'],1.)
        self.assertEqual(result['roc_auc']['conditional_ci95'],[1.,1.])
        # An inverse ranking has AUC0 but AP above0; check explicit date expansion.
        expected=[]
        for draw in draws:
            ids=np.concatenate([np.flatnonzero(rows['date']==f'd{day}') for day in draw])
            a=binary_metrics(rows['y'][ids],p[ids]);b=binary_metrics(rows['y'][ids],q[ids])
            expected.append(a['average_precision']-b['average_precision'])
        self.assertAlmostEqual(result['average_precision']['difference'],7/12)
        np.testing.assert_allclose(result['average_precision']['conditional_ci95'],np.quantile(expected,[.025,.975]))

    def test_undefined_draws_are_reported_without_silent_deletion(self):
        rows={'y':np.array([1,0]),'date':np.array(['d0','d1'])}
        p=np.array([.8,.2]);q=np.array([.2,.8]);draws=np.array([[0,0],[0,1]])
        result=date_paired_bootstrap(rows,p,q,['d0','d1'],draws)
        for row in result.values():
            self.assertEqual(row['undefined_draws'],1);self.assertIsNone(row['conditional_ci95'])

    def test_only_declared_cache_reads_allowed_inputs_never_written(self):
        declared=str(ROOT/INPUT_NAMES[2])
        guard('open',(declared,'rb',0))
        with self.assertRaises(PermissionError):guard('open',(declared,'wb',0))
        for path in (str(ROOT/'data/raw/pems-bay.h5'),
            str(ROOT/'outputs/pems-bay-evaluation/evaluation.npz'),
            str(ROOT/'outputs/unknown-new-cohort/evaluation_features.npz')):
            with self.assertRaises(PermissionError):guard('open',(path,'rb',0))
        guard('open',(str(OUT/'unit-only-output.json'),'w',0))

    def test_fitting_or_recalibration_entrypoint_is_rejected(self):
        with self.assertRaises(PermissionError):prohibit_refit()


if __name__=='__main__':unittest.main()
