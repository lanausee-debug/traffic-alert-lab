"""Causal online state, gap handling, and jointly protected service constraints."""
from pathlib import Path
import sys
import unittest
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from adaptive_confirmation import adaptive_alarm,block_gate,paired_counts
from calibration_fragility import causal_residual,guard
from pems_bay_alert_replay import alarm,replay


def clock(n):return np.arange(n),np.datetime64('2017-01-01')+np.arange(n)*np.timedelta64(5,'m')


class AdaptiveConfirmationTest(unittest.TestCase):
    def test_only_new_starts_confirm_existing_alarms_do_not_fragment(self):
        scores=np.array([.1,.6,.6,.6,.1,.6,.6])[:,None]
        residual=np.array([0,6,6,10,0,0,8.])[:,None]
        origins,ts=clock(7)
        out=adaptive_alarm(scores,residual,origins,ts)
        self.assertEqual(out[:,0].tolist(),[False,False,True,True,False,True,True])

    def test_no_large_residual_and_missing_residual_equal_original_c1(self):
        rng=np.random.default_rng(13);scores=rng.random((40,3));origins,ts=clock(40)
        for residual in (np.zeros_like(scores),np.full_like(scores,np.nan)):
            np.testing.assert_array_equal(adaptive_alarm(scores,residual,origins,ts),scores>=.46)

    def test_always_large_residual_equals_global_c2(self):
        rng=np.random.default_rng(8);scores=rng.random((50,2));origins,ts=clock(50)
        out=adaptive_alarm(scores,np.full_like(scores,6.),origins,ts)
        expected=alarm(scores,.46,2,{'origins':origins,'timestamps':ts})
        np.testing.assert_array_equal(out,expected)

    def test_clock_and_origin_gaps_reset_pending_and_ongoing(self):
        origins,ts=clock(7);ts[3:]+=np.timedelta64(5,'m')
        out=adaptive_alarm(np.ones((7,1)),np.full((7,1),8.),origins,ts)
        self.assertEqual(out[:,0].tolist(),[False,True,True,False,True,True,True])
        origins=np.array([0,1,3,4,5]);ts=np.datetime64('2017-01-01')+np.arange(6)*np.timedelta64(5,'m')
        out=adaptive_alarm(np.ones((5,1)),np.full((5,1),8.),origins,ts)
        self.assertEqual(out[:,0].tolist(),[False,True,False,True,True])

    def test_strict_residual_cutoff_and_inclusive_score_threshold(self):
        origins,ts=clock(3)
        out=adaptive_alarm(np.full((3,2),.46),np.tile([5.,5.0001],(3,1)),origins,ts)
        self.assertEqual(out[0].tolist(),[True,False])

    def test_one_step_confirmation_can_lose_10minute_warning_without_losing_detection(self):
        origins,ts=clock(20)
        truth=np.zeros((20,1),bool);truth[8:12]=True
        part={'origins':origins,'timestamps':ts,'truth':truth,'eligible':np.ones_like(truth)}
        scores=np.zeros((20,1));scores[7:10]=.8
        residual=np.zeros_like(scores);residual[7]=6
        before=replay(part,scores>=.46,details=True)[0]
        after=replay(part,adaptive_alarm(scores,residual,origins,ts),details=True)[0]
        self.assertEqual(before['detection_recall'],after['detection_recall'])
        self.assertEqual(before['warning_recall_at_least10'],1.)
        self.assertEqual(after['warning_recall_at_least10'],0.)

    def test_future_input_changes_do_not_change_prefix(self):
        rng=np.random.default_rng(9);scores=rng.random((40,3));residual=rng.normal(5,2,(40,3));origins,ts=clock(40)
        before=adaptive_alarm(scores,residual,origins,ts)
        scores[21:]=1;residual[21:]=1e6
        after=adaptive_alarm(scores,residual,origins,ts)
        np.testing.assert_array_equal(before[:21],after[:21])

    def test_residual_ignores_future_labels_and_unavailable_observation(self):
        origins,ts=clock(5);x=np.zeros((5,2,51),np.float32)
        x[:,:,12]=1;x[:,:,0]=.6;x[:,:,8]=.5
        part={'origins':origins,'timestamps':ts,'natural_state':x,'truth':np.zeros((5,2),bool)}
        before=causal_residual(part,'natural');part['truth'][:]=True
        np.testing.assert_array_equal(before,causal_residual(part,'natural'))
        part['natural_state'][2,0,12]=0
        self.assertTrue(np.isnan(causal_residual(part,'natural')[2,0]))

    def test_false_reduction_cannot_override_warning_or_detection_loss(self):
        scenarios=('natural','single_outage','group_outage')
        reference={s:{'false_per_valid_station_day':.1,'warning_recall_at_least10':.2,'detection_recall':.8} for s in scenarios}
        candidate={s:dict(reference[s],false_per_valid_station_day=.05) for s in scenarios}
        self.assertTrue(block_gate(candidate,reference)['passed'])
        candidate['natural']['warning_recall_at_least10']=.19
        self.assertFalse(block_gate(candidate,reference)['passed'])
        candidate['natural']['warning_recall_at_least10']=.2
        candidate['group_outage']['detection_recall']=.77
        self.assertFalse(block_gate(candidate,reference)['passed'])
        candidate['group_outage']['detection_recall']=None
        self.assertFalse(block_gate(candidate,reference)['defined'])

    def test_count_bootstrap_handles_undefined_without_zero_imputation(self):
        a=np.zeros((3,10,13));draws=np.zeros((2000,10),int)
        for value in paired_counts(a,a,draws).values():
            self.assertIsNone(value['difference']);self.assertIsNone(value['ci95'])
            self.assertEqual(value['undefined_draws'],2000)

    def test_invalid_inputs_and_forbidden_reads_rejected(self):
        origins,ts=clock(4)
        with self.assertRaises(ValueError):adaptive_alarm(np.ones((4,2)),np.zeros((4,1)),origins,ts)
        with self.assertRaises(ValueError):adaptive_alarm(np.full((4,1),np.nan),np.zeros((4,1)),origins,ts)
        for path in ('C:/p/data/raw/pems-bay.h5','C:/p/outputs/pems-bay-evaluation/evaluation.npz',
                     'C:/p/outputs/new-station-transfer-2026-10-15/evaluation_features.npz'):
            with self.assertRaises(PermissionError):guard('open',(path,'rb',0))


if __name__=='__main__':unittest.main()
