"""Expanded target labels, unchanged scaling, and training-only early protection."""
from pathlib import Path
import sys
import unittest
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from effective_alert_pilot import build_training,fit_effective,training_cutoff
from alarm_start_separability import start_features,predict
from early_warning_protection import guard
from congestion_alert_pilot import SCENARIOS


def fixture(n=40):
    p={'origins':np.arange(n),'timestamps':np.datetime64('2017-01-01')+np.arange(n)*np.timedelta64(5,'m'),
       'truth':np.zeros((n,1),bool),'eligible':np.ones((n,1),bool)}
    p['truth'][8:13]=True;p['truth'][28:34]=True
    for s in SCENARIOS:
        x=np.zeros((n,1,51),np.float32);x[:,:,12]=1;x[:,:,8]=.5;p[s+'_state']=x
    return p


class EffectiveAlertTest(unittest.TestCase):
    def test_late_and_warned_are_positive_false_negative_duplicates_excluded(self):
        p=fixture();prob={s:np.zeros((40,1)) for s in SCENARIOS}
        for v in prob.values():v[0:1]=.8;v[7:10]=.8;v[11:12]=.8;v[20:21]=.8;v[30:31]=.8
        samples,counts=build_training(p,prob)
        self.assertEqual(samples['kind'].tolist(),['warned','false','late']*3)
        self.assertEqual(samples['y'].tolist(),[1,0,1]*3)
        self.assertEqual(samples['lead_minutes'].tolist(),[10,-1,0]*3)
        self.assertEqual(counts['natural']['duplicate'],1);self.assertEqual(counts['natural']['censored'],1)

    def test_future_labels_identity_and_target_fields_never_enter_features(self):
        p=fixture();prob=np.full((40,1),.8)
        first=start_features(p,'natural',prob)
        p['truth'][:]=True;p['eligible'][:]=False;p['natural_state'][:,:,24:48]=1e6
        p['lead_minutes']=np.full((40,1),1000)
        np.testing.assert_array_equal(first,start_features(p,'natural',prob))

    def test_fixed_original_training_normalization_preserved(self):
        rng=np.random.default_rng(9);x=rng.normal(size=(90,30));y=(x[:,0]+rng.normal(size=90)*.5>0).astype(int)
        old={'indices':np.arange(30),'mean':np.full(30,.2),'std':np.full(30,1.4)}
        model,rec=fit_effective({'x':x,'y':y},old)
        np.testing.assert_array_equal(model['mean'],old['mean']);np.testing.assert_array_equal(model['std'],old['std'])
        self.assertEqual(rec['parameters'],31);self.assertLessEqual(rec['max_abs_gradient'],1e-6)
        before=model['mean'].copy();predict(model,x*1e6);np.testing.assert_array_equal(before,model['mean'])

    def test_one_training_class_is_infeasible(self):
        old={'indices':np.arange(30),'mean':np.zeros(30),'std':np.ones(30)}
        with self.assertRaises(ValueError):fit_effective({'x':np.zeros((5,30)),'y':np.ones(5)},old)

    def test_cutoff_preserves_early_and_95pct_all_effective_training_starts(self):
        model={'indices':np.array([0]),'mean':np.array([0.]),'std':np.array([1.]),'weight':np.array([1.]),'bias':np.array([0.])}
        x=np.arange(24)[:,None]/10-1
        y=np.r_[np.ones(20),np.zeros(4)];kind=np.array(['late']*24,dtype='<U6');kind[0]='warned'
        rows={'x':x,'y':y,'kind':kind,'lead_minutes':np.r_[15,np.zeros(23)]}
        cutoff,rec=training_cutoff(rows,model);p=predict(model,x)
        self.assertTrue(np.all(p[(kind=='warned')]>=cutoff));self.assertGreaterEqual(np.mean(p[y==1]>=cutoff),.95)
        self.assertFalse(rec['later_values_used'])

    def test_no_training_early_warning_does_not_fabricate_cutoff(self):
        model={'indices':np.array([0]),'mean':np.array([0.]),'std':np.array([1.]),'weight':np.array([1.]),'bias':np.array([0.])}
        rows={'x':np.zeros((3,1)),'y':np.array([1,1,0]),'kind':np.array(['late','late','false']),'lead_minutes':np.array([0,0,-1])}
        with self.assertRaises(ValueError):training_cutoff(rows,model)

    def test_evaluation_and_transfer_sources_stay_forbidden(self):
        for path in ('C:/p/data/raw/pems-bay.h5','C:/p/outputs/pems-bay-evaluation/evaluation.npz',
          'C:/p/outputs/new-station-transfer-2026-10-15/evaluation_features.npz',
          'C:/p/outputs/frozen-probe-transfer-2026-10-15/results.json'):
            with self.assertRaises(PermissionError):guard('open',(path,'rb',0))


if __name__=='__main__':unittest.main()
