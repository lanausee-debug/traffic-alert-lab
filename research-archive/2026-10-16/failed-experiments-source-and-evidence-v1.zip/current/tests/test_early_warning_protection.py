"""Training early constraint and causality of full-episode suppression/bypass."""
from pathlib import Path
import sys
import unittest
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from early_warning_protection import (protected_cutoff,observed_past_low,episode_gate,protect_original_events,guard)
from pems_bay_alert_replay import alarm


def fixture(n=20):
    p={'origins':np.arange(n),'timestamps':np.datetime64('2017-01-01')+np.arange(n)*np.timedelta64(5,'m'),
       'truth':np.zeros((n,1),bool),'eligible':np.ones((n,1),bool)}
    x=np.zeros((n,1,51),np.float32);x[:,:,12]=1;x[:,:,8]=np.float32(25/70)
    p['natural_state']=x
    return p


class EarlyProtectionTest(unittest.TestCase):
    def test_cutoff_uses_every_original_training_early_positive(self):
        model={'indices':np.array([0]),'mean':np.array([0.]),'std':np.array([1.]),'weight':np.array([1.]),'bias':np.array([0.])}
        rows={'x':np.array([[-3.],[0.],[2.],[3.]]),'y':np.array([1,1,1,0]),'lead_minutes':np.array([15,10,5,-1])}
        cutoff,record=protected_cutoff(rows,model,.3)
        self.assertAlmostEqual(cutoff,1/(1+np.exp(3)))
        self.assertEqual(record['training_original_R10_rows'],2)
        self.assertFalse(record['later_development_block_values_used'])
        rows['lead_minutes'][:]=5
        with self.assertRaises(ValueError):protected_cutoff(rows,model,.3)

    def test_three_available_past_observations_no_future_labels(self):
        p=fixture();result=observed_past_low(p,'natural')
        self.assertFalse(result[:2].any());self.assertTrue(result[2:].all())
        p['truth'][:]=True;p['eligible'][:]=False
        np.testing.assert_array_equal(result,observed_past_low(p,'natural'))
        p['natural_state'][8,0,13]=1/12
        result=observed_past_low(p,'natural')
        self.assertFalse(result[8:11].any());self.assertTrue(result[11,0])

    def test_past_low_rejects_missing_above_threshold_and_gaps(self):
        p=fixture();p['natural_state'][4,0,12]=0;p['natural_state'][10,0,8]=np.float32(31/70)
        p['timestamps'][15:]+=np.timedelta64(5,'m')
        result=observed_past_low(p,'natural')
        for lo,hi in ((4,7),(10,13),(15,17)):self.assertFalse(result[lo:hi].any())

    def test_whole_run_decision_no_midrun_rescue_or_fragmentation(self):
        p=fixture(8);scores=np.array([0,1,1,0,1,1,1,0.])[:,None]
        cred=np.array([1,.1,1,0,.9,.1,.1,0])[:,None]
        out=episode_gate(scores,cred,p['origins'],p['timestamps'],.5)
        self.assertEqual(out[:,0].tolist(),[False,False,False,False,True,True,True,False])

    def test_observed_low_bypass_only_matters_at_start(self):
        p=fixture(6);scores=np.array([0,1,1,0,1,0.])[:,None]
        bypass=np.array([0,0,1,0,1,0],bool)[:,None]
        out=episode_gate(scores,np.zeros((6,1)),p['origins'],p['timestamps'],.5,bypass)
        self.assertEqual(out[:,0].tolist(),[False,False,False,False,True,False])

    def test_gap_forces_new_run_decision_and_future_never_changes_prefix(self):
        p=fixture(10);p['timestamps'][5:]+=np.timedelta64(5,'m')
        scores=np.ones((10,1));cred=np.ones((10,1));cred[5]=0
        out=episode_gate(scores,cred,p['origins'],p['timestamps'],.5)
        self.assertTrue(out[:5].all());self.assertFalse(out[5:].any())
        cred[7:]=1e6
        np.testing.assert_array_equal(out[:7],episode_gate(scores,cred,p['origins'],p['timestamps'],.5)[:7])

    def test_zero_cutoff_degenerates_to_original_c1(self):
        p=fixture();rng=np.random.default_rng(5);scores=rng.random((20,1));cred=rng.random((20,1))
        np.testing.assert_array_equal(episode_gate(scores,cred,p['origins'],p['timestamps'],0),alarm(scores,.46,1,p))

    def test_protection_matches_original_event_identity_and_lead(self):
        p=fixture();p['truth'][8:13]=True
        baseline=np.zeros_like(p['truth']);baseline[6:10]=True
        candidate=baseline.copy();candidate[6]=False
        result=protect_original_events(p,baseline,candidate)
        self.assertFalse(result['all_original_R10_events_and_leads_preserved'])
        self.assertEqual(result['protected_events_lost_or_delayed'][0]['old_lead_minutes'],15)
        self.assertEqual(result['protected_events_lost_or_delayed'][0]['new_lead_minutes'],10)

    def test_transfer_cache_and_raw_access_rejected(self):
        for path in ('C:/p/data/raw/pems-bay.h5','C:/p/outputs/pems-bay-evaluation/evaluation.npz',
          'C:/p/outputs/new-station-transfer-2026-10-15/evaluation_features.npz',
          'C:/p/outputs/frozen-probe-transfer-2026-10-15/results.json'):
            with self.assertRaises(PermissionError):guard('open',(path,'rb',0))


if __name__=='__main__':unittest.main()
