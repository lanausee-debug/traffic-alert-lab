"""Safety/selection checks for the exploratory anchored candidate."""
import sys
from pathlib import Path
import unittest

import numpy as np
import torch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from improve_anchored_risk import AnchoredRisk, inputs
from improve_alert_recall import audit, select
from congestion_risk_pilot import RiskModel


class AnchoredRiskTest(unittest.TestCase):
    def test_initial_anchor_identity_and_hard_correction_bound(self):
        torch.manual_seed(9)
        x=torch.randn(32,52)
        for bound in (0.5,1.0):
            model=AnchoredRisk(bound)
            self.assertTrue(torch.equal(model(x),x[:,-1]))
            with torch.no_grad():model.residual.layers[-1].bias.fill_(1e6)
            self.assertLessEqual(float((model(x)-x[:,-1]).abs().max().detach()),bound+1e-6)

    def test_gradients_and_real_parameter_update(self):
        model=AnchoredRisk(1.0);x=torch.randn(20,52);y=torch.ones(20)
        before=model.residual.layers[-1].bias.detach().clone()
        optimizer=torch.optim.Adam(model.parameters(),lr=.001)
        loss=torch.nn.functional.binary_cross_entropy_with_logits(model(x),y)
        loss.backward()
        self.assertTrue(all(p.grad is None or bool(torch.isfinite(p.grad).all()) for p in model.parameters()))
        optimizer.step()
        self.assertFalse(torch.equal(before,model.residual.layers[-1].bias.detach()))

    def test_deployment_inputs_ignore_future_labels(self):
        rng=np.random.default_rng(2)
        part={s+'_state':rng.normal(size=(5,2,51)).astype(np.float32) for s in ('natural','single_outage','group_outage')}
        part.update({s+'_single':rng.normal(size=(5,2)).astype(np.float32) for s in ('natural','single_outage','group_outage')})
        part['truth']=np.zeros((5,2),bool);part['onset']=np.zeros((5,2),bool)
        norm={'mean':np.zeros(51),'std':np.ones(51),'single_mean':np.array([0.]),'single_std':np.array([1.])}
        anchor=RiskModel(1,False)
        first=inputs(part,norm,anchor,False)
        part['truth'][:]=True;part['onset'][:]=True
        second=inputs(part,norm,anchor,False)
        self.assertTrue(all(np.array_equal(first[s],second[s]) for s in first))

    def test_constraints_reject_good_warning_with_bad_detection_or_false_rate(self):
        scenarios=('natural','single_outage','group_outage')
        reference={s:{'detection_recall':.8} for s in scenarios};budgets={s:.1 for s in scenarios}
        def candidate(index,r10,detection,false):
            return {'method':str(index),'method_index':index,'confirmation':1,'grid_index':index,
                'by_scenario':{s:{'warning_recall_at_least10':r10,'detection_recall':detection,'false_per_valid_station_day':false} for s in scenarios}}
        rows=[candidate(0,.9,.7,.09),candidate(1,.9,.8,.11),candidate(2,.2,.8,.09)]
        self.assertEqual(select(rows,reference,budgets)['method'],'2')
        self.assertIsNone(select(rows[:2],reference,budgets))
        rows[2]['by_scenario']['group_outage']['detection_recall']=.77
        self.assertIsNone(select(rows,reference,budgets))

    def test_training_open_guard_rejects_evaluation_and_raw_data(self):
        for path in ('C:/work/outputs/pems-bay-evaluation/evaluation.npz','C:/work/data/raw/pems-bay.h5'):
            with self.assertRaises(PermissionError):audit('open',(path,'rb',0))


if __name__=='__main__':unittest.main()
