"""Audit and summarize exploratory fixed-first replan and information-wait probes."""
import json
import numpy as np
import torch
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from recovery_pilot import ROOT, write_json
from multifault_pilot import ORDERS, sha256, day_macro, day_interval, relative_day_interval
from state_value_pilot import read_data, ridge_fit, ridge_predict, weighted_rows, ALPHAS
from waiting_diagnostic import METHODS, branch_orders, replan_features, summary


def main():
    torch.set_num_threads(1)
    out = ROOT/'outputs/replanning-diagnostic'; waiting_dir = ROOT/'outputs/waiting-diagnostic'; old = ROOT/'outputs/state-value-pilot'
    bounds = json.loads((out/'results.json').read_text(encoding='utf-8'))
    waits = json.loads((waiting_dir/'results.json').read_text(encoding='utf-8'))
    config = json.loads((old/'config.json').read_text(encoding='utf-8'))
    for source_hashes in (bounds['sources'], waits['config']['hashes'], config['hashes']):
        for path, expected in source_hashes.items():
            if sha256(ROOT/path) != expected: raise AssertionError(f'Source hash mismatch: {path}')
    events, groups = config['events'], config['groups']; parts = ('training', 'validation', 'test')
    all_events = sum([events[p] for p in parts], []); slices = {}; begin = 0
    for p in parts: slices[p] = slice(begin, begin+len(events[p])); begin += len(events[p])
    z, valid, scale, adjacency, timestamps, context, _ = read_data()
    audit = {'source_hashes': True, 'training_standardization': True, 'coefficients_refitted': True,
             'all_alpha_validation_scores_recomputed': True, 'choices_reproduced': True, 'summary_reproduced': True,
             'decision_time_information_boundary': True, 'visible_first_reading_affects_features': True,
             'zero_wait_matches_archived_costs': True, 'exploratory_already_used_dates': True, 'models': {}}
    additional = {}
    for variant in waits['models']:
        source_labels = {}
        with np.load(ROOT/'outputs/fresh-holdout-pilot'/f'arrays_{variant}.npz') as arc:
            source_labels['training'] = {k: np.concatenate([arc['calibration_'+k], arc[k]]) for k in ('actual', 'healthy')}
        for p in ('validation', 'test'):
            with np.load(old/f'labels_{variant}_{p}.npz') as arc: source_labels[p] = {k: arc[k] for k in ('actual', 'healthy')}
        with np.load(out/f'choices_{variant}.npz') as arc:
            ref = {p: arc[p+'_reference_choice'] for p in parts}
        all_ref = np.concatenate([ref[p] for p in parts]); orders = branch_orders(all_ref)
        raw = {mode: [] for mode in ('immediate', 'wait', 'hidden')}
        tested_visible = False
        for i, (e, choice) in enumerate(zip(all_events, all_ref)):
            first = ORDERS[int(choice)][0]; group = groups[e['group']]; origin = e['origin']
            for mode, lag, hide in (('immediate', 0, False), ('wait', 1, False), ('hidden', 1, True)):
                raw[mode].append(replan_features(z, valid, context, origin, group, first, lag, adjacency, hide))
            if not tested_visible:
                finished = origin+group['durations_steps'][first]; node = group['nodes'][first]
                if valid[finished, node]:
                    changed = z.copy(); changed[finished, node] += 1234
                    visible = replan_features(changed, valid, context, origin, group, first, 1, adjacency)
                    hidden = replan_features(changed, valid, context, origin, group, first, 1, adjacency, True)
                    instant = replan_features(changed, valid, context, origin, group, first, 0, adjacency)
                    if np.array_equal(visible[1], raw['wait'][-1][1]): raise AssertionError('Visible reading ignored')
                    if not np.array_equal(hidden[1], raw['hidden'][-1][1]): raise AssertionError('Hidden reading leaked')
                    if not np.array_equal(instant[1], raw['immediate'][-1][1]): raise AssertionError('Completion-time reading read early')
                    tested_visible = True
        if not tested_visible: raise AssertionError('No observable repaired reading to test')
        raw = {mode: [np.stack([pair[i] for pair in rows]) for i in (0, 1)] for mode, rows in raw.items()}
        nonwaiting = np.concatenate([source_labels[p]['actual'] for p in parts])[np.arange(len(all_events))[:, None], orders]
        with np.load(waiting_dir/f'waiting_costs_{variant}.npz') as arc:
            waiting = arc['cost']
            if not np.array_equal(waiting, arc['per_seed'].mean(axis=0)): raise AssertionError('Seed averaging changed')
        with np.load(waiting_dir/f'zero_wait_check_{variant}.npz') as arc:
            if not np.allclose(arc['cost'], nonwaiting[arc['sample']], rtol=1e-7, atol=1e-5): raise AssertionError('Zero wait cost mismatch')
        selection = json.loads((waiting_dir/f'selection_{variant}.json').read_text(encoding='utf-8'))
        cost_tables = {p: {'keep_plan': source_labels[p]['actual'][np.arange(len(events[p])), ref[p]]} for p in parts}
        with np.load(waiting_dir/f'policy_{variant}.npz') as policy, np.load(waiting_dir/f'choices_{variant}.npz') as choices:
            if not np.array_equal(choices['orders'], orders): raise AssertionError('First station changed')
            for method in METHODS:
                mode = 'immediate' if method.startswith('immediate') else 'hidden' if method == 'wait_hidden' else 'wait'
                column = 0 if method.endswith('calendar') else 1
                train = raw[mode][column][slices['training']]; std = train.std(axis=0); std = np.where(std > 1e-5, std, 1)
                mean = train.mean(axis=0)
                if not np.array_equal(mean, policy[method+'_mean']) or not np.array_equal(std, policy[method+'_std']): raise AssertionError('Normalization leak')
                x = {p: (raw[mode][column][slices[p]]-mean)/std for p in parts}
                costs = nonwaiting if mode == 'immediate' else waiting
                y = (costs[:, 0]-costs[:, 1])[slices['training'], None]
                grid = []
                for alpha in ALPHAS:
                    coef = ridge_fit(x['training'], y, alpha, weighted_rows(events['training']))
                    chosen_branch = (ridge_predict(x['validation'], coef)[:, 0] > 0).astype(int)
                    cost = float(day_macro(costs[slices['validation']][np.arange(len(chosen_branch)), chosen_branch], events['validation']))
                    grid.append({'alpha': alpha, 'validation_cost': cost})
                    if alpha == selection['methods'][method]['alpha'] and not np.allclose(coef, policy[method], rtol=1e-10, atol=1e-10):
                        raise AssertionError('Coefficient refit differs')
                expected = min(grid, key=lambda item: item['validation_cost'])
                if grid != selection['methods'][method]['grid'] or expected['alpha'] != selection['methods'][method]['alpha']: raise AssertionError('Validation selection changed')
                for p in parts:
                    branch = (ridge_predict(x[p], policy[method])[:, 0] > 0).astype(int)
                    if not np.array_equal(branch, choices[p+'_'+method]): raise AssertionError('Choice mismatch')
                    cost_tables[p][method] = costs[slices[p]][np.arange(len(branch)), branch]
        val_costs = {k: float(day_macro(v, events['validation'])) for k, v in cost_tables['validation'].items()}
        chosen = min(('keep_plan', 'immediate_state', 'wait_state'), key=lambda k: val_costs[k])
        if val_costs != selection['validation_costs'] or chosen != selection['chosen']: raise AssertionError('Mode selection changed')
        for p in parts:
            sl = slices[p]
            cost_tables[p]['no_wait_conditional_oracle'] = nonwaiting[sl].min(axis=1)
            cost_tables[p]['wait_conditional_oracle'] = waiting[sl].min(axis=1)
            cost_tables[p]['optional_wait_oracle'] = np.minimum(nonwaiting[sl].min(axis=1), waiting[sl].min(axis=1))
            recalculated = summary(cost_tables[p], source_labels[p]['healthy'], events[p], chosen)
            if recalculated != waits['models'][variant]['parts'][p]: raise AssertionError('Summary mismatch')
        test_sl = slices['test']; reference_branch = (orders[test_sl, 0] != ref['test']).astype(int)
        wait_fixed = waiting[test_sl][np.arange(len(events['test'])), reference_branch]
        difference = cost_tables['test']['keep_plan']-wait_fixed
        avg, ci = day_interval(difference, events['test'])
        additional[variant] = {'descriptive_wait_same_plan_absolute_gain': float(avg), 'ci': ci.tolist()}
        audit['models'][variant] = {'checks_passed': True, 'calendar_features': raw['wait'][0].shape[1], 'state_features': raw['wait'][1].shape[1]}
    write_json(out/'audit.json', audit); write_json(out/'additional_descriptive.json', additional)
    titles = {'graph_tcn_candidate': '图TCN', 'mlp_baseline': '图MLP'}
    names = {'keep_plan': '保持原计划', 'immediate_calendar': '完工即决策：日历', 'immediate_state': '完工即决策：可见状态',
             'wait_calendar': '等5分钟：日历', 'wait_state': '等5分钟：可见状态', 'wait_hidden': '等5分钟：隐藏修复站读数',
             'no_wait_conditional_oracle': '不等待的条件离线最优', 'wait_conditional_oracle': '等5分钟的条件离线最优',
             'optional_wait_oracle': '未来已知是否等待及后续顺序'}
    lines = ['# 第五轮：修后重新观察是否值得', '',
             '本轮已经执行固定首站上界诊断、5分钟付费等待模拟和条件顺序岭回归探测。复用已分析过的35日训练、14日验证、28日评测数据，属于事后探索，不是新的独立测试。第四轮未证明价值MLP稳定有效的结论保持。', '',
             '当前设定下，TCN完工即重排只改善0.20%故障增量（区间包含零），统一等5分钟重排则增加约5.98%损失，MLP复核增加约6.72%。此轮不支持直接投入更复杂的滚动算法；结论仅限当前信息规则、首站和任务规模。', '',
             '## 先确定剩余空间', '',
             '保持第四轮验证段选定参考的第一站，仅允许改变后两站。条件离线最优使用未来真值选两个后续顺序，给出不等待重规划的乐观上限，不能部署。', '',
             '| 预测器 | 原分区 | 固定首站后故障增量改善上限 | 占全部离线空间 | 首站限制留下的不可取空间 |', '|---|---|---:|---:|---:|']
    for variant in titles:
        for part, label in (('training', '35日训练'), ('validation', '14日验证'), ('test', '28日已用评测')):
            b = bounds['models'][variant][part]
            lines.append(f"| {titles[variant]} | {label} | {100*b['remaining_order_fault_added_fraction']:.2f}% | {100*b['remaining_order_share_of_full_space']:.2f}% | {b['first_station_constraint_absolute_gap']:.4f} |")
    lines += ['', 'TCN已用评测段的条件空间约6.20%，只占全部离线空间36.19%；其余63.81%在固定首站限制下无法通过后两站排序取得。想达到原5%研发参考线，需要兑现约80.6%的条件离线空间，不能把全部17.13%空间都计入滚动决策机会。该分解只适用于当前参考首站及两个剩余任务，不能推广成所有滚动策略无效。', '',
              '## 信息和维修时刻', '',
              '输入历史截至决策时刻前一个5分钟采样步。第一站完工时，其修复后可用历史数为0；等到5分钟后，最多有1条自然有效读数。不等待策略只能用其他站更新的观测；等待策略把第二、第三站完工各推迟5分钟，120分钟评估终点不延长。', '',
              '5分钟来自本实验严格过去历史的信息规则，未由现场读数到达/启动延迟验证。如果现实允许完工当刻读取即时测量，需要重新定义决策信息集合和验证，不能将本轮等待结论外推。具体边界见docs/observation_availability_boundary.zh-CN.md。', '',
              '条件岭回归只预测两个后续顺序的成本差，使用108维日历或540维状态特征；已有PyTorch交通预测器冻结不重训。本轮不继续加深价值网络。正则化仅在旧验证段的固定网格选择。正常/隐藏修复站读数两种等待策略的交通预测器都能使用同样物理可用的新读数，消融只改变排序器输入。', '']
    for variant, title in titles.items():
        model = waits['models'][variant]; s = model['parts']['test']
        lines += [f'## {title}：28日已使用数据上的探索结果', '',
                  f"验证段选定的候选为**{names[model['chosen']]}**；首条修复读数自然有效的情景比例约{100*model['valid_first_reading_fraction']:.2f}%。", '',
                  '| 方法 | 累计成本 | 故障增量改善 | 95%日期区间 |', '|---|---:|---:|---:|']
        for name, label in names.items():
            p = s['policies'][name]; ci = p['fault_added_ci']
            ci_text = f'[{100*ci[0]:.2f}%, {100*ci[1]:.2f}%]' if ci is not None else '分母不稳定'
            lines.append(f"| {label} | {p['cost']:.4f} | {100*p['fault_added_gain']:.2f}% | {ci_text} |")
        info = s['restored_reading_vs_hidden_ablation']; fixed = additional[variant]
        lines += ['', f"等5分钟时，使用修复站读数相对隐藏它的绝对改善为{info['absolute_gain']:.4f}，95%区间[{info['ci'][0]:.4f}, {info['ci'][1]:.4f}]。这是两个分别拟合的排序器的信息消融，不是随机因果实验。", '',
                  f"附加描述性检查：仍按原后续顺序但等5分钟，相对原计划的绝对改善为{fixed['descriptive_wait_same_plan_absolute_gain']:.4f}，区间[{fixed['ci'][0]:.4f}, {fixed['ci'][1]:.4f}]；负数代表等待更差。只经预测损失体现时间代价，未计货币/现场资源成本。", '']
    lines += ['## 研究定位和下一步边界', '',
              '未来已知是否等待的最优是非等待与等待两个可行集合的并集诊断；它允许事先知道未来，不能作为可用策略成绩。等待集合不包含原来的0等待六顺序，不能错误地要求两者形成同一嵌套界。', '',
              '一般异质设备的动态维修、MDP及在线rollout已有[Tian与Shone的2026年研究](https://arxiv.org/abs/2602.19277)。交通信号故障的深度学习恢复顺序评估已有[Zhao与Zhang的TR-C论文](https://www.sciencedirect.com/science/article/pii/S0968090X21005040)（作者公开稿：https://par.nsf.gov/servlets/purl/10354638）。后者用交通延误作目标，说明换成下游交通收益本身也不保证创新；信号恢复与检测器恢复仍是不同对象。', '',
              '[MoGERNN](https://arxiv.org/abs/2501.12281)解决感知变化下的未观测位置预测，属于估计层。维修动作选择是决策层；两者关系需要具体实验与模型信息边界说明，不能只用名称区分来证明新颖性。上述文献核查不等于穷尽所有相关研究。', '',
              '本轮只回答当前固定首站、三故障和确定工时模拟是否显示值得升级方法的迹象。小上界或弱简单探测不能证明所有自适应维修无效；也不能因为变成序贯决策就直接称原创。旧日期已经全部分析，不继续靠扩展网格、换首站参考或删时段在同一评测段制造正结果。', '',
              '若继续推进论文，先确定与既有工作的实质方法差异、现实决策目标和新的外部验证数据，再冻结下一轮协议。工程项目可以保留这些负结果作为复现实验和故障压力测试模块，但工具完整性与论文方法创新应分别评估。', '',
              '## 检查与保存', '',
              '旧源码/协议/数据/标签/权重及新协议哈希核对；训练标准化和选定系数重新拟合；全部正则化验证得分、分支选择、全局模式选择及统计复算；完工时0条、等5分钟1条的可见边界检查；合法首条读数确实进入状态特征，隐藏它或在完工时访问它不会泄漏；0等待代价与旧六顺序数组复算一致；物理等待时延、无完工前历史恢复和预测器mask不变性通过。', '',
              '上界结果与总报告保存在outputs/replanning-diagnostic；等待三种子成本、训练系数/标准化、验证选择和分支选择保存在outputs/waiting-diagnostic。所有新文件另行归档，旧输出不覆盖。', '']
    (out/'report.zh-CN.md').write_text('\n'.join(lines), encoding='utf-8')
    names_plot = ['keep_plan', 'immediate_state', 'wait_state', 'wait_hidden', 'no_wait_conditional_oracle', 'wait_conditional_oracle', 'optional_wait_oracle']
    labels = ['Keep start-time plan', 'Replan at completion', 'Wait 5 min + replan', 'Wait 5 min, hide new reading', 'No-wait future oracle', 'Wait future oracle', 'Future-known optional wait']
    fig, axes = plt.subplots(1, 2, figsize=(12, 5), sharey=True)
    for ax, variant, title in zip(axes, titles, ('Frozen graph TCN', 'Frozen graph MLP')):
        p = waits['models'][variant]['parts']['test']['policies']
        values = np.array([p[k]['fault_added_gain']*100 for k in names_plot]); intervals = np.array([p[k]['fault_added_ci'] for k in names_plot])*100
        errors = np.stack([np.maximum(values-intervals[:, 0], 0), np.maximum(intervals[:, 1]-values, 0)])
        ax.barh(np.arange(len(values)), values, color=['#74869a']*4+['#d9a441']*3)
        ax.errorbar(values, np.arange(len(values)), xerr=errors, fmt='none', capsize=3, color='#333')
        ax.axvline(0, color='#555', lw=.8); ax.set_yticks(np.arange(len(values)), labels); ax.set_title(title)
        ax.set_xlabel('Fault-added loss improvement vs original plan (%)'); ax.grid(axis='x', alpha=.2)
    axes[0].invert_yaxis(); fig.suptitle('Exploratory reuse: fixed first repair, paid observation wait')
    fig.tight_layout(); fig.savefig(out/'replanning_summary.png', dpi=180); fig.savefig(out/'replanning_summary.svg'); plt.close(fig)
    print(json.dumps({'audit': audit, 'report': str(out/'report.zh-CN.md')}, ensure_ascii=False))


if __name__ == '__main__': main()
