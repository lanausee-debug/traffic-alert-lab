"""Independently reconstruct full episode decisions and event-level protection."""
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
import torch
import early_warning_protection as pilot
import alarm_start_separability as probe
import calibration_fragility as common
from congestion_alert_pilot import SCENARIOS,runs
from pems_bay_alert_replay import alarm,replay,layout
from train_pems_bay_risk import load_risk
from evaluate_pems_bay_alerts import paired_difference
from adaptive_confirmation import block_gate

ROOT=pilot.ROOT;OUT=pilot.OUT


def independent_observed_low(part,scenario):
    x=part[scenario+'_state'];result=np.zeros(x.shape[:2],bool)
    times=part['timestamps'][part['origins']]
    for t in range(2,len(x)):
        if not np.all(np.diff(part['origins'][t-2:t+1])==1):continue
        if not np.all(np.diff(times[t-2:t+1])==np.timedelta64(5,'m')):continue
        window=x[t-2:t+1]
        result[t]=np.all((window[:,:,12]>0)&(np.abs(window[:,:,13])<1e-6)&
            (window[:,:,8]>0)&(window[:,:,8]<=np.float32(30/70)),axis=0)
    return result


def interval_gate(probability,credibility,bypass,part,cutoff):
    result=np.zeros_like(probability,bool)
    for lo,hi in layout(part)[0]:
        for node in range(probability.shape[1]):
            for start,end in runs(probability[lo:hi,node]>=.46):
                start,end=int(start+lo),int(end+lo)
                if credibility[start,node]>=cutoff or bypass[start,node]:result[start:end,node]=True
    return result


def matched_event_diagnosis(part,baseline,candidate):
    _,_,a=replay(part,baseline,details=True);_,_,b=replay(part,candidate,details=True)
    key=lambda r:(r['node'],r['event_start_origin'])
    before={key(r):r for r in a};after={key(r):r for r in b};assert before.keys()==after.keys()
    changes=[];counts={}
    for k,old in before.items():
        new=after[k];name=old['status']+'->'+new['status'];counts[name]=counts.get(name,0)+1
        if old['status']!=new['status'] or old['lead_minutes']!=new['lead_minutes']:
            changes.append({'node':int(k[0]),'event_start_origin':int(k[1]),'timestamp':old['timestamp'],
                'old_status':old['status'],'new_status':new['status'],
                'old_lead_minutes':old['lead_minutes'],'new_lead_minutes':new['lead_minutes']})
    lost=[r for r in changes if r['old_status']!='missed' and r['new_status']=='missed']
    removed={}
    for rec in common.episodes(part,baseline):
        if not candidate[rec['row'],rec['node']]:removed[rec['kind']]=removed.get(rec['kind'],0)+1
    return {'status_transition_counts':counts,'newly_missed_by_original_status':
        {status:sum(r['old_status']==status for r in lost) for status in ('warned','late')},
        'suppressed_baseline_episode_types':removed,'changed_events':changes}


def main():
    torch.set_num_threads(1)
    plan=common.read(OUT/'plan.json');r=common.read(OUT/'results.json');done=common.read(OUT/'completion.json')
    seal=common.read(OUT/'parameter_freeze.json');selection=common.read(OUT/'selection_freeze.json')
    for name,digest in plan['source_and_input_sha256'].items():assert common.sha(ROOT/name)==digest,name
    for name,digest in done['artifacts'].items():assert common.sha(OUT/name)==digest,name
    assert done['plan_sha256']==seal['plan_sha256']==selection['plan_sha256']==common.sha(OUT/'plan.json')
    assert selection['parameter_freeze_sha256']==common.sha(OUT/'parameter_freeze.json')
    assert selection['results_sha256']==common.sha(OUT/'results.json')
    assert datetime.fromisoformat(plan['frozen_at_utc'])<datetime.fromisoformat(seal['frozen_at_utc'])<datetime.fromisoformat(selection['frozen_at_utc'])
    assert not selection['ablation_substitution'] and not r['consumed_transfer_values_used_in_this_run']
    assert selection['accepted_for_future_validation']==r['primary_acceptance_passed']
    model=common.load(probe.OUT/'state_logistic.npz');training=common.load(probe.OUT/'training_pooled_samples.npz')
    x=training['x'][:,model['indices']];z=(x-model['mean'])/model['std']
    p=1/(1+np.exp(-np.clip(z@model['weight']+float(model['bias'][0]),-50,50)))
    early=(training['y']==1)&(training['lead_minutes']>=10)
    old=common.read(probe.OUT/'training_freeze.json')['cutoffs']['state_logistic']
    cutoff=min(old,float(p[early].min()))
    assert cutoff==seal['parameters']['protected_cutoff']==r['parameters']['protected_cutoff']
    assert early.sum()==seal['parameters']['training_original_R10_rows'] and np.all(p[early]>=cutoff)
    assert common.sha(probe.OUT/'state_logistic.npz')==seal['model_sha256']
    norm=common.load(common.RISK/'normalization.npz');anchor=load_risk(common.RISK/'global_calibration.pt')
    val=common.load(common.RISK/'risk_validation.npz');cal=common.load(common.CAL/'calibration.npz')
    parts={'calibration_full14':cal,'risk_validation7':val,
        'calibration_week1_7':common.subset(cal,0,7),'calibration_week2_7':common.subset(cal,7,14)}
    definitions={'old_gate':(old,False),'early_cutoff_gate':(cutoff,False),
        'old_gate_observed_low':(old,True),pilot.PRIMARY:(cutoff,True)}
    active=common.load(OUT/'activations.npz');daily=common.load(OUT/'daily.npz');diagnoses={}
    for block,part in parts.items():
        probabilities=common.global_scores(part,norm,anchor);diagnoses[block]={}
        for s in SCENARIOS:
            observed=independent_observed_low(part,s)
            np.testing.assert_array_equal(observed,pilot.observed_past_low(part,s))
            credibility=probe.predict(model,probe.start_features(part,s,probabilities[s]).reshape(-1,30)).reshape(part['truth'].shape)
            baseline=alarm(probabilities[s],.46,1,part)
            choices={'global_c1':baseline,**{m:interval_gate(probabilities[s],credibility,observed if bypass else np.zeros_like(observed),part,t) for m,(t,bypass) in definitions.items()}}
            for method,expected in choices.items():
                key=f'{block}__{method}__{s}';np.testing.assert_array_equal(expected,active[key])
                assert not np.any(expected&~baseline)
                row,days,_=replay(part,expected,details=True)
                assert row==r['evaluation'][block][method][s];np.testing.assert_array_equal(days,daily[key])
                if method!='global_c1':
                    assert pilot.protect_original_events(part,baseline,expected)==r['original_early_event_checks'][block][method][s]
            diagnoses[block][s]=matched_event_diagnosis(part,baseline,choices[pilot.PRIMARY])
            protected=r['original_early_event_checks'][block][pilot.PRIMARY][s]
            assert protected['all_original_R10_events_and_leads_preserved']
    budgets=common.read(common.CAL/'selection.json')['budgets']
    for method,g in r['gates'].items():
        service={b:block_gate(v[method],v['global_c1']) for b,v in r['evaluation'].items()}
        assert service==g['service_block_checks']
        identity={b:all(v['all_original_R10_events_and_leads_preserved'] for v in scenes[method].values()) for b,scenes in r['original_early_event_checks'].items()}
        assert identity==g['original_early_event_identity_and_lead_preserved']
        candidate=r['means']['calibration_full14'][method]['false_per_valid_station_day']
        reference=r['means']['calibration_full14']['global_c1']['false_per_valid_station_day']
        assert g['full14_false_reduction_at_least10pct']==(candidate<=.9*reference+1e-12)
        budget_check={s:r['evaluation']['calibration_full14'][method][s]['false_per_valid_station_day']<=budgets[s]+1e-12 for s in SCENARIOS}
        assert budget_check==g['full14_original_budget_met']
        assert g['passed']==(all(v['passed'] for v in service.values()) and all(identity.values()) and candidate<=.9*reference+1e-12 and all(budget_check.values()))
    bootstrap=common.load(OUT/'bootstrap_draws.npz');dates=layout(cal)[2];draws=bootstrap['draws']
    np.testing.assert_array_equal(bootstrap['dates'],dates)
    np.testing.assert_array_equal(draws,np.random.default_rng(20261015).integers(0,len(dates),(2000,len(dates))))
    baseline=np.stack([daily[f'calibration_full14__global_c1__{s}'] for s in SCENARIOS])
    for method,comparison in r['paired_calibration_comparisons'].items():
        independent=paired_difference(np.stack([daily[f'calibration_full14__{method}__{s}'] for s in SCENARIOS]),baseline,draws)
        for original,current in [('warning10_recall','R10'),('detection_recall','detection'),('false_rate','false_rate')]:
            a=independent[original];b=comparison[current]
            assert np.isclose(a['difference'],b['difference'])
            assert a['undefined_bootstrap_replicates']==b['undefined_draws']
            assert (a['ci95'] is None and b['ci95'] is None) or np.allclose(a['ci95'],b['ci95'])
    prior=common.read(ROOT/'outputs/frozen-probe-transfer-2026-10-15/writing_archive_manifest.json')
    for name,meta in prior['files'].items():
        if name in ('README.md','CURRENT_STATE.zh-CN.md') and (OUT/'writing_archive_manifest.json').exists():
            assert common.sha(ROOT/name)==common.read(OUT/'writing_archive_manifest.json')['files'][name]['sha256']
        else:assert common.sha(ROOT/name)==meta['sha256'],name
    common.write(OUT/'matched_event_diagnosis.json',diagnoses)
    proof={'passed':True,'checked_at_utc':datetime.now(timezone.utc).isoformat(),
        'training_only_early_cutoff_recomputed':True,'all60_full_operating_replays_checked':True,
        'all48_gated_activations_reconstructed_by_intervals':True,
        'fresh_observed_low_bypass_independently_checked':True,
        'all_original_development_R10_event_identities_and_leads_preserved_by_primary':True,
        'primary_acceptance_passed':r['primary_acceptance_passed'],
        'event_transitions_and_paired_bootstrap_independently_checked':True,
        'prior_scientific_files_unchanged':True,'new_station_cohort_consumed':False,
        'source_sha256':common.sha(Path(__file__))}
    common.write(OUT/'audit.json',proof);print(proof)
    print({b:{s:v['newly_missed_by_original_status'] for s,v in scenes.items()} for b,scenes in diagnoses.items()})


if __name__=='__main__':main()
