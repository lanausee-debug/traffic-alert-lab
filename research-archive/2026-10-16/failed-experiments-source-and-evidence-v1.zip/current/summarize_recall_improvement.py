"""Write a clearly exploratory comparison without modifying the thesis tables."""
from pathlib import Path
import json

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs/anchored-risk-2026-10-15'


def main():
    first=json.loads((ROOT/'outputs/recall-repair-2026-10-15/results.json').read_text(encoding='utf-8'))
    calibration=json.loads((OUT/'results.json').read_text(encoding='utf-8'))
    replay=json.loads((OUT/'historical-replay/results.json').read_text(encoding='utf-8'))
    assert not first['pilot_acceptance_passed'] and calibration['pilot_acceptance_passed']
    assert not replay['independent_confirmation'] and replay['original_thesis_primary_test_still_failed']
    lines=['# 漏报改善实验：有希望的候选，尚非独立确认','',
        '日期：2026-10-15。本轮新增两个自适应探索阶段，不改原论文、原始主检验或已公开冻结结果。','',
        '原起点MLP主要学习“起点即将出现”，容易压低事件已经发生后的告警分数。首先测试0.5/0.75混合持续低速与起点监督，每种三种子、每模型1350次更新；两种三种子集成方案都没达到预定的检出率/误报联合约束。已有模型重新选阈值同样不可行；普通告警加起点告警的组合只回到原基线，没有新增预警收益。失败结果完整保存。','',
        '第二轮保留固定全局校准风险为底座，用相同51维特征的小MLP学习有界logit修正；末层零初始化，最初精确等于底座。目标改为“持续低速或即将起点”。比较修正上限0.5/1.0，每种三种子、每模型1350次实际更新；仅按风险验证集BCE选检查点。没有重新训练图TCN。','',
        '校准共同约束：每种情景误报不超原预算，检出率不低于原全局校准超过2个百分点；以平均R10优先排序。先固定候选，再进行一次已经使用过的旧评测段回放，不扫描旧评测阈值，不重训或根据回放改选。','',
        '## 校准结果（14日、69个共同事件）','',
        '| 方法 | ≥10分钟代理预警召回 | 含迟报检出率 | 误报/有效站日 |',
        '| --- | ---: | ---: | ---: |']
    calrows={'全局校准':calibration['reference_global'],'原起点MLP':calibration['original_onset'],'有界修正候选':calibration['selected_means']}
    for label,row in calrows.items():
        lines.append(f"| {label} | {100*row['warning_recall_at_least10']:.2f}% | {100*row['detection_recall']:.2f}% | {row['false_per_valid_station_day']:.6f} |")
    lines+=['','候选三情景的检出率分别与全局校准相同，平均提前召回增加6.28个百分点，误报平均略增；满足此次探索性校准验收。校准调参后的成绩不能当作泛化证明。','',
        '## 固定候选的旧数据回放（83日、673个共同事件）','',
        '**以下是已分析过的数据上的探索性回放，不是新测试集，也不是重新通过论文主检验。** 三种情景复用事件，不能说成2019个独立事件。','',
        '| 方法 | ≥10分钟代理预警召回 | 含迟报检出率 | 误报/有效站日 |',
        '| --- | ---: | ---: | ---: |']
    names={'global_calibration':'全局校准','group_calibration':'分组校准','onset_mlp':'原起点MLP','anchored_candidate':'有界修正候选'}
    for method,label in names.items():
        row=replay['means'][method]
        lines.append(f"| {label} | {100*row['warning_recall_at_least10']:.2f}% | {100*row['detection_recall']:.2f}% | {row['false_per_valid_station_day']:.6f} |")
    candidate=replay['means']['anchored_candidate'];global_row=replay['means']['global_calibration'];onset=replay['means']['onset_mlp']
    lines+=['',
        f"相对原起点MLP：检出率增加{100*(candidate['detection_recall']-onset['detection_recall']):.2f}个百分点，R10下降{100*(onset['warning_recall_at_least10']-candidate['warning_recall_at_least10']):.2f}个百分点，误报约为原来的{candidate['false_per_valid_station_day']/onset['false_per_valid_station_day']:.2f}倍。不能只报漏报改善而隐藏误报增加。",'',
        f"相对强参考全局校准：R10增加{100*(candidate['warning_recall_at_least10']-global_row['warning_recall_at_least10']):.2f}个百分点，检出率降低{100*(global_row['detection_recall']-candidate['detection_recall']):.2f}个百分点，误报点估计降低{100*(1-candidate['false_per_valid_station_day']/global_row['false_per_valid_station_day']):.2f}%。这些是探索性点估计，不表示统计显著或整体服务优势。",'',
        '### 旧回放段误报预算仍未守住','',
        '| 情景 | 校准误报预算 | 回放误报率 | 超预算 |','| --- | ---: | ---: | --- |']
    for scenario,row in replay['historical_budget_exceedance'].items():
        lines.append(f"| {scenario} | {row['calibration_budget']:.6f} | {row['candidate_rate']:.6f} | {'是' if row['exceeded'] else '否'} |")
    lines+=['','校准预算不能保证新时段的误报率。候选在全部旧回放情景超过校准预算，不能声称部署误报受控。需要新的数据验证、风险校准和明确管理方可接受的服务门槛。','',
        '## 冻结候选与限制','',
        f"候选：`{calibration['selected']['method']}`；阈值`{calibration['selected']['threshold']}`，确认次数`{calibration['selected']['confirmation']}`，三种子等权集成。参数及选择SHA见`selection_freeze.json`，回放计划与完成SHA见`historical-replay/`。",'',
        '- 两轮共训练12个小模型、16200次实际参数更新；第一轮失败和所有扫描候选保留。','- 两轮训练/校准进程通过运行时文件打开守卫禁止访问旧评测和原HDF5；最后单独进程在候选固定后访问旧评测缓存，仅做一次固定回放。','- 51维特征来源与原来一致，只使用历史观测、预测和可用性；未来标签只作训练目标或离线评测。','- 使用论文原低速代理标签和L=5(s−a+1)，不是实测事故起点或真实物理提前时间。','- 新方案是在已知旧研究结果后提出，且第二轮受第一轮校准失败启发；必须明确是自适应探索。未新增独立数据、置信检验、运营收益或原创性证明。','- 原论文主检验仍失败；不覆盖已发布表格，不上传原始数据、真实站点缓存或权重。','',
        '## 下一项必要工作','',
        '保持当前候选、阈值和验收门槛固定，在未用于本次开发的新时间段、站点或外部数据上验证。需同时检查提前召回、检出、误报、缺测情景和日期漂移；不得按新评测成绩再次挑阈值后称独立验证。','']
    (OUT/'report.zh-CN.md').write_text('\n'.join(lines),encoding='utf-8')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(1,3,figsize=(12,4.8),facecolor='#f5f8fa')
    methods=['global_calibration','onset_mlp','anchored_candidate'];labels=['Global calibration','Original onset MLP','Anchored candidate']
    for ax,(metric,title,multiplier) in zip(axes,[('warning_recall_at_least10','Proxy warning >=10 min (%)',100),('detection_recall','Detection incl. late (%)',100),('false_per_valid_station_day','False alerts / valid station-day',1)]):
        values=[replay['means'][m][metric]*multiplier for m in methods]
        bars=ax.bar(range(3),values,color=['#8297ab','#d29572','#137c83'],width=.65)
        ax.set_title(title,fontsize=11);ax.set_xticks(range(3),['Global','Onset MLP','Anchored'],fontsize=9)
        ax.spines[['top','right']].set_visible(False)
        ax.set_ylim(0,100 if metric=='detection_recall' else max(values)*1.3)
        for bar,value in zip(bars,values):ax.text(bar.get_x()+bar.get_width()/2,bar.get_height(),f'{value:.2f}' if multiplier==100 else f'{value:.3f}',ha='center',va='bottom',fontsize=10)
    fig.suptitle('Fixed candidate on previously used data: EXPLORATORY ONLY',fontsize=14)
    fig.text(.5,.025,'83 days / 673 shared proxy events. Original primary test remains failed. Independent validation is still required.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.08,1,.91));fig.savefig(OUT/'historical-comparison.png',dpi=150);plt.close(fig)
    print(json.dumps({'report':str(OUT/'report.zh-CN.md'),'historical_replay_only':True,'original_primary_test_still_failed':True}))


if __name__=='__main__':main()
