"""Cumulative local checkpoint of record-only event and episode attribution."""
from datetime import datetime,timezone
from pathlib import Path
import hashlib
from zipfile import ZipFile,ZIP_DEFLATED
import event_lineage_attribution as pilot
from save_station_agnostic_checkpoint import read,write,sha

ROOT=pilot.ROOT;OUT=pilot.OUT
NAME='traffic-recovery-lab-2026-10-16-event-lineage-attribution'


def main():
    archive=ROOT.parent/'checkpoints'/(NAME+'.zip');receipt=archive.with_name(NAME+'-save-receipt.json')
    if archive.exists() or receipt.exists():raise FileExistsError('Preserve existing archives')
    r=read(OUT/'results.json');audit=read(OUT/'audit.json');tests=read(OUT/'test_receipt.json')
    assert audit['passed'] and tests['passed'] and tests['tests_run']==7
    assert tests['test_source_sha256']==sha(ROOT/'tests/test_event_lineage_attribution.py')
    assert audit['results_sha256']==sha(OUT/'results.json')
    assert r['new_models_fitted']==r['optimizer_updates']==r['new_model_inference_calls']==0
    assert not r['policy_changed'] and not r['labels_changed'] and not r['new_acceptance_test_performed']
    assert r['original_thesis_primary_test_still_failed'] and not r['previous_candidate_acceptance_passed']
    assert not r['new_station_cohort_consumed'] and not r['consumed_transfer_values_used']
    for name,digest in read(OUT/'completion.json')['artifacts'].items():assert sha(OUT/name)==digest
    for name,digest in read(OUT/'plan.json')['source_and_input_sha256'].items():assert sha(ROOT/name)==digest
    prior_name='outputs/recovery-definition-sensitivity-2026-10-16/writing_archive_manifest.json';prior=read(ROOT/prior_name)
    # Old assets are hashed for preservation only, never decoded as experiment input.
    for name,meta in prior['files'].items():assert sha(ROOT/name)==meta['sha256'],name
    summary=('固定谱系归因：验证豁免救回的唯一早预警只属后续重入，没有保护父过程第一段；'
        '现有过滤的检出损失在第一段。更换定义后同样78个自然验证告警片段仅类型改变，'
        '不能把误报改标重复算成少发通知。')
    marker='# 最新检查点：首次子段、重入与告警负担已分开（2026-10-16）'
    p=ROOT/'CURRENT_STATE.zh-CN.md';old=p.read_text(encoding='utf-8');assert marker not in old
    p.write_text(marker+'\n\n- '+summary+'\n'
        '- 原one-high完整旧段按two-high父过程分第一/重入/父删失，定义离线固定；第一不是现场首次实际拥堵。验证46/6/0，校准62/3/1，训练167/8/8。\n'
        '- 自然验证第一子段原global检出39/46、两过滤37/46；重入6/6→5/6→6/6。三情景过滤新增第一漏检2/0/1，校准每情景第一漏1，豁免后续段获益不能掩盖。\n'
        '- two-high下验证豁免实际多13/14/11片段=3/4/3误报+10/10/8重复，无新检出/R10；校准多11/10/9，含各1误报、重复8/7/8及前两情景删失/未知各1。\n'
        '- 定义重标使自然验证有豁免误报20→18、重复14→22，但片段总78保持；自然校准总114保持。原通知日志没有，片段计数仅负担代理。\n'
        '- 7测试；独立核查90方法汇总/90成对/45转移表、6336事件与10600片段，含相关方法/情景/训练和重叠子块。没有样本/权重解码、推理或训练。\n'
        '- 报告outputs/event-lineage-attribution-2026-10-16/report.zh-CN.md；接续docs/event_lineage_attribution_handoff.zh-CN.md。下一轮可固定会话通知去重试验，要求保首次不丢不延后，只用当时可见观测；本轮未实现/验证。\n'
        '- 原论文/候选失败保留；模型、阈值、标签、Word/PPT与GitHubv7保持；原评测/迁移/新站/HDF5值未读。\n'
        '- 最新累计包2026-10-16-event-lineage-attribution；先10月11日完整基包后本包，所有旧科学文件和ZIP保留。\n\n以下为之前阶段记录。\n\n'+old,encoding='utf-8')
    p=ROOT/'README.md';old=p.read_text(encoding='utf-8')
    p.write_text('# 最新研究：重入保护与首次检出损失分开归因\n\n'
        '[完整报告](outputs/event-lineage-attribution-2026-10-16/report.zh-CN.md) · [接续说明](docs/event_lineage_attribution_handoff.zh-CN.md)\n\n'
        +summary+' 只重组已冻结开发记录，没有模型/规则变化或新性能确认。最新累计包2026-10-16-event-lineage-attribution。\n\n以下为之前阶段记录。\n\n'+old,encoding='utf-8')
    files=set(prior['files'])|{prior_name,'event_lineage_attribution.py','audit_event_lineage_attribution.py',
        'summarize_event_lineage_attribution.py','save_event_lineage_attribution_checkpoint.py',
        'tests/test_event_lineage_attribution.py','docs/event_lineage_attribution_handoff.zh-CN.md'}
    files|={p.relative_to(ROOT).as_posix() for p in OUT.rglob('*') if p.is_file() and p.name!='writing_archive_manifest.json'}
    base_path=ROOT.parent/'checkpoints/traffic-recovery-lab-2026-10-11-event-timeline-save-receipt.json';base=read(base_path)
    assert base['archive_crc_and_all_sha256_verified'] and Path(base['full_archive']).stat().st_size==base['full_archive_bytes']
    manifest=OUT/'writing_archive_manifest.json'
    write(manifest,{'client_date':'2026-10-16','stage':'cumulative_record_only_event_lineage_attribution',
        'archive_name':archive.name,'restore':'October11 full base, then this cumulative supplement',
        'new_models_fitted':0,'optimizer_updates':0,'new_model_inference_calls':0,'record_only_input':True,
        'policy_changed':False,'labels_changed':False,'independent_confirmation':False,
        'new_station_cohort_consumed':False,'consumed_transfer_values_decoded':False,
        'original_thesis_primary_test_still_failed':True,'previous_acceptance_passed':False,
        'unit_tests_observed_passed':7,'method_aggregations_checked':90,'pair_comparisons_checked':90,
        'definition_transition_tables_checked':45,'event_records_checked_including_related_blocks_and_methods':6336,
        'episode_records_checked_including_related_blocks_and_methods':10600,
        'comparison_plot_visually_inspected':True,'prior_scientific_files_preserved':True,
        'prior_files_changed':['README.md','CURRENT_STATE.zh-CN.md'],
        'public_commit_unchanged':'ab8760a3e6ea1784fea3195a0e7aadbaff6fe80d',
        'base_crc_rechecked_this_turn':False,'base_sha256_from_prior_verified_receipt':base['full_archive_sha256'],
        'files':{n:{'bytes':(ROOT/n).stat().st_size,'sha256':sha(ROOT/n)} for n in sorted(files)}})
    files.add(manifest.relative_to(ROOT).as_posix())
    with ZipFile(archive,'x',compression=ZIP_DEFLATED) as z:
        for n in sorted(files):z.write(ROOT/n,'traffic-recovery-lab/'+n)
    with ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist())==len(files)
        for n in sorted(files):
            data=z.read('traffic-recovery-lab/'+n)
            assert data==(ROOT/n).read_bytes() and hashlib.sha256(data).hexdigest()==sha(ROOT/n)
    proof={'saved_at_utc':datetime.now(timezone.utc).isoformat(),'client_date':'2026-10-16',
        'archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'files':len(files),
        'crc_and_all_file_bytes_and_sha256_verified':True,'new_models_fitted':0,'new_model_inference_calls':0,
        'policy_changed':False,'labels_changed':False,'new_station_cohort_consumed':False,
        'original_thesis_primary_test_still_failed':True,'public_version_unchanged':True,
        'base_prior_verified_receipt':str(base_path),'base_crc_rechecked_this_turn':False}
    write(receipt,proof);print(proof)


if __name__=='__main__':main()
