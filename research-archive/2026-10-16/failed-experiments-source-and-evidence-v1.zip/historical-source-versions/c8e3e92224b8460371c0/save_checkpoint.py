"""Create and verify a portable checkpoint without environment/cache files."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--date", required=True, help="User-facing date, YYYY-MM-DD")
    parser.add_argument("--label", required=True, help="Lowercase letters, numbers and hyphens")
    args = parser.parse_args()
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", args.date) or not re.fullmatch(r"[a-z0-9-]{1,40}", args.label):
        parser.error("Invalid checkpoint date or label")
    excluded = {".venv", ".mplconfig", "__pycache__", ".git"}
    manifest_path = ROOT/f"checkpoint_manifest-{args.date}-{args.label}.json"
    files = sorted(p for p in ROOT.rglob("*") if p.is_file()
                   and not excluded.intersection(p.relative_to(ROOT).parts) and p != manifest_path)
    manifest = {"date": args.date, "timezone": "Asia/Shanghai", "label": args.label,
                "files": {p.relative_to(ROOT).as_posix(): {"bytes": p.stat().st_size,
                           "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}}
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    files.append(manifest_path)
    destination = ROOT.parent/"checkpoints"
    destination.mkdir(exist_ok=True)
    base_name = f"traffic-recovery-lab-{args.date}-{args.label}"
    archive = destination/f"{base_name}.zip"
    suffix = 2
    while archive.exists():
        archive = destination/f"{base_name}-v{suffix}.zip"
        suffix += 1
    with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as packed:
        for path in files:
            packed.write(path, f"{ROOT.name}/{path.relative_to(ROOT).as_posix()}")
    with zipfile.ZipFile(archive) as packed:
        if packed.testzip() is not None:
            raise AssertionError("Archive CRC verification failed")
        for path, entry in manifest["files"].items():
            if hashlib.sha256(packed.read(f"{ROOT.name}/{path}")).hexdigest() != entry["sha256"]:
                raise AssertionError(f"Archive content differs: {path}")
    print(json.dumps({"archive": str(archive), "files": len(files), "bytes": archive.stat().st_size,
                      "integrity": "CRC + every archived SHA256 passed"}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
